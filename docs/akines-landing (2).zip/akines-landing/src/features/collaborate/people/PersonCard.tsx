'use client';

import { Button, Tag } from '@/ui';
import { asset } from '@/lib/assets';
import { IconBookmark } from './cc-ui';
import { personRoutes, type Person } from './data';

type Props = {
  person: Person;
  /** Saved variant: the Saved tag shows next to the availability. */
  saved?: boolean;
  saveLabel: string;
  onSave?: () => void;
  /** Saved collaborators list: no Not relevant link. */
  hideNotRelevant?: boolean;
  onNotRelevant?: () => void;
  onAsk?: () => void;
};

/**
 * Collaborator card of Discovery (B3) and Saved collaborators (B11).
 * Figma: Collaborator Card 680 wide, padding 28, gap 24. View profile and Request introduction open the profile and the request of the
 * person (Amina B5 and B9, Kunle, Funmi and Chidi 12.28 to 12.30). Not relevant and Ask Akines why open the overlays of that person
 * (the screen passes the handlers; the Saved list passes none for Ask Akines why, as in Figma).
 */
export function PersonCard({ person, saved, saveLabel, onSave, hideNotRelevant, onNotRelevant, onAsk }: Props) {
  const routes = personRoutes(person.id);
  return (
    <article className="cc-card" data-saved={saved || undefined} aria-labelledby={`cc-card-${person.id}`}>
      <div className="cc-card__top">
        <div className="cc-card__photo">
          {/* Figma portrait 188 x 228 (see data.ts for the node ids) */}
          <img src={asset(person.photo)} alt="" loading="lazy" decoding="async" width={188} height={228} />
        </div>
        <div className="cc-card__info">
          <div className="cc-card__avail">
            <span className="cc-card__avail-text">
              <span className="cc-dot" aria-hidden="true" />
              {person.availability}
            </span>
            {saved ? (
              <Tag className="cc-card__saved" icon={<IconBookmark size={12} />}>
                Saved
              </Tag>
            ) : null}
          </div>
          <h2 className="cc-card__name" id={`cc-card-${person.id}`}>
            {person.name}
          </h2>
          <p className="cc-card__role">{person.role}</p>
          <p className="cc-card__skills">{person.skills}</p>
          <p className="cc-card__intro">{person.intro}</p>
        </div>
      </div>

      <div className="cc-card__why">
        <p className="cc-cap">Why you may work well together</p>
        <p className="cc-card__compat">{person.compat}</p>
      </div>

      <div className="cc-card__facts">
        <div>
          <p className="cc-cap">Relevant experience</p>
          <p className="cc-card__fact">{person.experience}</p>
        </div>
        <div>
          <p className="cc-cap">Working preferences</p>
          <p className="cc-card__fact">{person.preference}</p>
        </div>
      </div>

      <div className="cc-card__actions">
        <div className="cc-card__primary">
          <Button href={routes.profile} arrow="up-right">
            View profile
          </Button>
          <Button variant="secondary" href={routes.request}>
            Request introduction
          </Button>
        </div>
        <div className="cc-card__secondary">
          <Button variant="link" onClick={onSave} aria-pressed={saved && !hideNotRelevant ? true : undefined}>
            {saveLabel}
          </Button>
          {hideNotRelevant ? null : (
            <Button variant="link" onClick={onNotRelevant}>
              Not relevant
            </Button>
          )}
          <Button variant="link" onClick={onAsk}>
            Ask Akines why
          </Button>
        </div>
      </div>
    </article>
  );
}
