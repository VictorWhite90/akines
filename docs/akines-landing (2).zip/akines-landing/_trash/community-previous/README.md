# Previous Community Home (moved out of the build)

The ten-band Home (Home.tsx, bands.tsx) and its Loading, Section error and Empty boards (States.tsx).
Replaced by the Community Home feed in src/features/community/feed. These files are not compiled:
tsconfig.json excludes `_trash`, and nothing under src imports them.
Their styles (`.cm-*` rules in src/features/community/community.css) were left in place.
Figma counterpart: TRASH page, section "V2 Desktop / 10 - COMMUNITY HOME (previous Home and its modals, moved out)".
