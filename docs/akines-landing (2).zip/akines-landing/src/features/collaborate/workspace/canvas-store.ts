// Studio page, removed 5 Nov 2026 (Tasks, Conversations, Files and Workspace cover it). Commented out, not deleted. Figma: parked on the TRASH page.
// To bring it back: remove the leading "// " of every commented line below.
export {};

// 'use client';
//
// import { useSyncExternalStore } from 'react';
// import type { CanvasItem } from './data';
// import type { ProjectKey } from './project';
//
// /**
//  * What the team adds to the shared canvas during a visit (Modal: Add to canvas). The cards are shown first on the canvas;
//  * "Undo" in the toast takes the card away again. Same pattern as workspace/store.ts. Kept per project, so a card added on
//  * Career Guidance for Everyone never shows on Adire Stories and the other way round.
//  */
// let added: Record<ProjectKey, CanvasItem[]> = { career: [], adire: [] };
// const listeners = new Set<() => void>();
// const emit = () => listeners.forEach((l) => l());
// const subscribe = (cb: () => void) => {
//   listeners.add(cb);
//   return () => {
//     listeners.delete(cb);
//   };
// };
//
// export const useAddedCanvas = (project: ProjectKey) => useSyncExternalStore(subscribe, () => added[project], () => added[project]);
//
// export const canvasStore = {
//   /** Newest first. */
//   add(project: ProjectKey, item: CanvasItem) {
//     added = { ...added, [project]: [item, ...added[project]] };
//     emit();
//   },
//   remove(project: ProjectKey, id: string) {
//     added = { ...added, [project]: added[project].filter((c) => c.id !== id) };
//     emit();
//   },
// };
