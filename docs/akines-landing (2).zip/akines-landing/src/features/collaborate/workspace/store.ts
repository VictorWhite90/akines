'use client';

import { useSyncExternalStore } from 'react';
import { DRAFTS, type DraftCard } from './data';
// Studio removed 5 Nov 2026: the studio work and the comments of the work detail went with it (see workspace/Studio.tsx).
// import { COMMENTS, type CommentEntry, type StudioWork } from './data';
// import { ART_STUDIO_WORK, CAREER_STUDIO } from './art-studio-data';
// import type { ProjectKey } from './project';

/**
 * Small shared store of the workspace screens: the drafts list (delete and undo) and the "list has loaded once" flag.
 * Lives for one visit (not across reloads), like useMemoState. Drafts belong to Career only.
 */
type State = {
  drafts: DraftCard[];
  // works: Record<ProjectKey, StudioWork[]>;
  // comments: CommentEntry[];
  listLoaded: boolean;
};

let state: State = { drafts: DRAFTS, listLoaded: false };
const listeners = new Set<() => void>();
const set = (patch: Partial<State>) => {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};

export function useWorkspace<T>(select: (s: State) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => select(state),
    () => select(state),
  );
}

export const workspace = {
  /** Removes a draft and returns it with its position so "Undo" can put it back where it was. */
  deleteDraft(id: string): { draft: DraftCard; index: number } | null {
    const index = state.drafts.findIndex((d) => d.id === id);
    if (index < 0) return null;
    const draft = state.drafts[index];
    set({ drafts: state.drafts.filter((d) => d.id !== id) });
    return { draft, index };
  },
  restoreDraft(draft: DraftCard, index: number) {
    if (state.drafts.some((d) => d.id === draft.id)) return;
    const next = [...state.drafts];
    next.splice(Math.min(index, next.length), 0, draft);
    set({ drafts: next });
  },
  // addWork, removeWork, addComment and removeComment belonged to the Studio page (commented out 5 Nov 2026).
  markListLoaded() {
    if (!state.listLoaded) set({ listLoaded: true });
  },
  get listLoaded() {
    return state.listLoaded;
  },
};
