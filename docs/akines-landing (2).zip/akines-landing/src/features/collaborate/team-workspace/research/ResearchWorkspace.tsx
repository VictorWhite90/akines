'use client';

/**
 * 12.15 Collaborate / Workspace (Research): the document workspace of a Research project, with its outline, the page, the comments
 * and every live state of the Figma file (saved, saving, collaborator offline, connection lost, reconnecting, view only, version
 * history) plus the comment reply thread. People and access, the project menu and the heading style menu are overlays.
 */
import { useEffect, useRef, useState } from 'react';
import {
  AlignCenter,
  AlignLeft,
  Bold,
  Check,
  ChevronDown,
  History,
  Italic,
  Link as LinkIcon,
  List,
  ListOrdered,
  MessageSquarePlus,
  Quote,
  Redo2,
  Table,
  Underline,
  Undo2,
} from 'lucide-react';
import { Link, useNav } from '@/lib/nav';
import { asset } from '@/lib/assets';
import { Button } from '@/ui';
import {
  Banner,
  Ic,
  Popover,
  VersionPanel,
  WorkspaceShell,
  bannerFor,
  type BannerHrefs,
  type PresenceItem,
  type SaveLinks,
  type TopBarLinks,
} from '../shared';
import { DEFAULT_VERSION, PEOPLE_ROWS, PEOPLE_SUMMARY, R_PATHS, VERSIONS, versionBannerTitle, type VersionRow, type WsState } from '../data';
import { DOC_TITLE, OUTLINE, PROJECT_NAME, STYLE_ITEMS, THREADS, type Thread, type ThreadState } from './content';
import './research.css';

/* ------------------------------------------------------------------ format toolbar */

type Mode = 'Editing' | 'Suggesting' | 'Viewing';

function Tool({ label, icon, dim }: { label: string; icon: Parameters<typeof Ic>[0]['icon']; dim: boolean }) {
  return (
    <button type="button" className="tr-tool" aria-label={label} disabled={dim}>
      <Ic icon={icon} size={20} />
    </button>
  );
}

function FormatToolbar({ viewOnly, mode, onMode, styleOpen, onStyle }: { viewOnly: boolean; mode: Mode; onMode: (m: Mode) => void; styleOpen: boolean; onStyle: () => void }) {
  return (
    <div className="tr-bar" role="toolbar" aria-label="Formatting" data-view={viewOnly || undefined}>
      <div className="tr-bar__group">
        <Tool label="Undo" icon={Undo2} dim={viewOnly} />
        <Tool label="Redo" icon={Redo2} dim={viewOnly} />
      </div>
      <i className="tr-bar__rule" />
      <button type="button" className="tr-style" onClick={onStyle} aria-haspopup="menu" aria-expanded={styleOpen} disabled={viewOnly} aria-label="Text style: Heading 2">
        <span>Heading 2</span>
        <Ic icon={ChevronDown} />
      </button>
      <i className="tr-bar__rule" />
      <div className="tr-bar__group">
        <Tool label="Bold" icon={Bold} dim={viewOnly} />
        <Tool label="Italic" icon={Italic} dim={viewOnly} />
        <Tool label="Underline" icon={Underline} dim={viewOnly} />
        <Tool label="Link" icon={LinkIcon} dim={viewOnly} />
      </div>
      <i className="tr-bar__rule" />
      <div className="tr-bar__group">
        <Tool label="Bulleted list" icon={List} dim={viewOnly} />
        <Tool label="Numbered list" icon={ListOrdered} dim={viewOnly} />
        <Tool label="Align left" icon={AlignLeft} dim={viewOnly} />
        <Tool label="Align centre" icon={AlignCenter} dim={viewOnly} />
      </div>
      <i className="tr-bar__rule" />
      <div className="tr-bar__group">
        <Tool label="Table" icon={Table} dim={viewOnly} />
        <Tool label="Quote" icon={Quote} dim={viewOnly} />
        <Tool label="Comment" icon={MessageSquarePlus} dim={false} />
      </div>
      <span className="tr-bar__spacer" />
      <div className="tr-mode" role="radiogroup" aria-label="Mode">
        {(['Editing', 'Suggesting', 'Viewing'] as Mode[]).map((m) => (
          <button key={m} type="button" role="radio" aria-checked={mode === m} className="tr-mode__item" data-on={mode === m || undefined} onClick={() => onMode(m)}>
            {m}
          </button>
        ))}
      </div>
    </div>
  );
}

/** Figma "Style menu": opens under the style select and closes on a click outside. */
function StyleMenu({ onClose }: { onClose: () => void }) {
  return (
    <Popover onClose={onClose} label="Text style" className="tr-pop--style">
      <ul className="tr-styles" role="menu">
        {STYLE_ITEMS.map((s) => (
          <li key={s.id} role="none">
            <button type="button" role="menuitemradio" aria-checked={s.selected || false} className="tr-styles__item" data-style={s.id} data-on={s.selected || undefined} onClick={onClose}>
              <span>{s.label}</span>
              {s.selected ? <Ic icon={Check} /> : null}
            </button>
          </li>
        ))}
      </ul>
    </Popover>
  );
}

/* ------------------------------------------------------------------ outline */

function Outline({ versionHref }: { versionHref?: string }) {
  const [active, setActive] = useState('Executive summary');
  const footer = (
    <>
      <Ic icon={History} size={18} />
      <span>Version history</span>
    </>
  );
  return (
    <nav className="tr-outline" aria-label="Outline">
      <p className="tr-outline__head">OUTLINE</p>
      <ul className="tr-outline__list">
        {OUTLINE.map((o) => (
          <li key={o.label}>
            <button type="button" className="tr-outline__item" data-level={o.level} aria-current={active === o.label ? 'location' : undefined} onClick={() => setActive(o.label)}>
              {o.label}
            </button>
          </li>
        ))}
      </ul>
      <div className="tr-outline__foot">
        {versionHref ? (
          <Link href={versionHref} className="tr-outline__link">
            {footer}
          </Link>
        ) : (
          <span className="tr-outline__link" aria-current="page">
            {footer}
          </span>
        )}
      </div>
    </nav>
  );
}

/* ------------------------------------------------------------------ document */

const Cursor = ({ name }: { name: string }) => (
  <span className="tr-cursor" aria-hidden="true">
    <span className="tr-cursor__tag">{name}</span>
    <span className="tr-cursor__caret" />
  </span>
);

function DocPage({ offline, hideCaret }: { offline: boolean; hideCaret: boolean }) {
  return (
    <article className="tr-page" data-offline={offline || undefined}>
      <h2 className="tr-page__title">{DOC_TITLE}</h2>
      <p className="tr-page__meta">Draft 3, last edited today at 10:42</p>

      <h3 className="tr-h2">Executive summary</h3>
      <p className="tr-p tr-p--first">
        <span className="tr-line">
          This report looks at how secondary school students in <mark className="tr-mark tr-mark--amara">three states</mark> find
        </span>
        <span className="tr-line">and use career guidance. It draws on a survey of 1,240 students and</span>
        <span className="tr-line">
          interviews with 36 teachers and parents.
          {hideCaret ? null : <span className="tr-caret" aria-hidden="true" />}
        </span>
      </p>
      <p className="tr-p tr-p--second">
        <span className="tr-line">
          <mark className="tr-mark tr-mark--ayo">Only 41% of students had met a career counsellor,</mark> and most said the first
        </span>
        <span className="tr-line">time was in their final year. Students with a mentor outside school were</span>
        <span className="tr-line">twice as likely to name a clear next step.</span>
      </p>

      <h3 className="tr-h2">Findings</h3>
      <p className="tr-p tr-p--first">
        <span className="tr-line">
          1. Access is uneven. <span className="tr-sel">Urban schools were four times more likely</span>
          <Cursor name="Amara" /> to host a
        </span>
        <span className="tr-line tr-line--cont">career day than rural schools.</span>
      </p>
      <p className="tr-p tr-p--item">
        <span className="tr-line">2. Timing matters. Guidance offered before Year 10 changed subject choices,</span>
        <span className="tr-line tr-line--cont">not just university plans.</span>
      </p>
      <p className="tr-p tr-p--item">
        <span className="tr-line">3. Parents want a voice. Most asked for a simple way to join sessions.</span>
      </p>

      <h3 className="tr-h2">Recommendations</h3>
      <p className="tr-p tr-p--first">
        <span className="tr-line">Start guidance earlier, pair every school with a volunteer mentor, and give</span>
        <span className="tr-line">parents a short, plain-language summary after each session.</span>
      </p>
    </article>
  );
}

/* ------------------------------------------------------------------ comments */

const Avatar28 = ({ who }: { who: 'ayo' | 'amara' | 'kemi' }) =>
  who === 'kemi' ? (
    <span className="tr-c28 tr-c28--kemi" aria-hidden="true">
      KA
    </span>
  ) : (
    // eslint-disable-next-line @next/next/no-img-element
    <img className="tr-c28" src={asset(`/images/app/workspace/${who}.jpg`)} alt="" loading="lazy" decoding="async" />
  );

function ThreadCard({ thread, state, active, onState, onPick }: { thread: Thread; state: ThreadState; active: boolean; onState: (s: ThreadState, reply?: string) => void; onPick: () => void }) {
  const field = useRef<HTMLTextAreaElement>(null);
  const [text, setText] = useState('');
  // the field takes focus when the person presses Reply, not when the screen opens already in the reply state (Figma 12.15 comment reply)
  const before = useRef(state);
  useEffect(() => {
    if (before.current !== 'replying' && state === 'replying') field.current?.focus({ preventScroll: true });
    before.current = state;
  }, [state]);
  return (
    <section className="tr-thread" data-state={state} data-active={active || state === 'replying' || undefined} aria-label={`Comment thread on "${thread.quote}"`} onClick={onPick}>
      <div className="tr-thread__quote">
        <i className="tr-thread__bar" />
        <p>{thread.quote}</p>
      </div>
      <div className="tr-thread__msgs">
        {thread.messages.map((m, i) => (
          <div className="tr-msg" key={i}>
            <Avatar28 who={m.who} />
            <div className="tr-msg__body">
              <p className="tr-msg__head">
                <b>{m.name}</b>
                <span>{m.time}</span>
              </p>
              <p className="tr-msg__text">{m.text}</p>
            </div>
          </div>
        ))}
      </div>
      {state === 'open' ? (
        <div className="tr-thread__actions">
          <Button variant="ghost" size="sm" onClick={() => onState('replying')}>
            Reply
          </Button>
          <Button variant="secondary" size="sm" onClick={() => onState('resolved')}>
            Resolve
          </Button>
        </div>
      ) : null}
      {state === 'replying' ? (
        <>
          <textarea ref={field} className="tr-thread__field" rows={1} value={text} onChange={(e) => setText(e.target.value)} placeholder="Write a reply" aria-label="Write a reply" />
          <div className="tr-thread__actions tr-thread__actions--end">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setText('');
                onState('open');
              }}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                const t = text.trim();
                setText('');
                onState('open', t || undefined);
              }}
            >
              Reply
            </Button>
          </div>
        </>
      ) : null}
      {state === 'resolved' ? (
        <div className="tr-thread__actions tr-thread__actions--between">
          <span className="tr-thread__done">
            <Ic icon={Check} />
            <span>Resolved by Kemi</span>
          </span>
          <Button variant="ghost" size="sm" onClick={() => onState('open')}>
            Reopen
          </Button>
        </div>
      ) : null}
    </section>
  );
}

function CommentsPanel({ initialReply }: { initialReply: boolean }) {
  const [threads, setThreads] = useState<Thread[]>(THREADS);
  const [states, setStates] = useState<Record<string, ThreadState>>({ ayo: initialReply ? 'replying' : 'open', amara: 'open' });
  const [active, setActive] = useState('ayo');
  const open = Object.values(states).filter((s) => s !== 'resolved').length;
  const resolved = 1 + Object.values(states).filter((s) => s === 'resolved').length;
  const set = (id: string, s: ThreadState, reply?: string) => {
    setActive(id);
    setStates((p) => ({ ...p, [id]: s }));
    if (reply) setThreads((p) => p.map((t) => (t.id === id ? { ...t, messages: [...t.messages, { who: 'kemi', name: 'Kemi Adeyemi', time: 'Now', text: reply }] } : t)));
  };
  return (
    <div className="tr-comments">
      <header className="tr-comments__head">
        <h2>Comments</h2>
        <p>{`${open} open, ${resolved} resolved`}</p>
      </header>
      <div className="tr-filters" role="group" aria-label="Filter comments">
        <button type="button" className="tr-filter" data-on>
          Open
        </button>
        <button type="button" className="tr-filter">
          Resolved
        </button>
        <button type="button" className="tr-filter">
          Mine
        </button>
      </div>
      {threads.map((t) => (
        <ThreadCard key={t.id} thread={t} state={states[t.id]} active={active === t.id} onState={(s, r) => set(t.id, s, r)} onPick={() => setActive(t.id)} />
      ))}
      <p className="tr-comments__resolved">
        <Ic icon={Check} />
        <span>{resolved === 1 ? '1 resolved comment' : `${resolved} resolved comments`}</span>
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ screen */

const BANNER_HREFS: BannerHrefs = { retry: R_PATHS.reconnecting, back: R_PATHS.main, restore: R_PATHS.main };
/** Save status popover: Save now shows the Saving screen, Version history opens it, Try again goes back to the workspace. */
const SAVE_LINKS: SaveLinks = { saveNow: R_PATHS.saving, history: R_PATHS.versionHistory, retry: R_PATHS.main };

export function ResearchWorkspace({ state = 'saved', initialReply = false }: { state?: WsState; initialReply?: boolean }) {
  const nav = useNav();
  const [mode, setMode] = useState<Mode>(state === 'viewOnly' ? 'Viewing' : 'Editing');
  const [styleOpen, setStyleOpen] = useState(false);
  const [saved, setSaved] = useState(false);
  // the save status popover under the status pill; the Saving and Reconnecting screens wait while it is open
  const [saveOpen, setSaveOpen] = useState(false);
  const [version, setVersion] = useState<VersionRow>(VERSIONS.find((v) => v.id === DEFAULT_VERSION)!);

  // Figma: Saving turns into "All changes saved" after 1.5 s and returns to the workspace after 2 s; Reconnecting returns after 3 s.
  // A popover that is open holds them (the Saving screen goes on from the start when it closes).
  useEffect(() => {
    if (saveOpen) return;
    if (state === 'saving') {
      const a = window.setTimeout(() => setSaved(true), 1500);
      const b = window.setTimeout(() => nav.replace(R_PATHS.main), 2000);
      return () => {
        window.clearTimeout(a);
        window.clearTimeout(b);
      };
    }
    if (state === 'reconnecting') {
      const c = window.setTimeout(() => nav.replace(R_PATHS.main), 3000);
      return () => window.clearTimeout(c);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state, saveOpen]);

  const shown: WsState = state === 'saving' && saved ? 'saved' : state;
  const offline = state === 'collaboratorOffline';
  const viewOnly = state === 'viewOnly';
  const preview = state === 'versionHistory';
  const kind = bannerFor(state);

  const avatars: PresenceItem[] = [
    { id: 'kemi', state: 'editing' },
    { id: 'amara', state: offline ? 'offline' : 'editing' },
    { id: 'ayo', state: 'viewing' },
  ];
  const links: TopBarLinks = {
    history: preview ? R_PATHS.main : R_PATHS.versionHistory,
    comments: state === 'saved' ? undefined : R_PATHS.main,
  };

  return (
    <WorkspaceShell
      kind="research"
      state={shown}
      title={DOC_TITLE}
      project={PROJECT_NAME}
      avatars={avatars}
      more="+1"
      links={links}
      saveMenu={initialReply ? undefined : { links: SAVE_LINKS, initialOpen: state === 'couldNotSave' }}
      onSaveOpenChange={setSaveOpen}
      peopleRows={PEOPLE_ROWS}
      peopleSummary={PEOPLE_SUMMARY}
      overlays={styleOpen ? <StyleMenu onClose={() => setStyleOpen(false)} /> : null}
    >
      <FormatToolbar viewOnly={viewOnly} mode={mode} onMode={setMode} styleOpen={styleOpen} onStyle={() => setStyleOpen((v) => !v)} />
      <div className="tr-body">
        <Outline versionHref={preview ? undefined : R_PATHS.versionHistory} />
        <div className="tr-stage">
          {kind ? <Banner kind={kind} hrefs={BANNER_HREFS} title={preview ? versionBannerTitle(version.time) : undefined} /> : null}
          <main className="tr-canvas" id="main" tabIndex={-1}>
            <DocPage offline={offline} hideCaret={viewOnly} />
          </main>
        </div>
        <aside className="tr-side" aria-label={preview ? 'Version history' : 'Comments'}>
          {preview ? <VersionPanel versions={VERSIONS} selected={version.id} onSelect={setVersion} /> : <CommentsPanel initialReply={initialReply} />}
        </aside>
      </div>
    </WorkspaceShell>
  );
}

