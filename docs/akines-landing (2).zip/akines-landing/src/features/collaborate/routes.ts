import type { RouteDef } from '@/routes.types';
import { routes as start } from './start/routes';
import { routes as people } from './people/routes';
import { routes as projects } from './projects/routes';
import { routes as workspace } from './workspace/routes';
import { routes as teamWorkspace } from './team-workspace/routes';
import { routes as tasks } from './tasks/routes';
import { routes as files } from './files/routes';
import { routes as decisions } from './decisions/routes';
import { routes as projectTeam } from './project-team/routes';
import { routes as agreements } from './agreements/routes';
import { routes as applications } from './applications/routes';
import { routes as applicants } from './applicants/routes';
import { routes as overviewLists } from './overview-lists/routes';
// Reflection and Launch removed 5 Nov 2026 (files in _trash, see _trash/PARKED-reflection-and-launch.md):
// import { routes as reflection } from './reflection/routes';
// import { routes as launch } from './launch/routes';
import { routes as projectHeader } from './project-header/routes';
import { routes as opportunities } from './opportunities/routes';
import { routes as meetings, artRoutes as artMeetings } from './meetings/routes';
import { artRoutes as artOverview } from './workspace/art-routes';
// Studio removed 5 Nov 2026: import { artRoutes as artStudio } from './workspace/art-studio-routes';
import { artRoutes as artConversations } from './workspace/conversations/art-routes';
import { artRoutes as artTasks } from './tasks/art-routes';
import { artRoutes as artFiles } from './files/art-routes';
import { artRoutes as artDecisions } from './decisions/art-routes';
import { artRoutes as artTeam } from './project-team/art-routes';
import { artRoutes as artAgreements } from './agreements/art-routes';
// import { artRoutes as artReflection } from './reflection/art-routes';
// import { artRoutes as artLaunch } from './launch/art-routes';
import { placeholderRoutes } from '@/features/placeholder-routes';

/** The project pages of Adire Stories (the Digital Art project): Meetings, Overview, Conversations, Tasks, Files, Decisions, Team and Agreements (Reflection and Launch removed 5 Nov 2026). Its Workspace is in team-workspace. */
const adireStories = [...artMeetings, ...artOverview, ...artConversations, ...artTasks, ...artFiles, ...artDecisions, ...artTeam, ...artAgreements];

const designed = [...start, ...people, ...projects, ...workspace, ...teamWorkspace, ...tasks, ...files, ...decisions, ...projectTeam, ...agreements, ...applications, ...applicants, ...overviewLists, ...projectHeader, ...opportunities, ...meetings, ...adireStories];
const taken = designed.map((r) => r.path);

/** Tabs of the Collaborate sub row that have no design yet (Opportunities, My Contributions) fall back to the placeholder page. */
export const routes: RouteDef[] = [...designed, ...placeholderRoutes('collaborate', taken)];
