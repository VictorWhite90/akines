import { ART_PATH, useProject } from '../project';
import { CAREER_CONVERSATIONS, EMPTY, STARTED_TOAST, type ConversationsData } from './data';

/**
 * The Conversations page of Adire Stories (Figma 17759:89576): same type, keys, array lengths and order as the Career Guidance for
 * Everyone data (data.ts), Adire copy. Only the Conversations page is mirrored, so a row or link whose Career target is a drill down
 * page (the decision discussion, the decision detail) has no `href` here and does nothing. The decision thread is kept for the shape;
 * no Adire route shows it.
 */

const DECISION_CARD = { title: 'Choose the headwrap palette', status: 'Awaiting acknowledgement' };

export const ART_CONVERSATIONS: ConversationsData = {
  conversations: [
    { id: 'onboarding', name: 'Headwrap colours', time: '10:48', href: `${ART_PATH}/conversations` },
    { id: 'team', name: 'Adire Stories team', time: '09:15' },
    { id: 'decision', name: 'Choose the headwrap palette', time: 'Yesterday', unread: true },
    { id: 'milestone', name: 'Headwrap Portrait', time: 'Yesterday', unread: true },
    { id: 'questions', name: 'Questions to ask the dyers about cloth', time: 'Mon' },
  ],
  threads: {
    onboarding: {
      id: 'onboarding',
      title: 'Headwrap colours',
      kind: 'Work discussion',
      line: '4 people, linked to the headwrap colour layer',
      date: 'Today',
      join: true,
      messages: [
        { id: 'm1', initials: 'YD', name: 'Yusuf Danjuma', time: '10:30', text: 'These are the dye pot notes behind the shades.', file: { name: 'Adire dye pot notes.docx', meta: 'Word, 180 KB' } },
        { id: 'm2', initials: 'AO', name: 'Amara Obi', time: '10:48', text: 'We should settle the palette before colouring more areas.', decision: DECISION_CARD },
        { id: 'm3', initials: 'KA', name: 'You', time: '11:02', text: 'Agreed. I will review the decision today.', own: true },
        { id: 'm4', initials: 'AB', name: 'Ayo Bello', time: '11:20', text: 'Let us talk it through on Thursday.' },
      ],
    },
    decision: {
      id: 'decision',
      title: 'Choose the headwrap palette',
      kind: 'Decision discussion',
      line: '4 people, decision awaiting acknowledgement',
      date: 'Yesterday',
      messages: [
        { id: 'd1', initials: 'AB', name: 'Ayo Bello', time: '15:10', text: 'The brighter option may overpower the indigo cloth.' },
        { id: 'd2', initials: 'YD', name: 'Yusuf Danjuma', time: '16:30', text: 'Agreed. Most of the cloth in our references keeps to one deep blue.' },
        { id: 'd3', initials: 'AO', name: 'Amara Obi', time: '17:40', text: 'I prefer the deeper indigo. Can we decide before Friday?', decision: DECISION_CARD },
      ],
    },
  },
  linkedWork: { title: 'Review the headwrap colour layer', status: 'Needs your review' },
  sharedFiles: [
    { name: 'Headwrap colour layer.pdf', meta: 'PDF, 2.4 MB' },
    { name: 'Adire dye pot notes.docx', meta: 'Word, 180 KB' },
  ],
  empty: EMPTY,
  startedToast: STARTED_TOAST,
  startPlaceholder: 'For example, Headwrap colours',
};

/** The Conversations data of the project of the page being shown. */
export function useConversationsData(): ConversationsData {
  return useProject().key === 'adire' ? ART_CONVERSATIONS : CAREER_CONVERSATIONS;
}
