import type { RouteDef } from '@/routes.types';
import { AP } from './data';
import {
  AgreementsAcknowledgeModal,
  AgreementsAcknowledged,
  AgreementsAcknowledgedToast,
  AgreementsCreateModal,
  AgreementsCreated,
  AgreementsEmpty,
  AgreementsFormal,
  AgreementsOverview,
  AgreementsRoles,
  AgreementsSuggestModal,
  AgreementsSuggested,
} from './Agreements';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * Agreements 12.22: Agreements, Empty, Stage detail (Roles), Formal agreement and Acknowledged, with the three modals and three toasts.
 * The "state-" routes are the Figma frames that have no natural trigger in the prototype: the empty overview, the Acknowledged page
 * (it opens from the Acknowledge modal, which is its own route here too) and every overlay frame, which is the page that opens
 * the overlay with the modal or the toast showing.
 */
export const routes: RouteDef[] = [
  { path: AP.overview, title: 'Agreements', shell: 'app', nav, component: AgreementsOverview },
  { path: AP.empty, title: 'Agreements', shell: 'app', nav, component: AgreementsEmpty },
  { path: AP.roles, title: 'Roles', shell: 'app', nav, component: AgreementsRoles },
  { path: AP.formal, title: 'Formal Agreement', shell: 'app', nav, component: AgreementsFormal },
  { path: AP.acknowledged, title: 'Roles', shell: 'app', nav, component: AgreementsAcknowledged },

  { path: AP.createModal, title: 'Agreements', shell: 'app', nav, component: AgreementsCreateModal },
  { path: AP.created, title: 'Agreements', shell: 'app', nav, component: AgreementsCreated },
  { path: AP.suggestModal, title: 'Roles', shell: 'app', nav, component: AgreementsSuggestModal },
  { path: AP.suggested, title: 'Roles', shell: 'app', nav, component: AgreementsSuggested },
  { path: AP.acknowledgeModal, title: 'Roles', shell: 'app', nav, component: AgreementsAcknowledgeModal },
  { path: AP.acknowledgedToast, title: 'Roles', shell: 'app', nav, component: AgreementsAcknowledgedToast },
];
