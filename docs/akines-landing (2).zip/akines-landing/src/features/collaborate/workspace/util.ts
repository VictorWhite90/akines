/** Joins class names, skipping the falsy ones. Lives apart from parts.tsx so shared pieces (dash.tsx, rail.tsx) can use it without importing the frame. */
export const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(' ');

/** Scrolls to a card of the same page by id (the metric cards of the dashboard pages). The pinned headers are cleared by scroll-margin-top in dash.css. */
export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
}
