'use client';

/**
 * Constant hero of the feed: a full width carousel of vertical portrait cards (Banters, Live rooms, Games, Activities).
 * It steps one card to the left every HERO.interval (5 s) and returns to the first card after the last. The reader can
 * also scroll it sideways at any time (touch, trackpad, shift + wheel, or by dragging with the mouse).
 * Autoplay waits while the pointer is over the carousel, while a card has focus, while the reader is scrolling or pressing,
 * and while the tab is hidden; it never runs with reduced motion. Layout: feed.css, "Hero".
 */
import { useEffect, useRef } from 'react';
import { Link } from '@/lib/nav';
import { HERO, HERO_CARDS, type HeroCardData } from './content';
import { src } from './images';

/** Cards that are in view on a wide screen load at once; the rest load when the reader gets near them. */
const EAGER = 5;
/** Distance in px a mouse has to travel before a press becomes a drag (below it the press is a click on the card). */
const DRAG_START = 6;

export function Hero() {
  const track = useRef<HTMLUListElement>(null);

  useEffect(() => {
    const el = track.current;
    if (!el) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    let timer: number | undefined;
    let lockUntil = 0; // scroll events before this moment come from our own smooth scroll, not from the reader
    let held = false; // pointer over the carousel (mouse), pointer pressed, or focus inside
    let overMouse = false;
    let pressed = false;
    let focused = false;
    let drag: { x: number; left: number; id: number; moved: boolean } | null = null;
    let swallowClick = false;

    const items = () => Array.from(el.children) as HTMLElement[];
    const pad = () => parseFloat(getComputedStyle(el).paddingLeft) || 0;
    const refreshHeld = () => {
      held = overMouse || pressed || focused;
    };

    const schedule = () => {
      window.clearTimeout(timer);
      if (reduce.matches) return;
      timer = window.setTimeout(step, HERO.interval);
    };

    /** One card forward: the next card whose left edge is still to the right of the current position. After the last card, back to the start. */
    function step() {
      if (held || document.hidden || reduce.matches) {
        schedule();
        return;
      }
      const max = el!.scrollWidth - el!.clientWidth;
      const left = el!.scrollLeft;
      let to = 0;
      if (left < max - 2) {
        const start = pad();
        const next = items().find((c) => c.offsetLeft - start > left + 2);
        to = next ? Math.min(next.offsetLeft - start, max) : 0;
      }
      lockUntil = performance.now() + 1100;
      el!.scrollTo({ left: to, behavior: 'smooth' });
      schedule();
    }

    const onScroll = () => {
      if (performance.now() > lockUntil) schedule(); // the reader is scrolling: wait a full interval after the last movement
    };
    const onEnter = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse') return;
      overMouse = true;
      refreshHeld();
    };
    const onLeave = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse') return;
      overMouse = false;
      refreshHeld();
      schedule();
    };
    const onDown = (e: PointerEvent) => {
      pressed = true;
      refreshHeld();
      if (e.pointerType === 'mouse' && e.button === 0) drag = { x: e.clientX, left: el.scrollLeft, id: e.pointerId, moved: false };
    };
    const onMove = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dx = e.clientX - drag.x;
      if (!drag.moved && Math.abs(dx) > DRAG_START) {
        drag.moved = true;
        el.setPointerCapture(e.pointerId);
        el.classList.add('is-dragging');
      }
      if (drag.moved) el.scrollLeft = drag.left - dx;
    };
    const onUp = () => {
      pressed = false;
      refreshHeld();
      if (drag?.moved) {
        swallowClick = true;
        window.setTimeout(() => (swallowClick = false), 0);
      }
      drag = null;
      el.classList.remove('is-dragging');
      schedule();
    };
    const onClick = (e: MouseEvent) => {
      if (!swallowClick) return;
      e.preventDefault();
      e.stopPropagation();
    };
    const onFocusIn = () => {
      focused = true;
      refreshHeld();
    };
    const onFocusOut = () => {
      focused = false;
      refreshHeld();
      schedule();
    };
    const onVisible = () => {
      if (!document.hidden) schedule();
    };

    el.addEventListener('scroll', onScroll, { passive: true });
    el.addEventListener('pointerenter', onEnter);
    el.addEventListener('pointerleave', onLeave);
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
    el.addEventListener('click', onClick, true);
    el.addEventListener('focusin', onFocusIn);
    el.addEventListener('focusout', onFocusOut);
    document.addEventListener('visibilitychange', onVisible);
    reduce.addEventListener('change', schedule);
    schedule();
    return () => {
      window.clearTimeout(timer);
      el.removeEventListener('scroll', onScroll);
      el.removeEventListener('pointerenter', onEnter);
      el.removeEventListener('pointerleave', onLeave);
      el.removeEventListener('pointerdown', onDown);
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerup', onUp);
      el.removeEventListener('pointercancel', onUp);
      el.removeEventListener('click', onClick, true);
      el.removeEventListener('focusin', onFocusIn);
      el.removeEventListener('focusout', onFocusOut);
      document.removeEventListener('visibilitychange', onVisible);
      reduce.removeEventListener('change', schedule);
    };
  }, []);

  return (
    <section className="fd-hero" aria-roledescription="carousel" aria-label={HERO.label}>
      <h1 className="sr-only">{HERO.heading}</h1>
      <ul className="fd-hero__track" ref={track}>
        {HERO_CARDS.map((c, i) => (
          <li key={c.id} className="fd-hero__item" style={{ ['--i' as string]: i }}>
            <HeroCard card={c} eager={i < EAGER} />
          </li>
        ))}
      </ul>
    </section>
  );
}

function HeroCard({ card, eager }: { card: HeroCardData; eager: boolean }) {
  return (
    <Link className="fd-hcard" data-kind={card.kind} href={card.href} draggable={false}>
      <span className="fd-hcard__photo">
        <img className="cover" src={src(card.image)} alt="" loading={eager ? 'eager' : 'lazy'} decoding="async" draggable={false} />
        <span className="fd-hcard__tag">
          {card.kind === 'live' ? <span className="fd-hcard__dot" aria-hidden="true" /> : null}
          {card.tag}
        </span>
      </span>
      <span className="fd-hcard__text">
        <span className="fd-hcard__title">{card.title}</span>
        <span className="fd-hcard__meta">{card.meta}</span>
      </span>
      <span className="fd-hcard__rule" aria-hidden="true" />
    </Link>
  );
}
