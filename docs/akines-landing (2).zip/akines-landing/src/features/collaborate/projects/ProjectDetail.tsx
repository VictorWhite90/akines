'use client';

/**
 * 12.6 Project detail (Figma 17321:20075) and its states: D2 Loading (17321:32078), D2 Could not load (17321:32238), D2 No longer open (17321:32264).
 * It is also 12.8 "Project detail (interest sent)" (17328:22708) and Modal:Withdraw interest (17328:22980) with Toast:Interest withdrawn (17332:22825):
 * once interest was sent for the project, the side panel shows the request and a Withdraw interest button.
 */
import { useEffect, useState } from 'react';
import { Button, Modal } from '@/ui';
import { Link, useNav } from '@/lib/nav';
import { LOADING_MS, isDetailSaved, takeFirstVisit, toggleSaved, useInterestState, useSavedState } from './store';
import { DESIGNED_SLUG, ownerFirst, projectBySlug, type Project } from './data';
import { DetailItem, FactList, FactRow, GlancePanel, InterestPanel, MatchBox, PrivacyPanel, Section, SentPanel, SkelSection, SkelSidePanels, TagList, TeamMember, glanceRows } from './parts';
import { Bar, BackLink, IconBookmark, StageLine, StatePanel } from './ui';
import { REQUEST_BASE } from '../applications/paths';
import { useQueuedToast, withdrawRequest } from '../applications/store';

export type DetailVariant = 'loading' | 'error' | 'closed' | 'sent';
type Phase = 'loading' | 'ready' | 'error';

/* ------------------------------------------------------------------ skeleton (Detail Skeleton 17320:13584) */

/** Also the body of the Loading frame of the application status (12.44, Figma 17974:162360). */
export function DetailSkeleton({ label = 'Loading the project' }: { label?: string }) {
  return (
    <div className="dsc-page">
      <div className="dsc-detail" aria-busy="true" aria-label={label}>
        <div className="dsc-detail__main" aria-hidden="true">
          <Bar w={170} h={14} />
          <span className="dsc-spacer" style={{ height: 36 }} />
          <div className="dsc-skel-header">
            <Bar w={220} h={12} />
            <Bar w={560} h={56} />
            <div className="dsc-skel-header__lead">
              <Bar w="93%" h={18} />
              <Bar w={600} h={18} />
            </div>
            <div className="dsc-skel-chips">
              {[0, 1, 2, 3].map((i) => (
                <Bar key={i} w={110} h={36} r={999} />
              ))}
            </div>
          </div>
          <SkelSection>
            <Bar w={140} h={12} />
            <Bar w="100%" h={16} />
            <Bar w="100%" h={16} />
            <Bar w={640} h={16} />
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            {[0, 1, 2].map((i) => (
              <div className="dsc-skel-item" key={i}>
                <Bar w={300} h={22} />
                <Bar w={440} h={14} />
              </div>
            ))}
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            <div className="dsc-skel-chips">
              {[0, 1, 2, 3].map((i) => (
                <Bar key={i} w={120} h={36} r={999} />
              ))}
            </div>
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            {[0, 1].map((i) => (
              <div className="dsc-skel-member" key={i}>
                <Bar w={44} h={44} r={22} />
                <div className="dsc-skel-member__text">
                  <Bar w={140} h={14} />
                  <Bar w={100} h={12} />
                </div>
              </div>
            ))}
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            {[0, 1, 2, 3].map((i) => (
              <div className="dsc-skel-row" key={i}>
                <Bar w={208} h={14} />
                <Bar w={400} h={16} />
              </div>
            ))}
          </SkelSection>
        </div>
        <SkelSidePanels rows />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ states without the page */

function StateHeader({ project }: { project: Project }) {
  return (
    <div className="dsc-summary-head">
      <StageLine stage={project.stage} type={project.type} />
      <h1 className="dsc-h1 dsc-h1--detail">{project.title}</h1>
    </div>
  );
}

/* ------------------------------------------------------------------ Modal:Withdraw interest (17328:22980) */

/** Withdraw interest modal, shared by the project detail and the Pending page of the application status (12.44). */
export function WithdrawInterestModal({ open, onClose, onWithdraw, owner }: { open: boolean; onClose: () => void; onWithdraw: () => void; owner: string }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="dsc-modal dsc-modal--withdraw"
      eyebrow="Withdraw interest"
      title="Withdraw your interest?"
      description={`${owner} will no longer see your request. You can send interest again later.`}
      footer={
        <div className="dsc-modal__actions dsc-modal__actions--wide">
          <Button onClick={onWithdraw}>Withdraw interest</Button>
          <button type="button" className="dsc-link" onClick={onClose}>
            <span className="dsc-link__label">Keep my interest</span>
          </button>
        </div>
      }
    >
      {null}
    </Modal>
  );
}

/* ------------------------------------------------------------------ screen */

export function ProjectDetailScreen({ slug, variant }: { slug: string; variant?: DetailVariant }) {
  const project = projectBySlug(slug)!;
  const nav = useNav();
  const savedState = useSavedState();
  const interests = useInterestState();
  const interest = interests[slug];
  const saved = isDetailSaved(savedState, slug);
  const [phase, setPhase] = useState<Phase>(() => (variant === 'loading' ? 'loading' : variant === 'error' ? 'error' : takeFirstVisit('detail') ? 'loading' : 'ready'));
  const [forcedSent, setForcedSent] = useState(variant === 'sent');
  const [withdrawOpen, setWithdrawOpen] = useState(false);

  useEffect(() => {
    if (phase !== 'loading') return;
    const t = window.setTimeout(() => {
      if (variant === 'loading') nav.replace(`/collaborate/projects/${slug}`);
      else setPhase('ready');
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, variant, slug]);
  // the Interest withdrawn toast of the request page shows here once the project is on screen
  useQueuedToast(phase === 'ready');

  if (phase === 'loading') return <DetailSkeleton />;

  /* D2 Could not load */
  if (phase === 'error') {
    return (
      <div className="dsc-page">
        <div className="dsc-stack">
          <BackLink href="/collaborate/discover">Back to discover projects</BackLink>
          <StatePanel pair role="alert" headline="We could not load this project." support="Check your connection and try again. Your saved projects are safe.">
            <Button onClick={() => setPhase('loading')}>Try again</Button>
            <Button variant="secondary" href="/collaborate/discover">
              Back to discover projects
            </Button>
          </StatePanel>
        </div>
      </div>
    );
  }

  /* D2 No longer open */
  if (variant === 'closed' || project.closed) {
    return (
      <div className="dsc-page">
        <div className="dsc-stack">
          <BackLink href="/collaborate/discover">Back to discover projects</BackLink>
          <StateHeader project={project} />
          <StatePanel
            pair
            headline="This project is not looking for people right now."
            support="The owner has paused new collaborators. You can save it and check back later, or look at other projects."
          >
            <Button href="/collaborate/discover">Back to discover projects</Button>
            <Button variant="secondary" className="dsc-savebtn" data-saved={saved || undefined} aria-pressed={saved} icon={<IconBookmark filled={saved} />} onClick={() => toggleSaved(slug, 'detail')}>
              {saved ? 'Saved' : 'Save project'}
            </Button>
          </StatePanel>
        </div>
      </div>
    );
  }

  const sent = Boolean(interest) || forcedSent;
  const lead = project.team[0];
  const first = ownerFirst(project);
  const withdraw = () => {
    // clears the request, marks the application Withdrawn (12.44) and shows the Interest withdrawn toast with Undo
    withdrawRequest(slug, interest);
    setForcedSent(false);
    setWithdrawOpen(false);
  };

  return (
    <div className="dsc-page">
      <div className="dsc-detail">
        <div className="dsc-detail__main">
          <BackLink href="/collaborate/discover">Back to discover projects</BackLink>
          <span className="dsc-spacer" style={{ height: 36 }} />
          <header className="dsc-project-head">
            <div className="dsc-project-head__info">
              <StageLine stage={project.stage} type={project.type} />
              <h1 className="dsc-h1 dsc-h1--detail" data-m="words">
                {project.title}
              </h1>
              <p className="dsc-project-head__owner">
                {lead?.slug ? (
                  <Link href={`/collaborate/members/${lead.slug}`}>
                    Led by {project.owner}, {project.place}
                  </Link>
                ) : (
                  <>
                    Led by {project.owner}, {project.place}
                  </>
                )}
              </p>
              <p className="dsc-project-head__intro">{project.intro}</p>
              <TagList tags={project.skillTags} label="Skills needed" />
            </div>
          </header>

          <Section title="About the project">
            <p className="dsc-body">{project.about}</p>
          </Section>
          <Section title="What the project needs">
            <div className="dsc-items">
              {project.needs.map((n) => (
                <DetailItem key={n.title} title={n.title} detail={n.detail} />
              ))}
            </div>
          </Section>
          <Section title="The team so far">
            <div className="dsc-members">
              {project.team.map((m) => (
                <TeamMember key={m.name} initials={m.initials} name={m.name} role={m.role} href={m.slug ? `/collaborate/members/${m.slug}` : undefined} />
              ))}
            </div>
          </Section>
          <Section title="Progress so far">
            <div className="dsc-items">
              {project.progress.map((n) => (
                <DetailItem key={n.title} title={n.title} detail={n.detail} />
              ))}
            </div>
          </Section>
          <Section title="Working together">
            <FactList>
              <FactRow label="Commitment" value={project.working.commitment} />
              <FactRow label="Working rhythm" value={project.working.rhythm} />
              <FactRow label="Location" value={project.working.location} />
              <FactRow label="Open to" value={project.working.openTo} />
            </FactList>
          </Section>
          <Section title="Why this may fit you">
            <MatchBox sentence={project.fit} />
          </Section>
        </div>

        <aside className="dsc-detail__side" aria-label="Project actions">
          {sent ? (
            <SentPanel owner={first} saved={saved} onSave={() => toggleSaved(slug, 'detail')} onWithdraw={() => setWithdrawOpen(true)} requestHref={slug === DESIGNED_SLUG ? REQUEST_BASE : undefined} />
          ) : (
            // Express interest is a flow only for A Better Way to Learn (12.8); on the five 12.27 details the button has no reaction in Figma
            <InterestPanel interestHref={slug === DESIGNED_SLUG ? `/collaborate/projects/${slug}/interest` : undefined} saved={saved} onSave={() => toggleSaved(slug, 'detail')} />
          )}
          <GlancePanel rows={glanceRows(project)} />
          <PrivacyPanel text="The project summary and what the owner chose to share. Private details stay private." />
        </aside>
      </div>

      <WithdrawInterestModal open={withdrawOpen} onClose={() => setWithdrawOpen(false)} owner={first} onWithdraw={withdraw} />
    </div>
  );
}

export const ProjectDetail = ({ slug }: { slug: string }) => <ProjectDetailScreen slug={slug} />;
