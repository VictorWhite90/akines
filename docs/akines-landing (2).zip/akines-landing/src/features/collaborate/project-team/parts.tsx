'use client';

import type { ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { asset } from '@/lib/assets';
import { Button } from '@/ui';
import { Ctx, Dot, Over, PeopleRows, cx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { teamFor, type Contribution, type Presence, type TeamMember } from './data';

/**
 * Pieces of the project Team pages (12.21). The Figma components are Skill Tag 17729:93206, Member Card 17729:93368,
 * Interest Request 17729:98852, Context Panel / Team 17729:98919, Contribution Item 17729:93249 and Confirmation Line 17729:114781.
 * Every class is prefixed pt- and lives in team.css. Default, Hover, Pressed and Focus of each component come from CSS.
 */

const PRESENCE_TONE: Record<Presence, 'green' | 'accent' | 'gray'> = { available: 'green', working: 'accent', away: 'gray', unshared: 'gray' };

/** The Team data of the project of the page being shown (Career Guidance for Everyone or Adire Stories). */
export const useTeam = () => teamFor(useProject().key);

/* ------------------------------------------------------------------ people */

/** Round portrait (photo of a person who has one). */
export function Photo({ src, size }: { src: string; size: number }) {
  return (
    <span className="pt-photo" style={{ ['--pt-ph' as string]: `${size}px` }} aria-hidden="true">
      <img src={asset(src)} alt="" width={size} height={size} loading="lazy" decoding="async" />
    </span>
  );
}

/* ------------------------------------------------------------------ Skill Tag */

/**
 * Skill Tag (Default, Hover, Pressed, Focus, Demonstrated). A tag has no destination in the design: it reacts to hover and press
 * and does nothing. Demonstrated adds an amber dot (a skill used in project work).
 */
export function SkillTag({ label, used }: { label: string; used?: boolean }) {
  return (
    <button type="button" className={cx('pt-skill', used && 'pt-skill--used')}>
      {used ? <i className="pt-skill__dot" aria-hidden="true" /> : null}
      {used ? <span className="sr-only">Used in project work: </span> : null}
      {label}
    </button>
  );
}

export function SkillTags({ labels, wrap }: { labels: { label: string; used?: boolean }[]; wrap?: boolean }) {
  return (
    <ul className={cx('pt-skills', wrap && 'pt-skills--wrap')} aria-label="Skills">
      {labels.map((s) => (
        <li key={s.label}>
          <SkillTag label={s.label} used={s.used} />
        </li>
      ))}
    </ul>
  );
}

/* ------------------------------------------------------------------ Member Card */

/** Arrow of the portrait card's hover button (Figma icon/arrow-up-right, 18 px, 1.5 stroke). */
const ArrowUpRight18 = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="M5 13 13 5M6 5h7v7" />
  </svg>
);

/**
 * Member Card, "Team Portrait Card" (Default, Hover, Pressed): the 342 x 430 portrait, the name in Alice, the role, one skill and "+2"
 * for the rest. The whole card is one button that opens the member slide-out (the arrow circle shows on hover and focus). A member
 * without a photo shows their initials on the ivory tile.
 */
export function MemberCard({ m, onOpen, wide }: { m: TeamMember; onOpen: (m: TeamMember) => void; wide?: boolean }) {
  const [first, ...rest] = m.skills;
  // a card with a row to itself is 702 wide: it takes the wider crop of the portrait when there is one
  const src = wide ? (m.photoWide ?? m.photo) : m.photo;
  return (
    <button type="button" className={wide ? 'pt-mcard pt-mcard--wide' : 'pt-mcard'} onClick={() => onOpen(m)} aria-haspopup="dialog">
      <span className="pt-mcard__media">
        <span className="pt-mcard__img">
          {src ? <img src={asset(src)} alt="" width={wide ? 702 : 342} height={430} loading="lazy" decoding="async" data-crop={wide && !m.photoWide ? 'top' : undefined} /> : <span className="pt-mcard__initials">{m.initials}</span>}
        </span>
        <span className="pt-mcard__go" aria-hidden="true">
          <ArrowUpRight18 />
        </span>
      </span>
      <span className="pt-mcard__info">
        <span className="pt-mcard__name">{m.name}</span>
        <span className="pt-mcard__role">{m.role}</span>
        <span className="pt-mcard__skills">
          {first ? <span className="pt-mcard__tag">{first}</span> : null}
          {rest.length ? <span className="pt-mcard__more">+{rest.length}</span> : null}
        </span>
      </span>
      <span className="sr-only">Open {m.name.replace(/\s*\(you\)/i, '')}</span>
    </button>
  );
}

/* ------------------------------------------------------------------ Interest Request */

/** Interest Request (17729:98852): who asked, their skills, the role they want, their message, and Accept or Not now. */
export function InterestRequest({ onAccept, onNotNow }: { onAccept: () => void; onNotNow: () => void }) {
  const { request } = useTeam();
  return (
    <article className="pt-req" aria-label={`Interest request from ${request.name}`}>
      <div className="pt-req__top">
        <div className="pt-req__person">
          <Photo src={request.photo} size={56} />
          <div className="pt-req__text">
            <h3 className="pt-req__name">{request.name}</h3>
            <p className="pt-req__role">{request.role}</p>
          </div>
        </div>
        <p className="pt-req__sent">{request.sent}</p>
      </div>
      <SkillTags labels={request.skills.map((label) => ({ label }))} />
      <div className="pt-rule" aria-hidden="true" />
      <div className="pt-req__fields">
        <div className="pt-req__field">
          <Over className="cw-over--12">{request.wantsLabel}</Over>
          <p className="pt-req__value">{request.wants}</p>
        </div>
        <div className="pt-req__field pt-req__field--grow">
          <Over className="cw-over--12">{request.messageLabel}</Over>
          <p className="pt-req__value pt-req__value--msg">{request.message}</p>
        </div>
      </div>
      <div className="pt-req__actions">
        <Button size="sm" onClick={onAccept}>
          Accept
        </Button>
        <Button size="sm" variant="secondary" onClick={onNotNow} aria-haspopup="dialog">
          Not now
        </Button>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ Confirmation Line */

/** Confirmation Line (17729:114781): the result of answering a request, in the place the request was. */
export function ConfirmationLine({ message }: { message: string }) {
  return (
    <p className="pt-confirm">
      <Dot tone="green" size={8} />
      <span>{message}</span>
    </p>
  );
}

/* ------------------------------------------------------------------ Contribution Item */

/** Contribution Item (17729:93249): type, work, context, an optional acknowledgement and the date. One link to where the work lives. */
export function ContributionItem({ c }: { c: Contribution }) {
  const body = (
    <>
      <span className="pt-contrib__content">
        <span className="pt-contrib__type">{c.type}</span>
        <span className="pt-contrib__work">{c.work}</span>
        <span className="pt-contrib__context">{c.context}</span>
        {c.acknowledgement ? (
          <span className="pt-contrib__ack">
            <Dot size={7} />
            {c.acknowledgement}
          </span>
        ) : null}
      </span>
      <span className="pt-contrib__date">{c.date}</span>
    </>
  );
  /* A row without a destination reacts to hover like the others but is not a link (the two rows that used to open the Studio). */
  return c.href ? (
    <Link href={c.href} className="pt-contrib">
      {body}
    </Link>
  ) : (
    <div className="pt-contrib">{body}</div>
  );
}

/* ------------------------------------------------------------------ Context Panel / Team */

/**
 * Context Panel / Team (17729:98919). Members=Full: availability of the people who share it, team health, the upcoming session.
 * Members=Solo (the Empty frame): only the owner, a note about team health and no session.
 */
export function TeamContext({ solo }: { solo?: boolean }) {
  const { members, panel } = useTeam();
  // everyone but the owner shares their availability
  const rows = solo
    ? [{ initials: 'KA', name: 'Kemi Adeyemi', text: 'Available for review', tone: 'green' as const }]
    : members.slice(1).map((m) => ({ initials: m.initials, name: m.name, text: m.availability, tone: PRESENCE_TONE[m.presence] }));
  return (
    <div className="pt-ctx">
      <Ctx label={panel.availability}>
        <PeopleRows people={rows} />
        <p className="pt-note">{solo ? panel.soloNote : panel.availabilityNote}</p>
      </Ctx>
      <Ctx label={panel.health}>
        {solo ? (
          <p className="pt-ctx__solo">{panel.soloHealth}</p>
        ) : (
          <>
            <p className="cw-session__title">{panel.healthTitle}</p>
            <ul className="pt-themes">
              {panel.themes.map((t) => (
                <li className="pt-theme" key={t.text}>
                  <Dot tone={t.tone} size={7} />
                  {t.text}
                </li>
              ))}
            </ul>
            <p className="pt-note">{panel.healthNote}</p>
          </>
        )}
      </Ctx>
      {solo ? null : (
        <Ctx label={panel.session}>
          <p className="cw-ctx__item">{panel.sessionTitle}</p>
          <p className="pt-line">{panel.sessionWhen}</p>
          <p className="pt-line">{panel.sessionWho}</p>
        </Ctx>
      )}
    </div>
  );
}

/** Small labelled heading of a block of the member detail (Skills, Availability). */
export function BlockLabel({ children }: { children: ReactNode }) {
  return <h2 className="cw-over pt-block__label">{children}</h2>;
}
