'use client';

/**
 * Building blocks shared by the Project detail (12.6) and Member profile (12.7) pages:
 * sections, detail items, fact rows, tags, team members and the three side panels.
 */
import type { ReactNode } from 'react';
import { Button } from '@/ui';
import { Link } from '@/lib/nav';
import type { Project } from './data';
import { Bar, CardLink, IconArrowRight, IconBookmark, IconEye, StatusPill } from './ui';

/** Section with a hairline on top, a small caps title and its content (Figma "Section / ...", 17319:13610). */
export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="dsc-section" data-m="up">
      <h2 className="dsc-eyebrow">{title}</h2>
      {children}
    </section>
  );
}

/** Detail Item: serif title with a line of detail under it. */
export function DetailItem({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="dsc-item">
      <h3 className="dsc-item__title">{title}</h3>
      <p className="dsc-item__detail">{detail}</p>
    </div>
  );
}

/** Fact Row, wide (label column 240) or compact (label column 130). */
export function FactRow({ label, value, compact }: { label: string; value: string; compact?: boolean }) {
  return (
    <div className={`dsc-fact${compact ? ' dsc-fact--compact' : ''}`}>
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}

export function FactList({ children, compact }: { children: ReactNode; compact?: boolean }) {
  return <dl className={`dsc-facts${compact ? ' dsc-facts--compact' : ''}`}>{children}</dl>;
}

export function TagList({ tags, label }: { tags: string[]; label: string }) {
  return (
    <ul className="dsc-tags" aria-label={label}>
      {tags.map((t) => (
        <li key={t}>
          <span className="dsc-tag">{t}</span>
        </li>
      ))}
    </ul>
  );
}

/** Team Member (Figma 17319:13612): initials avatar, name and role. Links to the profile when there is one. */
export function TeamMember({ initials, name, role, href }: { initials: string; name: string; role: string; href?: string }) {
  const inner = (
    <>
      <span className="dsc-member__avatar" aria-hidden="true">
        {initials}
      </span>
      <span className="dsc-member__info">
        <span className="dsc-member__name">{name}</span>
        <span className="dsc-member__role">{role}</span>
      </span>
    </>
  );
  return href ? (
    <Link href={href} className="dsc-member">
      {inner}
    </Link>
  ) : (
    <div className="dsc-member dsc-member--static">{inner}</div>
  );
}

/** Match context box: a serif sentence in a bordered box, optionally with a link under it. */
export function MatchBox({ sentence, children }: { sentence: string; children?: ReactNode }) {
  return (
    <div className="dsc-match">
      <p className="dsc-match__sentence">{sentence}</p>
      {children}
    </div>
  );
}

/** Save Button (Figma 17319:13595): outline pill, ink fill on the bookmark and a grey ground once saved. */
export function SaveButton({ saved, onClick, fullWidth = true }: { saved: boolean; onClick: () => void; fullWidth?: boolean }) {
  return (
    <Button variant="secondary" fullWidth={fullWidth} className="dsc-savebtn" data-saved={saved || undefined} aria-pressed={saved} icon={<IconBookmark filled={saved} />} onClick={onClick}>
      {saved ? 'Saved' : 'Save project'}
    </Button>
  );
}

/** Side panel with the call to action: "Interested in this project?" */
export function InterestPanel({ interestHref, saved, onSave }: { interestHref?: string; saved: boolean; onSave: () => void }) {
  return (
    <section className="dsc-panel-card dsc-panel-card--actions" aria-label="Interest">
      <p className="dsc-eyebrow">Interested in this project?</p>
      <Button href={interestHref} fullWidth iconRight={<IconArrowRight />}>
        Express interest
      </Button>
      <SaveButton saved={saved} onClick={onSave} />
    </section>
  );
}

/** Side panel once interest was sent: status, note, View request (12.44), Withdraw interest, Save project. */
export function SentPanel({ saved, onSave, onWithdraw, owner, requestHref }: { saved: boolean; onSave: () => void; onWithdraw: () => void; owner: string; requestHref?: string }) {
  return (
    <section className="dsc-panel-card dsc-panel-card--actions" aria-label="Your interest">
      <p className="dsc-eyebrow">Your interest</p>
      <div className="dsc-sent-status">
        <StatusPill status="pending" />
        <span>Sent today</span>
      </div>
      <p className="dsc-panel-card__note">{owner} will reply here. You can withdraw your interest until they respond.</p>
      {requestHref ? (
        <CardLink href={requestHref} arrow>
          View request
        </CardLink>
      ) : null}
      <Button variant="secondary" fullWidth onClick={onWithdraw}>
        Withdraw interest
      </Button>
      <SaveButton saved={saved} onClick={onSave} />
    </section>
  );
}

export function GlancePanel({ rows }: { rows: { label: string; value: string }[] }) {
  return (
    <section className="dsc-panel-card dsc-panel-card--glance" aria-label="At a glance">
      <h2 className="dsc-eyebrow">At a glance</h2>
      <FactList compact>
        {rows.map((r) => (
          <FactRow key={r.label} compact label={r.label} value={r.value} />
        ))}
      </FactList>
    </section>
  );
}

export const glanceRows = (p: Project) => [
  { label: 'Stage', value: p.stage },
  { label: 'Type', value: p.type },
  { label: 'Team', value: `${p.teamCount} people` },
  { label: 'Commitment', value: p.working.commitment },
  { label: 'Location', value: p.glanceLocation },
];

export function PrivacyPanel({ text }: { text: string }) {
  return (
    <section className="dsc-panel-card dsc-panel-card--privacy" aria-label="What you are seeing">
      <div className="dsc-panel-card__head">
        <IconEye />
        <h2 className="dsc-eyebrow">What you’re seeing</h2>
      </div>
      <p className="dsc-panel-card__note">{text}</p>
    </section>
  );
}

/* ------------------------------------------------------------------ skeleton helpers (Detail Skeleton 17320, Profile Skeleton 17322:32656) */

export function SkelSection({ children, height }: { children: ReactNode; height?: number }) {
  return (
    <div className="dsc-skel-section" style={height ? { minHeight: height } : undefined}>
      {children}
    </div>
  );
}

export function SkelSidePanels({ rows }: { rows: boolean }) {
  return (
    <div className="dsc-detail__side" aria-hidden="true">
      <div className="dsc-panel-card dsc-skel-panel">
        <Bar w={200} h={12} />
        <Bar w="100%" h={48} r={999} />
        <Bar w="100%" h={48} r={999} />
      </div>
      {rows ? (
        <div className="dsc-panel-card dsc-skel-panel dsc-skel-panel--rows">
          <Bar w={120} h={12} />
          {[0, 1, 2, 3, 4].map((i) => (
            <div className="dsc-skel-row dsc-skel-row--tight" key={i}>
              <Bar w={110} h={14} />
              <Bar w={200} h={14} />
            </div>
          ))}
        </div>
      ) : null}
      <div className="dsc-panel-card dsc-skel-panel">
        <Bar w={160} h={12} />
        <Bar w="100%" h={14} />
        <Bar w={300} h={14} />
      </div>
    </div>
  );
}
