'use client';

import { forwardRef, type AnchorHTMLAttributes } from 'react';
import { Link } from '@/lib/nav';
import { LINKS } from '@/lib/links';
import { openSignIn } from '@/features/auth/panel-store';

type Props = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> & { href: string };

/**
 * Every link on the landing page goes through this. Internal paths use the router (works in Next and in the preview),
 * "#anchors" and external URLs are plain anchors, and the sign-in path opens the slide-out panel in place instead of
 * changing screen (the same as the Figma prototype), while still being a real link without script.
 */
export const AppLink = forwardRef<HTMLAnchorElement, Props>(function AppLink({ href, onClick, ...rest }, ref) {
  return (
    <Link
      ref={ref}
      href={href}
      {...rest}
      onClick={(e) => {
        onClick?.(e);
        if (e.defaultPrevented) return;
        if (href === LINKS.signIn && e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
          e.preventDefault();
          openSignIn();
        }
      }}
    />
  );
});
