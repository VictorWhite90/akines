import { CONTRIBUTIONS } from './data';

/**
 * Copy of Team / Member detail (Figma 12.21, frame 17729:111084), word for word. The member page is a Career Guidance for Everyone page
 * only (Adire Stories mirrors the Team list, not this page). The shorter lines of the dashboard version replace the longer paragraphs of
 * data.ts (DETAIL), which stays in place for the Team list and the member slide-out.
 */

export const MEMBER = {
  back: 'Back to team',
  label: 'TEAM MEMBER',
  name: 'Adaeze Okoye',
  initials: 'AO',
  lead: 'Product Designer, designing the student-facing screens.',
  metrics: {
    tasks: { label: 'OPEN TASKS', value: '2', caption: 'in this project' },
    contributions: { label: 'CONTRIBUTIONS', value: '5', caption: 'since 12 Oct' },
    acknowledged: { label: 'ACKNOWLEDGED', value: '1', caption: 'by a teammate' },
    session: { label: 'NEXT SESSION', value: 'Thu', caption: '4:00 PM' },
  },
  week: {
    title: 'CONTRIBUTIONS BY WEEK',
    total: '5',
    caption: 'logged since 12 Oct',
    /** Bar heights in px as the design draws them (the chart is 88 px tall, the day label below takes 24). The last week is the current one. */
    bars: [
      { label: '12 Oct', h: 30 },
      { label: '19 Oct', h: 50 },
      { label: '26 Oct', h: 40 },
      { label: '2 Nov', h: 60, now: true },
    ],
  },
  availability: {
    title: 'AVAILABILITY',
    status: 'Available for review',
    nextLabel: 'NEXT SESSION',
    session: 'Prototype review',
    when: 'Thursday at 4:00 PM',
    note: 'Shown because Adaeze chose to share it.',
  },
  role: {
    title: 'ROLE IN THIS PROJECT',
    fields: [
      { label: 'PROJECT ROLE', value: 'Product Designer, supporting' },
      { label: 'EXPECTED', value: 'Review work on the first student experience' },
      { label: 'RESPONSIBLE FOR', value: 'Student-facing screens and design review' },
      { label: 'WORKS BEST WITH', value: 'Written feedback first, then a short call' },
    ],
  },
  skills: {
    title: 'SKILLS',
    note: 'A dot marks a skill Adaeze has used in project work.',
  },
  history: {
    id: 'mb-history',
    title: 'CONTRIBUTION HISTORY',
    support: 'Recognises meaningful work. Hours online and message counts are never recorded.',
  },
};

/** Where a contribution row goes: the destinations are those of the Contribution Item rows in data.ts (CONTRIBUTIONS). */
const to = (id: string) => CONTRIBUTIONS.find((c) => c.id === id)?.href;

export type HistoryRow = { id: string; title: string; status: string; href?: string };

/**
 * The six rows of the contribution history. Decision influenced opens the decision discussion, Milestone completed the project brief,
 * Skill demonstrated the milestone and Final credits the agreements; the other two rows have no destination in the design.
 */
export const HISTORY_ROWS: HistoryRow[] = [
  { id: 'work', title: 'Second onboarding screen', status: 'Work submitted, Mon 2 Nov', href: to('work') },
  { id: 'decisions', title: 'Choose the onboarding approach', status: 'Decision influenced, Fri 30 Oct', href: to('decisions') },
  { id: 'milestones', title: 'Project brief approved', status: 'Milestone completed, Mon 12 Oct', href: to('milestones') },
  { id: 'peer', title: 'Map the student journey', status: 'Acknowledged by Tobi Adeyemi, Tue 27 Oct', href: to('peer') },
  { id: 'skills', title: 'Interface design', status: 'Skill demonstrated, Mon 2 Nov', href: to('skills') },
  { id: 'credits', title: 'Final credits', status: 'To be agreed, not agreed yet', href: to('credits') },
];
