'use client';

import '../workspace/workspace.css';
import '../workspace/dash.css';
import '../meetings/meetings.css';
import { Button } from '@/ui';
import { VISIBLE_NAV_ITEMS } from '../workspace/project';
import { ArrowUpRight, Dot } from '../workspace/atoms';
import { Portrait, type Tone } from '../workspace/dash';
import { OverviewBody } from '../workspace/Overview';
import { COMMUNITY_LEARNING_DASH, MENTORSHIP_CIRCLE_DASH, type SampleDash, type SampleRail } from '../workspace/overview-data';
import { COMMUNITY_LEARNING, MENTORSHIP_CIRCLE, type SampleProject } from './data';
import { ProjectHeader } from './ProjectHeader';

/**
 * 12.26 Sample projects: the Overview of Community Learning Initiative and of Mentorship Circle. The same dashboard as the Project overview of
 * Career Guidance for Everyone (OverviewBody) with its own copy, and the project rail of the design with its own people (the shared rail reads
 * the two full projects only). Only the project switcher of the header works: every other control has no reaction in the design, so the cards,
 * rows, links and the project navigation have no destination.
 */

const NAV_LABELS = VISIBLE_NAV_ITEMS.map((i) => i.label);
const TONE: Record<SampleRail['people'][number]['presence'], Tone> = { available: 'green', working: 'accent', away: 'gray' };
const WORD = { available: 'Available', working: 'Working', away: 'Away' } as const;

function SampleNav() {
  return (
    <nav className="cw-nav ph-nav" aria-label="Project workspace">
      <p className="cw-nav__eyebrow">PROJECT WORKSPACE</p>
      <ul className="cw-nav__list">
        {NAV_LABELS.map((label, i) => (
          <li key={label}>
            <button type="button" className="cw-nav__item" aria-current={i === 0 ? 'page' : undefined}>
              <span className="cw-nav__num">{String(i + 1).padStart(2, '0')}</span>
              <span className="cw-nav__label">{label}</span>
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}

const DocIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="M4 1.8h5.2L12.2 4.8v9.4H4z" />
    <path d="M9 1.8v3.2h3.2M6 8h4M6 10.5h4" />
  </svg>
);
const ChevronRight = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="m6 3.5 4.5 4.5L6 12.5" />
  </svg>
);

/** The project rail of a sample project (Figma Overview rail 17816:97511 and 17816:97810): meeting card, team availability, needs review, workload. */
function SampleRailBlocks({ r }: { r: SampleRail }) {
  const count = (p: SampleRail['people'][number]['presence']) => r.people.filter((m) => m.presence === p).length;
  return (
    <div className="cd-rail">
      <section className="mt-card" aria-label="Next session">
        <div className="mt-card__top">
          <span className="mt-tile mt-tile--date" aria-hidden="true">
            <span className="mt-tile__day">{r.meeting.day}</span>
            <span className="mt-tile__time">{r.meeting.time}</span>
          </span>
          <div className="mt-card__text">
            <p className="mt-eyebrow">
              <Dot size={6} />
              NEXT SESSION
            </p>
            <h3 className="mt-title">{r.meeting.title}</h3>
            <p className="mt-sub">{r.meeting.meta}</p>
          </div>
        </div>
        <Button size="sm" variant="secondary" fullWidth iconRight={<ArrowUpRight />}>
          View meeting
        </Button>
      </section>

      <section className="cd-rail__block" aria-label="Team availability">
        <header className="cd-rail__head">
          <h3 className="cd-rail__title">TEAM AVAILABILITY</h3>
          <button type="button" className="cd-rail__link ov-plain">
            Team
            <ArrowUpRight size={14} />
          </button>
        </header>
        <ul className="cd-avail ov-avail">
          {r.people.map((m) => (
            <li key={m.name}>
              <div className="cd-avail__item ov-plain">
                <Portrait src={m.photo} size={56} tone={TONE[m.presence]} />
                <span className="cd-avail__name">{m.name}</span>
                <span className="cd-avail__word">{WORD[m.presence]}</span>
              </div>
            </li>
          ))}
        </ul>
        <p className="cd-legend">
          <span>
            <Dot tone="green" size={6} />
            {count('available')} available
          </span>
          <span>
            <Dot size={6} />
            {count('working')} working
          </span>
          <span>
            <Dot tone="gray" size={6} />
            {count('away')} away
          </span>
        </p>
      </section>

      <section className="cd-rail__block" aria-label="Needs review">
        <header className="cd-rail__head">
          <h3 className="cd-rail__title">NEEDS REVIEW</h3>
          <span className="cd-badge">{r.review.length}</span>
        </header>
        <ul className="cd-review">
          {r.review.map((row) => (
            <li key={row.title}>
              <div className="cd-review__row ov-plain">
                <span className="cd-review__icon">
                  <DocIcon />
                </span>
                <span className="cd-review__text">
                  <span className="cd-review__title">{row.title}</span>
                  <span className="cd-review__cap">{row.caption}</span>
                </span>
                <ChevronRight />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="cd-rail__block" aria-label="Workload">
        <header className="cd-rail__head">
          <h3 className="cd-rail__title">WORKLOAD</h3>
          <span className="cd-rail__note">Open tasks</span>
        </header>
        <ul className="cd-load">
          {r.people.map((m) => (
            <li className="cd-load__row" key={m.name}>
              <Portrait src={m.photo} size={28} />
              <span className="cd-load__name">{m.name}</span>
              <span className="cd-load__track" role="img" aria-label={`${m.tasks} open tasks`}>
                <i style={{ width: `${Math.min(100, Math.round((m.tasks / 3) * 100))}%` }} />
              </span>
              <span className="cd-load__n">{m.tasks}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function SamplePage({ p, d }: { p: SampleProject; d: SampleDash }) {
  return (
    <div className="cw-ws">
      <ProjectHeader project={p.header} wired={false} />
      <div className="cw-ws__grid cw-ws__grid--dash">
        <div className="cw-navwrap">
          <SampleNav />
        </div>
        <div className="cw-main cw-main--dash">
          <OverviewBody name={p.header.name} lead={d.lead} d={d} />
        </div>
        <aside className="cw-ctx cw-rail" aria-label="Project rail">
          <SampleRailBlocks r={d.rail} />
        </aside>
      </div>
    </div>
  );
}

/** Frame "Community Learning Initiative" (17703:73613). */
export const CommunityLearningPage = () => <SamplePage p={COMMUNITY_LEARNING} d={COMMUNITY_LEARNING_DASH} />;
/** Frame "Mentorship Circle" (17703:74159). */
export const MentorshipCirclePage = () => <SamplePage p={MENTORSHIP_CIRCLE} d={MENTORSHIP_CIRCLE_DASH} />;
