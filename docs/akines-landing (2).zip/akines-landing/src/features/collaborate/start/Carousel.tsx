'use client';

/**
 * Paged carousel of the Home (Figma "Projects Carousel", "Collaborators Carousel", "Invitations Carousel", "Open Calls Carousel").
 * A viewport clips a track that slides one page at a time (0.6 s ease in out in Figma). Previous on the first page goes to the last
 * page and Next on the last goes to the first, which is what the Figma reactions do. Controls: previous, "1 / 2", next.
 */
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { IconButton } from '@/ui';
import { useLayout } from '@/lib/hooks';
import { IcChevronLeft, IcChevronRight } from './parts';

type Per = { desktop: number; tablet: number; mobile: number };

export function Carousel({
  label,
  noun,
  per,
  children,
  className,
}: {
  /** accessible name of the carousel */
  label: string;
  /** what one page holds, for the button names ("projects" gives "Previous projects") */
  noun: string;
  per: Per;
  children: ReactNode[];
  className?: string;
}) {
  const layout = useLayout();
  const n = children.length;
  const perPage = per[layout];
  const pages = Math.max(1, Math.ceil(n / perPage));
  const [raw, setPage] = useState(0);
  const page = Math.min(raw, pages - 1);
  const go = (p: number) => setPage(((p % pages) + pages) % pages);
  const down = useRef<number | null>(null);

  // keep the page in range when the layout changes the page size
  useEffect(() => {
    if (raw > pages - 1) setPage(pages - 1);
  }, [raw, pages]);

  return (
    <div
      className={'cs-car' + (className ? ' ' + className : '')}
      role="group"
      aria-roledescription="carousel"
      aria-label={label}
      style={{ ['--page' as string]: page, ['--per' as string]: perPage }}
    >
      <div
        className="cs-car__viewport"
        onPointerDown={(e) => {
          if (e.pointerType === 'touch') down.current = e.clientX;
        }}
        onPointerUp={(e) => {
          if (down.current === null) return;
          const dx = e.clientX - down.current;
          down.current = null;
          if (Math.abs(dx) > 50) go(page + (dx < 0 ? 1 : -1));
        }}
        onPointerCancel={() => {
          down.current = null;
        }}
      >
        <div className="cs-car__track" aria-live="off">
          {children.map((c, i) => {
            const here = Math.floor(i / perPage) === page;
            return (
              <div
                key={i}
                className="cs-car__item"
                role="group"
                aria-roledescription="slide"
                aria-label={`${i + 1} of ${n}`}
                aria-hidden={here ? undefined : true}
                {...(here ? {} : { inert: true })}
              >
                {c}
              </div>
            );
          })}
        </div>
      </div>
      <div className="cs-car__controls">
        <IconButton label={`Previous ${noun}`} onClick={() => go(page - 1)}>
          <IcChevronLeft />
        </IconButton>
        <span className="cs-car__count" aria-live="polite">
          {page + 1} / {pages}
        </span>
        <IconButton label={`Next ${noun}`} onClick={() => go(page + 1)}>
          <IcChevronRight />
        </IconButton>
      </div>
    </div>
  );
}
