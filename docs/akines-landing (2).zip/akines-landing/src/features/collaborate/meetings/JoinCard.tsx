'use client';

import './meetings.css';
import { Video } from 'lucide-react';
import { Button } from '@/ui';
import { useProject } from '../workspace/project';
import { meetPaths, useMeeting } from './store';

/**
 * The Join card inside a conversation (Figma Conversations 17389, after the last message): the meeting, when it is and how long, and Join.
 * It is shown while a meeting is upcoming or ongoing; once the call has ended (no meeting) there is nothing to join and it is not drawn.
 */
export function JoinCard() {
  const { key, root } = useProject();
  const m = useMeeting(key);
  if (m.status === 'none') return null;
  return (
    <div className="mt-join" role="group" aria-label="Meeting">
      <div className="mt-join__main">
        <span className="mt-join__icon" aria-hidden="true">
          <Video size={18} strokeWidth={1.5} />
        </span>
        <div className="mt-join__text">
          <span className="mt-join__title">{m.name}</span>
          <span className="mt-join__meta">{m.status === 'ongoing' ? `Started ${m.startedAt}, ${m.minutes} min` : `${m.when}, ${m.minutes} min`}</span>
        </div>
      </div>
      <Button size="sm" href={meetPaths(root).lobby}>
        Join
      </Button>
    </div>
  );
}
