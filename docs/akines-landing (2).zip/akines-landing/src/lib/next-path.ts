/** Where to send the visitor after signing in (set when a signed-out visitor opens a member page). Kept free of imports so any screen can use it. */
export const NEXT_KEY = 'akines.next';
export const rememberNext = (path: string) => {
  try {
    sessionStorage.setItem(NEXT_KEY, path);
  } catch {
    /* ignore */
  }
};
export const takeNext = (fallback: string) => {
  try {
    const v = sessionStorage.getItem(NEXT_KEY);
    sessionStorage.removeItem(NEXT_KEY);
    return v && v.startsWith('/') ? v : fallback;
  } catch {
    return fallback;
  }
};
