import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { DP } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Mirrored: Decisions (17729:108407) and History (17729:113566), the two views the view tabs switch between.
 * Not mirrored: Empty, Decision detail and every "state-" frame (modal and toast frames). The Propose decision modal and its toast still
 * work on these pages. The decision rows, Review decision and View milestone have no destination on Adire Stories.
 */
const MIRRORED: string[] = [DP.list, DP.history];

export const artRoutes: RouteDef[] = routes
  .filter((r) => MIRRORED.includes(r.path))
  .map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
