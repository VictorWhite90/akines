'use client';

/**
 * 12.44 APPLICATION STATUS: what the applicant sees after "Interest sent". One request (to join A Better Way to Learn) moves through
 * Pending (17974:154292), Shortlisted (17974:154458), Pick a time (17974:154645, Slot chosen 17974:156712), Talk booked (17974:156858,
 * Toast:Time booked 17974:162346), Offer received (17974:157052, Modal:Accept offer 17974:162255, Modal:Decline offer 17974:162290,
 * Toast:Offer accepted 17974:162353) and ends as Joined (17974:164547), Offer declined (17974:164652), Not selected (17974:164756) or
 * Withdrawn (17974:164860). Loading (17974:162360) and Could not load (17974:162499) belong to the base page.
 * The stage lives in ./store.ts. The base path renders the stage the store has; the other paths are entry points that set it.
 */
import { useEffect, useState } from 'react';
import { Button, Chip, Modal } from '@/ui';
import { useNav } from '@/lib/nav';
import { DESIGNED_SLUG, interestDefaults } from '../projects/data';
import { LOADING_MS, setInterest, takeFirstVisit, useInterestState, type Interest } from '../projects/store';
import { BackLink, CardLink, StatePanel } from '../projects/ui';
import { DetailSkeleton, WithdrawInterestModal } from '../projects/ProjectDetail';
import { DEFAULT_PICK, DECLINED_ON, offerSteps, pendingSteps, pickFull, shortlistedSteps, talkSteps, type DayKey } from './data';
import { PATHS as WORKSPACE_PATHS } from '../workspace/data';
import { DISCOVER_PATH, HOME_PATH, MY_PROJECTS_PATH, PROJECT_PATH, REQUEST_BASE, REQUEST_PATHS } from './paths';
import { EndState, NextSteps, OfferCard, RequestHead, RequestLayout, RequestSummary, SlotPicker, TalkCard, roleOf } from './parts';
import { ApplicationTimeline } from './shared';
import { acceptOffer, bookTalk, declineOffer, getApplication, setStage, toastOnNextPage, useApplication, useQueuedToast, withdrawRequest, type Stage } from './store';

const SLUG = DESIGNED_SLUG;
const LOADING_KEY = 'application';

/** Tab titles of the frames (the Figma browser tab), for the base path that shows different stages. */
const TAB_TITLE: Record<Stage, string> = {
  pending: 'Your request',
  shortlisted: 'Your request',
  talk: 'Talk booked',
  offer: 'Offer from Ngozi',
  joined: 'You are on the team',
  declined: 'Offer declined',
  'not-selected': 'Your request',
  withdrawn: 'Interest withdrawn',
};

/** "Product Designer, a few hours a week" */
const lowerFirst = (text: string) => text.charAt(0).toLowerCase() + text.slice(1);

/** The request being shown: the one sent in Express interest, or the drawn one when someone opens a stage page directly. */
function useRequest(): Interest {
  const interests = useInterestState();
  return interests[SLUG] ?? interestDefaults(SLUG);
}

/**
 * A stage page was opened: the request exists (so "Back to project" reaches the project detail with the interest sent),
 * except on the Withdrawn page, where it does not.
 */
function useRequestExists(withdrawn: boolean) {
  const interests = useInterestState();
  useEffect(() => {
    if (withdrawn) {
      if (interests[SLUG]) setInterest(SLUG, undefined);
    } else if (!interests[SLUG]) {
      setInterest(SLUG, interestDefaults(SLUG));
    }
    // once, when the page opens
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

/** Sets the browser tab title after the route frame has set its own. */
function useTabTitle(title: string) {
  useEffect(() => {
    const t = window.setTimeout(() => {
      document.title = `${title} | Akines`;
    }, 0);
    return () => window.clearTimeout(t);
  }, [title]);
}

/* ------------------------------------------------------------------ Pending (17974:154292) */

function PendingPage() {
  const nav = useNav();
  const interest = useRequest();
  const interests = useInterestState();
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  return (
    <>
      <RequestLayout
        back={{ href: PROJECT_PATH, label: 'Back to project' }}
        head={<RequestHead title="Your request" lead="Sent Thu 5 Nov. Ngozi has not replied yet. You will see her answer here." />}
        side={
          <>
            <NextSteps
              title="What happens next"
              lines={['Ngozi reads your note and your profile.', 'If she would like to talk, she shortlists you and you pick a time.', 'You hear back here, so there is nothing to chase.']}
            />
            <CardLink onClick={() => setWithdrawOpen(true)}>Withdraw interest</CardLink>
          </>
        }
      >
        <div className="apl-stack">
          <RequestSummary interest={interest} status="Pending" />
          <ApplicationTimeline steps={pendingSteps} />
        </div>
      </RequestLayout>
      {/* the existing Modal:Withdraw interest (17328:22980); it leads to the project detail with the Interest withdrawn toast */}
      <WithdrawInterestModal
        open={withdrawOpen}
        onClose={() => setWithdrawOpen(false)}
        owner="Ngozi"
        onWithdraw={() => {
          setWithdrawOpen(false);
          withdrawRequest(SLUG, interests[SLUG], true);
          nav.push(PROJECT_PATH);
        }}
      />
    </>
  );
}

/* ------------------------------------------------------------------ Shortlisted (17974:154458) */

function ShortlistedPage() {
  const interest = useRequest();
  return (
    <RequestLayout
      back={{ href: PROJECT_PATH, label: 'Back to project' }}
      head={<RequestHead title="Ngozi Eze shortlisted you." lead="She would like to talk before deciding. It is a 20 minute video call, and you choose the time." />}
      side={<NextSteps title="What happens next" lines={['Pick a time that suits you.', 'Talk with Ngozi for 20 minutes on a video call.', 'She may then send you an offer. Nothing is agreed until you accept.']} />}
    >
      <div className="apl-actions">
        <Button href={REQUEST_PATHS.time}>Pick a time to talk</Button>
      </div>
      <p className="apl-note">Ngozi shortlisted you on Sat 7 Nov. Choose a time that suits you.</p>
      <div className="apl-stack">
        <RequestSummary interest={interest} status="Shortlisted" />
        <ApplicationTimeline steps={shortlistedSteps} />
      </div>
    </RequestLayout>
  );
}

/* ------------------------------------------------------------------ Pick a time (17974:154645) and Slot chosen (17974:156712) */

function PickTimePage() {
  const nav = useNav();
  const app = useApplication();
  // Change time comes back here with the booked time chosen
  const [day, setDay] = useState<DayKey>(app.booked?.day ?? 'tue');
  const [slot, setSlot] = useState<number | null>(app.booked ? app.booked.slot : null);
  const confirm = () => {
    if (slot === null) return;
    bookTalk({ day, slot });
    toastOnNextPage({ message: 'Time booked with Ngozi.' });
    nav.push(REQUEST_PATHS.talk);
  };
  return (
    <RequestLayout
      back={{ href: REQUEST_BASE, label: 'Back to your request' }}
      head={<RequestHead title="Pick a time to talk." lead="Ngozi shared these times. It is a 20 minute video call. Times are shown in WAT, Lagos time." />}
      side={<NextSteps title="About the talk" lines={['20 minutes, on a video call.', 'Ngozi sees the time you choose.', 'You can change the time later if something comes up.']} />}
    >
      <div className="apl-stack">
        <SlotPicker
          day={day}
          slot={slot}
          onDay={(d) => {
            setDay(d);
            setSlot(null);
          }}
          onSlot={setSlot}
          onConfirm={confirm}
        />
      </div>
    </RequestLayout>
  );
}

/* ------------------------------------------------------------------ Talk booked (17974:156858) */

function TalkBookedPage() {
  const app = useApplication();
  const pick = app.booked ?? DEFAULT_PICK;
  return (
    <RequestLayout
      back={{ href: PROJECT_PATH, label: 'Back to project' }}
      head={<RequestHead title="Your talk is booked." lead={`${pickFull(pick)}. Ngozi has been told, and you can change the time if something comes up.`} />}
      side={
        <NextSteps
          title="After the talk"
          lines={['Ngozi decides whether to send you an offer.', 'If she does, you will see it here and can take your time.', 'You do not have to accept. Nothing is agreed until you do.']}
        />
      }
    >
      <div className="apl-actions">
        <Button arrow="up-right">Open call link</Button>
        <CardLink>Add to calendar</CardLink>
        <CardLink href={REQUEST_PATHS.time}>Change time</CardLink>
        <CardLink>Message Ngozi</CardLink>
      </div>
      <div className="apl-stack">
        <TalkCard pick={pick} />
        <ApplicationTimeline steps={talkSteps(pick)} />
      </div>
    </RequestLayout>
  );
}

/* ------------------------------------------------------------------ Offer received (17974:157052) with its two modals */

const DECLINE_REASONS = ['The timing does not work', 'It is not the right fit', 'I joined another project', 'I would rather not say'];

function OfferPage() {
  const nav = useNav();
  const app = useApplication();
  const interest = useRequest();
  const role = roleOf(interest);
  const pick = app.booked ?? DEFAULT_PICK;
  const [acceptOpen, setAcceptOpen] = useState(false);
  const [declineOpen, setDeclineOpen] = useState(false);
  // the reason is optional and only Ngozi sees it, so it is not shown anywhere on this side
  const [reason, setReason] = useState<string | null>(null);

  const accept = () => {
    acceptOffer();
    setAcceptOpen(false);
    toastOnNextPage({ message: 'You joined A Better Way to Learn.' });
    nav.push(REQUEST_PATHS.joined);
  };
  const decline = () => {
    declineOffer();
    setDeclineOpen(false);
    nav.push(REQUEST_PATHS.declined);
  };
  const closeDecline = () => {
    setDeclineOpen(false);
    setReason(null);
  };

  return (
    <>
      <RequestLayout
        back={{ href: PROJECT_PATH, label: 'Back to project' }}
        head={<RequestHead title="Ngozi sent you an offer." lead="Read it through and reply when you are ready. Nothing is agreed until you accept." />}
        side={<NextSteps title="If you accept" lines={[`You join A Better Way to Learn as ${role}.`, 'You start on Mon 23 Nov.', 'You can see the team, tasks and files straight away.']} />}
      >
        <div className="apl-stack">
          <OfferCard role={role} />
          <div className="apl-offer-actions">
            <Button onClick={() => setAcceptOpen(true)}>Accept offer</Button>
            <Button variant="secondary" onClick={() => setDeclineOpen(true)}>
              Decline offer
            </Button>
            <CardLink>Ask a question</CardLink>
            {/* Figma goes to Agreements (12.22), the one sample agreement that exists */}
            <CardLink href={WORKSPACE_PATHS.agreements}>See the working agreement</CardLink>
          </div>
          <ApplicationTimeline steps={offerSteps(pick)} />
        </div>
      </RequestLayout>

      {/* Modal:Accept offer (17974:162255) */}
      <Modal
        open={acceptOpen}
        onClose={() => setAcceptOpen(false)}
        width={640}
        className="dsc-modal"
        eyebrow="Accept offer"
        title={`Join A Better Way to Learn as ${role}?`}
        description="You start on Mon 23 Nov, 6 hours a week, agreed together. Ngozi will be told right away."
        footer={
          <div className="dsc-modal__actions dsc-modal__actions--wide">
            <Button onClick={accept}>Accept and join</Button>
            <CardLink onClick={() => setAcceptOpen(false)}>Not yet</CardLink>
          </div>
        }
      >
        {null}
      </Modal>

      {/* Modal:Decline offer (17974:162290) */}
      <Modal
        open={declineOpen}
        onClose={closeDecline}
        width={640}
        className="dsc-modal"
        eyebrow="Decline offer"
        title="Decline this offer?"
        description="Ngozi will be told. You can add a reason if you like. It is optional and only Ngozi sees it."
        footer={
          <div className="dsc-modal__actions dsc-modal__actions--wide">
            <Button onClick={decline}>Decline offer</Button>
            <CardLink onClick={closeDecline}>Keep the offer</CardLink>
          </div>
        }
      >
        <div className="apl-reasons" role="group" aria-label="Reason (optional)">
          {DECLINE_REASONS.map((r) => (
            <Chip key={r} variant="choice" selected={reason === r} onClick={() => setReason(reason === r ? null : r)}>
              {r}
            </Chip>
          ))}
        </div>
      </Modal>
    </>
  );
}

/* ------------------------------------------------------------------ end states */

function JoinedPage() {
  const role = roleOf(useRequest());
  return (
    <EndState
      eyebrow="You are on the team"
      title="You are on the team."
      lead="Welcome to A Better Way to Learn. Ngozi has been told, and your first day is Mon 23 Nov."
      meta={`${role}, 6 hours a week`}
      status="Joined"
      note="What you can do now: say hello to the team, see your first tasks and read the working agreement."
    >
      <Button href={MY_PROJECTS_PATH} arrow="up-right">
        Open project
      </Button>
      <Button variant="secondary" href={HOME_PATH}>
        Back to Collaborate
      </Button>
    </EndState>
  );
}

function DeclinedPage() {
  const role = roleOf(useRequest());
  return (
    <EndState
      eyebrow="Offer declined"
      title="You declined the offer."
      lead="Ngozi has been told. There is nothing more to do here, and you can look for other projects whenever you like."
      meta={`${role}, 6 hours a week`}
      status="Declined"
      note={`You declined on ${DECLINED_ON}. If you added a reason, only Ngozi can see it.`}
    >
      <Button href={DISCOVER_PATH} arrow="up-right">
        Find more projects
      </Button>
      <Button variant="secondary" href={HOME_PATH}>
        Back to Collaborate
      </Button>
    </EndState>
  );
}

function NotSelectedPage() {
  const interest = useRequest();
  return (
    <EndState
      eyebrow="Not selected this time"
      title="Ngozi chose other collaborators this time."
      lead="This says little about your work. Other projects are looking for people with your skills."
      meta={`${roleOf(interest)}, ${lowerFirst(interest.time)}`}
      status="Not selected"
      note="Ngozi has made her choice for now. Your request stays in your history."
    >
      <Button href={DISCOVER_PATH} arrow="up-right">
        Find more projects
      </Button>
      <Button variant="secondary" href={HOME_PATH}>
        Back to Collaborate
      </Button>
    </EndState>
  );
}

function WithdrawnPage() {
  const interest = useRequest();
  return (
    <EndState
      eyebrow="Interest withdrawn"
      title="You withdrew your interest."
      lead="Ngozi has been told. You can send interest again at any time."
      meta={`${roleOf(interest)}, ${lowerFirst(interest.time)}`}
      status="Withdrawn"
      note="Withdrawn Fri 6 Nov. Nothing else is needed from you."
    >
      <Button href={PROJECT_PATH} arrow="up-right">
        Back to project
      </Button>
      <Button variant="secondary" href={DISCOVER_PATH}>
        Find more projects
      </Button>
    </EndState>
  );
}

/* ------------------------------------------------------------------ stage switch */

function StagePage({ stage }: { stage: Stage }) {
  // a toast queued by the page before (Time booked, Offer accepted, Interest withdrawn) shows once this one is on screen
  useQueuedToast();
  switch (stage) {
    case 'shortlisted':
      return <ShortlistedPage />;
    case 'talk':
      return <TalkBookedPage />;
    case 'offer':
      return <OfferPage />;
    case 'joined':
      return <JoinedPage />;
    case 'declined':
      return <DeclinedPage />;
    case 'not-selected':
      return <NotSelectedPage />;
    case 'withdrawn':
      return <WithdrawnPage />;
    default:
      return <PendingPage />;
  }
}

/** An entry path: opens the page of `stage` and sets the stage in the store. */
function Entry({ stage }: { stage: Stage }) {
  useRequestExists(stage === 'withdrawn');
  useEffect(() => {
    setStage(stage);
  }, [stage]);
  return <StagePage stage={stage} />;
}

/* ------------------------------------------------------------------ routes */

/**
 * The base path: the stage the request is at (Pending until something changes it). The first visit shows the Loading frame
 * (17974:162360) for 2.5 s. The stage is read once when the page opens, so an action that changes it (booking, accepting,
 * declining, withdrawing) does not flash another stage while the next page loads.
 */
export function RequestRoute() {
  const [stage] = useState<Stage>(() => getApplication().stage);
  const [loading, setLoading] = useState(() => takeFirstVisit(LOADING_KEY));
  useRequestExists(stage === 'withdrawn');
  useTabTitle(TAB_TITLE[stage]);
  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(() => setLoading(false), LOADING_MS);
    return () => window.clearTimeout(t);
  }, [loading]);
  if (loading) return <DetailSkeleton label="Loading your request" />;
  return <StagePage stage={stage} />;
}

export const ShortlistedRoute = () => <Entry stage="shortlisted" />;
export const TalkRoute = () => <Entry stage="talk" />;
export const OfferRoute = () => <Entry stage="offer" />;
export const JoinedRoute = () => <Entry stage="joined" />;
export const DeclinedRoute = () => <Entry stage="declined" />;
export const NotSelectedRoute = () => <Entry stage="not-selected" />;
export const WithdrawnRoute = () => <Entry stage="withdrawn" />;

/** /time: the request is at Shortlisted (or Talk booked, when the person came to change the time). */
export function PickTimeRoute() {
  useRequestExists(false);
  useEffect(() => {
    const now = getApplication().stage;
    if (now !== 'shortlisted' && now !== 'talk') setStage('shortlisted');
  }, []);
  return <PickTimePage />;
}

/** /state-loading: the Loading frame, then the request. */
export function LoadingRoute() {
  const nav = useNav();
  useRequestExists(getApplication().stage === 'withdrawn');
  useEffect(() => {
    const t = window.setTimeout(() => {
      takeFirstVisit(LOADING_KEY);
      nav.replace(REQUEST_BASE);
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return <DetailSkeleton label="Loading your request" />;
}

/** /state-error: Could not load (17974:162499). Try again leads to Loading and then to the request. */
export function ErrorRoute() {
  const nav = useNav();
  const [loading, setLoading] = useState(false);
  useRequestExists(false);
  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(() => {
      takeFirstVisit(LOADING_KEY);
      nav.replace(REQUEST_BASE);
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);
  if (loading) return <DetailSkeleton label="Loading your request" />;
  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        <BackLink href={PROJECT_PATH}>Back to project</BackLink>
        <StatePanel pair role="alert" headline="We could not load your request." support="Check your connection and try again. Your request is safe.">
          <Button onClick={() => setLoading(true)}>Try again</Button>
          <Button variant="secondary" href={PROJECT_PATH}>
            Back to project
          </Button>
        </StatePanel>
      </div>
    </div>
  );
}
