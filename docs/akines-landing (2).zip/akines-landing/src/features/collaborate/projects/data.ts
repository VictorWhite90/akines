/**
 * Sample data for the Collaborate "Discover projects" journeys (12.5 to 12.9) and the project details of 12.27.
 * The six projects are the cards of Figma frame 12.5 (17311:18092). Every project has a Figma detail page: A Better Way to Learn
 * (12.6, 17321:20075) and, in 12.27, Voices of Lagos (17705:73482), Clean Water Mapping (closed, 17722:77401), Market Women Ledger
 * (17705:74067), Stories for Small Hands (17705:74349) and Clinic Queue (17705:74631). Only the first has an Express interest flow.
 * Only Ngozi Eze and Obinna Adeyemi have designed member profiles (12.7).
 */

export type Stage = 'Just an idea' | 'Exploring' | 'Ready to plan' | 'Building' | 'Launching';
export type ProjectType = 'Application' | 'Film' | 'Social impact' | 'Book';
export type SkillCat = 'Design' | 'Engineering' | 'Research' | 'Writing' | 'Film and sound' | 'Community';
export type CommitmentCat = 'month' | 'week' | 'weekend' | 'full' | 'flexible';
export type LocationCat = 'state' | 'remote';

export type Member = {
  /** Slug of the profile page, only for people who have a designed profile. */
  slug?: string;
  name: string;
  initials: string;
  role: string;
};

export type Project = {
  slug: string;
  title: string;
  stage: Stage;
  type: ProjectType;
  purpose: string;
  /** "Looking for" line of the card. */
  roles: string[];
  skillCats: SkillCat[];
  teamCount: number;
  /** Initials of the first two avatars of the card. */
  avatars: [string, string];
  commitment: string;
  commitmentCat: CommitmentCat;
  locationCats: LocationCat[];
  owner: string;
  /** True when the project has its own Figma detail frame (all six now do). */
  designed: boolean;
  /** Closed after it was saved: the Saved list shows the Closed tag and the detail page shows "No longer open". */
  closed?: boolean;
  /* ---- detail page ---- */
  place: string;
  intro: string;
  skillTags: string[];
  about: string;
  needs: { title: string; detail: string }[];
  team: Member[];
  progress: { title: string; detail: string }[];
  working: { commitment: string; rhythm: string; location: string; openTo: string };
  glanceLocation: string;
  fit: string;
};

export const PROJECTS: Project[] = [
  {
    slug: 'a-better-way-to-learn',
    title: 'A Better Way to Learn',
    stage: 'Exploring',
    type: 'Application',
    purpose: 'A digital learning initiative exploring more accessible ways for students to learn.',
    roles: ['Product Designer', 'Software Engineer', 'Education Researcher'],
    skillCats: ['Design', 'Engineering', 'Research'],
    teamCount: 2,
    avatars: ['NE', 'OA'],
    commitment: 'Flexible, based on agreed contribution.',
    commitmentCat: 'flexible',
    locationCats: ['remote', 'state'],
    owner: 'Ngozi Eze',
    designed: true,
    place: 'Lagos',
    intro:
      'A digital learning initiative exploring more accessible ways for students to learn. The team is testing simple lesson tools with students in Lagos and is looking for people who care about how young people learn.',
    skillTags: ['Product design', 'Software engineering', 'Education research', 'Learning design'],
    about:
      'A Better Way to Learn explores how simple, low-cost lesson tools can help students who learn at different speeds. The team has spoken with students and teachers in Lagos and is now shaping a first version that works on a basic phone.',
    needs: [
      { title: 'Product Designer', detail: 'Shapes how students move through each lesson. A few hours a week.' },
      { title: 'Software Engineer', detail: 'Builds the first lesson tool that works on a basic phone. Flexible hours.' },
      { title: 'Education Researcher', detail: 'Runs short student interviews and turns them into clear findings. Weekends.' },
    ],
    team: [
      { slug: 'ngozi-eze', name: 'Ngozi Eze', initials: 'NE', role: 'Project owner' },
      { slug: 'obinna-adeyemi', name: 'Obinna Adeyemi', initials: 'OA', role: 'Learning designer' },
    ],
    progress: [
      { title: 'Student interviews in Lagos', detail: 'Held with a small group of students and teachers.' },
      { title: 'First lesson sketches', detail: 'Reviewed with two teachers. The next step is a simple prototype.' },
    ],
    working: {
      commitment: 'Flexible, based on agreed contribution',
      rhythm: 'A weekly check-in, with shared documents in between',
      location: 'Remote, with occasional meetings in Lagos',
      openTo: 'Individuals and small teams',
    },
    glanceLocation: 'Remote, with occasional meetings in Lagos',
    fit: 'Your product design experience could help this project make lessons easier to follow. Akines suggests it because you care about education and learning tools.',
  },
  {
    slug: 'voices-of-lagos',
    title: 'Voices of Lagos',
    stage: 'Building',
    type: 'Film',
    purpose: 'A documentary series capturing everyday stories from Lagos neighbourhoods.',
    roles: ['Cinematographer', 'Sound Designer', 'Documentary Editor'],
    skillCats: ['Film and sound'],
    teamCount: 3,
    avatars: ['TB', 'KO'],
    commitment: 'Weekends, over three months.',
    commitmentCat: 'weekend',
    locationCats: ['state'],
    owner: 'Tunde Bakare',
    designed: true,
    place: 'Lagos',
    intro:
      'A documentary series capturing everyday stories from Lagos neighbourhoods. The team has filmed first test shoots and is looking for people who can shoot, record and edit them into episodes.',
    skillTags: ['Filmmaking', 'Documentary', 'Sound design', 'Storytelling'],
    about:
      'Voices of Lagos follows ordinary people through a day in their own neighbourhood. The team has filmed short test shoots and written an outline for the first episode, and now needs a small crew to shape it into a series.',
    needs: [
      { title: 'Cinematographer', detail: 'Films the street and home scenes for each episode. Weekends.' },
      { title: 'Sound Designer', detail: 'Records and cleans the audio so every voice is easy to hear. Weekends.' },
      { title: 'Documentary Editor', detail: 'Cuts the footage into short episodes and agrees the story with the team. Flexible hours.' },
    ],
    team: [
      { name: 'Tunde Bakare', initials: 'TB', role: 'Project owner' },
      { name: 'Kehinde Olawale', initials: 'KO', role: 'Producer' },
      { name: 'Efe Okoro', initials: 'EO', role: 'Researcher' },
    ],
    progress: [
      { title: 'Test shoots in three neighbourhoods', detail: 'Short films made with local residents who agreed to be recorded.' },
      { title: 'First episode outline', detail: 'Reviewed with a local editor. The next step is a rough cut.' },
    ],
    working: {
      commitment: 'Weekends, over three months.',
      rhythm: 'A short call on Sunday evenings, with shared folders in between',
      location: 'On location in Lagos neighbourhoods',
      openTo: 'Individuals and small crews',
    },
    glanceLocation: 'On location in Lagos neighbourhoods',
    fit: 'Akines shows it because you saved it. The team needs film roles, so your product design experience may help most with how the series is presented.',
  },
  {
    // Closed: Figma shows only the "not looking for people right now" layout (17722:77401), so the detail fields stay empty
    slug: 'clean-water-mapping',
    title: 'Clean Water Mapping',
    stage: 'Ready to plan',
    type: 'Social impact',
    purpose: 'A community-led map of safe water points across Kaduna and Abuja.',
    roles: ['Field Researcher', 'GIS Analyst', 'Community Organiser'],
    skillCats: ['Research', 'Engineering', 'Community'],
    teamCount: 4,
    avatars: ['HY', 'SA'],
    commitment: 'About ten hours a month.',
    commitmentCat: 'month',
    locationCats: [],
    owner: 'Halima Yusuf',
    designed: true,
    closed: true,
    place: 'Kaduna',
    intro: 'A community-led map of safe water points across Kaduna and Abuja.',
    skillTags: [],
    about: 'A community-led map of safe water points across Kaduna and Abuja.',
    needs: [],
    team: [],
    progress: [],
    working: { commitment: 'About ten hours a month.', rhythm: '', location: 'Kaduna and Abuja', openTo: '' },
    glanceLocation: 'Kaduna and Abuja',
    fit: '',
  },
  {
    slug: 'market-women-ledger',
    title: 'Market Women Ledger',
    stage: 'Building',
    type: 'Application',
    purpose: 'A simple mobile ledger helping market traders record sales and savings.',
    roles: ['Mobile Developer', 'UX Researcher', 'Finance Advisor'],
    skillCats: ['Engineering', 'Research', 'Design'],
    teamCount: 2,
    avatars: ['AO', 'BN'],
    commitment: 'Flexible, based on agreed contribution.',
    commitmentCat: 'flexible',
    locationCats: ['remote'],
    owner: 'Amaka Okafor',
    designed: true,
    place: 'Enugu',
    intro:
      'A simple mobile ledger helping market traders record sales and savings. The team is building a first version and is looking for people who can shape it around how traders already work.',
    skillTags: ['Mobile development', 'User research', 'Financial inclusion', 'Small business'],
    about:
      'Market Women Ledger replaces paper notebooks with a simple phone app that records daily sales and savings. The team has spoken with traders about how they keep records today and is now building a first version.',
    needs: [
      { title: 'Mobile Developer', detail: 'Builds the first version of the ledger so it works on a basic phone. Flexible hours.' },
      { title: 'UX Researcher', detail: 'Runs short interviews with traders and turns them into clear findings. Weekends.' },
      { title: 'Finance Advisor', detail: 'Checks that the savings features are simple and safe for traders. A few hours a month.' },
    ],
    team: [
      { name: 'Amaka Okafor', initials: 'AO', role: 'Project owner' },
      { name: 'Bukola Ndukwe', initials: 'BN', role: 'Business analyst' },
    ],
    progress: [
      { title: 'Trader interviews', detail: 'Held with twelve market traders about how they record sales today.' },
      { title: 'First ledger screens', detail: 'Reviewed with three traders. The next step is a simple prototype.' },
    ],
    working: {
      commitment: 'Flexible, based on agreed contribution.',
      rhythm: 'Two short check-ins a week, with shared designs in between',
      location: 'Remote',
      openTo: 'Individuals and small teams',
    },
    glanceLocation: 'Remote',
    fit: 'Your product design experience could help this project make a mobile ledger simple for traders to use. Akines suggests it because the team needs user research and design thinking.',
  },
  {
    slug: 'stories-for-small-hands',
    title: 'Stories for Small Hands',
    stage: 'Exploring',
    type: 'Book',
    purpose: 'An illustrated book series helping young students learn kindness in Hausa and English.',
    roles: ['Illustrator', 'Hausa Translator', 'Children’s Book Editor'],
    skillCats: ['Design', 'Writing'],
    teamCount: 2,
    avatars: ['IO', 'MA'],
    commitment: 'Flexible, based on agreed contribution.',
    commitmentCat: 'flexible',
    locationCats: ['remote'],
    owner: 'Ifeoma Obi',
    designed: true,
    place: 'Kano',
    intro:
      'An illustrated book series helping young students learn kindness in Hausa and English. The team is exploring the first story and is looking for people to bring it to life.',
    skillTags: ['Illustration', 'Translation', 'Children’s books', 'Education'],
    about:
      'Stories for Small Hands is a series of short picture books that teach kindness through everyday moments. The team has drafted the first story in English and is exploring how to publish each book in both Hausa and English.',
    needs: [
      { title: 'Illustrator', detail: 'Draws the pictures for each page in a warm, simple style. Flexible hours.' },
      { title: 'Hausa Translator', detail: 'Writes the Hausa version so it reads naturally for young children. Weekends.' },
      { title: 'Children’s Book Editor', detail: 'Shapes the stories so they are clear and kind. A few hours a week.' },
    ],
    team: [
      { name: 'Ifeoma Obi', initials: 'IO', role: 'Project owner' },
      { name: 'Musa Aliyu', initials: 'MA', role: 'Storyteller' },
    ],
    progress: [
      { title: 'First story drafted', detail: 'Written in English and shared with two teachers.' },
      { title: 'Sample illustrations', detail: 'Three pages sketched. The next step is a Hausa version of the text.' },
    ],
    working: {
      commitment: 'Flexible, based on agreed contribution.',
      rhythm: 'A fortnightly review of drafts and illustrations',
      location: 'Remote, with occasional meetings in Kano',
      openTo: 'Individuals',
    },
    glanceLocation: 'Remote, with occasional meetings in Kano',
    fit: 'The team’s main needs are illustration, translation and editing. Your product design experience could still help with page layout. Akines shows it because the project is open to new people.',
  },
  {
    slug: 'clinic-queue',
    title: 'Clinic Queue',
    stage: 'Exploring',
    type: 'Application',
    purpose: 'A queue and appointment tool for busy primary health centres.',
    roles: ['Mobile Developer', 'Health Informatics Lead', 'UX Writer'],
    skillCats: ['Engineering', 'Writing', 'Research'],
    teamCount: 3,
    avatars: ['DA', 'EE'],
    commitment: 'Two evenings a week, for six weeks.',
    commitmentCat: 'week',
    locationCats: ['remote'],
    owner: 'Dayo Adebayo',
    designed: true,
    place: 'Ibadan',
    intro:
      'A queue and appointment tool for busy primary health centres. The team is exploring how it could work and is looking for people who can build, write and advise.',
    skillTags: ['Mobile development', 'Health informatics', 'UX writing', 'Public health'],
    about:
      'Clinic Queue helps patients know when to arrive and helps nurses see who is waiting. The team has watched how queues work at two primary health centres and is now exploring a first version.',
    needs: [
      { title: 'Mobile Developer', detail: 'Builds the first queue screen so it works on a basic phone. Flexible hours.' },
      { title: 'Health Informatics Lead', detail: 'Advises on how patient information should be handled with care. Two evenings a week.' },
      { title: 'UX Writer', detail: 'Writes short, clear messages for patients and nurses. A few hours a week.' },
    ],
    team: [
      { name: 'Dayo Adebayo', initials: 'DA', role: 'Project owner' },
      { name: 'Esther Eze', initials: 'EE', role: 'Clinic operations lead' },
      { name: 'Femi Alabi', initials: 'FA', role: 'Backend engineer' },
    ],
    progress: [
      { title: 'Clinic visits', detail: 'Observed how queues work at two primary health centres.' },
      { title: 'Queue flow sketched', detail: 'Reviewed with a clinic manager. The next step is a simple prototype.' },
    ],
    working: {
      commitment: 'Two evenings a week, for six weeks.',
      rhythm: 'Two evening sessions a week, with notes shared in between',
      location: 'Remote, with occasional clinic visits',
      openTo: 'Individuals and small teams',
    },
    glanceLocation: 'Remote, with occasional clinic visits',
    fit: 'Your product design experience could help this project make queues clear for patients and nurses. Akines suggests it because the team needs design and writing skills.',
  },
];

export const projectBySlug = (slug: string) => PROJECTS.find((p) => p.slug === slug);
export const DESIGNED_SLUG = 'a-better-way-to-learn';

/** Type chips of the Discover screen (first one is "All projects"). */
export const TYPE_CHIPS = ['Business', 'Application', 'Film', 'Research', 'Community', 'Book', 'Event', 'Course', 'Social impact'] as const;

/** Filters of Modal:More filters (17312:19924). `selected` is the state the frame shows. */
export const FILTER_GROUPS = [
  {
    key: 'stage',
    name: 'Project stage',
    description: 'Where the project is today',
    options: ['Just an idea', 'Exploring', 'Ready to plan', 'Building', 'Launching'],
    initial: ['Exploring'],
  },
  {
    key: 'looking',
    name: 'Looking for',
    description: 'Skills the project needs',
    options: ['Design', 'Engineering', 'Research', 'Writing', 'Film and sound', 'Community'],
    initial: [] as string[],
  },
  {
    key: 'commitment',
    name: 'Commitment',
    description: 'How much time it asks of you',
    options: ['A few hours a month', 'A few hours a week', 'Weekends', 'Full project'],
    initial: ['A few hours a week'],
  },
  {
    key: 'location',
    name: 'Location',
    description: 'Where the team works',
    options: ['Anywhere in Nigeria', 'My state', 'Remote'],
    initial: ['Anywhere in Nigeria'],
  },
] as const;
export type FilterKey = (typeof FILTER_GROUPS)[number]['key'];
export type FilterState = Record<FilterKey, string[]>;
export const initialFilters = (): FilterState => ({ stage: [], looking: [], commitment: [], location: [] });
/** What the modal shows the first time it opens (the selection drawn in the Figma frame). */
export const figmaFilters = (): FilterState => ({ stage: ['Exploring'], looking: [], commitment: ['A few hours a week'], location: ['Anywhere in Nigeria'] });

const COMMITMENT_BY_LABEL: Record<string, CommitmentCat> = {
  'A few hours a month': 'month',
  'A few hours a week': 'week',
  Weekends: 'weekend',
  'Full project': 'full',
};

export const filtersActive = (f: FilterState) =>
  f.stage.length > 0 || f.looking.length > 0 || f.commitment.length > 0 || (f.location.length > 0 && !f.location.includes('Anywhere in Nigeria'));

export const filterLabels = (f: FilterState): string[] => [
  ...f.stage,
  ...f.looking,
  ...f.commitment,
  ...(f.location.includes('Anywhere in Nigeria') ? [] : f.location),
];

/** Does a project pass the modal filters? Groups are combined with AND, options inside a group with OR. */
export function passesFilters(p: Project, f: FilterState): boolean {
  if (f.stage.length && !f.stage.includes(p.stage)) return false;
  if (f.looking.length && !f.looking.some((l) => p.skillCats.includes(l as SkillCat))) return false;
  if (f.commitment.length) {
    // "Flexible" projects adapt to any commitment
    const ok = p.commitmentCat === 'flexible' || f.commitment.some((c) => COMMITMENT_BY_LABEL[c] === p.commitmentCat);
    if (!ok) return false;
  }
  if (f.location.length && !f.location.includes('Anywhere in Nigeria')) {
    const ok = f.location.some((l) => (l === 'My state' ? p.locationCats.includes('state') : p.locationCats.includes('remote')));
    if (!ok) return false;
  }
  return true;
}

/** Text search over what the card shows. Returns a relevance score (0 = no match). */
export function searchScore(p: Project, q: string): number {
  const query = q.trim().toLowerCase();
  if (!query) return 1;
  const words = query.split(/\s+/);
  const fields: [string, number][] = [
    [p.title, 5],
    [p.purpose, 3],
    [p.roles.join(' '), 3],
    [p.type, 2],
    [p.stage, 2],
    [p.owner, 2],
    [p.place, 2],
    [p.commitment, 1],
  ];
  let total = 0;
  for (const w of words) {
    let best = 0;
    for (const [text, weight] of fields) if (text.toLowerCase().includes(w)) best = Math.max(best, weight);
    if (!best) return 0;
    total += best;
  }
  return total;
}

/* ---------------- people (12.7) ---------------- */

export type Person = {
  slug: string;
  name: string;
  first: string;
  pronoun: 'she' | 'he';
  role: string;
  place: string;
  /** Project the profile belongs to ("On this project"). */
  projectSlug: string;
  kind: 'owner' | 'team';
  headline: string;
  keySkills: string[];
  about: string;
  experience: { title: string; detail: string }[];
  skills: string[];
  interests: string[];
  preferences: { label: string; value: string }[];
  contributions: { title: string; detail: string }[];
  onProject: string;
  seeing: string;
  seeingLimited: string;
  limitedIntro: string;
  /** Portrait photo (public/images/app/collab-projects). */
  portrait: string;
};

export const PEOPLE: Person[] = [
  {
    slug: 'ngozi-eze',
    name: 'Ngozi Eze',
    first: 'Ngozi',
    pronoun: 'she',
    role: 'Product Designer',
    place: 'Lagos',
    projectSlug: 'a-better-way-to-learn',
    kind: 'owner',
    headline: 'I design simple tools that help students keep up in class. I started A Better Way to Learn to make lessons easier to follow on a basic phone.',
    keySkills: ['Product design', 'Education technology', 'User research'],
    about:
      'Ngozi designs learning tools for secondary school students in Lagos. She started A Better Way to Learn after seeing how many students fall behind when lessons are not built for the phones and data they have.',
    experience: [
      { title: 'Study tool for secondary school students', detail: 'Lead designer, education start-up in Lagos' },
      { title: 'Teacher feedback dashboard', detail: 'Product designer' },
      { title: 'Reading habits research', detail: 'Researcher and designer' },
    ],
    skills: ['Product design', 'Interaction design', 'User research', 'Prototyping'],
    interests: ['Access to education', 'Youth development', 'Inclusive design', 'Community learning'],
    preferences: [
      { label: 'Communication style', value: 'Short written updates and a weekly call' },
      { label: 'Preferred working rhythm', value: 'Weekly, with shared notes between calls' },
      { label: 'Availability', value: 'Open to new collaborators on A Better Way to Learn' },
      { label: 'Collaboration preferences', value: 'Shared documents and one live session each week' },
    ],
    contributions: [
      { title: 'Lesson sketch reviews', detail: 'Led two sessions with teachers. Shared with Ngozi’s consent.' },
      { title: 'Study tool for secondary school students', detail: 'Lead designer. Shared with Ngozi’s consent.' },
    ],
    onProject: 'Ngozi started A Better Way to Learn and is looking for a product designer, a software engineer and an education researcher.',
    seeing: 'Ngozi’s public profile and the details she shared on this project. Private information stays private.',
    seeingLimited: 'Ngozi chose to share fewer details. Private information stays private.',
    limitedIntro: 'Ngozi shares only a few details with other members. You can see her role on this project and the skills she lists.',
    portrait: '/images/app/collab-projects/ngozi-eze.jpg',
  },
  {
    slug: 'obinna-adeyemi',
    name: 'Obinna Adeyemi',
    first: 'Obinna',
    pronoun: 'he',
    role: 'Learning Designer',
    place: 'Abuja',
    projectSlug: 'a-better-way-to-learn',
    kind: 'team',
    headline: 'I turn classroom ideas into short, clear lessons. On A Better Way to Learn I shape how each lesson is written and tested with students.',
    keySkills: ['Learning design', 'Curriculum writing', 'Teacher training'],
    about:
      'Obinna has spent years writing lessons and training teachers in Abuja and Kaduna. He joined A Better Way to Learn to make sure every lesson is clear for students who learn at different speeds.',
    experience: [
      { title: 'Primary school reading programme', detail: 'Curriculum writer, Kaduna' },
      { title: 'Teacher training course', detail: 'Trainer and course designer' },
      { title: 'Literacy radio lessons', detail: 'Script writer' },
    ],
    skills: ['Learning design', 'Lesson writing', 'Teacher training', 'Assessment design'],
    interests: ['Early literacy', 'Teacher support', 'Low-data learning', 'Community education'],
    preferences: [
      { label: 'Communication style', value: 'Clear briefs and quick written replies' },
      { label: 'Preferred working rhythm', value: 'Two focused sessions each week' },
      { label: 'Availability', value: 'Part of the team, a few hours a week' },
      { label: 'Collaboration preferences', value: 'Shared documents and short voice notes' },
    ],
    contributions: [
      { title: 'Lesson structure for A Better Way to Learn', detail: 'Wrote the first three lesson outlines. Shared with Obinna’s consent.' },
      { title: 'Teacher guide', detail: 'Co-author. Shared with Obinna’s consent.' },
    ],
    onProject:
      'Obinna is on the A Better Way to Learn team as the learning designer. The project is looking for a product designer, a software engineer and an education researcher.',
    seeing: 'Obinna’s public profile and the details he shared on this project. Private information stays private.',
    seeingLimited: 'Obinna chose to share fewer details. Private information stays private.',
    limitedIntro: 'Obinna shares only a few details with other members. You can see his role on this project and the skills he lists.',
    portrait: '/images/app/collab-projects/obinna-adeyemi.jpg',
  },
];

export const personBySlug = (slug: string) => PEOPLE.find((p) => p.slug === slug);

/* ---------------- express interest (12.8) ---------------- */

export const TIME_OPTIONS = ['A few hours a week', 'Weekends only', 'Flexible'] as const;
export const OTHER_ROLE = 'Another way I can help';

/** Express interest exists only for A Better Way to Learn (Figma 12.8); on the other five details the button is inert. The form starts prefilled so Send interest works at once; clearing the role reaches the Figma "Express interest" frame. */
export const INTEREST_DEFAULTS: Record<string, { role: string; time: string; message: string }> = {
  'a-better-way-to-learn': {
    role: 'Product Designer',
    time: 'A few hours a week',
    message: 'I design simple learning tools and have worked with teachers in Ibadan. I can help shape how students move through each lesson.',
  },
};
export const interestDefaults = (slug: string) => INTEREST_DEFAULTS[slug] ?? INTEREST_DEFAULTS['a-better-way-to-learn'];

/** First name of the project owner ("Ngozi"). */
export const ownerFirst = (p: Project) => p.owner.split(' ')[0];
