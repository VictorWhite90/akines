'use client';

/** The questions of 12.2 Start a project: entry (A1), your idea (A2), your purpose (A3, Q1 to Q4), your progress (A4), your people (A5). */
import { useState } from 'react';
import { Button } from '@/ui';
import { asset } from '@/lib/assets';
import { BackLink, BuilderProgress, IcArrowRight, Notice, OptionGroup, QuestionProgress, StepHeading, TextField } from './parts';
import {
  IDEA_TYPES,
  NEEDS,
  PATHS,
  QUESTIONS,
  STAGES,
  type Answers,
  type Question,
  type StepId,
} from './flow-data';

export type StepProps = {
  answers: Answers;
  setAnswers: (fn: (a: Answers) => Answers) => void;
  go: (s: StepId) => void;
};

/* ------------------------------------------------------------------ A1 entry */
export function EntryStep({ go }: Pick<StepProps, 'go'>) {
  return (
    <section className="cs-split cs-entry">
      <div className="cs-split__main">
        <div className="cs-split__text">
          <p className="cs-eyebrow">Start something meaningful</p>
          <h1 className="cs-hero" id="cs-entry-title" tabIndex={-1} data-m="words">
            Every meaningful project begins somewhere.
          </h1>
          <p className="cs-hero__support">
            Bring an idea, a question or something you’ve been thinking about. We’ll help you shape it into a project and find the people who can bring it to life.
          </p>
          <div className="cs-btnrow">
            <Button iconRight={<IcArrowRight />} onClick={() => go('idea')}>
              Start with my idea
            </Button>
            <Button variant="secondary" href={PATHS.collaborators}>
              Explore collaborators
            </Button>
          </div>
          <p className="cs-note">You don’t need to have everything figured out.</p>
        </div>
      </div>
      {/* Figma 17212:12216 "Idea photo" (A1 entry, right column 605x762) */}
      <div className="cs-split__photo" data-m="frame">
        <img className="cover cs-photo" src={asset('/images/app/collab-start/start-idea.jpg')} loading="lazy" decoding="async" alt="" />
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ A2 your idea */
export function IdeaStep({ answers, setAnswers, go }: StepProps) {
  const [touched, setTouched] = useState(false);
  const typeOk = Boolean(answers.type);
  const ideaOk = answers.idea.trim().length > 0;
  const valid = typeOk && ideaOk;
  return (
    <section className="cs-col">
      <div className="cs-top">
        <BuilderProgress step={1} />
        <StepHeading
          eyebrow="01 / Your idea"
          title="What would you like to bring to life?"
          support="It can be something you’ve been imagining, something you’re already building or something you want to explore with others."
        />
      </div>
      <OptionGroup
        label="Type of project"
        deselectable
        items={IDEA_TYPES}
        value={answers.type ? [answers.type] : []}
        onChange={(v) => setAnswers((a) => ({ ...a, type: v[0] ?? '' }))}
      />
      {!typeOk ? (
        <Notice title="Every idea is different.">Describe what you’re imagining and we’ll help you find the right direction.</Notice>
      ) : null}
      <TextField
        label="Tell us about your idea."
        hint="A few sentences are enough to get started."
        placeholder="I’ve been thinking about creating..."
        value={answers.idea}
        onChange={(idea) => setAnswers((a) => ({ ...a, idea }))}
        onBlur={() => setTouched(true)}
        error={touched && !ideaOk ? 'Write a short message to continue.' : undefined}
        min={120}
      />
      {!ideaOk ? <Notice title="Let’s start with what you have.">A sentence, a question or a rough idea is enough to begin.</Notice> : null}
      <div className="cs-actions">
        <BackLink onClick={() => go('entry')} />
        <Button disabled={!valid} iconRight={valid ? <IcArrowRight /> : undefined} onClick={() => go('q1')}>
          Continue
        </Button>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ A3 your purpose */
const QN = { q1: 1, q2: 2, q3: 3, q4: 4 } as const;
const prevOf = (q: Question['id']): StepId => (q === 'q1' ? 'idea' : (('q' + (QN[q] - 1)) as StepId));
const nextOf = (q: Question['id']): StepId => (q === 'q4' ? 'stage' : (('q' + (QN[q] + 1)) as StepId));

export function QuestionStep({ qid, answers, setAnswers, go }: StepProps & { qid: Question['id'] }) {
  const q = QUESTIONS.find((x) => x.id === qid)!;
  const n = QN[qid];
  const earlier = QUESTIONS.filter((x) => QN[x.id] < n && answers.q[x.id].trim());
  const next = () => go(nextOf(qid));
  return (
    <section className="cs-col">
      <div className="cs-top">
        <BuilderProgress step={2} />
        <StepHeading
          eyebrow="02 / Your purpose"
          title="Why does this matter to you?"
          support="Help us understand the problem, the people it matters to and the change you hope to make."
        />
      </div>
      <QuestionProgress n={n} />
      {earlier.length ? (
        <ul className="cs-answered" aria-label="Your earlier answers">
          {earlier.map((e) => (
            <li key={e.id} className="cs-answered__row">
              <span className="cs-answered__label">{e.label}</span>
              <span className="cs-answered__text">{answers.q[e.id]}</span>
              <Button variant="link" className="cs-answered__edit" onClick={() => go(e.id)} aria-label={`Edit your answer: ${e.label}`}>
                Edit
              </Button>
            </li>
          ))}
        </ul>
      ) : null}
      <div className="cs-question">
        <h2 className="cs-question__title">{q.title}</h2>
        <TextField
          label="Your answer"
          hint="Add as much or as little as you like. You can skip this and come back later."
          placeholder={q.placeholder}
          value={answers.q[qid]}
          onChange={(v) => setAnswers((a) => ({ ...a, q: { ...a.q, [qid]: v } }))}
          min={144}
        />
      </div>
      <div className="cs-actions">
        <BackLink onClick={() => go(prevOf(qid))} />
        <div className="cs-actions__right">
          <Button variant="link" onClick={next}>
            Skip for now
          </Button>
          <Button iconRight={<IcArrowRight />} onClick={next}>
            Continue
          </Button>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ A4 your progress */
export function StageStep({ answers, setAnswers, go }: StepProps) {
  const valid = Boolean(answers.stage);
  return (
    <section className="cs-col">
      <div className="cs-top">
        <BuilderProgress step={3} />
        <StepHeading eyebrow="03 / Your progress" title="Where are you with this idea?" support="Every project starts somewhere. Tell us where yours stands today." />
      </div>
      <OptionGroup
        label="Where the project stands"
        items={STAGES}
        value={answers.stage ? [answers.stage] : []}
        onChange={(v) => setAnswers((a) => ({ ...a, stage: v[0] ?? '' }))}
      />
      <div className="cs-actions">
        <BackLink onClick={() => go('q4')} />
        <Button disabled={!valid} iconRight={valid ? <IcArrowRight /> : undefined} onClick={() => go('people')}>
          Continue
        </Button>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ A5 your people */
export function PeopleStep({ answers, setAnswers, go }: StepProps) {
  const valid = answers.needs.length > 0;
  return (
    <section className="cs-col">
      <div className="cs-top">
        <BuilderProgress step={4} />
        <StepHeading
          eyebrow="04 / Your people"
          title="What would help you move forward?"
          support="Tell us what you need. We’ll help you identify the people, skills and resources that could make a difference."
        />
      </div>
      <OptionGroup
        multi
        label="What would help"
        items={NEEDS}
        wide={['collaborators']}
        value={answers.needs}
        onChange={(needs) => setAnswers((a) => ({ ...a, needs: NEEDS.filter((x) => needs.includes(x.id)).map((x) => x.id) }))}
      />
      <div className="cs-actions">
        <BackLink onClick={() => go('stage')} />
        <Button disabled={!valid} iconRight={valid ? <IcArrowRight /> : undefined} onClick={() => go('workspace')}>
          Prepare my project brief
        </Button>
      </div>
    </section>
  );
}
