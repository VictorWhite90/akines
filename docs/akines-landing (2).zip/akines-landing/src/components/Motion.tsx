'use client';

import { useEffect } from 'react';
import { initMotion } from '@/lib/motion';
import { IS_PREVIEW } from '@/lib/nav';

/**
 * Starts scroll reveals, the hero scrub and eased anchor scrolling (see src/lib/motion.ts). Renders nothing.
 * Mount it with a `key` that changes with the route so it starts again on a new screen.
 */
export function Motion() {
  useEffect(() => initMotion({ updateHash: !IS_PREVIEW }), []);
  return null;
}
