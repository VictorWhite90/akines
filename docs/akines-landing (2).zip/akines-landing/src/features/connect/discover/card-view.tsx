'use client';

/**
 * One For you card of any kind (person, circle, artwork, project / studio visit / story / event). Used by the For you block of Discover
 * (ForYou.tsx) and by the pages that list the same cards (For you all, Interest, Events; see lists.tsx). The markup is in cards.tsx.
 */
import type { ForYouCard, ForYouFilter } from './data';
import { ArtworkCard, CircleCard, DiscoverCard, PersonCard } from './cards';
import { useDiscover } from './state';

export function CardView({ card, filter, reveal }: { card: ForYouCard; filter: ForYouFilter; reveal: boolean }) {
  const d = useDiscover();
  const common = { filter, reveal };
  switch (card.kind) {
    case 'person':
      return <PersonCard card={card} requested={d.isRequested(card.id)} {...common} />;
    case 'circle':
      return <CircleCard card={card} joined={d.isJoined(card.id)} {...common} />;
    case 'artwork':
      return <ArtworkCard card={card} {...common} />;
    default:
      return <DiscoverCard card={card} {...common} />;
  }
}
