import { placeholderRoutes } from '@/features/placeholder-routes';

/** Section 14 EXPLORE: placeholder pages (Shop Art, Studio Visits, Stories and Legacy). */
export const routes = placeholderRoutes('explore');
