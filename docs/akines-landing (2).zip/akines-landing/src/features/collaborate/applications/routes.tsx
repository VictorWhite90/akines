import type { RouteDef } from '@/routes.types';
import { DeclinedRoute, ErrorRoute, JoinedRoute, LoadingRoute, NotSelectedRoute, OfferRoute, PickTimeRoute, RequestRoute, ShortlistedRoute, TalkRoute, WithdrawnRoute } from './Requests';
import { REQUEST_PATHS } from './paths';

// 12.44 APPLICATION STATUS (applicant, after "Interest sent"). Paths follow the Figma browser tabs:
// /collaborate/projects/requests/a-better-way-to-learn (+ /time, /talk, /offer, /joined, /declined).
// The base path shows the stage the request is at (Pending until something changes it). Frames without a tail of their own
// (Shortlisted, Not selected, Withdrawn, Loading, Could not load) get entry paths: /shortlisted, /not-selected, /withdrawn, /state-loading, /state-error.
// Modal:Accept offer, Modal:Decline offer and the two toasts open from the Offer received page and the actions on it.
const nav = { page: 'collaborate', tab: 'Discover Projects' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

export const routes: RouteDef[] = [
  def(REQUEST_PATHS.base, 'Your request', RequestRoute),
  def(REQUEST_PATHS.shortlisted, 'Your request', ShortlistedRoute),
  def(REQUEST_PATHS.time, 'Pick a time', PickTimeRoute),
  def(REQUEST_PATHS.talk, 'Talk booked', TalkRoute),
  def(REQUEST_PATHS.offer, 'Offer from Ngozi', OfferRoute),
  def(REQUEST_PATHS.joined, 'You are on the team', JoinedRoute),
  def(REQUEST_PATHS.declined, 'Offer declined', DeclinedRoute),
  def(REQUEST_PATHS.notSelected, 'Your request', NotSelectedRoute),
  def(REQUEST_PATHS.withdrawn, 'Interest withdrawn', WithdrawnRoute),
  def(REQUEST_PATHS.stateLoading, 'Your request', LoadingRoute),
  def(REQUEST_PATHS.stateError, 'Your request', ErrorRoute),
];
