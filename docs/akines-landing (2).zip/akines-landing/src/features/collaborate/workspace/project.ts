import { usePath } from '@/lib/nav';
import { ART as ART_HEADER, CAREER as CAREER_HEADER, type HeaderProject } from '../project-header/data';
import { BASE, MEMBERS, PATHS, PROJECT_PATH, type Member } from './data';

/**
 * Which project a project page belongs to. Two projects have the full set of project pages: Career Guidance for Everyone
 * ("career", the original sample) and Adire Stories ("adire", the Digital Art project). The project is read from the path
 * (everything under /collaborate/my-projects/adire-stories is Adire Stories), so a page component needs no prop and no
 * provider: `useProject()` gives it the right header, people, navigation targets and routes root.
 */

export type ProjectKey = 'career' | 'adire';

/** 'studio' was removed 5 Nov 2026 (its page is commented out). 'reflection' and 'launch' were removed the same day (files in _trash). */
export type NavKey = 'overview' | 'tasks' | 'workspace' | 'conversations' | 'files' | 'decisions' | 'team' | 'agreements';

/**
 * The project navigation (Figma "Project Nav" 17352:14054): one list for the Project nav, the Workspace project menu and the sample
 * project pages. Hidden items are not drawn and do not take a number; their pages still exist and open from a link or the address bar.
 */
export const NAV_ITEMS: { label: string; key: NavKey; hidden?: boolean }[] = [
  { label: 'Overview', key: 'overview' },
  { label: 'Tasks', key: 'tasks' },
  { label: 'Workspace', key: 'workspace' },
  { label: 'Conversations', key: 'conversations' },
  { label: 'Files', key: 'files' },
  { label: 'Decisions', key: 'decisions' },
  { label: 'Team', key: 'team' },
  { label: 'Agreements', key: 'agreements' },
  // Reflection and Launch removed 5 Nov 2026:
  // { label: 'Reflection', key: 'reflection', hidden: true },
  // { label: 'Launch', key: 'launch', hidden: true },
];
/** The items that are drawn, numbered 01 to 08 in this order. */
export const VISIBLE_NAV_ITEMS = NAV_ITEMS.filter((i) => !i.hidden);

export const ART_SLUG = 'adire-stories';
export const ART_PATH = `${BASE}/${ART_SLUG}`;

/** The folder every page of a project lives under (the Overview is the folder itself). */
export const PROJECT_ROOT: Record<ProjectKey, string> = { career: PROJECT_PATH, adire: ART_PATH };

const navPaths = (root: string): Record<NavKey, string> => ({
  overview: root,
  tasks: `${root}/tasks`,
  workspace: `${root}/workspace`,
  conversations: `${root}/conversations`,
  files: `${root}/files`,
  decisions: `${root}/decisions`,
  team: `${root}/team`,
  agreements: `${root}/agreements`,
  // reflection: `${root}/reflection`, launch: `${root}/launch` (removed 5 Nov 2026)
});

/** The page behind every item of the project navigation, per project (the Project nav and the Workspace Project menu). */
export const NAV_PATHS: Record<ProjectKey, Record<NavKey, string>> = {
  career: {
    overview: PATHS.overview,
    tasks: PATHS.tasks,
    workspace: PATHS.workspace,
    conversations: PATHS.conversations,
    files: PATHS.files,
    decisions: PATHS.decisions,
    team: PATHS.team,
    agreements: PATHS.agreements,
    // reflection and launch removed 5 Nov 2026
  },
  adire: navPaths(ART_PATH),
};

export const projectKeyOf = (path: string): ProjectKey => (path === ART_PATH || path.startsWith(`${ART_PATH}/`) ? 'adire' : 'career');

/** The people of Adire Stories, same shape and order as MEMBERS (owner first, then three members with a presence). */
export const ART_MEMBERS: Member[] = [
  { initials: 'KA', name: 'Kemi Adeyemi', role: 'Owner' },
  { initials: 'AO', name: 'Amara Obi', role: 'Illustrator', presence: 'available' },
  { initials: 'AB', name: 'Ayo Bello', role: 'Colour Artist', presence: 'working' },
  { initials: 'YD', name: 'Yusuf Danjuma', role: 'Textile Historian', presence: 'away' },
];

/** Career initials of the members the context panels name, and who stands in for them on Adire Stories (by position). */
export const MEMBER_STAND_IN: Record<string, string> = { AO: 'AO', TA: 'AB', NE: 'YD' };

/** Copy of the context blocks that repeat on several pages (Upcoming session, Unresolved decisions). */
export const CONTEXT_COPY: Record<ProjectKey, { session: { title: string; when: string; people: string }; decision: { title: string; status: string } }> = {
  career: {
    session: { title: 'Prototype review', when: 'Thursday, 4:00 PM, 45 minutes', people: 'With Adaeze, Tobi and Ngozi' },
    decision: { title: 'Choose the onboarding approach', status: 'Awaiting acknowledgement' },
  },
  adire: {
    session: { title: 'Colour review', when: 'Thursday, 4:00 PM, 45 minutes', people: 'With Amara, Ayo and Yusuf' },
    decision: { title: 'Choose the headwrap palette', status: 'Awaiting acknowledgement' },
  },
};

export const HEADERS: Record<ProjectKey, HeaderProject> = { career: CAREER_HEADER, adire: ART_HEADER };
export const MEMBERS_OF: Record<ProjectKey, Member[]> = { career: MEMBERS, adire: ART_MEMBERS };

/** The project of the page being shown: its key, header, people, navigation targets and routes root. */
export function useProject() {
  const key = projectKeyOf(usePath());
  return { key, root: PROJECT_ROOT[key], nav: NAV_PATHS[key], header: HEADERS[key], members: MEMBERS_OF[key], context: CONTEXT_COPY[key] };
}
export type ProjectInfo = ReturnType<typeof useProject>;
