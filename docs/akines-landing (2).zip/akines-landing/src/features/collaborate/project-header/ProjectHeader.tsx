'use client';

import '../workspace/workspace.css';
import './project-header.css';
import { createContext, useContext, useEffect, useRef, useState, type RefObject } from 'react';
import { useNav, usePath } from '@/lib/nav';
import { Button, IconButton, toast } from '@/ui';
import { PATHS } from '../workspace/data';
import { ARCHIVE_MODAL, CAREER, EDIT_MODAL, LEAVE_MODAL, PREFERENCES_MODAL, type HeaderProject } from './data';
import { BellIcon, SlidersIcon, SwitcherIcon } from './icons';
import { NotificationsMenu, SettingsMenu, SwitcherMenu } from './menus';
import { ArchiveModal, EditDetailsModal, LeaveModal, PreferencesModal } from './modals';
import { ProjectAI } from './ProjectAI';
import { headerStore, headerUi, useHeaderState } from './store';

/**
 * Project header (Figma "Project header" 17352, with the overlays of 12.25): the project name and phase, the project
 * switcher, team pulse and next milestone, the notifications bell, Create AI and the project settings. It is the header of
 * every project page (WorkspaceFrame renders it) and of the sample projects (12.26), where only the switcher is wired.
 */

/** The state frames of 12.25 and 12.26 open one overlay at once (the "state-" routes provide this). */
export type HeaderInitial = 'switcher' | 'notifications' | 'notifications-read' | 'settings' | 'ai' | 'ai-thinking' | 'ai-answer' | 'edit' | 'edit-saved' | 'archive' | 'leave' | 'prefs' | 'prefs-saved';
export const HeaderInitialContext = createContext<HeaderInitial | null>(null);

/** The toast of a "state-" frame stays longer so it can be looked at (same as Conversations). */
const STATE_TOAST_MS = 8000;

type Menu = 'switcher' | 'notifications' | 'settings' | null;
type ModalName = 'edit' | 'archive' | 'leave' | 'prefs' | null;

const Dot = ({ tone, size = 8 }: { tone: 'accent' | 'green'; size?: number }) => <i className={`cw-dot cw-dot--${tone}`} style={{ ['--cw-dot' as string]: `${size}px` }} aria-hidden="true" />;

/** Moves focus back to the control that opened an overlay (after the exit animation has started). */
const focusLater = (ref: RefObject<HTMLElement | null>) => requestAnimationFrame(() => ref.current?.focus({ preventScroll: true }));

export function ProjectHeader({ project = CAREER, wired = true }: { project?: HeaderProject; /** Only the project switcher works on the sample projects (Figma 12.26). */ wired?: boolean }) {
  const initial = useContext(HeaderInitialContext);
  const nav = useNav();
  const path = usePath();
  const { details, open: openToCollaborators, prefs, unread } = useHeaderState();
  const isCareer = project.slug === CAREER.slug;
  const name = isCareer ? details.name : project.name;

  const [menu, setMenu] = useState<Menu>(initial === 'switcher' ? 'switcher' : initial === 'notifications' || initial === 'notifications-read' ? 'notifications' : initial === 'settings' ? 'settings' : null);
  const [modal, setModal] = useState<ModalName>(initial === 'edit' ? 'edit' : initial === 'archive' ? 'archive' : initial === 'leave' ? 'leave' : initial === 'prefs' ? 'prefs' : null);
  const [ai, setAi] = useState(initial === 'ai' || initial === 'ai-thinking' || initial === 'ai-answer');

  const switchRef = useRef<HTMLButtonElement>(null);
  const bellRef = useRef<HTMLButtonElement>(null);
  const settingsRef = useRef<HTMLButtonElement>(null);
  const aiRef = useRef<HTMLButtonElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const refs = { switcher: switchRef, notifications: bellRef, settings: settingsRef };

  const toggle = (m: Exclude<Menu, null>) => setMenu((cur) => (cur === m ? null : m));
  const closeMenu = (m: Exclude<Menu, null>) => (returnFocus = true) => {
    setMenu((cur) => (cur === m ? null : cur));
    if (returnFocus) focusLater(refs[m]);
  };

  // the state frames that show a toast or the read notifications
  useEffect(() => {
    if (initial === 'notifications-read') headerStore.markAllRead();
    if (initial === 'edit-saved') toast.show({ message: EDIT_MODAL.saved, actionLabel: 'Undo', duration: STATE_TOAST_MS });
    if (initial === 'prefs-saved') toast.show({ message: PREFERENCES_MODAL.saved, actionLabel: 'Undo', duration: STATE_TOAST_MS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // "Edit project details" and "Open project settings" on the Overview open the same overlays as the header buttons
  useEffect(() => {
    if (!wired) return;
    return headerUi.subscribe((r) => {
      if (r === 'edit') setModal('edit');
      else setMenu('settings');
    });
  }, [wired]);

  const saveDetails = (next: typeof details) => {
    const before = headerStore.get().details;
    headerStore.saveDetails(next);
    setModal(null);
    toast.show({ message: EDIT_MODAL.saved, actionLabel: 'Undo', duration: 2500, onAction: () => headerStore.saveDetails(before) });
  };
  const savePrefs = (next: typeof prefs) => {
    const before = headerStore.get().prefs;
    headerStore.savePrefs(next);
    setModal(null);
    toast.show({ message: PREFERENCES_MODAL.saved, actionLabel: 'Undo', duration: 2500, onAction: () => headerStore.savePrefs(before) });
  };
  // Archive and Leave go to My projects and show the toast there. Undo returns to the page the person left
  // (the design sends Undo to Conversations, a leftover of the Conversations toast).
  const leaveTo = (message: string) => {
    const origin = path;
    setModal(null);
    nav.push(PATHS.list);
    toast.show({ message, actionLabel: 'Undo', duration: 2500, onAction: () => nav.push(origin) });
  };

  const unreadCount = wired ? unread.length : 1;
  const bellLabel = unreadCount > 0 ? `Project notifications, ${unreadCount} unread` : 'Project notifications';

  return (
    <div className="cw-ph">
      <div className="cw-ph__left">
        <p className="cw-ph__name">{name}</p>
        <span className="cw-pill">
          <Dot tone="accent" />
          {project.phase}
        </span>
        <IconButton ref={switchRef} variant="outline" label="Switch project" aria-haspopup="menu" aria-expanded={menu === 'switcher'} onClick={() => toggle('switcher')}>
          <SwitcherIcon />
        </IconButton>
      </div>
      <div className="cw-ph__mid">
        <div className="cw-ph__stat">
          <span className="cw-ph__lab">TEAM PULSE</span>
          <span className="cw-ph__val">
            <Dot tone="green" />
            {project.pulse}
          </span>
        </div>
        <span className="cw-ph__div" aria-hidden="true" />
        <div className="cw-ph__stat">
          <span className="cw-ph__lab">NEXT MILESTONE</span>
          <span className="cw-ph__val">{project.nextMilestone}</span>
        </div>
      </div>
      <div className="cw-ph__right" ref={rightRef}>
        <IconButton ref={bellRef} variant="outline" label={bellLabel} aria-haspopup={wired ? 'dialog' : undefined} aria-expanded={wired ? menu === 'notifications' : undefined} onClick={wired ? () => toggle('notifications') : undefined}>
          <BellIcon />
          {unreadCount > 0 ? <i className="cw-ibtn__dot" aria-hidden="true" /> : null}
        </IconButton>
        <Button ref={aiRef} variant="secondary" aria-haspopup={wired ? 'dialog' : undefined} aria-expanded={wired ? ai : undefined} onClick={wired ? () => setAi(true) : undefined}>
          Create AI
        </Button>
        <IconButton ref={settingsRef} variant="outline" label="Project settings" aria-haspopup={wired ? 'menu' : undefined} aria-expanded={wired ? menu === 'settings' : undefined} onClick={wired ? () => toggle('settings') : undefined}>
          <SlidersIcon />
        </IconButton>
      </div>

      <SwitcherMenu open={menu === 'switcher'} onClose={closeMenu('switcher')} triggerRef={switchRef} currentSlug={project.slug} currentName={name} />

      {wired ? (
        <>
          <NotificationsMenu
            open={menu === 'notifications'}
            onClose={closeMenu('notifications')}
            triggerRef={bellRef}
            edgeRef={rightRef}
            projectName={name}
            unread={unread}
            onPreferences={() => setModal('prefs')}
          />
          <SettingsMenu
            open={menu === 'settings'}
            onClose={closeMenu('settings')}
            triggerRef={settingsRef}
            edgeRef={rightRef}
            openToCollaborators={openToCollaborators}
            onToggleOpen={headerStore.setOpen}
            onEdit={() => setModal('edit')}
            onArchive={() => setModal('archive')}
            onLeave={() => setModal('leave')}
          />
          <ProjectAI
            open={ai}
            onClose={() => {
              setAi(false);
              focusLater(aiRef);
            }}
            projectName={name}
            initialView={initial === 'ai-thinking' ? 'thinking' : initial === 'ai-answer' ? 'answer' : 'start'}
            holdThinking={initial === 'ai-thinking'}
          />
          <EditDetailsModal open={modal === 'edit'} onClose={() => setModal(null)} details={details} onSave={saveDetails} />
          <ArchiveModal open={modal === 'archive'} onClose={() => setModal(null)} name={name} onConfirm={() => leaveTo(ARCHIVE_MODAL.done)} />
          <LeaveModal open={modal === 'leave'} onClose={() => setModal(null)} onConfirm={() => leaveTo(LEAVE_MODAL.done)} />
          <PreferencesModal open={modal === 'prefs'} onClose={() => setModal(null)} name={name} prefs={prefs} onSave={savePrefs} />
        </>
      ) : null}
    </div>
  );
}
