'use client';

/** Shared helpers for the kit: class joining, tiny icons, presence (mount while animating out) and the overlay layer stack. */
import { useEffect, useRef, useState, type SVGProps } from 'react';
import { useReducedMotion } from '@/lib/hooks';

export const cx = (...parts: Array<string | false | null | undefined | 0>) => parts.filter(Boolean).join(' ');

/* ---------- Icons (24 px grid, 1.5 stroke, currentColor: the Figma icon look) ---------- */
type IconProps = Omit<SVGProps<SVGSVGElement>, 'children'> & { size?: number };
const base = (size: number | undefined, p: SVGProps<SVGSVGElement>) => ({
  width: size ?? 20,
  height: size ?? 20,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.5,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  'aria-hidden': true,
  focusable: false as const,
  ...p,
});
export const IconCheck = ({ size, ...p }: IconProps) => (
  <svg {...base(size, p)}>
    <path d="M5 12.5l4.5 4.5L19 7.5" />
  </svg>
);
export const IconClose = ({ size, ...p }: IconProps) => (
  <svg {...base(size, p)}>
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
export const IconChevronDown = ({ size, ...p }: IconProps) => (
  <svg {...base(size, p)}>
    <path d="M6 9.5l6 6 6-6" />
  </svg>
);
export const IconAlert = ({ size, ...p }: IconProps) => (
  <svg {...base(size, p)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7.5v5.5M12 16.2v.1" />
  </svg>
);
export const IconCircleCheck = ({ size, ...p }: IconProps) => (
  <svg {...base(size, p)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M8.5 12.2l2.5 2.5 4.5-4.7" />
  </svg>
);
export const IconRefresh = ({ size, ...p }: IconProps) => (
  <svg {...base(size, p)}>
    <path d="M20 12a8 8 0 1 1-2.6-5.9" />
    <path d="M20 4.5v4.6h-4.6" />
  </svg>
);

/* ---------- Presence: keeps a closing overlay mounted until its exit animation has played ---------- */
export function usePresence(open: boolean, exitMs: number) {
  const reduced = useReducedMotion();
  const [mounted, setMounted] = useState(open);
  useEffect(() => {
    if (open) {
      setMounted(true);
      return;
    }
    const t = window.setTimeout(() => setMounted(false), reduced ? 0 : exitMs);
    return () => window.clearTimeout(t);
  }, [open, exitMs, reduced]);
  return { mounted: open || mounted, state: open ? ('open' as const) : ('closed' as const) };
}

/* ---------- Layer stack: Escape and the Tab trap act only on the topmost overlay (modal, drawer, menu) ---------- */
type Layer = { id: number };
const layers: Layer[] = [];
let layerId = 0;
const isTop = (l: Layer) => layers[layers.length - 1] === l;

/** Registers an overlay while `active` and returns whether it is the topmost one. */
export function useLayer(active: boolean) {
  const layer = useRef<Layer | null>(null);
  useEffect(() => {
    if (!active) return;
    const l = { id: ++layerId };
    layer.current = l;
    layers.push(l);
    return () => {
      const i = layers.indexOf(l);
      if (i >= 0) layers.splice(i, 1);
      layer.current = null;
    };
  }, [active]);
  return () => (layer.current ? isTop(layer.current) : false);
}

/** Calls `onEscape` when Escape is pressed and this layer is on top. */
export function useEscape(active: boolean, onEscape: () => void) {
  const top = useLayer(active);
  const fn = useRef(onEscape);
  fn.current = onEscape;
  const topRef = useRef(top);
  topRef.current = top;
  useEffect(() => {
    if (!active) return;
    const key = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || !topRef.current()) return;
      e.preventDefault();
      e.stopPropagation();
      fn.current();
    };
    document.addEventListener('keydown', key);
    return () => document.removeEventListener('keydown', key);
  }, [active]);
  return top;
}

export const TABBABLE =
  'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]), [contenteditable="true"]';

export function tabbables(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(TABBABLE)).filter(
    (el) => !el.hasAttribute('hidden') && el.getAttribute('aria-hidden') !== 'true' && (el.offsetWidth > 0 || el.offsetHeight > 0 || el === document.activeElement),
  );
}

/** Focus trap for a dialog: moves focus in on open, wraps Tab, restores focus on close. Needs the layer's `isTop`. */
export function useFocusTrap(active: boolean, ref: React.RefObject<HTMLElement | null>, isTop: () => boolean) {
  const topRef = useRef(isTop);
  topRef.current = isTop;
  useEffect(() => {
    if (!active) return;
    const root = ref.current;
    if (!root) return;
    const previous = document.activeElement as HTMLElement | null;
    const pick = () => {
      const auto = root.querySelector<HTMLElement>('[data-autofocus], [autofocus]');
      if (auto) return auto;
      const body = root.querySelector<HTMLElement>('[data-k-body]');
      const inBody = body ? tabbables(body)[0] : undefined;
      return inBody ?? tabbables(root)[0] ?? root;
    };
    pick().focus({ preventScroll: true });
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Tab' || !topRef.current()) return;
      const list = tabbables(root);
      if (!list.length) {
        e.preventDefault();
        root.focus();
        return;
      }
      const first = list[0];
      const last = list[list.length - 1];
      const cur = document.activeElement as HTMLElement | null;
      if (!cur || !root.contains(cur)) {
        e.preventDefault();
        (e.shiftKey ? last : first).focus();
      } else if (e.shiftKey && (cur === first || cur === root)) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && cur === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      if (previous && previous.isConnected) previous.focus({ preventScroll: true });
    };
  }, [active, ref]);
}
