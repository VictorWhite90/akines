/**
 * Copy and sample rows of the three lists behind the Collaborate Home count tiles. Taken word for word from the Figma frames
 * (V2 Desktop, section 12): 12.48 Decisions awaiting you (17972:150992, Empty 17972:160702, Loading 17972:161086),
 * 12.49 Introduction requests (17974:131855, Accepted 17974:132361, Not now 17974:132650, Empty 17974:132922, Loading 17974:133310,
 * Toast:Introduction accepted 17974:166519, Toast:Response sent 17974:166526) and 12.50 Tasks due this week (17974:155481,
 * Empty 17974:155938, Loading 17974:156322). No 'use client' here: the route table reads the paths on the server.
 */
import { PATHS } from '../workspace/data';
import { DP } from '../decisions/data';
import { PATHS as FLOW } from '../start/flow-data';

/** The paths are the address bar of the Figma frames. The "state-" paths are frames with no natural trigger (see routes.tsx). */
export const OL = {
  home: PATHS.home,
  decisions: '/collaborate/decisions',
  decisionsEmpty: '/collaborate/decisions/state-empty',
  decisionsLoading: '/collaborate/decisions/state-loading',
  introductions: '/collaborate/introductions',
  introductionsAccepted: '/collaborate/introductions/state-accepted',
  introductionsNotNow: '/collaborate/introductions/state-not-now',
  introductionsEmpty: '/collaborate/introductions/state-empty',
  introductionsLoading: '/collaborate/introductions/state-loading',
  tasks: '/collaborate/tasks',
  tasksEmpty: '/collaborate/tasks/state-empty',
  tasksLoading: '/collaborate/tasks/state-loading',
  /** 12.46 Open calls, built with the host pages of the applicants area. */
  openCalls: '/collaborate/open-calls',
  /** Home Loading (17974:166533) and the zero My projects list of the empty Home tiles. */
  homeLoading: '/collaborate/state-loading',
  myProjectsEmpty: `${PATHS.list}/state-empty`,
} as const;

/** The back link of the three lists. */
export const BACK = { label: 'Collaborate Home', href: OL.home };

/* ------------------------------------------------------------------ 12.48 Decisions awaiting you */

export const DECISIONS_PAGE = {
  eyebrow: 'DECISIONS',
  title: 'Decisions awaiting you.',
  lead: 'Choices your teams are waiting on you for, across all your projects.',
  tab: 'Awaiting you',
  empty: {
    headline: 'Nothing is waiting for your decision.',
    support: 'When a team asks for your answer on a choice, it will appear here.',
    action: 'View my projects',
    href: PATHS.list,
  },
};

export type AwaitingDecision = {
  id: string;
  title: string;
  askedBy: string;
  project: string;
  proposed: string;
  deadline: string;
  /** Where the row and its Review button go. */
  href: string;
};
export const AWAITING_DECISIONS: AwaitingDecision[] = [
  {
    id: 'choose-the-onboarding-approach',
    title: 'Choose the onboarding approach',
    askedBy: 'Adaeze Okoye',
    project: 'Career Guidance for Everyone',
    proposed: 'Proposed 2 Nov',
    deadline: 'Decide by Fri 6 Nov',
    href: DP.detail,
  },
  {
    id: 'choose-the-headwrap-palette',
    title: 'Choose the headwrap palette',
    askedBy: 'Amara Obi',
    project: 'Adire Stories',
    proposed: 'Proposed 3 Nov',
    deadline: 'Decide by Mon 9 Nov',
    // Adire Stories has no decision detail frame: its row opens the Adire Stories Decisions list (12.38)
    href: `${PATHS.adireOverview}/decisions`,
  },
];

/** The status of every row (Status Tag, Awaiting acknowledgement). */
export const AWAITING_STATUS = 'Awaiting acknowledgement' as const;

/* ------------------------------------------------------------------ 12.49 Introduction requests */

export const INTRODUCTIONS_PAGE = {
  eyebrow: 'COLLABORATOR INTRODUCTIONS',
  title: 'Introduction requests.',
  lead: 'People who asked to be introduced to you. You decide whether to connect.',
  tab: 'Waiting for you',
  empty: {
    headline: 'No introduction requests yet.',
    support: 'When someone asks to be introduced to you, their note will appear here.',
    action: 'Explore collaborators',
    href: FLOW.collaborators,
  },
};

/** The person who asked. Amina Yusuf, as on the Home "Needs your attention" row. */
export const INTRODUCTION = {
  person: 'amina' as const,
  name: 'Amina Yusuf',
  role: 'Career Researcher',
  received: 'Received yesterday',
  skills: ['Career research', 'Student interviews', 'Survey design'],
  purposeLabel: 'Shared purpose',
  purpose: 'Helping students make informed career choices',
  noteLabel: 'Their note',
  note: 'Hello Kemi. I read your brief for Career Guidance for Everyone. I research how students choose careers and I would like to talk about the first screens.',
  /** Portrait under /public, wrap with asset() where it is rendered. */
  photo: '/images/app/collab-people/amina.jpg',
};

/** What the request shows after the answer. */
export const INTRODUCTION_ANSWERS = {
  accepted: {
    line: 'You and Amina Yusuf are now connected.',
    toast: 'Introduction accepted. You and Amina Yusuf are connected.',
  },
  notNow: {
    line: 'Response sent to Amina Yusuf. She will see that you are not available to connect right now.',
    toast: 'Response sent. Amina Yusuf will see it shortly.',
  },
};

/* ------------------------------------------------------------------ 12.50 Tasks due this week */

export const TASKS_PAGE = {
  eyebrow: 'TASKS',
  title: 'Tasks due this week.',
  lead: 'What is due in the next few days, across all your projects.',
  tab: 'Due this week',
  empty: {
    headline: 'No tasks are due this week.',
    support: 'When a task has a due date this week, it will appear here with its project.',
    action: 'View my projects',
    href: PATHS.list,
  },
};

export type DueTask = {
  id: string;
  title: string;
  project: string;
  priority: 'High' | 'Medium' | 'Low';
  /** Name of the person responsible; the circle shows the initials. */
  owner: string;
  status: 'In review' | 'In progress';
  due: string;
  /** The Tasks list of the project of the task (Career Tasks 12.14, Adire Stories Tasks 12.36). */
  href: string;
};
/** The dates follow the calendar of the sample project (today is Wednesday 4 November), as the Tasks screens do. */
export const DUE_TASKS: DueTask[] = [
  { id: 'review-the-student-onboarding-draft', title: 'Review the student onboarding draft', project: 'Career Guidance for Everyone', priority: 'High', owner: 'Adaeze Okoye', status: 'In review', due: 'Fri 6 Nov', href: PATHS.tasks },
  { id: 'review-the-headwrap-colour-layer', title: 'Review the headwrap colour layer', project: 'Adire Stories', priority: 'High', owner: 'Amara Obi', status: 'In review', due: 'Fri 6 Nov', href: `${PATHS.adireOverview}/tasks` },
  { id: 'collect-questions-students-ask-about-careers', title: 'Collect questions students ask about careers', project: 'Career Guidance for Everyone', priority: 'High', owner: 'Ngozi Eze', status: 'In progress', due: 'Mon 9 Nov', href: PATHS.tasks },
  { id: 'write-the-guided-onboarding-questions', title: 'Write the guided onboarding questions', project: 'Career Guidance for Everyone', priority: 'Medium', owner: 'Kemi Adeyemi', status: 'In progress', due: 'Tue 10 Nov', href: PATHS.tasks },
];

/* ------------------------------------------------------------------ shared */

/** Loading is announced to assistive technology only; the tab row of a loading list says "Loading". */
export const LOADING_COUNT = 'Loading';
export const countOf = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;
