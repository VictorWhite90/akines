'use client';

/**
 * The four cards of "For you on Akines" (Figma Person Card 17896:20684, Circle Card 17896:20960, Discover Card 17897:20711 and the
 * Feed Product Card 17468:14169 used as the artwork card). Prefix dxf-, styles in foryou.css.
 *
 * Every card is an <article> with one primary control, the title, whose ::after stretches over the whole card (so the card is clickable
 * and gets one focus ring, like the Focus variants) and, below it, the footer action. Pressing the card calls trackCardClick; pressing
 * the footer action calls trackCardAction (Connect and Join do it through state.ts). Only the two cards that have a destination in
 * data.ts render the title as a link; the others are plain buttons that do nothing visible, as in the prototype.
 */
import type { ReactNode } from 'react';
import { Button } from '@/ui';
import { Link } from '@/lib/nav';
import { IArrow, ICheck } from '@/features/community/ui';
import { trackCardAction, trackCardClick } from './analytics';
import { CARD_COPY, circleCopy } from './data';
import type { ArtworkCard as ArtworkData, CircleCard as CircleData, ContentCard, DiscoverImg, ForYouFilter, PersonCard as PersonData } from './data';
import { src } from './images';
import { connect, join } from './state';

type Common = {
  filter: ForYouFilter;
  /** Curtain reveal of the photograph. Off after the member changed the filter, so a swap is not a second page reveal. */
  reveal: boolean;
};

/** Square photograph. The curtain, the zoom and the loading fade are the feed's (fd-photo). Decorative: the title next to it names the card. */
function Photo({ image, reveal }: { image: DiscoverImg; reveal: boolean }) {
  return (
    <div className="fd-photo dxf-photo" data-m={reveal ? 'frame' : undefined}>
      <img className="cover" src={src(image)} alt="" loading="lazy" decoding="async" draggable={false} />
    </div>
  );
}

/** The card itself: the 2 px hover rule is the last child (it is drawn on hover and on press, never on focus, as in Figma). */
function Shell({ kind, children }: { kind: string; children: ReactNode }) {
  return (
    <article className="dxf-card" data-kind={kind}>
      {children}
      <span className="dxf-rule" aria-hidden="true" />
    </article>
  );
}

/** The title control that covers the card. A link only where data.ts gives the card a destination. */
function Main({ id, filter, href, children }: { id: string; filter: ForYouFilter; href?: string; children: ReactNode }) {
  const open = () => trackCardClick(id, filter);
  return href ? (
    <Link href={href} className="dxf-main" onClick={open}>
      {children}
    </Link>
  ) : (
    <button type="button" className="dxf-main" onClick={open}>
      {children}
    </button>
  );
}

/**
 * Holds the footer button, or the pill that replaces it once pressed. The slot is a polite live region, so the new state is announced,
 * and the pill is plain text (no dead tab stop). Button and pill are both 48 high, so nothing moves.
 */
function Act({ done, label, children }: { done: boolean; label: string; children: ReactNode }) {
  return (
    <div className="dxf-act" aria-live="polite" aria-atomic="true">
      {done ? (
        <span className="dxf-pill">
          <ICheck />
          <span>{label}</span>
        </span>
      ) : (
        children
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- Person Card */
export function PersonCard({ card, filter, reveal, requested }: Common & { card: PersonData; requested: boolean }) {
  const copy = CARD_COPY.person;
  return (
    <Shell kind="person">
      <Photo image={card.image} reveal={reveal} />
      <div className="dxf-text">
        <h3 className="dxf-name">
          <Main id={card.id} filter={filter} href={card.href}>
            {card.name}
          </Main>
        </h3>
        <p className="dxf-role">{card.identity}</p>
        <p className="dxf-desc">{card.text}</p>
      </div>
      <div className="dxf-foot">
        <span className="dxf-meta">{card.connections}</span>
        <Act done={requested} label={copy.done}>
          <Button variant="secondary" aria-label={`${copy.action} with ${card.name}`} onClick={() => connect(card.id)}>
            {copy.action}
          </Button>
        </Act>
      </div>
    </Shell>
  );
}

/* ---------------------------------------------------------------- Circle Card */
export function CircleCard({ card, filter, reveal, joined }: Common & { card: CircleData; joined: boolean }) {
  const copy = circleCopy(card);
  return (
    <Shell kind="circle">
      <Photo image={card.image} reveal={reveal} />
      <div className="dxf-text">
        <h3 className="dxf-name">
          <Main id={card.id} filter={filter}>
            {card.name}
          </Main>
        </h3>
        <p className="dxf-meta dxf-meta--block">{card.meta}</p>
        <p className="dxf-desc">{card.text}</p>
      </div>
      {/* Open circles have the button alone, on the right. Approval circles keep the note on the left, also after the request (Figma Done). */}
      <div className={copy.note ? 'dxf-foot' : 'dxf-foot dxf-foot--end'}>
        {copy.note ? <span className="dxf-meta">{copy.note}</span> : null}
        <Act done={joined} label={copy.done}>
          <Button variant="secondary" aria-label={`${copy.action} ${card.name}`} onClick={() => join(card.id)}>
            {copy.action}
          </Button>
        </Act>
      </div>
    </Shell>
  );
}

/* ---------------------------------------------------------------- Discover Card (project, studio visit, story, event) */
export function DiscoverCard({ card, filter, reveal }: Common & { card: ContentCard }) {
  const press = () => trackCardAction(card.id, filter);
  // The Card Link of the design: underlined label with an arrow. The visible label leads the accessible name, the title tells the three
  // "View project" links apart.
  const inner = (
    <>
      <span>
        {card.action}
        <span className="sr-only"> {card.title}</span>
      </span>
      <IArrow />
    </>
  );
  return (
    <Shell kind={card.kind}>
      <Photo image={card.image} reveal={reveal} />
      <div className="dxf-text">
        <p className="dxf-tag">{card.tag}</p>
        <h3 className="dxf-title">
          <Main id={card.id} filter={filter} href={card.href}>
            <span className="dxf-clamp">{card.title}</span>
          </Main>
        </h3>
        <p className="dxf-desc dxf-desc--tall">{card.text}</p>
      </div>
      <div className="dxf-foot">
        <span className="dxf-meta">{card.meta}</span>
        <div className="dxf-act">
          {card.href ? (
            <Link href={card.href} className="fd-link dxf-link" onClick={press}>
              {inner}
            </Link>
          ) : (
            <button type="button" className="fd-link dxf-link" onClick={press}>
              {inner}
            </button>
          )}
        </div>
      </div>
    </Shell>
  );
}

/* ---------------------------------------------------------------- Artwork Card (the Feed Product Card, built to the Figma numbers) */
export function ArtworkCard({ card, filter, reveal }: Common & { card: ArtworkData }) {
  return (
    <Shell kind="artwork">
      <Photo image={card.image} reveal={reveal} />
      <div className="dxf-text">
        <p className="dxf-tag">{card.tag}</p>
        <h3 className="dxf-name">
          <Main id={card.id} filter={filter} href={card.href}>
            {card.title}
          </Main>
        </h3>
        {/* The maker row is its own link, above the control that covers the card: it opens the maker's profile (Figma 11.1) */}
        <Link href={card.makerHref} className="dxf-maker dxf-maker--link">
          <span className="fd-av dxf-av">
            <img src={src(card.makerImage)} alt="" loading="lazy" decoding="async" draggable={false} />
          </span>
          <span className="dxf-maker__name">{card.maker}</span>
        </Link>
      </div>
      <div className="dxf-foot">
        <p className="dxf-price">
          <span>{card.price}</span>
          <span className="dxf-meta">{card.edition}</span>
        </p>
        <div className="dxf-act">
          <Button variant="secondary" href={card.href} aria-label={`${card.action} ${card.title}`} onClick={() => trackCardAction(card.id, filter)}>
            {card.action}
          </Button>
        </div>
      </div>
    </Shell>
  );
}
