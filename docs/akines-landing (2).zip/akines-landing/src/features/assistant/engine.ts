/**
 * Create AI answers. Two engines behind one function:
 *  - live: in the published artifact the page can ask Claude (the `sample` capability of the artifact runtime, which
 *    exists as window.claude). Answers can be about anything; the standing instructions are in knowledge.ts.
 *  - guide: the built-in keyword guide, used when there is no live model (the Next.js build has no backend yet,
 *    or the viewer declined) so the panel never dead-ends.
 * To go live in the Next.js app, implement `ask` below against your own endpoint and return the same shape.
 */
import { guide, parseReply, persona, type Go } from './knowledge';

export type Turn = { role: 'user' | 'assistant'; content: string };
export type Answer = { text: string; go: Go[]; live: boolean; note?: string };
type Who = { name: string | null; signedIn: boolean };

type SampleError = { code?: string; text?: string };
type SampleFn = ((
  input: Turn[],
  options?: { cache?: boolean; modelTier?: 'quick' | 'default'; signal?: AbortSignal; onText?: (u: { text: string }) => void },
) => Promise<{ text: string }>) | null;

let samplePromise: Promise<SampleFn> | null = null;
let liveOff = false;

const getSample = (): Promise<SampleFn> => {
  if (samplePromise) return samplePromise;
  const c = typeof window !== 'undefined' ? (window as unknown as { claude?: { use?: (n: string) => Promise<unknown> } }).claude : undefined;
  samplePromise = c && typeof c.use === 'function' ? c.use('sample').then((s) => (typeof s === 'function' ? (s as SampleFn) : null)).catch(() => null) : Promise.resolve(null);
  return samplePromise;
};

/** True when a live model is reachable in this view (checked once, never prompts the viewer). */
export const liveAvailable = async () => !liveOff && (await getSample()) !== null;

/** While streaming, hide a trailing "G", "GO" or "GO: ..." line (the page suggestions) so it never flashes in the bubble. */
const strip = (raw: string) => raw.replace(/\n\s*G(?:O(?::[^\n]*)?)?$/i, '').trimEnd();

export async function askCreateAI(
  turns: Turn[],
  who: Who,
  opts: { signal?: AbortSignal; onText?: (visible: string) => void } = {},
): Promise<Answer> {
  const last = turns[turns.length - 1]?.content ?? '';
  const sample = liveOff ? null : await getSample();
  if (opts.signal?.aborted) throw { code: 'cancelled' };
  if (sample) {
    try {
      const input: Turn[] = [{ role: 'user', content: persona(who) }, ...turns.slice(-12)];
      const { text } = await sample(input, {
        cache: false,
        modelTier: 'quick',
        signal: opts.signal,
        onText: ({ text: t }) => opts.onText?.(strip(t)),
      });
      const parsed = parseReply(text);
      if (parsed.text) return { ...parsed, live: true };
    } catch (e) {
      const code = (e as SampleError).code;
      if (code === 'cancelled') throw e;
      if (code === 'rate_limited') {
        return { text: 'I am a little busy right now. Please try again in a moment.', go: [], live: true };
      }
      if (code === 'not_granted' || code === 'sampling_disabled' || code === 'not_declared' || code === 'capability_disabled' || code === 'capability_removed') liveOff = true;
      const partial = (e as SampleError).text;
      if (partial && code === 'upstream_error') {
        const p = parseReply(partial);
        return { ...p, live: true, note: 'That answer was cut short. You can ask again.' };
      }
      // fall through to the guide
    }
  }
  const g = guide(last);
  return {
    ...g,
    live: false,
    note: liveOff || !sample ? 'Live answers are not available here, so this is the built-in guide.' : undefined,
  };
}
