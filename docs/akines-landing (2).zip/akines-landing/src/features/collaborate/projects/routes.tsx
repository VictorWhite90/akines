import type { RouteDef } from '@/routes.types';
import { Discover, DiscoverEmpty, DiscoverLoading } from './Discover';
import { ExpressInterestScreen, type InterestVariant } from './ExpressInterest';
import { MemberProfileScreen, type ProfileVariant } from './MemberProfile';
import { ProjectDetailScreen, type DetailVariant } from './ProjectDetail';
import { SavedProjectsScreen, type SavedVariant } from './SavedProjects';
import { DESIGNED_SLUG, PEOPLE, PROJECTS } from './data';

// Collaborate "Discover projects" (12.5 to 12.9). Paths: /collaborate/discover, /collaborate/saved,
// /collaborate/projects/<slug> (+ /interest), /collaborate/members/<slug>. State frames without a natural trigger live at <path>/state-<name>.
const nav = { page: 'collaborate', tab: 'Discover Projects' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

const detail = (slug: string, variant?: DetailVariant) => {
  const Screen = () => <ProjectDetailScreen slug={slug} variant={variant} />;
  return Screen;
};
const interest = (slug: string, variant?: InterestVariant) => {
  const Screen = () => <ExpressInterestScreen slug={slug} variant={variant} />;
  return Screen;
};
const member = (slug: string, variant?: ProfileVariant) => {
  const Screen = () => <MemberProfileScreen slug={slug} variant={variant} />;
  return Screen;
};
const saved = (variant?: SavedVariant) => {
  const Screen = () => <SavedProjectsScreen variant={variant} />;
  return Screen;
};

const D = `/collaborate/projects/${DESIGNED_SLUG}`;

export const routes: RouteDef[] = [
  // 12.5 Discover projects
  def('/collaborate/discover', 'Discover projects', Discover),
  def('/collaborate/discover/state-loading', 'Discover projects', DiscoverLoading),
  def('/collaborate/discover/state-empty', 'Discover projects', DiscoverEmpty),

  // 12.9 Saved projects
  def('/collaborate/saved', 'Saved projects', saved()),
  def('/collaborate/saved/state-empty', 'Saved projects', saved('empty')),
  def('/collaborate/saved/state-loading', 'Saved projects', saved('loading')),
  def('/collaborate/saved/state-error', 'Saved projects', saved('error')),

  // 12.6 Project detail (A Better Way to Learn) and 12.27 Discover project details (the other five), one route per sample project.
  // 12.8 Express interest exists only for A Better Way to Learn: on the five new details the button has no reaction in Figma.
  ...PROJECTS.map((p) => def(`/collaborate/projects/${p.slug}`, p.title, detail(p.slug))),
  def(`${D}/interest`, 'Express interest', interest(DESIGNED_SLUG)),
  def(`${D}/state-loading`, 'A Better Way to Learn', detail(DESIGNED_SLUG, 'loading')),
  def(`${D}/state-error`, 'A Better Way to Learn', detail(DESIGNED_SLUG, 'error')),
  def(`${D}/state-closed`, 'A Better Way to Learn', detail(DESIGNED_SLUG, 'closed')),
  def(`${D}/state-interest-sent`, 'A Better Way to Learn', detail(DESIGNED_SLUG, 'sent')),
  def(`${D}/interest/state-empty`, 'Express interest', interest(DESIGNED_SLUG, 'empty')),
  def(`${D}/interest/state-sending`, 'Express interest', interest(DESIGNED_SLUG, 'sending')),
  def(`${D}/interest/state-error`, 'Express interest', interest(DESIGNED_SLUG, 'error')),
  def(`${D}/interest/state-sent`, 'Interest sent', interest(DESIGNED_SLUG, 'sent')),

  // 12.7 Member profile
  ...PEOPLE.map((m) => def(`/collaborate/members/${m.slug}`, m.name, member(m.slug))),
  def('/collaborate/members/obinna-adeyemi/state-limited', 'Obinna Adeyemi', member('obinna-adeyemi', 'limited')),
  def('/collaborate/members/ngozi-eze/state-loading', 'Ngozi Eze', member('ngozi-eze', 'loading')),
  def('/collaborate/members/ngozi-eze/state-error', 'Ngozi Eze', member('ngozi-eze', 'error')),
];
