import { PATHS, PROJECT_PATH } from '../workspace/data';

/**
 * Data of the host side of reviewing applicants: journey 12.45 REVIEW APPLICANTS (the applicants of Career Guidance for Everyone) and
 * journey 12.46 OPEN CALL REVIEW (the open calls list and the applicants of the call "Mapping the Market Road"). Copy is taken word for
 * word from the Figma frames; where Figma draws one sample (a single person, a single call) the same wording pattern is used for the
 * person or the call acted on. No 'use client': route tables and client screens both import this.
 *
 * Frames 12.45: Applicants 17974:162819, Compare selected 17974:168901, Compare 17974:169471, Loading 17974:169891, Empty 17974:170183,
 * Could not load 17974:170436, Offer sent 17974:174218, Joined 17974:174749, Not now 17974:175283.
 * Frames 12.46: Open calls 17976:149803, Open calls / Empty 17976:150048, Open call / Applicants 17976:169488, ready 17976:170080,
 * compare selected 17976:170664, Compare 17976:171287, Empty 17976:171684, Closed 17976:171908.
 */

/* ------------------------------------------------------------------ paths */

/** The Figma tab shows akines.vercel.app/collaborate/my-projects/career-guidance-for-everyone/applicants on every frame of 12.45. */
export const APPLICANTS_PATH = `${PROJECT_PATH}/applicants`;
export const APPLICANT_PATHS = {
  list: APPLICANTS_PATH,
  compare: `${APPLICANTS_PATH}/compare`,
  /** Frames without a natural trigger, or that need a seeded state: .../state-<name>. */
  compareSelected: `${APPLICANTS_PATH}/state-compare-selected`,
  loading: `${APPLICANTS_PATH}/state-loading`,
  empty: `${APPLICANTS_PATH}/state-empty`,
  error: `${APPLICANTS_PATH}/state-error`,
  offerSent: `${APPLICANTS_PATH}/state-offer-sent`,
  joined: `${APPLICANTS_PATH}/state-joined`,
  notNow: `${APPLICANTS_PATH}/state-not-now`,
} as const;

/** The Figma tab shows akines.vercel.app/collaborate/open-calls and .../open-calls/mapping-the-market-road. */
export const CALLS_PATH = '/collaborate/open-calls';
export const CALL_PATH = `${CALLS_PATH}/mapping-the-market-road`;
export const CALL_PATHS = {
  list: CALLS_PATH,
  listEmpty: `${CALLS_PATH}/state-empty`,
  call: CALL_PATH,
  compare: `${CALL_PATH}/compare`,
  compareSelected: `${CALL_PATH}/state-compare-selected`,
  ready: `${CALL_PATH}/state-ready`,
  closed: `${CALL_PATH}/state-closed`,
  empty: `${CALL_PATH}/state-empty`,
} as const;

/** Where links of the journeys lead: Team (12.21), My projects (12.10) and Start a project (A1). */
export const LINKS = { team: PATHS.team, myProjects: PATHS.list, start: '/collaborate/start' } as const;

/* ------------------------------------------------------------------ people */

export type Group = 'project' | 'call';
export type ApplicantId = 'amina' | 'kunle' | 'funmi' | 'chidi' | 'folake' | 'tunde' | 'ngozi' | 'chuka' | 'amara';
/** The statuses of a person who applied (the Application Status component, 12.44, without the ones only the applicant sees). */
export type Status = 'New' | 'Shortlisted' | 'Talk booked' | 'Offer sent' | 'Joined' | 'Not now';

export type Applicant = {
  id: ApplicantId;
  group: Group;
  name: string;
  first: string;
  /** He or she, for "She will see your reply." in the Not now modal. */
  pronoun: 'he' | 'she';
  photo: string;
  /** The role of the person's profile (Career Researcher), the first part of the subline. */
  role: string;
  place?: string;
  /** "2 Nov" after "Applied". */
  applied: string;
  /** What the person wants to join as. */
  wants: string;
  availability: string;
  message: string;
  /** The short form of the message on the request cards of the Overview. */
  short?: string;
  skills: string[];
  /** The Skills row of the compare table when it differs from the skills of the slide-out (Amina's). */
  compareSkills?: string;
  experience: string;
};

const P = '/images/app/collab-people';
const C = '/images/app/community';

export const APPLICANTS: Record<ApplicantId, Applicant> = {
  // Career Guidance for Everyone (12.45). Amina, Kunle, Funmi and Chidi are the people of the Collaborators pages (people/data.ts).
  amina: {
    id: 'amina',
    group: 'project',
    name: 'Amina Yusuf',
    first: 'Amina',
    pronoun: 'she',
    photo: `${P}/amina.jpg`,
    role: 'Career Researcher',
    applied: '2 Nov',
    wants: 'Product Designer',
    availability: 'Available for new projects',
    message: 'I would like to help shape the first screens students see.',
    skills: ['Career research', 'Student interviews', 'Survey design'],
    compareSkills: 'Research, Education, Career development',
    experience: 'Researched career decisions of secondary school students in Lagos.',
  },
  kunle: {
    id: 'kunle',
    group: 'project',
    name: 'Kunle Afolabi',
    first: 'Kunle',
    pronoun: 'he',
    photo: `${P}/kunle.jpg`,
    role: 'Software Engineer',
    applied: '3 Nov',
    wants: 'Software Engineer',
    availability: 'Open to new collaborations',
    message: 'I build learning and community tools that work on the phones and connections students actually have.',
    skills: ['Mobile development', 'Low-bandwidth design', 'APIs'],
    experience: 'Built a homework help app used in secondary schools across Lagos and Ibadan.',
  },
  funmi: {
    id: 'funmi',
    group: 'project',
    name: 'Funmi Okoro',
    first: 'Funmi',
    pronoun: 'she',
    photo: `${P}/funmi.jpg`,
    role: 'Learning Experience Designer',
    // Figma shows no application date for Funmi (her subline reads "Talk Tue 10 Nov, 4:00 pm"); it only appears if she is marked Not now. Assumed.
    applied: '3 Nov',
    wants: 'Learning Experience Designer',
    availability: 'Available from next month',
    message: 'I design learning journeys that help young people reflect on who they are and what they want to do.',
    skills: ['Learning design', 'Facilitation', 'Content'],
    experience: 'Designed an after-school career curriculum for community learning centres.',
  },
  chidi: {
    id: 'chidi',
    group: 'project',
    name: 'Chidi Nwosu',
    first: 'Chidi',
    pronoun: 'he',
    photo: `${P}/chidi.jpg`,
    role: 'Community Partnerships Lead',
    applied: '4 Nov',
    wants: 'Community Partnerships Lead',
    availability: 'Available for new projects',
    message: 'I connect schools, community groups and young people so good ideas reach the students who need them.',
    short: 'I connect schools, community groups and young people.',
    skills: ['Partnerships', 'Student outreach', 'Facilitation'],
    experience: 'Led a student mentorship network across eight schools in Enugu and Abuja.',
  },

  // Mapping the Market Road (12.46). All of it is invented in the design (the people of the Community pages are only borrowed for the portraits).
  folake: {
    id: 'folake',
    group: 'call',
    name: 'Folake Adeniran',
    first: 'Folake',
    pronoun: 'she',
    photo: `${C}/folake.jpg`,
    role: 'Writer',
    place: 'Lagos',
    applied: '3 Nov',
    wants: 'Writer',
    availability: 'Available for new projects',
    message: 'I write about markets and the people who keep them running. This is the story I want to tell.',
    skills: ['Feature writing', 'Interviews', 'Oral history'],
    experience: 'Wrote a series on Lagos market women for a community magazine.',
  },
  tunde: {
    id: 'tunde',
    group: 'call',
    name: 'Tunde Bello',
    first: 'Tunde',
    pronoun: 'he',
    photo: `${C}/tunde.jpg`,
    role: 'Photographer',
    place: 'Ibadan',
    applied: '3 Nov',
    wants: 'Photographer',
    availability: 'Available from next month',
    message: 'I photograph working streets and the people on them. I know the Ibadan end of the road well.',
    skills: ['Street photography', 'Portraits', 'Photo editing'],
    experience: 'Photographed trade routes between Ibadan and Lagos for a regional archive.',
  },
  ngozi: {
    id: 'ngozi',
    group: 'call',
    name: 'Ngozi Eze',
    first: 'Ngozi',
    pronoun: 'she',
    photo: `${C}/ngozi.jpg`,
    role: 'Writer',
    place: 'Lagos',
    applied: '4 Nov',
    wants: 'Writer',
    availability: 'A few hours a week',
    message: 'I have written about informal trade for three years and would like to interview traders along the road.',
    skills: ['Reporting', 'Interviews', 'Zine making'],
    // Figma draws the compare table for Folake and Tunde only; the experience lines of the other three are assumed from their messages.
    experience: 'Has written about informal trade for three years.',
  },
  chuka: {
    id: 'chuka',
    group: 'call',
    name: 'Chuka Nwosu',
    first: 'Chuka',
    pronoun: 'he',
    photo: `${C}/chuka.jpg`,
    role: 'Photographer',
    place: 'Port Harcourt',
    applied: '5 Nov',
    wants: 'Photographer',
    availability: 'Open to new collaborations',
    message: 'I can cover the Port Harcourt end of the road with portraits and market scenes.',
    skills: ['Portraits', 'Market scenes', 'Photo editing'],
    experience: 'Photographs portraits and market scenes in Port Harcourt.',
  },
  amara: {
    id: 'amara',
    group: 'call',
    name: 'Amara Okafor',
    first: 'Amara',
    pronoun: 'she',
    photo: `${C}/amara.jpg`,
    role: 'Writer',
    place: 'Abuja',
    applied: '6 Nov',
    wants: 'Writer',
    availability: 'Available for new projects',
    message: 'I write long pieces and would like to bring the voices of market women into the story.',
    skills: ['Long form writing', 'Interviews', 'Editing'],
    experience: 'Writes long form pieces and edits them.',
  },
};

/** The people of each list, in the order of the frames. */
export const ORDER: Record<Group, ApplicantId[]> = {
  project: ['amina', 'kunle', 'funmi', 'chidi'],
  call: ['folake', 'tunde', 'ngozi', 'chuka', 'amara'],
};

/** Status of each person in the first frame of each journey (Applicants, Open call / Applicants). */
export const INITIAL_STATUS: Record<ApplicantId, Status> = {
  amina: 'New',
  kunle: 'Shortlisted',
  funmi: 'Talk booked',
  chidi: 'New',
  folake: 'New',
  tunde: 'New',
  ngozi: 'New',
  chuka: 'New',
  amara: 'New',
};

/** Saved private notes at the start: Kunle's slide-out shows his note saved. */
export const INITIAL_NOTES: Partial<Record<ApplicantId, string>> = { kunle: 'Strong fit for the mobile build. Ask about offline use.' };
/** Funmi's slide-out shows a note being written (Private Note, Focus): typed, Save note enabled, not saved yet. */
export const INITIAL_DRAFTS: Partial<Record<ApplicantId, string>> = { funmi: 'Good talk. Clear plan for the learning journeys. Ready to make an offer.' };

/* ------------------------------------------------------------------ helpers */

/** "Folake and Tunde", "Folake, Tunde and Ngozi". */
export function joinNames(names: string[]): string {
  if (names.length <= 1) return names[0] ?? '';
  return `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
}

const TALK = 'Tue 10 Nov, 4:00 pm';
const OFFER_SENT = 'Wed 11 Nov';
const JOINED = 'Fri 13 Nov';

/** Subline of a row and of the slide-out: "Career Researcher · Applied 2 Nov", "... · Talk Tue 10 Nov, 4:00 pm", "... · Offer sent Wed 11 Nov", "... · Joined Fri 13 Nov". A call person also has the place. */
export function subline(a: Applicant, status: Status): string {
  const tail =
    status === 'Talk booked' ? `Talk ${TALK}` : status === 'Offer sent' ? `Offer sent ${OFFER_SENT}` : status === 'Joined' ? `Joined ${JOINED}` : `Applied ${a.applied}`;
  return [a.role, a.place, tail].filter(Boolean).join(' · ');
}

export const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

const WORD = ['no one', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];

/* ------------------------------------------------------------------ copy: 12.45 Applicants */

export const PROJECT_NAME = 'Career Guidance for Everyone';

export const PAGE = {
  back: 'Team',
  title: 'Applicants',
  support: `People who applied to join ${PROJECT_NAME}. You decide who goes ahead.`,
  emptySupport: `People who ask to join ${PROJECT_NAME} will appear here.`,
  /** The filter chips, in the order of the frames. The label is the status in the chip: "New 2". */
  chips: ['All', 'New', 'Shortlisted', 'Talk booked', 'Offer sent'] as const,
  empty: {
    title: 'No one has applied yet',
    text: `When someone asks to join ${PROJECT_NAME}, you will see them here. Share the project link to help the right people find it.`,
    action: 'Share the project link',
  },
  error: { title: 'We could not load your applicants.', text: 'Check your connection and try again. Your applicants are safe.', action: 'Try again' },
  /** A chip whose group has no one (assumed: Figma never draws a filtered list that is empty). */
  none: 'No one here yet.',
  linkCopied: 'Link copied.',
};

/** "4 applicants. 2 new, 1 shortlisted, 1 talk booked." The statuses without anyone are left out, as in the frames. */
export function summaryLine(counts: Record<Status, number>): string {
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const parts = (['New', 'Shortlisted', 'Talk booked', 'Offer sent', 'Joined', 'Not now'] as Status[]).filter((s) => counts[s] > 0).map((s) => `${counts[s]} ${s.toLowerCase()}`);
  return `${plural(total, 'applicant')}.${parts.length ? ` ${parts.join(', ')}.` : ''}`;
}

export const ROW = {
  compare: 'Compare',
  view: 'View applicant',
  wants: 'WANTS TO JOIN AS',
  availability: 'AVAILABILITY',
  message: 'MESSAGE',
  shortlist: 'Shortlist',
  notNow: 'Not now',
  proposeTimes: 'Propose times',
  sendOffer: 'Send offer',
  undo: 'Undo',
  seeOnTeam: 'See on Team',
  offerInfo: 'Offer sent. Waiting for an answer.',
};

export const JOINED_NOTICE = (name: string) => `${name} joined ${PROJECT_NAME}.`;

/* ------------------------------------------------------------------ compare */

export const COMPARE = {
  title: 'Compare applicants',
  back: 'Applicants',
  support: (names: string[]) => `${joinNames(names)}, side by side. Your notes are only visible to you.`,
  summary: (n: number) => `${n} people selected`,
  names: (names: string[]) => `${joinNames(names)}. You can compare up to three.`,
  clear: 'Clear',
  compare: 'Compare',
  max: 3,
  rows: ['ROLE', 'WANTS TO JOIN AS', 'AVAILABILITY', 'SKILLS', 'EXPERIENCE', 'MESSAGE', 'YOUR NOTES'] as const,
  noNote: 'No note yet.',
};

/* ------------------------------------------------------------------ slide-out and modals */

export const SLIDE = {
  eyebrow: 'APPLICANT',
  skills: 'SKILLS',
  note: { label: 'Private note', placeholder: 'For example, strong research background. Ask about availability.', helper: 'Only you can see this.', save: 'Save note', saved: 'Note saved' },
  noteToast: 'Note saved. Only you can see it.',
};

export const TIMES = {
  eyebrow: 'PROPOSE TIMES',
  title: (first: string) => `Propose times to ${first}`,
  description: 'Pick up to three slots. Times are in WAT. The talk is a 20 minute video call.',
  days: [
    { day: 'Mon 9 Nov', slots: ['10:00 am', '2:00 pm', '4:00 pm'] },
    { day: 'Tue 10 Nov', slots: ['10:00 am', '2:00 pm', '4:00 pm'] },
    { day: 'Wed 11 Nov', slots: ['10:00 am', '2:00 pm', '4:00 pm'] },
  ],
  /** The slots chosen when the modal opens (Propose Times Form, Ready): Mon 2:00 pm, Tue 10:00 am, Wed 4:00 pm. */
  chosen: ['Mon 9 Nov 2:00 pm', 'Tue 10 Nov 10:00 am', 'Wed 11 Nov 4:00 pm'],
  max: 3,
  count: (n: number) => `${n} of 3 chosen`,
  message: { label: 'Message', placeholder: 'For example, I would love to hear how you would approach the first screens.', hint: 'Optional.' },
  send: 'Send times',
  cancel: 'Cancel',
  toast: (name: string) => `Times sent. ${name} will pick one.`,
};

export const OFFER = {
  eyebrow: 'SEND OFFER',
  title: (first: string) => `Send an offer to ${first}`,
  description: (first: string) => `${first} decides. An offer is never accepted for anyone.`,
  role: { label: 'Role', hint: 'The role you are offering.', placeholder: 'For example, Product Designer' },
  hours: { label: 'Hours a week', hint: 'Agreed together.', placeholder: 'For example, 6 hours a week', value: '6 hours a week' },
  start: { label: 'Start date', hint: 'When they would begin.', placeholder: 'Choose a date', value: 'Mon 23 Nov' },
  note: {
    label: 'Note',
    hint: 'Optional. They will see it with the offer.',
    placeholder: 'A line about why you would like them on the team.',
    value: 'Thank you for the careful workshop plan. We would be glad to have you on the team.',
  },
  send: 'Send offer',
  cancel: 'Cancel',
  toast: (name: string) => `Offer sent. ${name} will see it.`,
};

export const NOT_NOW = {
  eyebrow: 'NOT NOW',
  title: (first: string) => `Reply to ${first}?`,
  description: (first: string) => `This is not a no. ${first} will see that now is not the right time.`,
  to: { label: 'To', hint: (pronoun: 'he' | 'she') => `${pronoun === 'she' ? 'She' : 'He'} will see your reply.` },
  message: { label: 'Message', hint: 'Optional.', placeholder: 'For example, We are not adding anyone just yet.' },
  send: 'Send',
  cancel: 'Cancel',
  toast: (name: string) => `Marked not now. ${name} will see your reply.`,
};

/* ------------------------------------------------------------------ copy: 12.46 Open calls */

export const CALL = {
  name: 'Mapping the Market Road',
  title: 'Mapping the Market Road: a call for a writer and a photographer',
  stage: 'Exploring',
  lookingFor: 'Writer, Photographer',
  /** Fri 20 Nov: "Closes" while the call is open, "Closed on" once it was closed. */
  date: 'Fri 20 Nov',
  /** The roles of the filter chips (the second and third chip of the frames). */
  roles: ['Writer', 'Photographer'] as const,
  chips: ['All', 'Writer', 'Photographer', 'Shortlisted'] as const,
};

export const CALLS_PAGE = {
  back: 'My projects',
  label: 'OPEN CALLS',
  title: 'Your open calls.',
  lead: 'Calls you posted that do not have a project yet. Choose who goes ahead when you are ready.',
  post: 'Post a new call',
  empty: { title: 'You have no open calls.', text: 'When you post a call for collaborators, it will appear here with the people who applied.', action: 'Post a new call' },
  review: 'Review applicants',
  open: 'Open',
  closed: 'Closed',
  meta: `${CALL.stage} · Looking for ${CALL.lookingFor}`,
  closes: `Closes ${CALL.date}`,
};

export const CALL_PAGE = {
  back: 'Your open calls',
  eyebrow: 'OPEN CALL',
  eyebrowClosed: 'CALL',
  stage: 'STAGE',
  lookingFor: 'LOOKING FOR',
  closes: 'CLOSES',
  closedOn: 'CLOSED ON',
  applicants: 'APPLICANTS',
  noProject: { title: 'This call does not have a project yet.', text: 'When you have chosen your collaborators, we will help you start the project with them.' },
  closeCall: 'Close call',
  closedNotice: { title: `Applications closed on ${CALL.date}`, text: 'No new people can apply. You can still review everyone who did.', reopen: 'Reopen call' },
  start: 'Start the project with shortlisted people',
  helperNone: 'Shortlist at least one person to start the project.',
  helper: (names: string[]) => `${plural(names.length, 'person', 'people')} shortlisted: ${joinNames(names)}.`,
  empty: { title: 'No one has applied yet', text: 'People who apply to this call will appear here. You can close the call whenever you are ready.', action: 'Share the call link' },
  linkCopied: 'Link copied.',
  closedToast: 'Call closed. No new applications.',
};

export const CLOSE_MODAL = {
  eyebrow: 'CLOSE CALL',
  title: 'Close this call?',
  description: 'People will not be able to apply any more. You can reopen it later, and everyone who applied stays on your list.',
  confirm: 'Close call',
  cancel: 'Cancel',
};

export const START_MODAL = {
  eyebrow: 'START PROJECT',
  title: (names: string[]) => `Start a project with ${joinNames(names)}?`,
  /** "the two of them" (assumed pattern for other counts; Figma draws two). */
  description: (names: string[]) => `We will set up the project with ${names.length === 1 ? names[0] : `the ${WORD[names.length] ?? names.length} of them`}. You can add or change the team afterwards.`,
  confirm: 'Start project',
  cancel: 'Not yet',
};

/* ------------------------------------------------------------------ copy: Overview band */

export const BAND = {
  label: 'INTEREST REQUESTS',
  waiting: (n: number) => `${n} waiting`,
  reviewAll: 'Review all',
  review: 'Review',
  wants: (role: string) => `Wants to join as ${role}`,
};
