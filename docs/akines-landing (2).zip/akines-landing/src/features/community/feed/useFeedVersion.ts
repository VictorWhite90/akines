import { useEffect, useRef, useState } from 'react';
import { FEED_LAST_KEY, isFeedVersion, pickVersion, type FeedVersion } from './arrangements';

/** Last version shown in this page session. Backs up localStorage when it is blocked (private window), so client navigation still never repeats. */
let lastInMemory: FeedVersion | null = null;

function readLast(): FeedVersion | null {
  try {
    const v = window.localStorage.getItem(FEED_LAST_KEY);
    if (isFeedVersion(v)) return v;
  } catch {
    /* storage can throw (blocked site data, private window): fall back to memory */
  }
  return lastInMemory;
}

function writeLast(v: FeedVersion) {
  lastInMemory = v;
  try {
    window.localStorage.setItem(FEED_LAST_KEY, v);
  } catch {
    /* ignore */
  }
}

/**
 * The arrangement to render. Returns null on the server and for the first paint (the page shows a feed skeleton),
 * then the version after mount. A new version is picked on every mount (every visit, client navigation included),
 * never the one stored from the last visit, and never again on a re-render.
 * With `forced` (preview routes, state routes) that version is used and nothing is written.
 */
export function useFeedVersion(forced?: FeedVersion): FeedVersion | null {
  const [version, setVersion] = useState<FeedVersion | null>(null);
  // Strict mode runs effects twice in development; the ref keeps the second run from picking again.
  const picked = useRef<FeedVersion | null>(null);
  useEffect(() => {
    if (forced) {
      setVersion(forced);
      return;
    }
    if (!picked.current) {
      picked.current = pickVersion(readLast());
      writeLast(picked.current);
    }
    setVersion(picked.current);
  }, [forced]);
  return version;
}
