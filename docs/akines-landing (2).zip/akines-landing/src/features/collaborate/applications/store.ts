/**
 * In-memory state of the one application the prototype has (the request to join A Better Way to Learn, Figma 12.44).
 * Module scope with useSyncExternalStore, like projects/store.ts, so the booking, accept and decline actions stay consistent
 * when a person goes back or re-enters a page. Default: Pending. The stage routes and the actions on the pages set it.
 */
import { useEffect, useSyncExternalStore } from 'react';
import { toast, type ToastInput } from '@/ui/toast';
import { interestDefaults } from '../projects/data';
import { setInterest, type Interest } from '../projects/store';
import type { Pick } from './data';

export type Stage = 'pending' | 'shortlisted' | 'talk' | 'offer' | 'joined' | 'declined' | 'not-selected' | 'withdrawn';

type ApplicationState = {
  stage: Stage;
  /** The booked talk time. Null until Confirm time was pressed (the Talk booked and Offer frames then show the drawn Tue 10 Nov, 4:00 pm). */
  booked: Pick | null;
};

const INITIAL: ApplicationState = { stage: 'pending', booked: null };
let state: ApplicationState = INITIAL;
const listeners = new Set<() => void>();
const set = (next: ApplicationState) => {
  state = next;
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};
const snapshot = () => state;

export const useApplication = () => useSyncExternalStore(subscribe, snapshot, snapshot);
export const getApplication = () => state;

/** A stage route was opened: the request is at that stage. */
export function setStage(stage: Stage) {
  if (state.stage !== stage) set({ ...state, stage });
}

/** Confirm time: the talk is booked at `pick`. */
export function bookTalk(pick: Pick) {
  set({ stage: 'talk', booked: pick });
}

/** Accept and join. */
export function acceptOffer() {
  set({ ...state, stage: 'joined' });
}

/** Decline offer. */
export function declineOffer() {
  set({ ...state, stage: 'declined' });
}

/** A new request was sent (Express interest): the application starts again at Pending. */
export function resetApplication() {
  set(INITIAL);
}

/* ---------------- toast that belongs to the next page ---------------- */

/** The page shell (and its toast host) is mounted again on every path, so a toast shown just before a push would be lost. */
let queuedToast: ToastInput | null = null;
export function toastOnNextPage(input: ToastInput) {
  queuedToast = input;
}
/** Call in the page that follows: shows the queued toast once the page is on screen (`ready`), like the Figma Toast frames. */
export function useQueuedToast(ready = true) {
  useEffect(() => {
    if (!ready || !queuedToast) return;
    const next = queuedToast;
    queuedToast = null;
    toast.show(next);
  }, [ready]);
}

/**
 * The interest was withdrawn (Modal:Withdraw interest, from the Pending page or the project detail): the request reads Withdrawn,
 * and the Interest withdrawn toast offers Undo, which puts back the request and the stage it had.
 * `leaves`: the person is sent to another page, so the toast shows there.
 */
export function withdrawRequest(slug: string, interest: Interest | undefined, leaves = false) {
  const previous = interest ?? interestDefaults(slug);
  const previousState = state;
  set({ ...state, stage: 'withdrawn' });
  setInterest(slug, undefined);
  const input: ToastInput = {
    message: 'Interest withdrawn.',
    actionLabel: 'Undo',
    onAction: () => {
      setInterest(slug, previous);
      set(previousState);
    },
  };
  if (leaves) toastOnNextPage(input);
  else toast.show(input);
}
