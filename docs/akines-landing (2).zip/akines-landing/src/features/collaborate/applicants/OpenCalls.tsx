'use client';

import './applicants.css';
import '../workspace/workspace.css';
import { useEffect, useState } from 'react';
import { useNav } from '@/lib/nav';
import { Button, EmptyState } from '@/ui';
import { toast } from '@/ui/toast';
import { BackLink, CardLink, Over } from '../workspace/atoms';
import { copyLink } from './Applicants';
import { ApplicantRow, CompareBar, CompareTable, FilterChips, Notice, type ChipItem, type CompareColumn, type RowHandlers } from './parts';
import { CloseCallModal, StartProjectModal } from './modals';
import { APPLICANTS, CALL, CALLS_PAGE, CALL_PAGE, CALL_PATH, CALL_PATHS, COMPARE, LINKS, ORDER, PAGE, plural, ROW, type ApplicantId, type Status } from './data';
import { useReviewer } from './reviewer';
import { SAMPLE_COMPARE, applicants, countsOf, peopleOf, useApplicantState, useSeeded, type CallSeed } from './store';

/**
 * 12.46 OPEN CALL REVIEW. Open calls (17976:149803) and Open calls / Empty (17976:150048); the call "Mapping the Market Road": Applicants
 * (17976:169488), Applicants ready (17976:170080), compare selected (17976:170664), Empty (17976:171684) and Closed (17976:171908); Compare
 * (17976:171287) is its own page. The call's people, the filter, the compare ticks, Shortlist, Close call and Reopen call are data driven
 * (store.ts); the frames that show another state seed it when their route opens.
 */

/* ------------------------------------------------------------------ Call status, Call Header */

function CallStatus({ open }: { open: boolean }) {
  return <span className={open ? 'ap-callstatus' : 'ap-callstatus ap-callstatus--closed'}>{open ? CALLS_PAGE.open : CALLS_PAGE.closed}</span>;
}

function CallHeader({ open, count }: { open: boolean; count: number }) {
  return (
    <header className="ap-callhead" data-m="up">
      <div className="ap-callhead__eyebrow">
        <Over className="cw-over--12">{open ? CALL_PAGE.eyebrow : CALL_PAGE.eyebrowClosed}</Over>
        <CallStatus open={open} />
      </div>
      <h1 className="ap-callhead__title">{CALL.title}</h1>
      <dl className="ap-meta">
        <div>
          <dt>
            <Over className="cw-over--12">{CALL_PAGE.stage}</Over>
          </dt>
          <dd>{CALL.stage}</dd>
        </div>
        <div>
          <dt>
            <Over className="cw-over--12">{CALL_PAGE.lookingFor}</Over>
          </dt>
          <dd>{CALL.lookingFor}</dd>
        </div>
        <div>
          <dt>
            <Over className="cw-over--12">{open ? CALL_PAGE.closes : CALL_PAGE.closedOn}</Over>
          </dt>
          <dd>{CALL.date}</dd>
        </div>
        <div>
          <dt>
            <Over className="cw-over--12">{CALL_PAGE.applicants}</Over>
          </dt>
          <dd>{plural(count, 'applicant')}</dd>
        </div>
      </dl>
      <Notice title={CALL_PAGE.noProject.title} text={CALL_PAGE.noProject.text} />
    </header>
  );
}

/* ------------------------------------------------------------------ Open calls list */

export function OpenCallsScreen({ variant }: { variant?: 'empty' }) {
  const s = useApplicantState();
  const empty = variant === 'empty';
  const open = s.callOpen;
  return (
    <div className="ap-wide ap-wide--list">
      <BackLink href={LINKS.myProjects}>{CALLS_PAGE.back}</BackLink>
      <header className="ap-listhead" data-m="up">
        <div className="ap-listhead__text">
          <Over className="cw-over--12">{CALLS_PAGE.label}</Over>
          <h1 className="ap-listhead__title">{CALLS_PAGE.title}</h1>
          <p className="ap-lead">{CALLS_PAGE.lead}</p>
        </div>
        <CardLink href={LINKS.start}>{CALLS_PAGE.post}</CardLink>
      </header>
      {empty ? (
        <div data-m="up">
          <EmptyState
            className="cw-empty"
            title={CALLS_PAGE.empty.title}
            text={CALLS_PAGE.empty.text}
            action={
              <Button href={LINKS.start} arrow="up-right">
                {CALLS_PAGE.empty.action}
              </Button>
            }
          />
        </div>
      ) : (
        <ul className="ap-list" data-m="up" aria-label="Open calls">
          <li>
            <article className="ap-callrow">
              <div className="ap-callrow__left">
                <h2 className="ap-callrow__title">{CALL.title}</h2>
                <p className="ap-callrow__line">{CALLS_PAGE.meta}</p>
                <p className="ap-callrow__line">{open ? CALLS_PAGE.closes : `Closed on ${CALL.date}`}</p>
              </div>
              <div className="ap-callrow__right">
                <CallStatus open={open} />
                <p className="ap-callrow__count">{plural(ORDER.call.length, 'applicant')}</p>
                <Button size="sm" variant="secondary" href={CALL_PATH} className="ap-callrow__go">
                  {CALLS_PAGE.review}
                  <span className="sr-only"> {CALL.name}</span>
                </Button>
              </div>
            </article>
          </li>
        </ul>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ The call: Applicants, ready, compare selected, Empty, Closed */

export type CallVariant = 'empty' | CallSeed;
const CALL_SEEDS: CallSeed[] = ['compare-selected', 'ready', 'closed'];

export function CallScreen({ variant }: { variant?: CallVariant }) {
  const nav = useNav();
  const seed = CALL_SEEDS.find((x) => x === variant);
  const s = useSeeded('call', seed);
  const r = useReviewer('call');
  const [filter, setFilter] = useState('All');
  const [modal, setModal] = useState<'close' | 'start' | null>(null);

  const empty = variant === 'empty';
  const open = s.callOpen;
  const people = peopleOf(s, 'call');
  const counts = countsOf(s, 'call');
  const chips: ChipItem[] = CALL.chips.map((label) => ({
    key: label,
    label,
    count: label === 'All' ? people.length : label === 'Shortlisted' ? counts.Shortlisted : people.filter((p) => APPLICANTS[p.id].wants === label).length,
  }));
  const shown = people.filter((p) => filter === 'All' || (filter === 'Shortlisted' ? p.status === 'Shortlisted' : APPLICANTS[p.id].wants === filter));
  const ticked = ORDER.call.filter((id) => s.compare.call.includes(id));
  const shortlisted = people.filter((p) => p.status === 'Shortlisted').map((p) => APPLICANTS[p.id].first);

  // a call person's View applicant opens the slide-out of a New person; a shortlisted one has none in the design. Not now belongs to the project journey: plain.
  const handlers = (id: ApplicantId, status: Status): RowHandlers => ({
    open: status === 'New' ? () => r.open(id) : undefined,
    shortlist: () => r.shortlist(id),
  });

  const closeCall = () => {
    applicants.closeCall();
    setModal(null);
    toast.show({ message: CALL_PAGE.closedToast });
  };
  const startProject = () => {
    setModal(null);
    nav.push(LINKS.start);
  };

  return (
    <div className="ap-wide">
      <BackLink href={CALL_PATHS.list}>{CALL_PAGE.back}</BackLink>
      <CallHeader open={open} count={empty ? 0 : people.length} />
      {empty ? (
        <div data-m="up">
          <EmptyState
            className="cw-empty"
            title={CALL_PAGE.empty.title}
            text={CALL_PAGE.empty.text}
            action={
              <Button arrow="up-right" onClick={() => copyLink(CALL_PATH, CALL_PAGE.linkCopied)}>
                {CALL_PAGE.empty.action}
              </Button>
            }
          />
        </div>
      ) : (
        <>
          {open ? null : (
            <div className="ap-closed" data-m="up">
              <Notice title={CALL_PAGE.closedNotice.title} text={CALL_PAGE.closedNotice.text} />
              <Button variant="secondary" arrow="up-right" onClick={() => applicants.reopenCall()}>
                {CALL_PAGE.closedNotice.reopen}
              </Button>
            </div>
          )}
          <div className="ap-filterrow" data-m="up">
            <FilterChips items={chips} value={filter} onChange={setFilter} label="Filter applicants" />
            {open ? <CardLink onClick={() => setModal('close')}>{CALL_PAGE.closeCall}</CardLink> : null}
          </div>
          {ticked.length >= 2 ? (
            <CompareBar
              count={ticked.length}
              names={COMPARE.names(ticked.map((id) => APPLICANTS[id].name))}
              onClear={() => applicants.clearCompare('call')}
              onCompare={() => nav.push(CALL_PATHS.compare)}
            />
          ) : null}
          {shown.length === 0 ? (
            <p className="ap-none">{PAGE.none}</p>
          ) : (
            <ul className="ap-list" data-m="up" aria-label="Applicants">
              {shown.map((p) => (
                <li key={p.id}>
                  <ApplicantRow
                    a={APPLICANTS[p.id]}
                    status={p.status}
                    selected={ticked.includes(p.id)}
                    tickLocked={ticked.length >= COMPARE.max}
                    onTick={() => applicants.toggleCompare('call', p.id)}
                    h={handlers(p.id, p.status)}
                  />
                </li>
              ))}
            </ul>
          )}
          <div className="ap-start" data-m="up">
            <Button arrow="up-right" disabled={shortlisted.length === 0} onClick={() => setModal('start')}>
              {CALL_PAGE.start}
            </Button>
            <p className="ap-start__help">{shortlisted.length === 0 ? CALL_PAGE.helperNone : CALL_PAGE.helper(shortlisted)}</p>
          </div>
        </>
      )}
      <CloseCallModal open={modal === 'close'} onClose={() => setModal(null)} onConfirm={closeCall} />
      <StartProjectModal open={modal === 'start'} names={shortlisted} onClose={() => setModal(null)} onConfirm={startProject} />
      {r.layer}
    </div>
  );
}

/* ------------------------------------------------------------------ Compare (12.46) */

/**
 * Open call / Compare (17976:171287): the people ticked in the call, side by side. Opened without anyone ticked it shows Folake Adeniran and
 * Tunde Bello, the pair of the frame. Shortlist (a shortlisted person has no more actions here) goes back to the list, as the frame does.
 * Not now stays plain: its modal belongs to the project journey.
 */
export function CallCompareScreen() {
  const nav = useNav();
  const s = useApplicantState();
  const picked = ORDER.call.filter((id) => s.compare.call.includes(id));
  const ids = picked.length >= 2 ? picked : SAMPLE_COMPARE.call;

  useEffect(() => {
    if (picked.length < 2) applicants.setCompare('call', SAMPLE_COMPARE.call);
    // once, when the page opens
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const columns: CompareColumn[] = ids.map((id) => {
    const status = s.status[id];
    return {
      a: APPLICANTS[id],
      status,
      note: (s.notes[id] ?? '').trim(),
      actions:
        status === 'New' ? (
          <>
            <Button
              size="sm"
              onClick={() => {
                applicants.shortlist(id);
                nav.push(CALL_PATH);
              }}
            >
              {ROW.shortlist}
            </Button>
            <Button size="sm" variant="secondary">
              {ROW.notNow}
            </Button>
          </>
        ) : status === 'Shortlisted' ? (
          <Button size="sm" variant="secondary">
            {ROW.notNow}
          </Button>
        ) : null,
    };
  });

  return (
    <div className="ap-wide">
      <BackLink href={CALL_PATH}>{COMPARE.back}</BackLink>
      <header className="ap-head" data-m="up">
        <h1 className="ap-title">{COMPARE.title}</h1>
        <p className="ap-lead">{COMPARE.support(ids.map((id) => APPLICANTS[id].name))}</p>
      </header>
      <CompareTable columns={columns} />
    </div>
  );
}
