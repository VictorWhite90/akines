/** Preview artifact version of src/lib/assets.ts: images are published next to the page, so paths are relative. */
export const asset = (path: string): string => path.replace(/^\/+/, '');
