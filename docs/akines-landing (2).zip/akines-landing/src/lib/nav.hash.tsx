'use client';

/**
 * Hash router used only by the single-file preview artifact (it replaces src/lib/nav.tsx at bundle time).
 * An artifact page may only use plain "#name" hashes (letters, digits, hyphens), so the path "/collaborate/projects"
 * is stored as "#collaborate-projects" and the landing page "/" is an empty hash. Only static routes exist.
 */
import { forwardRef, useCallback, useEffect, useSyncExternalStore, type AnchorHTMLAttributes, type MouseEvent } from 'react';

export const IS_PREVIEW = true;

export const pathToHash = (path: string) => {
  const clean = path.split('?')[0].replace(/^\/+|\/+$/g, '');
  return clean ? clean.replace(/\//g, '-') : '';
};

const listeners = new Set<() => void>();
const notify = () => listeners.forEach((l) => l());
let hashToPathMap: Record<string, string> = {};
/** Called once by the artifact entry with every registered path so hashes can be turned back into paths. */
export function registerPaths(paths: string[]) {
  hashToPathMap = {};
  paths.forEach((p) => {
    hashToPathMap['#' + pathToHash(p)] = p;
  });
  hashToPathMap['#'] = '/';
  hashToPathMap[''] = '/';
}

function currentPath(): string {
  const raw = window.location.hash;
  return hashToPathMap[raw] ?? (raw ? '/__unknown' + raw.slice(1) : '/');
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  window.addEventListener('hashchange', cb);
  return () => {
    listeners.delete(cb);
    window.removeEventListener('hashchange', cb);
  };
}

function go(path: string, replace = false) {
  const h = pathToHash(path);
  const url = window.location.pathname + window.location.search + (h ? '#' + h : '');
  try {
    if (replace) history.replaceState(null, '', url);
    else history.pushState(null, '', url);
  } catch {
    window.location.hash = h;
  }
  window.scrollTo(0, 0);
  notify();
}

type LinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> & { href: string; replace?: boolean };

export const Link = forwardRef<HTMLAnchorElement, LinkProps>(function Link({ href, replace, onClick, children, ...rest }, ref) {
  if (href.startsWith('/')) {
    const handle = (e: MouseEvent<HTMLAnchorElement>) => {
      onClick?.(e);
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      e.preventDefault();
      go(href, replace);
    };
    const h = pathToHash(href);
    return (
      <a ref={ref} href={h ? '#' + h : '#'} data-route="" onClick={handle} {...rest}>
        {children}
      </a>
    );
  }
  const external = /^https?:\/\//.test(href);
  return (
    <a ref={ref} href={href} onClick={onClick} {...(external ? { rel: 'noopener' } : {})} {...rest}>
      {children}
    </a>
  );
});

export function useNav() {
  return {
    push: useCallback((path: string) => go(path), []),
    replace: useCallback((path: string) => go(path, true), []),
    back: useCallback(() => history.back(), []),
  };
}

export function usePath(): string {
  return useSyncExternalStore(subscribe, currentPath, () => '/');
}

/** Keeps the document title in step with the route (artifacts do not get Next metadata). */
export function useDocumentTitle(title: string) {
  useEffect(() => {
    document.title = title;
  }, [title]);
}
