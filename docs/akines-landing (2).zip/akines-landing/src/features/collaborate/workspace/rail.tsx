'use client';

import './dash.css';
import { useState, type ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { MeetingCard } from '../meetings/MeetingCard';
import { DP } from '../decisions/data';
import { teamFor, type TeamMember } from '../project-team/data';
import { ArrowUpRight, Dot } from './atoms';
import { Portrait, type Tone } from './dash';
import { PATHS } from './data';
import { ART_PATH, useProject, type ProjectKey } from './project';
import { MemberSlideOut } from './slideout';
import { cx } from './util';

/**
 * The project rail (Figma Overview Rail 17798:20590): the right column of every project page that has a dashboard. The meeting card is
 * always first, in one of its three states; then team availability (portraits open the member slide-out), needs review and workload.
 * The empty pages show only the meeting card and team availability (`variant="short"`). `hide` leaves out a Needs review row that
 * points at the page itself.
 */
export type ReviewKey = 'file' | 'decision';
type Variant = 'full' | 'short';

const TONE: Record<TeamMember['presence'], Tone> = { available: 'green', working: 'accent', away: 'gray', unshared: 'gray' };
const WORD: Record<TeamMember['presence'], string> = { available: 'Available', working: 'Working', away: 'Away', unshared: 'Away' };

/** Open tasks per person, in the order of the team. The bar is the count out of three. */
const WORKLOAD: Record<ProjectKey, number[]> = { career: [2, 2, 2, 1], adire: [2, 2, 2, 1] };

type Review = { key: ReviewKey; title: string; caption: string; href: string };
const REVIEWS: Record<ProjectKey, Review[]> = {
  career: [
    { key: 'file', title: 'Student onboarding draft', caption: 'Adaeze Okoye, 2 hours ago', href: PATHS.draftFile },
    { key: 'decision', title: 'Choose the onboarding approach', caption: 'Decision, waiting for you', href: DP.detail },
  ],
  // the file preview and the decision detail are not mirrored on Adire Stories: the rows open the lists
  adire: [
    { key: 'file', title: 'Headwrap colour layer', caption: 'Amara Obi, 2 hours ago', href: `${ART_PATH}/files` },
    { key: 'decision', title: 'Choose the headwrap palette', caption: 'Decision, waiting for you', href: `${ART_PATH}/decisions` },
  ],
};

const DocIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="M4 1.8h5.2L12.2 4.8v9.4H4z" />
    <path d="M9 1.8v3.2h3.2M6 8h4M6 10.5h4" />
  </svg>
);
const ChevronRight = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="m6 3.5 4.5 4.5L6 12.5" />
  </svg>
);

/** Small uppercase label of a rail block, with an optional item at the right. */
function RailHead({ title, right }: { title: string; right?: ReactNode }) {
  return (
    <header className="cd-rail__head">
      <h3 className="cd-rail__title">{title}</h3>
      {right}
    </header>
  );
}

function TeamAvailability({ members }: { members: TeamMember[] }) {
  const { nav } = useProject();
  const [open, setOpen] = useState<TeamMember | null>(null);
  const [show, setShow] = useState(false);
  const count = (p: TeamMember['presence']) => members.filter((m) => m.presence === p).length;
  return (
    <section className="cd-rail__block" aria-label="Team availability">
      <RailHead
        title="TEAM AVAILABILITY"
        right={
          <Link href={nav.team} className="cd-rail__link">
            Team
            <ArrowUpRight size={14} />
          </Link>
        }
      />
      <ul className="cd-avail">
        {members.map((m) => (
          <li key={m.id}>
            <button
              type="button"
              className="cd-avail__item"
              aria-haspopup="dialog"
              onClick={() => {
                setOpen(m);
                setShow(true);
              }}
            >
              <Portrait src={m.photo} size={56} tone={TONE[m.presence]} />
              <span className="cd-avail__name">{m.name.split(' ')[0]}</span>
              <span className="cd-avail__word">{WORD[m.presence]}</span>
            </button>
          </li>
        ))}
      </ul>
      <p className="cd-legend">
        <span>
          <Dot tone="green" size={6} />
          {count('available')} available
        </span>
        <span>
          <Dot size={6} />
          {count('working')} working
        </span>
        <span>
          <Dot tone="gray" size={6} />
          {count('away')} away
        </span>
      </p>
      <MemberSlideOut member={open} open={show} onClose={() => setShow(false)} />
    </section>
  );
}

function NeedsReview({ hide }: { hide?: ReviewKey[] }) {
  const { key } = useProject();
  const rows = REVIEWS[key].filter((r) => !hide?.includes(r.key));
  if (rows.length === 0) return null;
  return (
    <section className="cd-rail__block cd-rail__block--review" aria-label="Needs review">
      <RailHead title="NEEDS REVIEW" right={<span className="cd-badge">{rows.length}</span>} />
      <ul className="cd-review">
        {rows.map((r) => (
          <li key={r.key}>
            <Link href={r.href} className="cd-review__row">
              <span className="cd-review__icon">
                <DocIcon />
              </span>
              <span className="cd-review__text">
                <span className="cd-review__title">{r.title}</span>
                <span className="cd-review__cap">{r.caption}</span>
              </span>
              <ChevronRight />
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Workload({ members }: { members: TeamMember[] }) {
  const { key } = useProject();
  return (
    <section className="cd-rail__block cd-rail__block--load" aria-label="Workload">
      <RailHead title="WORKLOAD" right={<span className="cd-rail__note">Open tasks</span>} />
      <ul className="cd-load">
        {members.map((m, i) => {
          const n = WORKLOAD[key][i] ?? 0;
          return (
            <li className="cd-load__row" key={m.id}>
              <Portrait src={m.photo} size={28} />
              <span className="cd-load__name">{m.name.split(' ')[0]}</span>
              <span className="cd-load__track" role="img" aria-label={`${n} open tasks`}>
                <i style={{ width: `${Math.min(100, Math.round((n / 3) * 100))}%` }} />
              </span>
              <span className="cd-load__n">{n}</span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function ProjectRail({ variant = 'full', hide }: { variant?: Variant; hide?: ReviewKey[] }) {
  const { key } = useProject();
  const members = teamFor(key).members;
  return (
    <div className={cx('cd-rail', variant === 'short' && 'cd-rail--short')}>
      <MeetingCard empty={variant === 'short'} />
      <TeamAvailability members={members} />
      {variant === 'full' ? (
        <>
          <NeedsReview hide={hide} />
          <Workload members={members} />
        </>
      ) : null}
    </div>
  );
}

