'use client';

import { useEffect, useState } from 'react';
import { useReducedMotion } from '@/lib/hooks';

export type ToastInput = { message: string; actionLabel?: string; onAction?: () => void; duration?: number };
type ToastItem = ToastInput & { id: number };

let nextId = 1;
let current: ToastItem | null = null;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

/** Show a toast from anywhere (no provider needed): `toast.show({ message: 'Saved', actionLabel: 'Undo', onAction })`. */
export const toast = {
  show(input: ToastInput) {
    current = { ...input, id: nextId++ };
    emit();
  },
  dismiss() {
    current = null;
    emit();
  },
};
export const useToast = () => toast;

/** Exit time in ms (CSS: 0.28 s). */
const EXIT_MS = 300;

/**
 * Mounted once by AppShell. Look: the Figma Toast (charcoal, 8 px radius, amber check, message, text action).
 * It slides up 12 px and fades in; on dismiss it fades out before it is removed.
 */
export function ToastHost() {
  const reduced = useReducedMotion();
  const [item, setItem] = useState<ToastItem | null>(null);
  const [leaving, setLeaving] = useState(false);
  useEffect(() => {
    const sync = () => {
      if (current) {
        setItem(current);
        setLeaving(false);
      } else {
        setLeaving(true);
      }
    };
    listeners.add(sync);
    return () => {
      listeners.delete(sync);
    };
  }, []);
  // auto dismiss
  useEffect(() => {
    if (!item || leaving) return;
    const t = window.setTimeout(() => toast.dismiss(), item.duration ?? 2500);
    return () => window.clearTimeout(t);
  }, [item, leaving]);
  // unmount after the exit animation
  useEffect(() => {
    if (!leaving) return;
    const t = window.setTimeout(() => setItem(null), reduced ? 0 : EXIT_MS);
    return () => window.clearTimeout(t);
  }, [leaving, reduced]);
  if (!item) return null;
  return (
    <div className="toast" role="status" aria-live="polite" key={item.id} data-state={leaving ? 'closed' : 'open'}>
      <svg className="toast__icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
        <path d="M5 12.5l4.5 4.5L19 7.5" />
      </svg>
      <span className="toast__msg">{item.message}</span>
      {item.actionLabel ? (
        <button
          type="button"
          className="toast__action"
          onClick={() => {
            item.onAction?.();
            toast.dismiss();
          }}
        >
          {item.actionLabel}
        </button>
      ) : null}
    </div>
  );
}
