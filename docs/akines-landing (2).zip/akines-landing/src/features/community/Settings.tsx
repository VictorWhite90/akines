'use client';

/**
 * Settings (Figma 10.5): Recommendation preferences 17109:8710, Recommendation explanations 17109:8924,
 * Privacy settings 17109:9113, Connection preferences 17109:9332. Every choice lives in the store and is saved with the primary button.
 */
import type { ReactNode } from 'react';
import { Button, Chip, Tag, Toggle } from '@/ui';
import { Link, usePath } from '@/lib/nav';
import './community.css';
import { P } from './data';
import { clearSaved, markSaved, openModal, setPrefs, useCommunity, type CommunityState } from './store';
import { Avatar, IArrow, ICheckCircle, IShield, TextLink } from './ui';

const NAV = [
  { label: 'Recommendation preferences', to: P.settings },
  { label: 'Recommendation explanations', to: P.recs },
  { label: 'Privacy settings', to: P.privacy },
  { label: 'Connection preferences', to: P.connection },
];

function Shell({ title, desc, children }: { title: string; desc: string; children: ReactNode }) {
  const path = usePath();
  return (
    <div className="ch-page">
      <div className="ch-set">
        <nav className="ch-nav" aria-label="Settings">
          <TextLink href={P.home}>Back to Community Home</TextLink>
          <span className="ch-nav__space" />
          <p className="ch-label">Your connections</p>
          {NAV.map((n) => (
            <Link key={n.to} href={n.to} className={`ch-nav__item${path === n.to ? ' ch-nav__item--on' : ''}`} aria-current={path === n.to ? 'page' : undefined}>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="ch-set__main">
          <h1 className="ch-set__title" data-m="words">
            {title}
          </h1>
          <p className="ch-set__desc">{desc}</p>
          {children}
        </div>
      </div>
    </div>
  );
}

type Prefs = CommunityState['prefs'];
const edit = (p: Partial<Prefs>) => {
  clearSaved();
  setPrefs(p);
};

function Row({ title, text, checked, onChange }: { title: string; text: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="ch-set__row">
      <div className="ch-set__rowtext">
        <span className="ch-set__rowtitle">{title}</span>
        <span className="ch-set__rowdesc">{text}</span>
      </div>
      <Toggle checked={checked} onChange={onChange} aria-label={title} />
    </div>
  );
}

function Save({ idx, label }: { idx: 0 | 1 | 2 | 3; label: string }) {
  const s = useCommunity();
  return (
    <div className="ch-set__save">
      <Button iconRight={<IArrow />} onClick={() => markSaved(idx)}>
        {label}
      </Button>
      {s.saved[idx] ? (
        <p className="ch-confirm" aria-live="polite">
          <ICheckCircle />
          <span>Saved. Your choices apply from now on.</span>
        </p>
      ) : null}
    </div>
  );
}

const toggleIn = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

export function SettingsRecommendation() {
  const { prefs } = useCommunity();
  return (
    <Shell title="Recommendation preferences" desc="Choose which interests and moments Akines may use to suggest people and activities.">
      <div className="ch-set__group">
        <p className="ch-label">Interests Akines may use</p>
        <div className="ch-chips" role="group" aria-label="Interests Akines may use">
          {['Community health', 'Making and craft', 'Storytelling', 'Food systems', 'Small business', 'Music'].map((i) => (
            <Chip key={i} variant="choice" selected={prefs.interests.includes(i)} onClick={() => edit({ interests: toggleIn(prefs.interests, i) })}>
              {i}
            </Chip>
          ))}
        </div>
      </div>
      <div className="ch-set__list">
        <Row title="Suggest people from my Cliqs and KinCircles" text="Start with people you may already share a space with." checked={prefs.suggestCircles} onChange={(v) => edit({ suggestCircles: v })} />
        <Row title="Use the times I have shared" text="Suggest moments that fit when you are usually free." checked={prefs.useTimes} onChange={(v) => edit({ useTimes: v })} />
        <Row title="Use my intention for the day" text="Let what you chose on Community Home shape what you see first." checked={prefs.useIntention} onChange={(v) => edit({ useIntention: v })} />
      </div>
      <Save idx={0} label="Save preferences" />
    </Shell>
  );
}

const WHY = [
  { who: 'Tunde', av: 'tunde', text: 'You both develop community-health initiatives and prefer practical, small-group work.', modal: 'why-tunde' },
  { who: 'Ngozi', av: 'ngozi', text: 'You both write to remember the people in your lives and prefer quiet, one-to-one conversation.', modal: 'why-ngozi' },
  { who: 'Chuka', av: 'chuka', text: 'You are both starting something of your own and like talking ideas through one person at a time.', modal: 'why-chuka' },
] as const;

export function SettingsExplanations() {
  const { prefs } = useCommunity();
  return (
    <Shell title="Recommendation explanations" desc="See why a person or activity was suggested to you, and what information was used.">
      <div className="ch-set__list" data-m="stagger">
        {WHY.map((w) => (
          <div className="ch-why" key={w.who}>
            <Avatar k={w.av} size={48} />
            <div className="ch-why__text">
              <span className="ch-why__title">Why {w.who} was suggested</span>
              <span className="ch-why__desc">{w.text}</span>
            </div>
            <TextLink onClick={() => openModal(w.modal)}>See the full reason</TextLink>
          </div>
        ))}
      </div>
      <p className="ch-ov__privacy">
        <IShield s={20} />
        <span>Not used: popularity, follower counts or relationship scores. Akines does not show them.</span>
      </p>
      <div className="ch-set__list">
        <Row title="Show a reason with every suggestion" text="Each person or activity comes with a short explanation." checked={prefs.showReason} onChange={(v) => edit({ showReason: v })} />
      </div>
      <Save idx={1} label="Save explanation settings" />
    </Shell>
  );
}

const INVITE = ['People in my Cliqs and KinCircles', 'People I have messaged', 'No one for now'];

export function SettingsPrivacy() {
  const { prefs } = useCommunity();
  return (
    <Shell title="Privacy settings" desc="Control who can see you and what stays private to you.">
      <div className="ch-set__list">
        <Row title="Show my profile to people in my Cliqs and KinCircles" text="Others in your spaces can see your name, interests and areas of experience." checked={prefs.showProfile} onChange={(v) => edit({ showProfile: v })} />
        <Row title="Show my collaborations on my profile" text="People can see the projects you are building together." checked={prefs.showCollabs} onChange={(v) => edit({ showCollabs: v })} />
        <Row title="Let people see when I was last active" text="Off keeps your activity to yourself." checked={prefs.showActive} onChange={(v) => edit({ showActive: v })} />
        <div className="ch-set__row">
          <div className="ch-set__rowtext">
            <span className="ch-set__rowtitle">Mood check-ins and private notes</span>
            <span className="ch-set__rowdesc">Always private. They are never shared, sent or shown to anyone.</span>
          </div>
          <Tag>Always private</Tag>
        </div>
      </div>
      <div className="ch-set__group">
        <p className="ch-label">Who can invite me to a conversation</p>
        <div className="ch-chips" role="radiogroup" aria-label="Who can invite me to a conversation">
          {INVITE.map((t, i) => (
            <Chip key={t} variant="choice" selected={prefs.invitePolicy === i + 1} onClick={() => edit({ invitePolicy: (i + 1) as 1 | 2 | 3 })}>
              {t}
            </Chip>
          ))}
        </div>
      </div>
      <Save idx={2} label="Save privacy settings" />
    </Shell>
  );
}

export function SettingsConnection() {
  const { prefs } = useCommunity();
  return (
    <Shell title="Connection preferences" desc="Tell Akines how you like to spend time with others.">
      <div className="ch-set__group">
        <p className="ch-label">Ways I like to connect</p>
        <div className="ch-chips" role="group" aria-label="Ways I like to connect">
          {['Short catch-ups', 'Longer conversations', 'Making something together', 'Quiet company'].map((t) => (
            <Chip key={t} variant="choice" selected={prefs.ways.includes(t)} onClick={() => edit({ ways: toggleIn(prefs.ways, t) })}>
              {t}
            </Chip>
          ))}
        </div>
      </div>
      <div className="ch-set__group">
        <p className="ch-label">When I am usually free</p>
        <div className="ch-chips" role="group" aria-label="When I am usually free">
          {['Mornings', 'Afternoons', 'Evenings', 'Weekends'].map((t) => (
            <Chip key={t} variant="choice" selected={prefs.free.includes(t)} onClick={() => edit({ free: toggleIn(prefs.free, t) })}>
              {t}
            </Chip>
          ))}
        </div>
      </div>
      <div className="ch-set__list">
        <Row title="Remind me before a moment starts" text="A gentle reminder, 15 minutes before." checked={prefs.remind} onChange={(v) => edit({ remind: v })} />
        <Row title="Suggest quiet company when my week looks busy" text="A calmer option, never an obligation." checked={prefs.quietWhenBusy} onChange={(v) => edit({ quietWhenBusy: v })} />
      </div>
      <Save idx={3} label="Save connection preferences" />
    </Shell>
  );
}
