/**
 * Paths of the applicant journey 12.44 APPLICATION STATUS. The Figma tabs show
 * akines.vercel.app/collaborate/projects/requests/a-better-way-to-learn (+ /time, /talk, /offer, /joined, /declined).
 * The base path shows the stage the request is at: Pending, Shortlisted, Not selected or Withdrawn have no tail of their own in Figma,
 * so they also get entry paths here (/shortlisted, /not-selected, /withdrawn) that set the stage first.
 * No 'use client': route tables and client screens both import this.
 */
import { DESIGNED_SLUG } from '../projects/data';

export const REQUEST_BASE = `/collaborate/projects/requests/${DESIGNED_SLUG}`;

export const REQUEST_PATHS = {
  base: REQUEST_BASE,
  shortlisted: `${REQUEST_BASE}/shortlisted`,
  time: `${REQUEST_BASE}/time`,
  talk: `${REQUEST_BASE}/talk`,
  offer: `${REQUEST_BASE}/offer`,
  joined: `${REQUEST_BASE}/joined`,
  declined: `${REQUEST_BASE}/declined`,
  notSelected: `${REQUEST_BASE}/not-selected`,
  withdrawn: `${REQUEST_BASE}/withdrawn`,
  stateLoading: `${REQUEST_BASE}/state-loading`,
  stateError: `${REQUEST_BASE}/state-error`,
} as const;

/** Project detail (interest sent, or plain once the interest was withdrawn). */
export const PROJECT_PATH = `/collaborate/projects/${DESIGNED_SLUG}`;
export const DISCOVER_PATH = '/collaborate/discover';
export const HOME_PATH = '/collaborate';
export const MY_PROJECTS_PATH = '/collaborate/my-projects';
