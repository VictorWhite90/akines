import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { RP } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Mirrored: Reflection (the page the Project navigation opens), Check-in, Check-in submitted and Team summary. The Submit check-in modal and
 * the two toasts open inside the check-in, so they work on Adire Stories without a route of their own. Not mirrored: the "state-" frames
 * (Not available yet and the overlay frames), which no control reaches.
 */
const MIRRORED = new Set([RP.open, RP.checkIn, RP.submitted, RP.summary]);

export const artRoutes: RouteDef[] = routes.filter((r) => MIRRORED.has(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
