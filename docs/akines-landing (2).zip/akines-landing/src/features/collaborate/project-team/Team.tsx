'use client';

import '../workspace/workspace.css';
import './team.css';
import '../applicants/applicants.css';
import { useEffect, useState } from 'react';
import { useNav } from '@/lib/nav';
import { Button, EmptyState, toast } from '@/ui';
import { MetricCard, MetricRow } from '../workspace/dash';
import { Band, CardLink, PageHead, WorkspaceFrame } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { MemberSlideOut } from '../workspace/slideout';
import { APPLICANT_PATHS } from '../applicants/data';
import { TEAM_PATHS, type TeamMember, type TeamView } from './data';
import { ConfirmationLine, InterestRequest, MemberCard, useTeam } from './parts';
import { InviteModal, NotNowModal } from './modals';

/**
 * 12.21 Team: Team (17729:100721), Empty (17729:110484), Interest request accepted (17729:116651), Request dismissed (17729:117247)
 * and their overlays Modal:Invite collaborator, Toast:Invitation sent, Toast:Request accepted, Modal:Not now and Toast:Response sent,
 * plus the member slide-outs (Slide-out:Member, one per member). One screen component drives every frame.
 *
 * The page: the header with the two metric cards (MEMBERS, INTEREST REQUESTS, no destination) and the three buttons, the interest
 * request, the portrait cards of the team in two columns, and the shared project rail on the right (the Empty frame has the short one).
 *
 * What the prototype does: Invite collaborator opens the invite modal (on Team, Empty and the two answered states, and in the empty
 * state block), Send invitation closes it and shows its toast. Accept goes to the accepted state with its toast. Not now opens the
 * Not now modal, Send goes to the dismissed state with its toast. Both toasts have Undo, which goes back to Team. A member card opens
 * that member's slide-out (Message has no destination, Start meeting opens the lobby, Open full profile opens the member detail of
 * Adaeze Okoye). "View contribution history" opens the member detail. The "state-" routes are the frames that have no natural trigger:
 * the empty team and the overlay frames with the modal or the toast already showing.
 *
 * Adire Stories shows this page too (art-routes.tsx), with its own people and copy. Only the Team page is mirrored there, so an
 * answered request is shown in the page itself (local state, gone when the page is left) instead of by a route, Undo puts the request
 * back, "View contribution history" has no destination, and the links stay inside Adire Stories.
 */

const TOAST_MS = 2500;
/** The toast of a "state-" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

type ToastKind = 'invitation' | 'accepted' | 'response';

type ScreenProps = {
  view: TeamView;
  /** Frame Modal:Invite collaborator: the page with the invite modal open. */
  inviteOpen?: boolean;
  /** Frame Modal:Not now: the page with the Not now modal open. */
  notNowOpen?: boolean;
  /** Frames Toast:...: the page with the toast already showing. */
  toastKind?: ToastKind;
};

/**
 * The modal frames open a modal without a pointer, and the first field in it would then show its focus ring, which the frames do not
 * have. The ring stays hidden (body.pt-quiet) until the first key press, so keyboard use is never affected.
 */
function useQuietFocus(active: boolean) {
  useEffect(() => {
    if (!active) return;
    const body = document.body;
    const off = () => body.classList.remove('pt-quiet');
    body.classList.add('pt-quiet');
    document.addEventListener('keydown', off, { once: true });
    return () => {
      document.removeEventListener('keydown', off);
      off();
    };
  }, [active]);
}

function Screen({ view: routeView, inviteOpen, notNowOpen, toastKind }: ScreenProps) {
  const nav = useNav();
  const { key, nav: paths } = useProject();
  const team = useTeam();
  const [invite, setInvite] = useState(Boolean(inviteOpen));
  const [notNow, setNotNow] = useState(Boolean(notNowOpen));
  useQuietFocus(Boolean(inviteOpen || notNowOpen));
  // the member whose slide-out is open (the slide-out keeps its last member while it closes)
  const [open, setOpen] = useState<TeamMember | null>(null);
  const [slide, setSlide] = useState(false);
  // Adire Stories has no answered-state routes: the request is answered in place
  const [answered, setAnswered] = useState<TeamView | null>(null);
  const view = answered ?? routeView;

  // Undo of the two answer toasts returns to Team (the request is back); Undo of the invitation toast only closes the toast
  const undo = () => (key === 'career' ? nav.push(TEAM_PATHS.team) : setAnswered('team'));
  const showToast = (kind: ToastKind, ms: number) => {
    if (kind === 'invitation') toast.show({ message: team.toasts.invitation, actionLabel: 'Undo', duration: ms });
    else toast.show({ message: team.toasts[kind], actionLabel: 'Undo', duration: ms, onAction: undo });
  };

  useEffect(() => {
    if (toastKind) showToast(toastKind, STATE_TOAST_MS);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toastKind]);

  const sendInvitation = () => {
    setInvite(false);
    showToast('invitation', TOAST_MS);
  };
  const accept = () => {
    if (key === 'career') nav.push(TEAM_PATHS.accepted);
    else setAnswered('accepted');
    showToast('accepted', TOAST_MS);
  };
  const sendResponse = () => {
    setNotNow(false);
    if (key === 'career') nav.push(TEAM_PATHS.dismissed);
    else setAnswered('dismissed');
    showToast('response', TOAST_MS);
  };
  const openMember = (m: TeamMember) => {
    setOpen(m);
    setSlide(true);
  };

  const { head, requestsBand, membersBand, empty } = team;
  const facts = team.facts[view];
  const members = view === 'accepted' ? team.accepted : team.members;
  // the slide-out names the person by their own profile role (Amina Yusuf joined as Product Designer, her profile says Career Researcher)
  const shown = open ? { ...open, role: open.profileRole ?? open.role } : null;

  return (
    <WorkspaceFrame active="team" rail={view === 'empty' ? 'short' : true}>
      <div className={view === 'empty' ? 'pt-page pt-page--empty' : 'pt-page'}>
        <PageHead label={head.label} title={head.title} lead={head.lead}>
          <MetricRow>
            <MetricCard label="MEMBERS" value={facts.members.value} caption={facts.members.caption} />
            {/* the card opens the Applicants page (Empty when nobody is waiting); Adire Stories has no applicants page of its own and uses the one of Career Guidance for Everyone */}
            <MetricCard label="INTEREST REQUESTS" value={facts.requests.value} caption={facts.requests.caption} dot={facts.requests.dot} href={view === 'empty' ? APPLICANT_PATHS.empty : APPLICANT_PATHS.list} />
          </MetricRow>
          <div className="cw-actions cw-actions--btns">
            <Button onClick={() => setInvite(true)} aria-haspopup="dialog">
              {head.invite}
            </Button>
            <Button variant="secondary" href={paths.agreements}>
              {head.agreements}
            </Button>
            {/* the member detail is not mirrored on Adire Stories: the link has no destination there */}
            {view === 'empty' ? null : <CardLink href={key === 'career' ? TEAM_PATHS.member : undefined}>{head.history}</CardLink>}
          </div>
        </PageHead>

        {view === 'empty' ? (
          <div data-m="up">
            <EmptyState
              className="cw-empty"
              title={empty.title}
              text={empty.text}
              action={
                <Button arrow="up-right" onClick={() => setInvite(true)} aria-haspopup="dialog">
                  {empty.action}
                </Button>
              }
            />
          </div>
        ) : (
          <>
            <Band label={requestsBand.label} {...(view === 'team' ? requestsBand.waiting : requestsBand.none)}>
              {view === 'team' ? (
                // Review sits at the right of Accept and Not now and opens the Applicants page
                <div className="ap-reqwrap">
                  <InterestRequest onAccept={accept} onNotNow={() => setNotNow(true)} />
                  <CardLink className="ap-reqwrap__review" href={APPLICANT_PATHS.list}>
                    Review
                  </CardLink>
                </div>
              ) : (
                <ConfirmationLine message={team.confirmation[view]} />
              )}
            </Band>

            <Band label={membersBand.label} title={view === 'accepted' ? membersBand.five : membersBand.four} support={membersBand.support}>
              <ul className="pt-grid">
                {members.map((m, i) => (
                  <li key={m.id}>
                    <MemberCard m={m} onOpen={openMember} wide={members.length % 2 === 1 && i === members.length - 1} />
                  </li>
                ))}
              </ul>
            </Band>
          </>
        )}
      </div>

      <InviteModal open={invite} onClose={() => setInvite(false)} onSend={sendInvitation} />
      <NotNowModal open={notNow} onClose={() => setNotNow(false)} onSend={sendResponse} />
      <MemberSlideOut member={shown} open={slide} onClose={() => setSlide(false)} />
    </WorkspaceFrame>
  );
}

export const Team = () => <Screen view="team" />;
export const TeamEmpty = () => <Screen view="empty" />;
export const TeamAccepted = () => <Screen view="accepted" />;
export const TeamDismissed = () => <Screen view="dismissed" />;
/** Frame "Modal:Invite collaborator": Team with the invite modal open. */
export const TeamInviteModal = () => <Screen view="team" inviteOpen />;
/** Frame "Toast:Invitation sent": Team with the toast showing. */
export const TeamInvitationSent = () => <Screen view="team" toastKind="invitation" />;
/** Frame "Toast:Request accepted": the accepted state with the toast showing. */
export const TeamAcceptedToast = () => <Screen view="accepted" toastKind="accepted" />;
/** Frame "Modal:Not now": Team with the Not now modal open. */
export const TeamNotNowModal = () => <Screen view="team" notNowOpen />;
/** Frame "Toast:Response sent": the dismissed state with the toast showing. */
export const TeamResponseSent = () => <Screen view="dismissed" toastKind="response" />;
