'use client';

import { useEffect, useRef, useState, useSyncExternalStore } from 'react';

export type Layout = 'mobile' | 'tablet' | 'desktop';

/** Matches the design breakpoints: mobile < 768 (402), tablet 768 to 1279 (1194), desktop 1280+ (1512). */
export const MQ = { mobile: '(max-width: 767px)', tablet: '(min-width: 768px) and (max-width: 1279px)' } as const;

function subscribe(cb: () => void) {
  const a = window.matchMedia(MQ.mobile);
  const b = window.matchMedia(MQ.tablet);
  a.addEventListener('change', cb);
  b.addEventListener('change', cb);
  return () => {
    a.removeEventListener('change', cb);
    b.removeEventListener('change', cb);
  };
}
const snapshot = (): Layout =>
  window.matchMedia(MQ.mobile).matches ? 'mobile' : window.matchMedia(MQ.tablet).matches ? 'tablet' : 'desktop';

/** Current layout. Server and first client render say "desktop". */
export function useLayout(): Layout {
  return useSyncExternalStore(subscribe, snapshot, () => 'desktop');
}

export function useReducedMotion(): boolean {
  return useSyncExternalStore(
    (cb) => {
      const m = window.matchMedia('(prefers-reduced-motion: reduce)');
      m.addEventListener('change', cb);
      return () => m.removeEventListener('change', cb);
    },
    () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    () => false,
  );
}

/** Calls `handler` when a pointer goes down outside `ref` or Escape is pressed, while `active`. */
export function useDismiss(active: boolean, ref: React.RefObject<HTMLElement | null>, handler: () => void) {
  const h = useRef(handler);
  h.current = handler;
  useEffect(() => {
    if (!active) return;
    const down = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) h.current();
    };
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') h.current();
    };
    document.addEventListener('pointerdown', down);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', down);
      document.removeEventListener('keydown', key);
    };
  }, [active, ref]);
}

/** Locks page scroll while `active` (modals, drawers, sheets). Keeps the scrollbar gutter so nothing shifts. */
export function useScrollLock(active: boolean) {
  useEffect(() => {
    if (!active) return;
    const html = document.documentElement;
    const prev = html.style.overflow;
    const prevGutter = html.style.scrollbarGutter;
    html.style.scrollbarGutter = 'stable';
    html.style.overflow = 'hidden';
    return () => {
      html.style.overflow = prev;
      html.style.scrollbarGutter = prevGutter;
    };
  }, [active]);
}

/** useState that survives remounts of the same screen during one visit (not across reloads). */
const memo = new Map<string, unknown>();
export function useMemoState<T>(key: string, initial: T): [T, (v: T | ((p: T) => T)) => void] {
  const [v, setV] = useState<T>(() => (memo.has(key) ? (memo.get(key) as T) : initial));
  const set = (next: T | ((p: T) => T)) =>
    setV((prev) => {
      const val = typeof next === 'function' ? (next as (p: T) => T)(prev) : next;
      memo.set(key, val);
      return val;
    });
  return [v, set];
}
