# UI kit contract (`@/ui`)

The kit worker implements EXACTLY this API in `src/ui/*` with `src/ui/index.ts` re-exporting everything; feature workers import only from `@/ui`
(and `@/ui/toast` for `toast`). Look and motion follow the Figma Components page (1:1120) and the Akines motion language (BUILD_GUIDE.md).
All components are client components, forward refs where it matters, and accept `className` (appended) and standard DOM attributes of their element.
Kit classes are prefixed `k-`; kit CSS lives in `src/styles/ui.css`. If a feature needs something not listed, build it locally with the feature prefix.

```ts
// Buttons and links
// The one button of the product is the landing page pill (rising fill, label swap, ring, arrow nudge). Colour table: BUTTON_SPEC.md, living gallery: /design/buttons
Button      { variant?: 'primary'|'secondary'|'accent'|'ghost'|'danger'|'link'  // default 'primary'
              tone?: 'dark'|'light'                                     // default 'dark' (for light surfaces), light is for photographs and dark surfaces
              size?: 'sm'|'md'|'lg'|'xl'                                // default 'md' (48 high), sm 36, lg 56, xl 62 (48 below 1280)
              fluid?: boolean                                           // landing only: the old landing box (md 48 then 50, xl 48 then 62)
              icon?: ReactNode; iconRight?: ReactNode                   // iconRight nudges on hover
              arrow?: 'up-right'|'down'|'right'                         // built-in arrow after the label, nudges the way it points
              loading?: boolean                                         // spinner left of the label, keeps the width, ignores clicks, aria-busy
              looksDisabled?: boolean                                   // grey but still clickable (forms that explain what is missing), aria-disabled
              disabled?: boolean; fullWidth?: boolean
              href?: string }                                           // with href it renders <AppLink> (class k-btn), otherwise <button type="button">
IconButton  { label: string /* aria-label, tooltip */; size?: 'sm'|'md'|'lg'  // 36, 44 (default), 52
              variant?: 'ghost'|'solid'|'outline'; tone?: 'dark'|'light'
              href?: string; tooltip?: boolean /* default true */; children: ReactNode }
Chip        { selected?: boolean; icon?: ReactNode; count?: number|string; removable?: boolean; onRemove?: () => void; as?: 'button'|'span'; children }
Tag         { tone?: 'neutral'|'accent'|'success'|'warning'|'danger'|'info'; icon?: ReactNode; children }
Avatar      { name: string /* initials fallback */; src?: string; size?: 24|32|36|44|56|72|96; tone?: 'warm'|'ink'|'sage' }
// Forms
Field       { label?: string; hint?: string; error?: string; required?: boolean; htmlFor?: string; children }  // label above, hint or error below (error replaces hint, role="alert")
TextInput   input attrs + { invalid?: boolean; iconLeft?: ReactNode; iconRight?: ReactNode }   // forwardRef<HTMLInputElement>
TextArea    textarea attrs + { invalid?: boolean; maxLength?: number /* shows a 12/280 style counter when set */ }
Select      select attrs + { invalid?: boolean }                       // native <select> styled, chevron icon
Checkbox    { checked: boolean; onChange: (checked: boolean) => void; label: ReactNode; description?: ReactNode; disabled?: boolean; id?: string }
Radio       { checked: boolean; onChange: () => void; label: ReactNode; description?: ReactNode; name: string; value: string; disabled?: boolean }
Toggle      { checked: boolean; onChange: (checked: boolean) => void; label?: ReactNode; disabled?: boolean; 'aria-label'?: string }   // role="switch"
// Navigation
Tabs        { items: { id: string; label: string; count?: number }[]; value: string; onChange: (id: string) => void; variant?: 'underline'|'pill'; ariaLabel: string }
// Overlays (React state in the screen, never routes)
Modal       { open: boolean; onClose: () => void; title?: ReactNode; description?: ReactNode; size?: 'sm'|'md'|'lg'|'xl' /* 480 600 760 960 */;
              footer?: ReactNode; hideClose?: boolean; closeOnBackdrop?: boolean /* default true */; label?: string /* aria-label if no title */; children }
              // centred dialog on tablet and desktop, bottom sheet below 768; portal to document.body; focus trap; Escape; scroll lock; restores focus; enter 0.45s rise, exit 0.28s
Drawer      { open: boolean; onClose: () => void; side?: 'right'|'left'; width?: number /* default 480 */; title?: ReactNode; footer?: ReactNode; label?: string; children }  // full width bottom sheet below 768
Menu        { trigger: (p: { ref: Ref<HTMLButtonElement>; onClick: () => void; 'aria-expanded': boolean; 'aria-haspopup': 'menu' }) => ReactNode;
              items: ({ label: string; onSelect: () => void; icon?: ReactNode; danger?: boolean; disabled?: boolean } | 'divider')[]; align?: 'start'|'end' }
Tooltip     { label: string; children: ReactElement }                 // dark pill like the header tooltips, shows on hover and focus
Skeleton    { width?: number|string; height?: number|string; radius?: number|string; className?: string }   // soft shimmer block for loading states (static under reduced motion)
EmptyState  { title: string; text?: string; action?: ReactNode; icon?: ReactNode }   // centred empty block
InlineError { title?: string; text: string; onRetry?: () => void; retryLabel?: string }  // "could not load" row with retry button
// Toast (already exists in src/ui/toast.tsx, API unchanged): toast.show({ message, actionLabel?, onAction?, duration? })
```
