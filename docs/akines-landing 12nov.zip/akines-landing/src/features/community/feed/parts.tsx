'use client';

/** Building blocks of the Community Home feed (prefix fd-). Buttons, chips and skeletons come from the kit (@/ui). */
import type { ReactNode } from 'react';
import { CircleAlert, RefreshCw } from 'lucide-react';
import { Button, Skeleton } from '@/ui';
import { Link } from '@/lib/nav';
import { useLayout } from '@/lib/hooks';
import { cx, IArrow, IRefresh } from '../ui';
import { ERROR_COPY, LOADING_NOTE, type FaceKey, type FeedCardData, type Img, type SectionHead } from './content';
import { faceImg, src } from './images';

/** Photograph with the curtain reveal (data-m="frame"). Size and shape come from the class that wraps it. */
export function FeedPhoto({ image, className, eager, position }: { image: Img; className?: string; eager?: boolean; position?: string }) {
  return (
    <div className={cx('fd-photo', className)} data-m="frame">
      <img className="cover" src={src(image)} alt="" loading={eager ? 'eager' : 'lazy'} decoding="async" draggable={false} style={position ? { objectPosition: position } : undefined} />
    </div>
  );
}

/** `size` is the default; an ancestor can set --fd-face (the phone layout does, feed-mobile.css). */
export function Face({ image, size = 32, ring }: { image: Img; size?: number; ring?: boolean }) {
  const s = `var(--fd-face, ${size}px)`;
  return (
    <span className={cx('fd-av', ring && 'fd-av--ring')} style={{ width: s, height: s }}>
      <img src={src(image)} alt="" loading="lazy" decoding="async" draggable={false} />
    </span>
  );
}

export function FaceStack({ faces, size = 32, overlap = 8 }: { faces: FaceKey[]; size?: number; overlap?: number }) {
  return (
    <span className="fd-avs" style={{ ['--fd-overlap' as string]: `-${overlap}px` }}>
      {faces.map((f) => (
        <Face key={f} image={faceImg(f)} size={size} ring />
      ))}
    </span>
  );
}

/** Underlined text link with an arrow (Figma Card Link). */
export function ArrowLink({ href, onClick, children, className }: { href?: string; onClick?: () => void; children: ReactNode; className?: string }) {
  const inner = (
    <>
      <span>{children}</span>
      <IArrow />
    </>
  );
  return href ? (
    <Link href={href} className={cx('fd-link', className)}>
      {inner}
    </Link>
  ) : (
    <button type="button" className={cx('fd-link', className)} onClick={onClick}>
      {inner}
    </button>
  );
}

/** Section header: title (Alice 32), support, and a right aligned underlined link with an arrow. */
export function SectionHeader({ id, head }: { id: string; head: SectionHead }) {
  return (
    <header className="fd-head" data-m="up">
      <div className="fd-head__copy">
        <h2 className="fd-head__title" id={id}>
          {head.title}
        </h2>
        <p className="fd-head__support">{head.support}</p>
      </div>
      {head.link ? <ArrowLink href={head.link.href}>{head.link.label}</ArrowLink> : null}
    </header>
  );
}

/** The feed card: square photo, optional tag, title, description and a meta row. The whole card is one link. */
export function FeedCard({ card }: { card: FeedCardData }) {
  return (
    <Link className="fd-card fd-card--sub" href={card.href}>
      <FeedPhoto image={card.image} className="fd-card__photo" />
      {card.tag ? <p className="fd-card__tag">{card.tag}</p> : null}
      <h3 className="fd-card__title">{card.title}</h3>
      <p className="fd-card__text">{card.text}</p>
      {card.left || card.right ? (
        <div className="fd-card__meta">
          <span>{card.left}</span>
          {card.right ? <span>{card.right}</span> : null}
        </div>
      ) : null}
      <span className="fd-card__rule" aria-hidden="true" />
    </Link>
  );
}

export function CardRow({ cards }: { cards: FeedCardData[] }) {
  return (
    <div className="fd-row fd-row--sub" data-m="stagger">
      {cards.map((c) => (
        <FeedCard key={c.id} card={c} />
      ))}
    </div>
  );
}

/* ---------------------------------------------------------------- loading and error */
const fill = { width: '100%', height: '100%', radius: 0 } as const;

/** Phone sizes of Feed Skeleton Section / Mobile (Figma 18080:171524): square bars, card photo 264 x 198, title 180 x 20, lines 240 and 200 x 12. */
const SK_PHONE = { title: [180, 20], lines: [[240, 12], [200, 12]], head: [[220, 28], [300, 14]] } as const;

export function SkeletonCards({ n = 3 }: { n?: number }) {
  const phone = useLayout() === 'mobile';
  return (
    <div className="fd-row fd-row--sk" aria-hidden="true">
      {Array.from({ length: n }, (_, i) => (
        <div className="fd-sk-card" key={i}>
          <div className="fd-sk-photo">
            <Skeleton {...fill} />
          </div>
          {phone ? (
            <>
              <Skeleton width={SK_PHONE.title[0]} height={SK_PHONE.title[1]} radius={0} />
              {SK_PHONE.lines.map(([w, h]) => (
                <Skeleton key={w} width={w} height={h} radius={0} />
              ))}
            </>
          ) : (
            <>
              <Skeleton width="86%" height={24} radius={2} />
              <Skeleton width="100%" height={14} radius={2} />
              <Skeleton width="64%" height={14} radius={2} />
            </>
          )}
        </div>
      ))}
    </div>
  );
}

/** Shown on the server, for the first paint and while a section reloads. Phones: two bars and no link (Figma). */
export function SkeletonSection({ withLink = true }: { withLink?: boolean }) {
  const phone = useLayout() === 'mobile';
  return (
    <div className="fd-section fd-section--sk" aria-hidden="true">
      <div className="fd-head">
        <div className="fd-head__copy">
          {phone ? (
            SK_PHONE.head.map(([w, h]) => <Skeleton key={w} width={`min(${w}px, 100%)`} height={h} radius={0} />)
          ) : (
            <>
              <Skeleton width="min(420px, 80%)" height={32} radius={2} />
              <Skeleton width="min(560px, 90%)" height={16} radius={2} />
            </>
          )}
        </div>
        {withLink && !phone ? <Skeleton width={96} height={16} radius={2} /> : null}
      </div>
      <SkeletonCards />
    </div>
  );
}

/** Six grey sections. `note` adds the "Getting things ready" line above them (the loading state route). */
export function FeedSkeleton({ note }: { note?: boolean }) {
  const phone = useLayout() === 'mobile';
  return (
    <div className="fd-feed__sk" aria-busy="true" aria-label="Loading your feed" role="status">
      {note ? (
        <p className="fd-note">
          {phone ? <RefreshCw size={16} strokeWidth={1.5} absoluteStrokeWidth aria-hidden focusable={false} /> : <IRefresh s={18} />}
          <span>{LOADING_NOTE}</span>
        </p>
      ) : null}
      {Array.from({ length: 6 }, (_, i) => (
        <SkeletonSection key={i} />
      ))}
    </div>
  );
}

export function ErrorPanel({ onRetry }: { onRetry: () => void }) {
  // Phones: the alert icon sits beside the title (Figma Feed Section Error / Mobile 18080:171552).
  const phone = useLayout() === 'mobile';
  const title = <h3 className="fd-error__title">{ERROR_COPY.title}</h3>;
  return (
    <div className="fd-error" role="alert">
      {phone ? (
        <div className="fd-error__head">
          <span className="fd-error__icon" aria-hidden="true">
            <CircleAlert size={24} strokeWidth={1.5} absoluteStrokeWidth aria-hidden focusable={false} />
          </span>
          {title}
        </div>
      ) : (
        title
      )}
      <p className="fd-error__text">{ERROR_COPY.text}</p>
      <div>
        <Button variant="secondary" onClick={onRetry}>
          {ERROR_COPY.retry}
        </Button>
      </div>
    </div>
  );
}
