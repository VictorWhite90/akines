/** Image URL helpers for the feed. Plain module: the preview build swaps @/lib/assets for its relative-path twin. */
import { asset } from '@/lib/assets';
import { imgPath, type FaceKey, type Img } from './content';

export const src = (img: Img) => asset(imgPath(img));
export const faceImg = (k: FaceKey): Img => `community/av-${k}`;
