'use client';

/**
 * Static frames of the sign-in panel (routes /sign-in/state-*): the landing page with the panel opened in the state of a
 * Figma frame (Focus, Missing, Invalid, Loading, Success). The default state is the live panel (route /sign-in).
 */
import { useEffect } from 'react';
import { LandingPage } from '@/features/landing/LandingPage';
import { usePath } from '@/lib/nav';
import { closeSignIn, openSignIn } from './panel-store';
import { setSignInPreset } from './SignInPanel';
import { SIGN_IN_FRAMES } from './signin-frames';

/** One component for every /sign-in/state-* route: it picks its preset from the current path. */
export function SignInStateFrame() {
  const path = usePath();
  const frame = SIGN_IN_FRAMES.find((f) => path === `/sign-in/state-${f.slug}`);
  const preset = frame ? frame.slug : null;
  useEffect(() => {
    if (!preset) return;
    setSignInPreset(preset);
    openSignIn();
    return () => {
      closeSignIn();
      setSignInPreset(null);
    };
  }, [preset]);
  return <LandingPage />;
}
