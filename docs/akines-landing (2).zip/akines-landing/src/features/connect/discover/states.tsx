'use client';

/**
 * Loading, empty and error parts of Discover, built to the Figma state frames (Loading 17904:100345, Section error 17904:115875,
 * Empty 17904:116242). Styles: states.css (prefix dxs-).
 *
 *  - Loading: DiscoverSkeleton stands in for For you, Explore by interest and the recommendations (Explore and the rail stay live).
 *    There is no visible note in the Figma frame, so the status is announced to assistive technology only.
 *  - Error: SectionError is the Community Home error panel with the Discover message and a 56 padding. It is built here rather than
 *    reused because ErrorPanel in the community feed has fixed copy and no icon.
 *  - Empty: EmptyText (Section Empty, used by the recommendations and available to the interests), EmptyCircles and EmptyMatch (rail).
 */
import './states.css';
import type { ReactNode } from 'react';
import { CircleAlert } from 'lucide-react';
import { Button } from '@/ui';
import { MATCH_COPY } from '@/features/community/feed/content';
import { LOADING_NOTE, STATE_COPY } from './data';

/* ---------------------------------------------------------------- loading */
/** Title bar 220 x 28 and support bar 440 x 16: the header of every skeleton section. */
function HeaderSkeleton() {
  return (
    <div className="dxs-head">
      <span className="dxs-bar dxs-head__title" />
      <span className="dxs-bar dxs-head__support" />
    </div>
  );
}

/** One Discover Card Skeleton (312 x 541 at 1512): photo, name and two lines, then a footer with a hairline. Pulses with the others. */
function DiscoverCardSkeleton() {
  return (
    <div className="dxs-dcard">
      <span className="dxs-dcard__photo dxs-pulse" />
      <div className="dxs-dcard__text">
        <span className="dxs-dcard__name dxs-pulse" />
        <span className="dxs-dcard__line dxs-pulse" />
        <span className="dxs-dcard__line dxs-dcard__line--short dxs-pulse" />
      </div>
      <div className="dxs-dcard__foot">
        <span className="dxs-dcard__bar dxs-pulse" />
      </div>
    </div>
  );
}

function InterestCardSkeleton() {
  return (
    <div className="dxs-icard">
      <span className="dxs-icard__title" />
      <span />
      <span />
      <span className="dxs-icard__short" />
      <div className="dxs-icard__action">
        <span />
      </div>
    </div>
  );
}

/** One Recommendation Card Skeleton (480 x 371): top row, profile row, three tags, two lines of reason and two buttons. */
function RecommendationCardSkeleton() {
  return (
    <div className="dxs-rcard">
      <div className="dxs-rcard__top">
        <span className="dxs-rcard__eyebrow" />
        <span className="dxs-rcard__match" />
      </div>
      <div className="dxs-rcard__who">
        <span className="dxs-rcard__photo" />
        <div className="dxs-rcard__id">
          <span className="dxs-rcard__name" />
          <span className="dxs-rcard__role" />
        </div>
      </div>
      <div className="dxs-rcard__tags">
        <span style={{ width: 76 }} />
        <span style={{ width: 126 }} />
        <span style={{ width: 146 }} />
      </div>
      <div className="dxs-rcard__reason">
        <span />
        <span style={{ width: 300, maxWidth: '70%' }} />
      </div>
      <div className="dxs-rcard__acts">
        <span />
        <span />
      </div>
    </div>
  );
}

/**
 * The recommendation cards only (2 x 2), for the section whose header stays: while "Try again" reloads it, and inside
 * SectionSkeleton. `cards` is 4 in the design. Announces the loading status to assistive technology only.
 */
export function CardsSkeleton({ cards = 4 }: { cards?: number }) {
  return (
    <div className="dxs-rcards" role="status" aria-busy="true">
      <p className="sr-only">{LOADING_NOTE}</p>
      <div className="dxs-rgrid" aria-hidden="true">
        {Array.from({ length: cards }, (_, i) => (
          <RecommendationCardSkeleton key={i} />
        ))}
      </div>
    </div>
  );
}

export type SkeletonKind = 'for-you' | 'interests' | 'recommendations';

/** A grey section: header skeleton, then the cards of the section (6, 4 or 4 of them). Decorative, so hidden from assistive technology. */
export function SectionSkeleton({ kind }: { kind: SkeletonKind }) {
  return (
    <div className="dxs-section" aria-hidden="true">
      <HeaderSkeleton />
      {kind === 'for-you' ? (
        <div className="dxs-dgrid">
          {Array.from({ length: 6 }, (_, i) => (
            <DiscoverCardSkeleton key={i} />
          ))}
        </div>
      ) : kind === 'interests' ? (
        <div className="dxs-igrid">
          {Array.from({ length: 4 }, (_, i) => (
            <InterestCardSkeleton key={i} />
          ))}
        </div>
      ) : (
        <div className="dxs-rcards">
          <div className="dxs-rgrid">
            {Array.from({ length: 4 }, (_, i) => (
              <RecommendationCardSkeleton key={i} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * The loading state: For you on Akines (3 x 2 cards), Explore by interest (4) and People whose journeys complement yours (2 x 2).
 * Explore is not here: it is live while the rest loads. One status for assistive technology, nothing visible besides the skeletons.
 */
export function DiscoverSkeleton() {
  return (
    <div className="dxs-sk" role="status" aria-busy="true">
      <p className="sr-only">{LOADING_NOTE}</p>
      <SectionSkeleton kind="for-you" />
      <SectionSkeleton kind="interests" />
      <SectionSkeleton kind="recommendations" />
    </div>
  );
}

/* ---------------------------------------------------------------- empty */
/** Section Empty: a message between two hairlines that keeps the context of the section (interests, recommendations). No action. */
export function EmptyText({ children }: { children: ReactNode }) {
  return <p className="dxs-empty">{children}</p>;
}

/** Rail, Your circles, when the member has joined none. `onFind` runs on "Find circles" (a plain button when it is missing). */
export function EmptyCircles({ onFind }: { onFind?: () => void }) {
  const c = STATE_COPY.circlesEmpty;
  return (
    <section className="fd-box dxs-rail-empty" aria-labelledby="fd-circles-title">
      <h2 className="fd-box__title" id="fd-circles-title">
        {c.title}
      </h2>
      <p className="dxs-rail-empty__text">{c.text}</p>
      <button type="button" className="fd-link" onClick={onFind}>
        {c.link}
      </button>
    </section>
  );
}

/** Rail, You two would get along, when there is nothing to suggest. Same box, Discover wording, no link. */
export function EmptyMatch() {
  return (
    <section className="fd-box dxs-rail-empty" aria-labelledby="fd-match-title">
      <h2 className="fd-box__title" id="fd-match-title">
        {MATCH_COPY.title}
      </h2>
      <p className="dxs-rail-empty__text">{STATE_COPY.matchEmpty}</p>
    </section>
  );
}

/* ---------------------------------------------------------------- error */
/** The section error panel: warning icon and "We could not load this section.", the message and "Try again". */
export function SectionError({ onRetry }: { onRetry: () => void }) {
  const c = STATE_COPY.sectionError;
  return (
    <div className="dxs-error" role="alert">
      <div className="dxs-error__head">
        <CircleAlert className="dxs-error__icon" size={24} strokeWidth={1.5} absoluteStrokeWidth aria-hidden="true" focusable="false" />
        <h3 className="dxs-error__title">{c.title}</h3>
      </div>
      <p className="dxs-error__text">{c.text}</p>
      <div className="dxs-error__actions">
        <Button variant="secondary" onClick={onRetry}>
          {c.retry}
        </Button>
      </div>
    </div>
  );
}
