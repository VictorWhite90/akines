'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { asset } from '@/lib/assets';
import { useNav } from '@/lib/nav';
import { Button } from '@/ui';
import { callClock, callStore, useCall } from './call-store';
import { CameraIcon, CameraOffIcon, ChatIcon, LeaveIcon, MicIcon, MicOffIcon, PeopleIcon, PresentIcon } from './CallIcons';
import { ChatPanel, PeoplePanel, type ChatMessage, type PanelKind } from './Panels';
import { LiveVideo, MutedTile, PhotoTile, RoundButton, SelfTile, useCast, useLeaveGuard, useSelf } from './parts';
import { meetings } from './store';

/**
 * In call (Figma 12.43 In call 17809:110599, Screen sharing 17809:110707, People 17809:110810, Chat 17809:110965).
 * Your own tile and the shared screen are real when the browser gave the devices; the other three people are simulated: portraits, Ngozi muted,
 * one speaker with the amber border who changes every few seconds. People and Chat are local state. `initial` opens the call already in a state
 * (the frames reached by their own address): a panel open, or presenting with the shared screen placeholder.
 */
export type CallInitial = { panel?: PanelKind; presenting?: boolean };

const SPEAKER_EVERY = 4500;

export function CallScreen({ simulate = false, initial = {} }: { simulate?: boolean; initial?: CallInitial }) {
  const cast = useCast();
  const nav = useNav();
  const call = useCall();
  const self = useSelf(simulate);
  useLeaveGuard();

  const [panel, setPanel] = useState<PanelKind | null>(initial.panel ?? null);
  const [placeholder, setPlaceholder] = useState(Boolean(initial.presenting));
  const presenting = Boolean(call.screen) || placeholder;
  const [speaker, setSpeaker] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    { id: 'm1', name: cast.others[0].name, time: '4:12 PM', text: 'I can see the second screen now.' },
    { id: 'm2', name: cast.others[2].name, time: '4:14 PM', text: 'Could we look at the last question again?' },
  ]);

  const panelRef = useRef<HTMLElement>(null);
  const peopleBtn = useRef<HTMLButtonElement>(null);
  const chatBtn = useRef<HTMLButtonElement>(null);
  const fromUser = useRef(false);

  // Joined: the clock starts, devices are asked for when the Lobby did not (a direct visit), a note of an earlier try is gone.
  useEffect(() => {
    callStore.markJoined();
    callStore.clearScreenNote();
    if (!simulate) void callStore.request();
  }, [simulate]);

  // The speaker rotates between the two people who are not muted.
  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    const id = window.setInterval(() => setSpeaker((s) => (s + 1) % 2), SPEAKER_EVERY);
    return () => window.clearInterval(id);
  }, []);

  // The clock of the call.
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 15000);
    return () => window.clearInterval(id);
  }, []);

  // The note that Present did not start fades after a few seconds.
  useEffect(() => {
    if (!call.screenNote) return;
    const id = window.setTimeout(() => callStore.clearScreenNote(), 6000);
    return () => window.clearTimeout(id);
  }, [call.screenNote]);

  const clock = callClock(call.joinedAt, now);

  const closePanel = useCallback(() => {
    (panel === 'chat' ? chatBtn : peopleBtn).current?.focus();
    setPanel(null);
  }, [panel]);

  // A panel the person opened takes focus; Escape closes it.
  useEffect(() => {
    if (!panel) return;
    if (fromUser.current) panelRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closePanel();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [panel, closePanel]);

  const togglePanel = (kind: PanelKind) => {
    fromUser.current = true;
    setPanel((cur) => (cur === kind ? null : kind));
  };

  const onPresent = async () => {
    if (presenting) {
      callStore.stopPresenting();
      setPlaceholder(false);
      return;
    }
    await callStore.present();
  };
  const stopPresenting = () => {
    callStore.stopPresenting();
    setPlaceholder(false);
  };

  const end = () => {
    meetings.end(cast.key);
    callStore.stopAll();
    nav.push(cast.paths.ended);
  };

  const send = (text: string) => {
    setMessages((m) => [...m, { id: `m${m.length + 1}-${Date.now()}`, name: cast.youName, time: callClock(callStore.get().joinedAt), text }]);
  };

  const [a, b, c] = cast.others;
  const speakers = [a, b];

  return (
    <div className="mc-call">
      <h1 className="mc-sr">{cast.meeting.name}</h1>
      <div className={`mc-stage${panel ? ' mc-stage--panel' : ''}${presenting ? ' mc-stage--share' : ''}`}>
        <div className="mc-main">
          {presenting ? (
            <>
              <div className="mc-share">
                {call.screen ? (
                  <LiveVideo stream={call.screen} contain />
                ) : (
                  <img className="mc-share__img" src={asset('/images/app/meet/shared-screen.jpg')} alt="Your shared screen" draggable={false} />
                )}
                <div className="mc-pill" role="status">
                  <span className="mc-pill__dot" aria-hidden="true" />
                  <span className="mc-pill__text">You are presenting to everyone</span>
                  <Button variant="danger" size="sm" onClick={stopPresenting}>
                    Stop presenting
                  </Button>
                </div>
              </div>
              <div className="mc-side">
                <PhotoTile person={a} speaking={speakers[speaker] === a} />
                <PhotoTile person={b} speaking={speakers[speaker] === b} />
                <MutedTile person={c} />
              </div>
            </>
          ) : (
            <div className="mc-grid">
              <PhotoTile person={a} speaking={speakers[speaker] === a} />
              <PhotoTile person={b} speaking={speakers[speaker] === b} />
              <MutedTile person={c} />
              <SelfTile self={self} person={cast.you} name={cast.youName} badge />
            </div>
          )}
        </div>
        {panel === 'people' ? <PeoplePanel ref={panelRef} cast={cast} self={self} onClose={closePanel} /> : null}
        {panel === 'chat' ? <ChatPanel ref={panelRef} messages={messages} onSend={send} onClose={closePanel} /> : null}
        {call.screenNote ? (
          <p className="mc-callnote" role="status">
            {call.screenNote}
          </p>
        ) : null}
      </div>

      <div className="mc-bar" role="group" aria-label="Call controls">
        <div className="mc-info">
          <span className="mc-info__time">{clock}</span>
          <span className="mc-info__sep" aria-hidden="true" />
          <span className="mc-info__name">{cast.meeting.name}</span>
        </div>
        <div className="mc-bar__center">
          <RoundButton label={self.micMuted ? 'Turn on microphone' : 'Turn off microphone'} tone={self.micMuted ? 'alert' : 'default'} onClick={self.toggleMic}>
            {self.micMuted ? <MicOffIcon /> : <MicIcon />}
          </RoundButton>
          <RoundButton label={self.camOff ? 'Turn on camera' : 'Turn off camera'} tone={self.camOff ? 'alert' : 'default'} onClick={self.toggleCam}>
            {self.camOff ? <CameraOffIcon /> : <CameraIcon />}
          </RoundButton>
          <RoundButton label="Present" tone={presenting ? 'selected' : 'default'} pressed={presenting} onClick={onPresent}>
            <PresentIcon />
          </RoundButton>
          <RoundButton label="Leave meeting" tone="alert" wide onClick={end}>
            <LeaveIcon />
          </RoundButton>
        </div>
        <div className="mc-bar__right">
          <RoundButton buttonRef={peopleBtn} label="People" tone={panel === 'people' ? 'selected' : 'default'} pressed={panel === 'people'} onClick={() => togglePanel('people')}>
            <PeopleIcon />
          </RoundButton>
          <RoundButton buttonRef={chatBtn} label="Chat" tone={panel === 'chat' ? 'selected' : 'default'} pressed={panel === 'chat'} onClick={() => togglePanel('chat')}>
            <ChatIcon />
          </RoundButton>
        </div>
      </div>
    </div>
  );
}
