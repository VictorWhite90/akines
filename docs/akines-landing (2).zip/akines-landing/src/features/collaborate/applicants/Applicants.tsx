'use client';

import './applicants.css';
import '../workspace/workspace.css';
import { useEffect, useState } from 'react';
import { useNav } from '@/lib/nav';
import { Button, EmptyState } from '@/ui';
import { toast } from '@/ui/toast';
import { LOADING_MS } from '../projects/store';
import { BackLink } from '../workspace/atoms';
import { WorkspaceFrame } from '../workspace/parts';
import { PROJECT_PATH } from '../workspace/data';
import { ApplicantRow, CompareBar, CompareTable, FilterChips, JoinedNotice, RowSkeleton, type ChipItem, type CompareColumn, type RowHandlers } from './parts';
import { APPLICANTS, APPLICANT_PATHS, COMPARE, JOINED_NOTICE, LINKS, ORDER, PAGE, ROW, summaryLine, type ApplicantId, type Status } from './data';
import { useReviewer } from './reviewer';
import { SAMPLE_COMPARE, applicants, countsOf, peopleOf, useApplicantState, useSeeded, type ProjectSeed } from './store';

/**
 * 12.45 REVIEW APPLICANTS. Applicants (17974:162819) with its variants Compare selected (17974:168901), Loading (17974:169891), Empty (17974:170183),
 * Could not load (17974:170436), Offer sent (17974:174218), Joined (17974:174749) and Not now (17974:175283); Compare (17974:169471) is its own page.
 * The people, their statuses, the filter, the compare ticks and the actions are data driven (store.ts); the frames that show another state of
 * the list seed that state when their route opens.
 */

export type ApplicantsVariant = 'loading' | 'empty' | 'error' | ProjectSeed;
const SEEDS: ProjectSeed[] = ['compare-selected', 'offer-sent', 'joined', 'not-now'];

/** "Share the project link": copies the link and shows Toast:Link copied. */
export function copyLink(path: string, message: string) {
  try {
    void navigator.clipboard?.writeText(`${window.location.origin}${path}`);
  } catch {
    // the toast is the answer either way
  }
  toast.show({ message });
}

function Head({ summary, support = PAGE.support }: { summary?: string; support?: string }) {
  return (
    <header className="ap-head" data-m="up">
      <BackLink href={LINKS.team}>{PAGE.back}</BackLink>
      <h1 className="ap-title">{PAGE.title}</h1>
      <p className="ap-lead">{support}</p>
      {summary ? <p className="ap-summary">{summary}</p> : null}
    </header>
  );
}

export function ApplicantsScreen({ variant }: { variant?: ApplicantsVariant }) {
  const nav = useNav();
  const seed = SEEDS.find((x) => x === variant);
  const s = useSeeded('project', seed);
  const r = useReviewer('project');
  const [filter, setFilter] = useState('All');
  const [failed, setFailed] = useState(variant === 'error');
  const loading = variant === 'loading';

  // Loading is the frame that moves on by itself: after LOADING_MS the list appears (Figma: after delay 2.5 s, dissolve to Applicants)
  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(() => nav.replace(APPLICANT_PATHS.list), LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  /* Loading: the header without the summary and the filter, four skeleton rows */
  if (loading) {
    return (
      <WorkspaceFrame active="team" wide>
        <div className="ap-page" aria-busy="true">
          <Head />
          <div className="ap-list" role="status" aria-label="Loading applicants">
            {[0, 1, 2, 3].map((i) => (
              <RowSkeleton key={i} />
            ))}
          </div>
        </div>
      </WorkspaceFrame>
    );
  }

  /* Could not load */
  if (failed) {
    return (
      <WorkspaceFrame active="team" wide>
        <div className="ap-page">
          <Head />
          <div data-m="up" role="alert">
            <EmptyState
              className="cw-empty"
              title={PAGE.error.title}
              text={PAGE.error.text}
              action={
                <Button
                  arrow="up-right"
                  onClick={() => {
                    setFailed(false);
                    if (variant === 'error') nav.push(APPLICANT_PATHS.list);
                  }}
                >
                  {PAGE.error.action}
                </Button>
              }
            />
          </div>
        </div>
      </WorkspaceFrame>
    );
  }

  /* Empty */
  if (variant === 'empty') {
    return (
      <WorkspaceFrame active="team" wide>
        <div className="ap-page">
          <Head support={PAGE.emptySupport} />
          <div data-m="up">
            <EmptyState
              className="cw-empty"
              title={PAGE.empty.title}
              text={PAGE.empty.text}
              action={
                <Button arrow="up-right" onClick={() => copyLink(PROJECT_PATH, PAGE.linkCopied)}>
                  {PAGE.empty.action}
                </Button>
              }
            />
          </div>
        </div>
      </WorkspaceFrame>
    );
  }

  const people = peopleOf(s, 'project');
  const counts = countsOf(s, 'project');
  const chips: ChipItem[] = PAGE.chips.map((label) => ({ key: label, label, count: label === 'All' ? people.length : counts[label as Status] }));
  const shown = people.filter((p) => filter === 'All' || p.status === filter);
  const ticked = ORDER.project.filter((id) => s.compare.project.includes(id));
  const joined = people.filter((p) => p.status === 'Joined');

  const handlers = (id: ApplicantId, status: Status): RowHandlers => ({
    // the slide-out exists for New, Shortlisted and Talk booked; the other rows leave View applicant plain, as in the design
    open: status === 'New' || status === 'Shortlisted' || status === 'Talk booked' ? () => r.open(id) : undefined,
    shortlist: () => r.shortlist(id),
    propose: () => r.propose(id),
    offer: () => r.offer(id),
    notNow: () => r.notNow(id),
    undo: () => r.undo(id),
    team: LINKS.team,
  });

  return (
    <WorkspaceFrame active="team" wide>
      <div className="ap-page">
        <Head summary={summaryLine(counts)} />
        {joined.map((p) => (
          <JoinedNotice key={p.id} message={JOINED_NOTICE(APPLICANTS[p.id].name)} />
        ))}
        <div data-m="up">
          <FilterChips items={chips} value={filter} onChange={setFilter} label="Filter applicants" />
        </div>
        {ticked.length >= 2 ? (
          <CompareBar
            count={ticked.length}
            names={COMPARE.names(ticked.map((id) => APPLICANTS[id].name))}
            onClear={() => applicants.clearCompare('project')}
            onCompare={() => nav.push(APPLICANT_PATHS.compare)}
          />
        ) : null}
        {shown.length === 0 ? (
          <p className="ap-none">{PAGE.none}</p>
        ) : (
          <ul className="ap-list" data-m="up" aria-label="Applicants">
            {shown.map((p) => (
              <li key={p.id}>
                <ApplicantRow
                  a={APPLICANTS[p.id]}
                  status={p.status}
                  selected={ticked.includes(p.id)}
                  tickLocked={ticked.length >= COMPARE.max}
                  onTick={() => applicants.toggleCompare('project', p.id)}
                  h={handlers(p.id, p.status)}
                />
              </li>
            ))}
          </ul>
        )}
      </div>
      {r.layer}
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Compare */

/**
 * Compare (17974:169471): the people ticked on the list, side by side. Opened without anyone ticked (the address typed in), it shows the pair of
 * the frame, Amina Yusuf and Kunle Afolabi. Shortlist changes the column in place; Propose times and Not now open their modals.
 */
export function CompareScreen() {
  const s = useApplicantState();
  const r = useReviewer('project');
  const picked = ORDER.project.filter((id) => s.compare.project.includes(id));
  const ids = picked.length >= 2 ? picked : SAMPLE_COMPARE.project;

  useEffect(() => {
    if (picked.length < 2) applicants.setCompare('project', SAMPLE_COMPARE.project);
    // once, when the page opens
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const columns: CompareColumn[] = ids.map((id) => {
    const status = s.status[id];
    return {
      a: APPLICANTS[id],
      status,
      note: (s.notes[id] ?? '').trim(),
      // the design draws the columns of New and Shortlisted people with their actions, and the Talk booked column without any
      actions:
        status === 'New' ? (
          <>
            <Button size="sm" onClick={() => r.shortlist(id)}>
              {ROW.shortlist}
            </Button>
            <Button size="sm" variant="secondary" onClick={() => r.notNow(id)}>
              {ROW.notNow}
            </Button>
          </>
        ) : status === 'Shortlisted' ? (
          <>
            <Button size="sm" onClick={() => r.propose(id)}>
              {ROW.proposeTimes}
            </Button>
            <Button size="sm" variant="secondary" onClick={() => r.notNow(id)}>
              {ROW.notNow}
            </Button>
          </>
        ) : null,
    };
  });

  return (
    <WorkspaceFrame active="team" wide>
      <div className="ap-page">
        <header className="ap-head" data-m="up">
          <BackLink href={APPLICANT_PATHS.list}>{COMPARE.back}</BackLink>
          <h1 className="ap-title">{COMPARE.title}</h1>
          <p className="ap-lead">{COMPARE.support(ids.map((id) => APPLICANTS[id].name))}</p>
        </header>
        <CompareTable columns={columns} />
      </div>
      {r.layer}
    </WorkspaceFrame>
  );
}
