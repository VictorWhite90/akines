'use client';

import { useState, type ButtonHTMLAttributes, type HTMLAttributes, type ReactNode } from 'react';
import { cx, IconCheck, IconClose } from './internal';

type ChipBase = {
  selected?: boolean;
  icon?: ReactNode;
  count?: number | string;
  removable?: boolean;
  onRemove?: () => void;
  as?: 'button' | 'span';
  /** 'filter' is the Figma Chip (44 high, ink when selected). 'choice' is the Choice and Option Chip (52 high, amber when selected). */
  variant?: 'filter' | 'choice';
  children?: ReactNode;
};
export type ChipProps = ChipBase & Omit<ButtonHTMLAttributes<HTMLButtonElement> & HTMLAttributes<HTMLSpanElement>, keyof ChipBase>;

/**
 * Filter or topic chip. A `button` (aria-pressed when `selected` is given) by default, a `span` with as="span".
 * A removable chip is a span that holds the label and a separate remove button (no nested buttons).
 */
export function Chip({ selected, icon, count, removable, onRemove, as, variant = 'filter', className, children, type, ...rest }: ChipProps) {
  const cls = cx('k-chip', `k-chip--${variant}`, selected && 'k-chip--selected', removable && 'k-chip--removable', className);
  const lead =
    variant === 'choice' ? (
      <span className="k-chip__ind" aria-hidden="true">
        <span className="k-chip__ind-dot" />
        <IconCheck size={12} strokeWidth={1.6} />
      </span>
    ) : selected ? (
      <span className="k-chip__icon" aria-hidden="true">
        <IconCheck size={14} strokeWidth={1.6} />
      </span>
    ) : icon ? (
      <span className="k-chip__icon" aria-hidden="true">{icon}</span>
    ) : null;
  const content = (
    <>
      {lead}
      <span className="k-chip__label">{children}</span>
      {count !== undefined && count !== null && count !== '' ? <span className="k-chip__count">{count}</span> : null}
    </>
  );
  if (removable) {
    const text = typeof children === 'string' ? children : undefined;
    return (
      <span {...(rest as HTMLAttributes<HTMLSpanElement>)} className={cls} data-selected={selected || undefined}>
        {content}
        <button type="button" className="k-chip__x" aria-label={text ? `Remove ${text}` : 'Remove'} onClick={onRemove}>
          <IconClose size={14} />
        </button>
      </span>
    );
  }
  if (as === 'span') {
    return (
      <span {...(rest as HTMLAttributes<HTMLSpanElement>)} className={cls} data-selected={selected || undefined}>
        {content}
      </span>
    );
  }
  return (
    <button
      {...(rest as ButtonHTMLAttributes<HTMLButtonElement>)}
      type={type ?? 'button'}
      className={cls}
      aria-pressed={selected === undefined ? undefined : selected}
      data-selected={selected || undefined}
    >
      {content}
    </button>
  );
}

export type TagProps = {
  tone?: 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info';
  icon?: ReactNode;
  children?: ReactNode;
} & Omit<HTMLAttributes<HTMLSpanElement>, 'children'>;

/** Small read-only label. Neutral is the Figma Tag; the other tones are the status pills (dot and label on a soft tint). */
export function Tag({ tone = 'neutral', icon, className, children, ...rest }: TagProps) {
  return (
    <span {...rest} className={cx('k-tag', `k-tag--${tone}`, className)}>
      {icon ? (
        <span className="k-tag__icon" aria-hidden="true">{icon}</span>
      ) : tone !== 'neutral' ? (
        <span className="k-tag__dot" aria-hidden="true" />
      ) : null}
      {children}
    </span>
  );
}

export type AvatarProps = {
  name: string;
  src?: string;
  size?: 24 | 32 | 36 | 44 | 56 | 72 | 96;
  tone?: 'warm' | 'ink' | 'sage';
} & Omit<HTMLAttributes<HTMLSpanElement>, 'children'>;

const initials = (name: string) => {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '';
  const a = parts[0][0] ?? '';
  const b = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (a + b).toUpperCase();
};

/** Round avatar: photo when `src` loads, otherwise the initials on a tone. */
export function Avatar({ name, src, size = 44, tone = 'warm', className, style, ...rest }: AvatarProps) {
  const [failed, setFailed] = useState(false);
  const showImg = src && !failed;
  return (
    <span
      role="img"
      aria-label={name}
      {...rest}
      className={cx('k-avatar', `k-avatar--${tone}`, className)}
      data-size={size}
      style={{ width: size, height: size, fontSize: Math.max(10, Math.round(size * 0.38)), ...style }}
    >
      {showImg ? <img src={src} alt="" loading="lazy" decoding="async" onError={() => setFailed(true)} /> : <span aria-hidden="true">{initials(name)}</span>}
    </span>
  );
}
