'use client';

/**
 * The ten bands of Community Home (Figma 10.1, frame 17095:5812). Each band reads and writes the store (store.ts),
 * so choices survive navigation and the overlays (Overlays.tsx) can change what the page shows.
 */
import { Button, Chip, Tag } from '@/ui';
import { Link } from '@/lib/nav';
import { useLayout } from '@/lib/hooks';
import {
  acceptInvite, dismissContinue, dismissIntro, dismissInvite, openModal, seeMoreIntros, setIntention, setMood, useCommunity,
  type Mood,
} from './store';
import { COLLABS, CONTINUE, CONTROLS, INTENTIONS, INTROS, INVITES, P, UPCOMING, WAYS, type Action } from './data';
import {
  Avatar, AvatarStack, CardLink, CarouselControls, EmptyPanel, IArrow, ICalendar, ICheckCircle, IClock, ILock, IPencil, ListRow, Photo, RowLink,
  SectionHeader, TextLink, Veil, useCarousel,
} from './ui';

export const HEAD = {
  cont: { label: 'Continue', headline: 'Pick up where you left off.', support: 'Some connections are worth continuing.' },
  intros: { label: 'Meaningful introductions', headline: 'Meet someone for a reason.', support: 'Discover people you could learn from, build with, or simply understand.' },
  ups: { label: 'Upcoming moments', headline: 'Make room for what matters.', support: 'Your next conversations and shared experiences.' },
  invs: { label: 'Invitations', headline: "You're invited.", support: 'People and communities are making room for you.' },
};

const act = (a: Action) => ('to' in a ? { href: a.to } : { onClick: () => openModal(a.modal) });

/* ---------------------------------------------------------------- 01 greeting and intention */
export function Hero() {
  return (
    <section className="ch-hero" aria-label="Greeting">
      <div className="ch-hero__frame">
        {/* Figma 17095:5918 "Photo: two friends in conversation at a sunlit table", greeting text removed, scrim and blur baked in */}
        <Photo name="hero" fill eager />
        <div className="ch-hero__text">
          <p className="ch-hero__greeting" data-m="up">
            Good afternoon, Kemi.
          </p>
          <h1 className="ch-hero__headline" data-m="words">
            How would you like to connect today?
          </h1>
        </div>
      </div>
    </section>
  );
}

export function Intentions() {
  const s = useCommunity();
  return (
    <section className="ch-intent" aria-label="Your intention for today">
      <p className="ch-intent__lead">Choose what feels right for you.</p>
      <div className="ch-chips" role="group" aria-label="Choose what feels right for you">
        {INTENTIONS.map((it, i) => (
          <Chip key={it.label} variant="choice" selected={s.intention === i + 1} onClick={() => setIntention(i + 1)}>
            {it.label}
          </Chip>
        ))}
      </div>
    </section>
  );
}

export function ResultBand() {
  const s = useCommunity();
  const it = INTENTIONS[s.intention - 1];
  if (!it) return null;
  return (
    <section className="ch-result" aria-label="Prioritised for you">
      <div className="ch-result__band" key={s.intention}>
        <div className="ch-result__intro">
          <p className="ch-label">For you today</p>
          <h2 className="ch-result__headline">{it.headline}</h2>
          <p className="ch-result__because">Because you chose: {it.label}</p>
          <TextLink onClick={() => setIntention(0)}>Show everything</TextLink>
        </div>
        <div className="ch-result__list">
          {it.items.map((r) => (
            <ListRow key={r.title} title={r.title} text={r.text} meta={r.meta} avatar={r.avatar ?? null} {...act(r.act)} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- 02 continue */
export function ContinueBand() {
  const s = useCommunity();
  const cards = CONTINUE.map((c, i) => ({ c, i })).filter(({ i }) => s.cont[i]);
  return (
    <section className="ch-band" aria-labelledby="ch-b-cont">
      <div className="ch-pad">
        <SectionHeader size="lg" {...HEAD.cont} />
      </div>
      {cards.length === 0 ? (
        <EmptyPanel variant="line" title="Nothing is waiting for you." text="Conversations and projects you start will appear here, so you can pick them up when you are ready.">
          <Button variant="secondary" href={P.messages}>
            Start a conversation
          </Button>
        </EmptyPanel>
      ) : (
        <div className="ch-cards" data-m="stagger">
          {cards.map(({ c, i }) => (
            <article className="ch-ocard" key={c.key}>
              {/* Figma 17096:5855 "Photo: Amara, portrait" and 17096:5883 "Photo: Folake, portrait" */}
              <Photo name={c.image} fill />
              <Veil />
              <div className="ch-ocard__body">
                <p className="ch-ocard__eyebrow">{c.who}</p>
                <h3 className="ch-ocard__title">Continue something meaningful</h3>
                <p className="ch-ocard__text">{c.text}</p>
                <p className="ch-ocard__meta">
                  <IClock />
                  <span>{c.last}</span>
                </p>
                <div className="ch-ocard__actions">
                  <Button tone="light" iconRight={<IArrow />} href={P.thread(c.thread)}>
                    Continue conversation
                  </Button>
                  <CardLink tone="light" onClick={() => openModal(c.call)}>
                    Arrange a Create Call
                  </CardLink>
                  <CardLink tone="light" onClick={() => dismissContinue(i as 0 | 1)}>
                    Not now
                  </CardLink>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

/* ---------------------------------------------------------------- 03 introductions */
export function IntrosBand() {
  const s = useCommunity();
  const cards = INTROS.map((c, i) => ({ c, i })).filter(({ i }) => s.intro.show[i] && (i < 2 || s.intro.more));
  return (
    <section className="ch-band" aria-label="Meaningful introductions">
      <div className="ch-pad">
        <SectionHeader size="lg" {...HEAD.intros} />
      </div>
      {cards.length === 0 ? (
        <EmptyPanel variant="line" title="No introductions right now." text="New people appear here when there is a real reason to meet. You can change what Akines uses to suggest them.">
          <Button variant="secondary" href={P.settings}>
            Review recommendation preferences
          </Button>
        </EmptyPanel>
      ) : (
        <div className="ch-intros" data-m="stagger">
          {cards.map(({ c, i }) => {
            const idx = i as 0 | 1 | 2;
            const sent = s.intro.sent[idx];
            return (
              <article className="ch-icard" key={c.key}>
                {/* Figma 17096:5921 Tunde, 17096:5952 Ngozi (Chuka has no visible large photo, see data.ts) */}
                <Photo name={c.image} className="ch-icard__photo" />
                <div className="ch-icard__body">
                  <h3 className="ch-icard__name">{c.name}</h3>
                  <div className="ch-tags">
                    {c.tags.map((t) => (
                      <Tag key={t}>{t}</Tag>
                    ))}
                  </div>
                  <p className="ch-icard__reason">{c.reason}</p>
                  <div className="ch-icard__act">
                    <p className="ch-label">Potential shared activity</p>
                    <p className="ch-icard__acttext">{c.activity}</p>
                  </div>
                  <div className="ch-icard__foot">
                    {sent ? (
                      <p className="ch-confirm">
                        <ICheckCircle />
                        <span>Introduction sent. {c.name} can choose whether to reply.</span>
                      </p>
                    ) : (
                      <div className="ch-icard__actions">
                        <Button iconRight={<IArrow />} onClick={() => openModal(c.intro)}>
                          Introduce us
                        </Button>
                        <div className="ch-icard__links">
                          <CardLink onClick={() => openModal(c.why)}>See why we matched</CardLink>
                          <CardLink onClick={() => dismissIntro(idx)}>Not now</CardLink>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {s.intro.more ? null : (
        <div className="ch-more">
          <Button variant="secondary" onClick={seeMoreIntros}>
            See more introductions
          </Button>
        </div>
      )}
    </section>
  );
}

/* ---------------------------------------------------------------- 04 upcoming */
export function UpcomingBand() {
  const s = useCommunity();
  const items = UPCOMING.filter((u) => !u.extra || (u.extra === 'inv0' ? s.inv.acc[0] : s.inv.acc[1]));
  return (
    <section className="ch-band" aria-label="Upcoming moments">
      <div className="ch-pad">
        <SectionHeader size="md" {...HEAD.ups} />
      </div>
      <div className="ch-ups" data-m="stagger">
        {items.map((u) => (
          <button type="button" className="ch-up" key={u.key} onClick={() => openModal(u.modal)}>
            {/* Figma photo strip 17139:20109 (cropped to the nearest card photo) */}
            <Photo name={u.image} className="ch-up__photo" />
            <span className="ch-up__time">{u.time}</span>
            <span className="ch-up__text">
              <span className="ch-up__title" title={u.title}>
                {u.title}
              </span>
              <span className="ch-up__meta">{u.meta}</span>
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- 05 invitations */
export function InvitesBand() {
  const s = useCommunity();
  const cards = INVITES.map((v, i) => ({ v, i })).filter(({ i }) => s.inv.show[i]);
  return (
    <section className="ch-band" aria-label="Invitations">
      <div className="ch-pad">
        <SectionHeader size="md" {...HEAD.invs} />
      </div>
      {cards.length === 0 ? (
        <EmptyPanel variant="line" narrow title="No invitations right now." text="People and communities will invite you here when they are making room for you.">
          <Button variant="secondary" onClick={() => openModal('quick')}>
            Find someone to connect with
          </Button>
        </EmptyPanel>
      ) : (
        <div className="ch-cards" data-m="stagger">
          {cards.map(({ v, i }) => {
            const idx = i as 0 | 1;
            const accepted = s.inv.acc[idx];
            return (
              <article className="ch-ocard" key={v.key}>
                {/* Figma 17097:5935 (KinCircle members around a table) and 17097:5968 (Folake, smiling) */}
                <Photo name={v.image} fill />
                <Veil />
                <div className="ch-ocard__body">
                  <div className="ch-ocard__who">
                    <Avatar k={v.inviterImg} size={28} />
                    <p className="ch-ocard__eyebrow">{v.inviter}</p>
                  </div>
                  <h3 className="ch-ocard__title">{v.title}</h3>
                  <p className="ch-ocard__text">{v.text}</p>
                  <p className="ch-ocard__meta" style={{ opacity: 0.9 }}>
                    <ICalendar />
                    <span>{v.meta}</span>
                  </p>
                  <div className="ch-ocard__ppl">
                    <AvatarStack people={v.people} size={28} overlap={8} />
                    <span>{v.peopleText}</span>
                  </div>
                  {accepted ? (
                    <div className="ch-ocard__actions">
                      <p className="ch-confirm ch-confirm--light">
                        <ICheckCircle />
                        <span>You are going. It is now in your upcoming moments.</span>
                      </p>
                    </div>
                  ) : (
                    <div className="ch-ocard__actions">
                      <Button tone="light" iconRight={<IArrow />} onClick={() => acceptInvite(idx)}>
                        Accept invitation
                      </Button>
                      <CardLink tone="light" onClick={() => openModal(v.modal)}>
                        View details
                      </CardLink>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}

/* ---------------------------------------------------------------- 06 ways to connect */
function WayCard({ w }: { w: (typeof WAYS)[number] }) {
  const inner = (
    <>
      <Photo name={w.image} fill />
      <Veil />
      <span className="ch-way__title">{w.title}</span>
      <span className="ch-way__action">
        <span className="ch-way__label">{w.action}</span>
      </span>
    </>
  );
  return 'to' in w.act ? (
    <Link className="ch-way" href={w.act.to}>
      {inner}
    </Link>
  ) : (
    <button type="button" className="ch-way" onClick={() => openModal((w.act as { modal: Parameters<typeof openModal>[0] }).modal)}>
      {inner}
    </button>
  );
}

export function WaysBand() {
  const layout = useLayout();
  const c = useCarousel(layout === 'desktop' ? 4 : 1);
  return (
    <section className="ch-ways" aria-roledescription="carousel" aria-label="Ways to connect" {...c.hold}>
      <div className="ch-ways__row">
        <div className="ch-ways__copy">
          <SectionHeader size="md" label="Ways to connect" headline="Something meaningful starts here." support="Explore a few ways to spend time with others." />
        </div>
        <div className="ch-ways__view">
          <div className="ch-track" style={{ translate: `${-c.page * 784}px 0` }}>
            {WAYS.map((w) => (
              <WayCard key={w.key} w={w} />
            ))}
          </div>
        </div>
      </div>
      <CarouselControls className="ch-ctrl--end" page={c.page} pages={4} onPrev={c.prev} onNext={c.next} label="ways to connect" />
    </section>
  );
}

/* ---------------------------------------------------------------- 07 active collaborations */
export function CollabsBand() {
  const layout = useLayout();
  const c = useCarousel(layout === 'desktop' ? 2 : 1);
  return (
    <section className="ch-collabs" aria-roledescription="carousel" aria-label="Active collaborations" {...c.hold}>
      <div className="ch-pad">
        <SectionHeader size="lg" label="Active collaborations" headline="Good things grow together." support="Continue building something meaningful." />
      </div>
      <div className="ch-collabs__view">
        <div className="ch-track" style={{ translate: `${-c.page * 472}px 0` }}>
          {COLLABS.map((k) => (
            <article className="ch-collab" key={k.key}>
              {/* Figma 17156:10160, 17156:10178, 17156:10197 and the Game Night card (photo reused, see data.ts) */}
              <Photo name={k.image} className="ch-collab__photo" />
              <div className="ch-collab__body">
                <div className="ch-collab__who">
                  <AvatarStack people={k.people} size={28} overlap={8} />
                  <span>{k.who}</span>
                </div>
                <h3 className="ch-collab__name">{k.title}</h3>
                <p className="ch-collab__text">{k.text}</p>
                <p className="ch-collab__line">
                  <IPencil />
                  <span>{k.status}</span>
                </p>
                <p className="ch-collab__line ch-collab__line--muted">
                  <IClock />
                  <span>{k.last}</span>
                </p>
                <div className="ch-collab__actions">
                  <Button iconRight={<IArrow />} {...act(k.go)}>
                    Continue collaborating
                  </Button>
                  <CardLink tone="dark" {...act(k.call)}>
                    {k.callLabel}
                  </CardLink>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
      <CarouselControls className="ch-ctrl--end" page={c.page} pages={2} onPrev={c.prev} onNext={c.next} label="collaborations" />
    </section>
  );
}

/* ---------------------------------------------------------------- 08 private wellbeing check-in */
type MoodAction = { label: string; primary?: boolean; act: Action };
const MOODS: { key: Exclude<Mood, 'none'>; label: string }[] = [
  { key: 'good', label: 'Good' },
  { key: 'okay', label: 'Okay' },
  { key: 'low', label: 'Low' },
  { key: 'support', label: 'I need support' },
];
const RESPONSES: Record<Mood, { text: string; actions: MoodAction[] }> = {
  none: { text: 'Choose how you feel. Your answer stays with you.', actions: [] },
  good: {
    text: 'Would you like to share some encouragement with someone?',
    actions: [
      { label: 'Encourage someone', primary: true, act: { modal: 'encourage' } },
      { label: 'Join a Banter', act: { to: P.banter } },
    ],
  },
  okay: {
    text: 'Would some company make today a little better?',
    actions: [
      { label: 'Talk to someone', primary: true, act: { to: P.messages } },
      { label: 'Quiet company', act: { to: P.care } },
    ],
  },
  low: {
    text: "You don't have to do everything alone.",
    actions: [
      { label: 'Quiet company', primary: true, act: { to: P.care } },
      { label: 'Message someone I trust', act: { modal: 'trust' } },
      { label: 'Reflect privately', act: { to: P.reflect } },
    ],
  },
  support: {
    text: 'Consider reaching out to someone you trust.',
    actions: [
      { label: 'Message someone I trust', primary: true, act: { modal: 'trust' } },
      { label: 'Find professional support', act: { to: P.pro } },
    ],
  },
};

export function WellbeingBand() {
  const s = useCommunity();
  const r = RESPONSES[s.mood];
  return (
    <section className="ch-well" aria-label="Private wellbeing check-in">
      <div className="ch-well__in">
        <div className="ch-well__intro">
          <SectionHeader size="md" label="Wellbeing" headline="How are you feeling today?" support="Take a moment for yourself." />
          <p className="ch-well__private">
            <ILock />
            <span>Only you can see this. Nothing is shared, sent or shown to anyone unless you choose to take an action.</span>
          </p>
        </div>
        <div className="ch-well__main">
          <div className="ch-chips" role="group" aria-label="How are you feeling today?">
            {MOODS.map((m) => (
              <Chip key={m.key} variant="choice" selected={s.mood === m.key} onClick={() => setMood(m.key)}>
                {m.label}
              </Chip>
            ))}
          </div>
          <div className="ch-resp" key={s.mood} aria-live="polite">
            <p className="ch-resp__text">{r.text}</p>
            {r.actions.length ? (
              <div className="ch-resp__actions">
                {r.actions.map((a) =>
                  a.primary ? (
                    <Button key={a.label} iconRight={<IArrow />} {...act(a.act)}>
                      {a.label}
                    </Button>
                  ) : (
                    <Button key={a.label} variant="secondary" {...act(a.act)}>
                      {a.label}
                    </Button>
                  ),
                )}
              </div>
            ) : null}
            <p className="ch-resp__note">
              <ILock />
              <span>This stays private. Choosing a mood does not message anyone or start a call.</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- 09 relationship memories */
const MEMORIES = [
  { key: 'amara', image: 'amara', eyebrow: 'Last Thursday', title: 'Your conversation with Amara', text: 'You discussed the next steps for your community-health initiative.', meta: 'Community Health Initiative', to: P.thread('amara') },
  { key: 'folake', image: 'folake', eyebrow: 'Last Sunday', title: 'Your walk with Folake', text: 'You and Folake planned a Sunday walk and a shared reading list.', meta: 'Folake', to: P.thread('folake') },
];
export function MemoriesBand() {
  return (
    <section className="ch-band ch-pad" aria-label="Recent relationship memories">
      <SectionHeader size="lg" className="ch-memhead" label="Relationship memories" headline="Some moments stay with us." support="Remember the conversations and experiences that mattered." />
      <div className="ch-mems" data-m="stagger">
        {MEMORIES.map((m) => (
          <Link className="ch-mem" href={m.to} key={m.key}>
            <Photo name={m.image} fill />
            <Veil />
            <p className="ch-mem__eyebrow">{m.eyebrow}</p>
            <h3 className="ch-mem__title">{m.title}</h3>
            <p className="ch-mem__text">{m.text}</p>
            <p className="ch-mem__meta">{m.meta}</p>
            <span className="ch-mem__action">
              <span className="ch-mem__label">Continue the conversation</span>
              <span className="ch-mem__arrow" aria-hidden="true">
                <IArrow />
              </span>
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- 10 privacy and recommendation controls */
export function ControlsBand() {
  return (
    <section className="ch-ctl" aria-label="Privacy and recommendation controls">
      <div className="ch-ctl__intro">
        <SectionHeader
          size="md"
          label="Your connections"
          headline="Your connections, your choices."
          support="Every suggestion on this page comes with a reason, and you can change what Akines uses at any time."
        />
      </div>
      <div className="ch-ctl__list" data-m="stagger">
        {CONTROLS.map((c) => (
          <RowLink key={c.title} title={c.title} text={c.text} href={c.to} />
        ))}
      </div>
    </section>
  );
}

