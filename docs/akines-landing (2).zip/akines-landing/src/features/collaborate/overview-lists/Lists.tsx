'use client';

/**
 * The three lists behind the Collaborate Home count tiles, each with its Empty and Loading frame:
 *   12.48 Decisions awaiting you  17972:150992, Empty 17972:160702, Loading 17972:161086
 *   12.49 Introduction requests   17974:131855, Accepted 17974:132361, Not now 17974:132650, Empty 17974:132922, Loading 17974:133310,
 *                                 Toast:Introduction accepted 17974:166519, Toast:Response sent 17974:166526
 *   12.50 Tasks due this week     17974:155481, Empty 17974:155938, Loading 17974:156322
 * A list shows its Loading frame the first time it is opened in a visit (2.5 s, like the other screens) and then the list. Empty and the
 * Accepted and Not now frames are reached from the page (Accept, Not now) or at their "state-" route. Accept shows the Accepted frame and a
 * toast, Not now shows the Not now frame and a toast; Undo on either toast, and Undo on the Not now frame, returns to the request.
 * "Start a conversation" opens the New conversation modal of the Conversations screen.
 */
import { useEffect, useState } from 'react';
import { Button, toast } from '@/ui';
import { Link, useNav } from '@/lib/nav';
import { personRoutes } from '../people/data';
import { ConfirmationLine } from '../project-team/parts';
import { LOADING_MS, takeFirstVisit } from '../projects/store';
import { CardLink } from '../projects/ui';
import { Owner, PriorityTag, StatusTag as TaskStatus } from '../tasks/parts';
import { PATHS } from '../workspace/data';
import { StartConversationModal } from '../workspace/conversations/Conversations';
import { useConversationsData } from '../workspace/conversations/art-data';
import {
  AWAITING_DECISIONS,
  DECISIONS_PAGE,
  DUE_TASKS,
  INTRODUCTION,
  INTRODUCTIONS_PAGE,
  INTRODUCTION_ANSWERS,
  LOADING_COUNT,
  OL,
  TASKS_PAGE,
  countOf,
} from './data';
import { AwaitingDecisionRow, EmptyPanel, IntroductionRequest, ListPage, SkeletonList, SkeletonRequest } from './parts';

/** The toasts of the "state-" frames stay longer so they can be looked at (the other state frames do the same). */
const STATE_TOAST_MS = 8000;

/**
 * Loading: a list shows it the first time it is opened in a visit. Its "state-loading" route shows it too and then continues to the list
 * (that visit counts as the first one, so the list does not show Loading a second time).
 */
function useLoading(key: string, variant: Variant, listPath: string): boolean {
  const nav = useNav();
  const [loading, setLoading] = useState(() => {
    if (variant === 'loading') {
      takeFirstVisit(key);
      return true;
    }
    return variant ? false : takeFirstVisit(key);
  });
  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(() => {
      if (variant === 'loading') nav.replace(listPath);
      else setLoading(false);
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, variant]);
  return loading;
}

type Variant = 'empty' | 'loading' | 'accepted' | 'not-now' | undefined;

/* ------------------------------------------------------------------ 12.48 Decisions awaiting you */

export function DecisionsScreen({ variant }: { variant?: 'empty' | 'loading' }) {
  const loading = useLoading('ol-decisions', variant, OL.decisions);
  const rows = variant === 'empty' ? [] : AWAITING_DECISIONS;
  const P = DECISIONS_PAGE;
  return (
    <ListPage eyebrow={P.eyebrow} title={P.title} lead={P.lead} tab={P.tab} count={loading ? LOADING_COUNT : countOf(rows.length, 'decision', 'decisions')} busy={loading}>
      {loading ? (
        <SkeletonList rows={3} />
      ) : rows.length ? (
        <ul className="ol-box" data-m="up">
          {rows.map((d) => (
            <AwaitingDecisionRow key={d.id} item={d} />
          ))}
        </ul>
      ) : (
        <EmptyPanel {...P.empty} />
      )}
    </ListPage>
  );
}

/* ------------------------------------------------------------------ 12.49 Introduction requests */

type Answer = 'waiting' | 'accepted' | 'not-now';

export function IntroductionsScreen({ variant }: { variant?: 'empty' | 'loading' | 'accepted' | 'not-now' }) {
  const nav = useNav();
  const loading = useLoading('ol-introductions', variant, OL.introductions);
  const [answer, setAnswer] = useState<Answer>(variant === 'accepted' ? 'accepted' : variant === 'not-now' ? 'not-now' : 'waiting');
  const [convo, setConvo] = useState(false);
  const conversations = useConversationsData();
  const P = INTRODUCTIONS_PAGE;
  const A = INTRODUCTION_ANSWERS;
  const profile = personRoutes(INTRODUCTION.person).profile;

  /** Undo returns to the request (the page of 12.49 as it was before the answer). */
  const back = () => {
    setAnswer('waiting');
    nav.push(OL.introductions);
  };

  // the "state-accepted" and "state-not-now" frames: the page with its toast already showing
  useEffect(() => {
    if (variant === 'accepted') toast.show({ message: A.accepted.toast, actionLabel: 'Undo', duration: STATE_TOAST_MS, onAction: back });
    if (variant === 'not-now') toast.show({ message: A.notNow.toast, actionLabel: 'Undo', duration: STATE_TOAST_MS, onAction: back });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [variant]);

  const accept = () => {
    setAnswer('accepted');
    toast.show({ message: A.accepted.toast, actionLabel: 'Undo', onAction: back });
  };
  const notNow = () => {
    setAnswer('not-now');
    toast.show({ message: A.notNow.toast, actionLabel: 'Undo', onAction: back });
  };
  // Start conversation in the modal opens Conversations with its toast, as it does from the Conversations screen itself
  const startConversation = () => {
    setConvo(false);
    nav.push(PATHS.conversations);
    toast.show({ message: conversations.startedToast, actionLabel: 'Undo', onAction: () => nav.push(PATHS.conversations) });
  };

  const waiting = variant !== 'empty' && answer === 'waiting';
  let body: React.ReactNode;
  if (loading) body = <SkeletonRequest />;
  else if (variant === 'empty') body = <EmptyPanel {...P.empty} />;
  else if (answer === 'waiting') body = <IntroductionRequest onAccept={accept} onNotNow={notNow} profileHref={profile} />;
  else if (answer === 'accepted')
    body = (
      <>
        <div className="ol-narrow">
          <ConfirmationLine message={A.accepted.line} />
        </div>
        <div className="ol-next">
          <Button arrow="up-right" aria-haspopup="dialog" onClick={() => setConvo(true)}>
            Start a conversation
          </Button>
          <CardLink href={profile}>View profile</CardLink>
        </div>
      </>
    );
  else
    body = (
      <>
        <div className="ol-narrow">
          <ConfirmationLine message={A.notNow.line} />
        </div>
        <div className="ol-next">
          <CardLink onClick={back}>Undo</CardLink>
        </div>
      </>
    );

  return (
    <>
      <ListPage eyebrow={P.eyebrow} title={P.title} lead={P.lead} tab={P.tab} count={loading ? LOADING_COUNT : countOf(waiting ? 1 : 0, 'introduction', 'introductions')} busy={loading}>
        {body}
      </ListPage>
      <StartConversationModal open={convo} onClose={() => setConvo(false)} onStart={startConversation} />
    </>
  );
}

/* ------------------------------------------------------------------ 12.50 Tasks due this week */

export function TasksScreen({ variant }: { variant?: 'empty' | 'loading' }) {
  const loading = useLoading('ol-tasks', variant, OL.tasks);
  const rows = variant === 'empty' ? [] : DUE_TASKS;
  const P = TASKS_PAGE;
  return (
    <ListPage eyebrow={P.eyebrow} title={P.title} lead={P.lead} tab={P.tab} count={loading ? LOADING_COUNT : countOf(rows.length, 'task', 'tasks')} busy={loading}>
      {loading ? (
        <SkeletonList rows={4} />
      ) : rows.length ? (
        <ul className="ol-box tk-rows" data-m="up">
          {rows.map((t) => (
            <li key={t.id}>
              {/* Task Row (17670:19352): a row opens the Tasks list of its project */}
              <Link href={t.href} className="tk-row">
                <span className="tk-row__content">
                  <span className="tk-row__title">{t.title}</span>
                  <span className="tk-row__meta">
                    <span className="tk-row__ms">{t.project}</span>
                    <PriorityTag priority={t.priority} />
                  </span>
                </span>
                <Owner name={t.owner} />
                <span className="tk-row__status">
                  <TaskStatus status={t.status} />
                </span>
                <span className="tk-row__due">{t.due}</span>
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyPanel {...P.empty} />
      )}
    </ListPage>
  );
}
