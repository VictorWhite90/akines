import type { RouteDef } from '@/routes.types';
import { Placeholder } from '@/app-shell/Placeholder';

/**
 * Avatar menu destinations that have no design in Figma yet (View profile, Complete your profile, Help).
 * They open a placeholder page with the app header so the menu never leads to a 404.
 */
const make = (title: string) => {
  const Screen = () => <Placeholder title={title} />;
  Screen.displayName = `Placeholder(${title})`;
  return Screen;
};

export const routes: RouteDef[] = [
  { path: '/profile', title: 'View profile', shell: 'app', component: make('View profile') },
  { path: '/profile/complete', title: 'Complete your profile', shell: 'app', component: make('Complete your profile') },
  { path: '/help', title: 'Help', shell: 'app', component: make('Help') },
];
