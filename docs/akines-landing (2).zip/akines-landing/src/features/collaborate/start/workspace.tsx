'use client';

/**
 * 12.17 and 12.18 Workspace recommendation, the step after "Your people" (A5) and before "Preparing your brief" (A6).
 * Figma: Research 17611:149 (recommended) and 17611:648 (accepted), Digital art 17611:973 and 17611:1342. Card: "Workspace / Recommendation card".
 * The footer button is the Disabled button until the Workspace is accepted. Accepting is a new frame in the prototype, so it is a new step here.
 */
import { asset } from '@/lib/assets';
import { Button } from '@/ui';
import { BackLink, BuilderProgress, IcCheck, IcSparkles, StepHeading } from './parts';
import { WORKSPACES, type StepId, type WorkspaceKind } from './flow-data';

export function WorkspaceStep({
  kind,
  accepted,
  project,
  onAccept,
  go,
}: {
  kind: WorkspaceKind;
  accepted: boolean;
  /** Name of the project the Workspace is saved to ("Career Guidance for Everyone", "Adire Stories", or the person's own). */
  project: string;
  onAccept: () => void;
  go: (s: StepId) => void;
}) {
  const ws = WORKSPACES[kind];
  return (
    <section className="cs-col">
      <div className="cs-top">
        <BuilderProgress step={4} />
        {accepted ? (
          <StepHeading
            eyebrow="Your Workspace"
            title="Your Workspace is ready"
            support="Your accepted Workspace is saved to the project. You can continue to your brief."
          />
        ) : (
          <StepHeading
            eyebrow="Your Workspace"
            title="Here’s the Workspace we recommend"
            support="Based on what you told us, Create AI suggests the Workspace where your team will work together. Accept it to continue."
          />
        )}
      </div>

      <article className="cs-wsr" data-accepted={accepted || undefined} data-kind={kind} aria-label={ws.name} data-m="up">
        <div className="cs-wsr__photo">
          <img className="cover cs-wsr__img" src={asset(ws.photo)} loading="lazy" decoding="async" alt="" />
        </div>
        <div className="cs-wsr__body">
          {accepted ? (
            <p className="cs-wsr__chip" data-tone="success">
              <IcCheck size={14} stroke={1.5} />
              <span>Accepted</span>
            </p>
          ) : (
            <p className="cs-wsr__chip">
              <IcSparkles size={14} stroke={1.5} />
              <span>Recommended for your project</span>
            </p>
          )}
          <div className="cs-wsr__head">
            <h2 className="cs-wsr__name">{ws.name}</h2>
            <p className="cs-wsr__why">{ws.why}</p>
          </div>
          <ul className="cs-wsr__features">
            {ws.features.map((f) => (
              <li key={f} className="cs-wsr__feature">
                <IcCheck size={16} stroke={1.5} />
                <span>{f}</span>
              </li>
            ))}
          </ul>
          <hr className="cs-wsr__rule" />
          {accepted ? (
            <p className="cs-wsr__note" role="status">
              <IcCheck size={20} stroke={1.5} />
              <span>
                {ws.name} is saved to {project}.
              </span>
            </p>
          ) : (
            <div className="cs-wsr__actions">
              <Button onClick={onAccept}>Accept Workspace</Button>
              <p className="cs-wsr__helper">Your Workspace is created when you accept.</p>
            </div>
          )}
        </div>
      </article>

      <div className="cs-actions">
        <BackLink onClick={() => go('people')} />
        <Button disabled={!accepted} arrow="up-right" onClick={() => go('preparing')}>
          Prepare my project brief
        </Button>
      </div>
    </section>
  );
}
