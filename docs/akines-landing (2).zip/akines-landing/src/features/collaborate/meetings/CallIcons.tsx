import type { ReactNode } from 'react';

/**
 * The icons of the meeting screens (Figma 12.43: Call Button, Call panel, Muted badge, People Row). Paths are read from the Figma
 * vectors on a 24 grid. `size` is the drawn size in px; the stroke stays 1.5 px (1.25 px for People) whatever the size.
 */
type IconProps = { size?: number; className?: string };

function Svg({ size = 24, stroke = 1.5, className, children }: IconProps & { stroke?: number; children: ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={(stroke * 24) / size}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      {children}
    </svg>
  );
}

export const MicIcon = (p: IconProps) => (
  <Svg {...p}>
    <rect x="9" y="3" width="6" height="11" rx="3" />
    <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
  </Svg>
);

/** Mic off: the 18 px Figma drawing (People Row, Muted badge) scaled to the 24 grid. */
export const MicOffIcon = (p: IconProps) => (
  <Svg {...p}>
    <g transform="scale(1.33333)">
      <path
        transform="translate(6.75 2.219)"
        d="M0 4.532V2.282C-0.007 1.796 0.144 1.32 0.43 0.927C0.716 0.534 1.121 0.244 1.586 0.1C2.05 -0.043 2.548 -0.032 3.006 0.131C3.464 0.294 3.857 0.601 4.125 1.007M4.5 4.907V6.032C4.495 6.432 4.384 6.823 4.177 7.166C3.97 7.508 3.676 7.789 3.325 7.98C2.973 8.171 2.577 8.265 2.178 8.252C1.778 8.239 1.389 8.12 1.05 7.907"
      />
      <path
        transform="translate(3.75 8.25)"
        d="M0 0C0.006 0.956 0.273 1.893 0.773 2.709C1.272 3.524 1.985 4.188 2.834 4.628C3.684 5.068 4.637 5.268 5.591 5.206C6.546 5.143 7.465 4.822 8.25 4.275M10.5 0C10.496 0.724 10.343 1.438 10.05 2.1M5.25 5.25V7.5"
      />
      <path transform="translate(3 3)" d="M0 0L12 12" />
    </g>
  </Svg>
);

export const CameraIcon = (p: IconProps) => (
  <Svg {...p}>
    <path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5" />
    <rect x="2" y="6" width="14" height="12" rx="2" />
  </Svg>
);

export const CameraOffIcon = (p: IconProps) => (
  <Svg {...p}>
    <path d="M10 5h3a2 2 0 0 1 2 2v3l6-3v10l-6-3v2M3 7v10a2 2 0 0 0 2 2h8" />
    <path d="M3 3l18 18" />
  </Svg>
);

/** Present: a screen with an arrow rising from its stand. */
export const PresentIcon = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3" y="4" width="18" height="12" rx="1" />
    <path d="M8 20h8M12 16v4M12 13V8M12 8l-2.5 2.5M12 8l2.5 2.5" />
  </Svg>
);

/** Leave: the flat handset. */
export const LeaveIcon = (p: IconProps) => (
  <Svg {...p}>
    <path transform="translate(2.5 9.75)" d="M0 3.75C5.5 -1.25 13.5 -1.25 19 3.75L16.8 6.95L13.2 5.55V2.95C10.8 2.05 8.2 2.05 5.8 2.95V5.55L2.2 6.95L0 3.75Z" />
  </Svg>
);

export const PeopleIcon = (p: IconProps) => (
  <Svg {...p} stroke={1.25}>
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M22 21v-2a4 4 0 0 0-3-3.871M16 3.129a4 4 0 0 1 0 7.746" />
  </Svg>
);

export const ChatIcon = (p: IconProps) => (
  <Svg {...p}>
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </Svg>
);

export const CloseIcon = (p: IconProps) => (
  <Svg {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Svg>
);
