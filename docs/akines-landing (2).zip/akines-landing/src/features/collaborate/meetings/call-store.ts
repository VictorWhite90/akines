'use client';

import { useSyncExternalStore } from 'react';

/**
 * The real devices of the meeting screens (Figma 12.43). One small module store, outside the route components, so the camera and microphone
 * the Lobby asked for are still there when the route changes to the call, and so leaving the meeting can stop every track.
 *
 *  - request(): asks for the camera and the microphone (getUserMedia). A refusal, a missing device or a sandbox that blocks them never throws:
 *    the screens show the designed camera-off tile with a quiet note instead.
 *  - toggleMic / toggleCam: the round buttons. The microphone is muted on its track; the camera is released (its light goes off) and asked again
 *    when it is turned back on.
 *  - present / stopPresenting: getDisplayMedia for Present. A refusal sets `screenNote`.
 *  - stopAll(): stops every track (camera, microphone, shared screen) and resets. Called by Call ended and when the meeting screens are left.
 */
export type Phase = 'idle' | 'requesting' | 'ready' | 'blocked';

export type CallState = {
  phase: Phase;
  /** Live camera and microphone tracks, or null when neither is available. A new object whenever the tracks change. */
  stream: MediaStream | null;
  hasMic: boolean;
  hasCam: boolean;
  /** What the person wants: microphone on, camera on. */
  micOn: boolean;
  camOn: boolean;
  /** The shared screen while presenting. */
  screen: MediaStream | null;
  /** Set when Present did not start (refused, cancelled or not available here). */
  screenNote: string | null;
  /** When the call was joined (ms), for the clock of the call. */
  joinedAt: number | null;
};

export const SCREEN_NOTE = 'Screen sharing did not start. Allow screen capture to present here.';

const INITIAL: CallState = { phase: 'idle', stream: null, hasMic: false, hasCam: false, micOn: true, camOn: true, screen: null, screenNote: null, joinedAt: null };

let state: CallState = INITIAL;
const listeners = new Set<() => void>();
const set = (patch: Partial<CallState>) => {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};

let audio: MediaStreamTrack | null = null;
let video: MediaStreamTrack | null = null;
/** Bumped by stopAll: a device prompt that is answered after leaving must not keep its tracks. */
let generation = 0;
let leaveTimer: ReturnType<typeof setTimeout> | undefined;

const devices = (): MediaDevices | undefined => (typeof navigator === 'undefined' ? undefined : navigator.mediaDevices);

/** Publishes the current tracks as a fresh stream so the video elements pick the change up. */
function publish(extra: Partial<CallState> = {}) {
  const tracks = [audio, video].filter((t): t is MediaStreamTrack => Boolean(t));
  let stream: MediaStream | null = null;
  try {
    stream = tracks.length ? new MediaStream(tracks) : null;
  } catch {
    stream = null;
  }
  set({ stream, hasMic: Boolean(audio), hasCam: Boolean(video), ...extra });
}

function adopt(s: MediaStream) {
  const a = s.getAudioTracks()[0];
  const v = s.getVideoTracks()[0];
  if (a) {
    audio?.stop();
    audio = a;
    a.enabled = state.micOn;
    a.addEventListener('ended', () => {
      if (audio === a) {
        audio = null;
        publish();
      }
    });
  }
  if (v) {
    video?.stop();
    video = v;
    v.addEventListener('ended', () => {
      if (video === v) {
        video = null;
        publish();
      }
    });
  }
}

const dropStream = (s: MediaStream) => s.getTracks().forEach((t) => t.stop());

async function ask(md: MediaDevices, constraints: MediaStreamConstraints): Promise<MediaStream | string> {
  try {
    return await md.getUserMedia(constraints);
  } catch (e) {
    return (e as { name?: string } | null)?.name ?? 'Error';
  }
}

/** Asks for the devices that are wanted and not there yet. Never throws. */
async function acquire(): Promise<void> {
  if (state.phase === 'requesting') return;
  const md = devices();
  if (!md || typeof md.getUserMedia !== 'function') {
    set({ phase: 'blocked' });
    return;
  }
  const wantAudio = !audio;
  const wantVideo = state.camOn && !video;
  if (!wantAudio && !wantVideo) {
    set({ phase: audio || video ? 'ready' : 'blocked' });
    return;
  }
  const mine = generation;
  set({ phase: 'requesting' });
  const got: MediaStream[] = [];
  const first = await ask(md, { audio: wantAudio, video: wantVideo });
  if (typeof first !== 'string') got.push(first);
  else if (wantAudio && wantVideo && first !== 'NotAllowedError' && first !== 'SecurityError') {
    // One of the two is missing (for example a computer without a camera): take what exists.
    const v = await ask(md, { video: true });
    if (typeof v !== 'string') got.push(v);
    const a = await ask(md, { audio: true });
    if (typeof a !== 'string') got.push(a);
  }
  if (mine !== generation) {
    got.forEach(dropStream);
    return;
  }
  got.forEach(adopt);
  publish({ phase: audio || video ? 'ready' : 'blocked' });
}

export const callStore = {
  get: () => state,

  /** Asks for the camera and the microphone. Without `again` it asks once per visit (a refusal is not asked again by itself). */
  request(again = false): Promise<void> {
    if (state.phase === 'requesting') return Promise.resolve();
    if (!again && state.phase !== 'idle') return Promise.resolve();
    return acquire();
  },

  setIntents(v: { micOn?: boolean; camOn?: boolean }) {
    set({ ...v });
  },

  toggleMic() {
    if (audio) {
      const on = !state.micOn;
      audio.enabled = on;
      set({ micOn: on });
      return;
    }
    set({ micOn: true });
    void acquire();
  },

  toggleCam() {
    if (video && state.camOn) {
      const v = video;
      video = null;
      v.stop();
      publish({ camOn: false });
      return;
    }
    set({ camOn: true });
    void acquire();
  },

  /** Present: the browser asks which screen to share. Resolves true when sharing started. Never throws. */
  async present(): Promise<boolean> {
    if (state.screen) return true;
    const md = devices();
    if (!md || typeof md.getDisplayMedia !== 'function') {
      set({ screenNote: SCREEN_NOTE });
      return false;
    }
    const mine = generation;
    try {
      const s = await md.getDisplayMedia({ video: true, audio: false });
      const t = s.getVideoTracks()[0];
      if (!t || mine !== generation) {
        dropStream(s);
        if (!t) set({ screenNote: SCREEN_NOTE });
        return false;
      }
      t.addEventListener('ended', () => {
        if (state.screen === s) callStore.stopPresenting();
      });
      set({ screen: s, screenNote: null });
      return true;
    } catch {
      set({ screenNote: SCREEN_NOTE });
      return false;
    }
  },

  stopPresenting() {
    const s = state.screen;
    if (s) dropStream(s);
    set({ screen: null });
  },

  clearScreenNote() {
    if (state.screenNote) set({ screenNote: null });
  },

  /** The call clock starts when the call is joined. */
  markJoined() {
    if (state.joinedAt == null) set({ joinedAt: Date.now() });
  },

  /** Stops every track (camera light off) and resets the store. */
  stopAll() {
    generation += 1;
    clearTimeout(leaveTimer);
    leaveTimer = undefined;
    audio?.stop();
    video?.stop();
    audio = null;
    video = null;
    if (state.screen) dropStream(state.screen);
    state = INITIAL;
    listeners.forEach((l) => l());
  },

  /**
   * Leave guard. Every meeting screen tells the store when it appears and when it goes. When the last one goes and no other meeting screen
   * appears within a moment (a route change inside the meeting appears at once), the person has left the meeting pages: stop every track.
   */
  screenShown() {
    clearTimeout(leaveTimer);
    leaveTimer = undefined;
  },
  screenGone() {
    clearTimeout(leaveTimer);
    leaveTimer = setTimeout(() => callStore.stopAll(), 600);
  },
};

export function useCall(): CallState {
  return useSyncExternalStore(
    subscribe,
    () => state,
    () => INITIAL,
  );
}

/** The clock of the call: 4:12 PM when it is joined, then one minute per minute. */
export function callClock(joinedAt: number | null, now = Date.now()): string {
  const elapsed = joinedAt == null ? 0 : Math.max(0, Math.floor((now - joinedAt) / 60000));
  const total = 16 * 60 + 12 + elapsed;
  const h24 = Math.floor(total / 60) % 24;
  const m = total % 60;
  const h = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h}:${String(m).padStart(2, '0')} ${h24 >= 12 ? 'PM' : 'AM'}`;
}
