/**
 * Sample data of 12.14 Tasks (Figma frames Tasks 17674:851, Board view 17675:149, Milestone view 17675:873, Empty 17675:1499,
 * Task detail 17677:149, Task detail / In review 17678:1287, Task detail / Completed 17678:1754, Modal:Create task 17680:460,
 * Modal:Request review 17680:546, Toast:Task created 17680:603, Toast:Review requested 17680:610, Toast:Task completed 17680:617,
 * Dropdown:Filter tasks 17680:624, Dropdown:Change status 17680:898). Copy is taken from the frames word for word.
 * The constants below are those of the sample project "Career Guidance for Everyone". Adire Stories (the Digital Art project) has a set of
 * the same shape at the end of this file (ART_TASKS); `tasksDataFor` picks the set of a project.
 */
import { PATHS } from '../workspace/data';
import type { ProjectKey } from '../workspace/project';

/* ---------------------------------------------------------------- paths */

/** The task that has a detail screen in the design. The three detail frames are three stages of this one task. */
export const WRITE_ID = 'write-the-guided-onboarding-questions';
const D = `${PATHS.tasks}/${WRITE_ID}`;

export const TP = {
  list: PATHS.tasks,
  board: `${PATHS.tasks}/board`,
  milestones: `${PATHS.tasks}/milestones`,
  /** The "state-" routes are Figma frames that no UI path reaches: the empty list and the overlay frames (see routes.tsx). */
  empty: `${PATHS.tasks}/state-empty`,
  createModal: `${PATHS.tasks}/state-create-task`,
  created: `${PATHS.tasks}/state-task-created`,
  filter: `${PATHS.tasks}/state-filter-tasks`,
  detail: D,
  inReview: `${D}/in-review`,
  completed: `${D}/completed`,
  requestModal: `${D}/state-request-review`,
  changeStatus: `${D}/state-change-status`,
  reviewRequested: `${D}/state-review-requested`,
  taskCompleted: `${D}/state-task-completed`,
  /** Edit task (Figma Slide-out:Edit task, its Needs attention state and Task detail (updated) with Toast:Task updated). */
  editTask: `${D}/state-edit-task`,
  editTaskInvalid: `${D}/state-edit-task-needs-attention`,
  taskUpdated: `${D}/state-task-updated`,
} as const;

/* ---------------------------------------------------------------- people, statuses, priorities */

export const STATUSES = ['Not started', 'In progress', 'In review', 'Completed'] as const;
export type Status = (typeof STATUSES)[number];
export const PRIORITIES = ['High', 'Medium', 'Low'] as const;
export type Priority = (typeof PRIORITIES)[number];

export type Person = { name: string; initials: string; label: string };
/** In the order of the filter menu and of the workload block. */
export const PEOPLE: Person[] = [
  { name: 'Adaeze Okoye', initials: 'AO', label: 'Adaeze Okoye' },
  { name: 'Tobi Adeyemi', initials: 'TA', label: 'Tobi Adeyemi' },
  { name: 'Ngozi Eze', initials: 'NE', label: 'Ngozi Eze' },
  { name: 'Kemi Adeyemi', initials: 'KA', label: 'Kemi Adeyemi (you)' },
];
export const YOU = 'Kemi Adeyemi';

export const initialsOf = (name: string) =>
  name
    .replace(/\(.*?\)/g, '')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');

/** Matches what was typed in a person field to a member of the team ("Kemi Adeyemi (you)" is Kemi). `people` are those of the project (Career by default). */
export function personOf(text: string, people: Person[] = PEOPLE): string {
  const t = text.trim().toLowerCase();
  const hit = people.find((p) => t.length > 0 && (t.startsWith(p.name.toLowerCase()) || p.name.toLowerCase().startsWith(t)));
  return hit ? hit.name : text.trim() || YOU;
}

/* ---------------------------------------------------------------- milestones */

export type MilestoneInfo = { name: string; due: string; href?: string };
/** Only the first milestone has a detail screen (12.11). */
export const MILESTONES: MilestoneInfo[] = [
  { name: 'First Student Experience', due: 'Due 28 November', href: PATHS.milestone },
  { name: 'Prototype Review', due: 'Due 12 December' },
];

/* ---------------------------------------------------------------- tasks */

/** "Today" of the sample project: Wednesday 4 November 2026. Days are counted from 1 November 2026. */
export const TODAY = 4;

export type Task = {
  id: string;
  title: string;
  milestone: string;
  priority: Priority;
  /** Name of the person responsible. */
  owner: string;
  status: Status;
  /** Due day of an open task. */
  day: number;
  /** Day a completed task was done. */
  doneDay?: number;
  /** A due date typed in the Create task or Edit task form that could not be read as a date is shown as typed. */
  dueText?: string;
  /** What the Edit task form changed; the detail screen shows the description of the design until then. */
  description?: string;
};

const FSE = MILESTONES[0].name;
const PR = MILESTONES[1].name;

export const SEED_TASKS: Task[] = [
  { id: 'review-the-student-onboarding-draft', title: 'Review the student onboarding draft', milestone: FSE, priority: 'High', owner: 'Adaeze Okoye', status: 'In review', day: 6 },
  { id: 'collect-questions-students-ask-about-careers', title: 'Collect questions students ask about careers', milestone: FSE, priority: 'High', owner: 'Ngozi Eze', status: 'In progress', day: 9 },
  { id: WRITE_ID, title: 'Write the guided onboarding questions', milestone: FSE, priority: 'Medium', owner: 'Kemi Adeyemi', status: 'In progress', day: 10 },
  { id: 'build-the-second-onboarding-screen', title: 'Build the second onboarding screen', milestone: FSE, priority: 'Medium', owner: 'Tobi Adeyemi', status: 'In progress', day: 13 },
  { id: 'confirm-the-final-interest-questions', title: 'Confirm the final interest questions', milestone: FSE, priority: 'High', owner: 'Ngozi Eze', status: 'Not started', day: 20 },
  { id: 'invite-two-schools-to-the-review', title: 'Invite two schools to the review', milestone: PR, priority: 'Medium', owner: 'Tobi Adeyemi', status: 'Not started', day: 27 },
  { id: 'plan-the-prototype-review-session', title: 'Plan the prototype review session', milestone: PR, priority: 'Low', owner: 'Adaeze Okoye', status: 'Not started', day: 34 },
  { id: 'share-the-career-interview-notes', title: 'Share the career interview notes', milestone: FSE, priority: 'Low', owner: 'Ngozi Eze', status: 'Completed', day: 3, doneDay: 3 },
  { id: 'set-up-the-shared-canvas', title: 'Set up the shared workspace', milestone: FSE, priority: 'Low', owner: 'Kemi Adeyemi', status: 'Completed', day: 2, doneDay: 2 },
];

const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DOW_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MON_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const at = (day: number) => new Date(Date.UTC(2026, 10, day));

/** "Fri 6 Nov" */
export function shortDate(day: number): string {
  const d = at(day);
  return `${DOW[d.getUTCDay()]} ${d.getUTCDate()} ${MON[d.getUTCMonth()]}`;
}
/** "Tuesday 10 November" */
export function longDate(day: number): string {
  const d = at(day);
  return `${DOW_LONG[d.getUTCDay()]} ${d.getUTCDate()} ${MON_LONG[d.getUTCMonth()]}`;
}
/** Reads "Tuesday 10 November", "10 Nov" or "Fri 4 Dec" (any text with a day number and a month name) as a day counted from 1 November 2026. */
export function parseDay(text: string): number | null {
  const m = /(\d{1,2})\s*(?:st|nd|rd|th)?\s+([A-Za-z]{3,})/.exec(text);
  if (!m) return null;
  const month = MON.findIndex((x) => m[2].toLowerCase().startsWith(x.toLowerCase()));
  if (month < 0) return null;
  const n = Math.round((Date.UTC(2026, month, Number(m[1])) - Date.UTC(2026, 10, 1)) / 86400000) + 1;
  return n;
}

/** The right-hand column of a row: the due date, or "Done 3 Nov" once the task is completed. */
export function dueLabel(t: Task): string {
  if (t.status === 'Completed') {
    const d = at(t.doneDay ?? t.day);
    return `Done ${d.getUTCDate()} ${MON[d.getUTCMonth()]}`;
  }
  return t.dueText ?? shortDate(t.day);
}

/** Open tasks by due date, then completed tasks with the most recently done first (the order of every view in the design). */
export function sortTasks(tasks: Task[]): Task[] {
  const open = tasks.filter((t) => t.status !== 'Completed').sort((a, b) => a.day - b.day);
  const done = tasks.filter((t) => t.status === 'Completed').sort((a, b) => (b.doneDay ?? b.day) - (a.doneDay ?? a.day));
  return [...open, ...done];
}

export const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;

/* ---------------------------------------------------------------- filters */

export type Filters = { status: Status[]; priority: Priority[]; person: string[] };
export const NO_FILTERS: Filters = { status: [], priority: [], person: [] };
/** The Dropdown:Filter tasks frame shows "In progress" ticked and "Show 3 tasks". */
export const FRAME_FILTERS: Filters = { status: ['In progress'], priority: [], person: [] };

/** A task matches when it fits every group that has a choice, and any choice within a group. */
export function matches(t: Task, f: Filters): boolean {
  return (f.status.length === 0 || f.status.includes(t.status)) && (f.priority.length === 0 || f.priority.includes(t.priority)) && (f.person.length === 0 || f.person.includes(t.owner));
}
export const hasFilters = (f: Filters) => f.status.length + f.priority.length + f.person.length > 0;

/* ---------------------------------------------------------------- copy */

export const COPY = {
  label: 'TASKS',
  title: 'The work ahead.',
  lead: 'A clear view of what needs to happen next.',
  empty: { title: 'Nothing on the list yet.', text: 'Define the next steps your team needs to take.' },
  created: 'Task created. It is on the list now.',
  completed: 'Task completed. Everyone on it has been told.',
  updated: 'Task updated. Everyone on it has been told.',
  reviewRequested: (name: string) => `Review requested. ${name} has been told.`,
  /** Used when the title of a new task is left empty, so the one press flow of the prototype works (the placeholder of the field). */
  fallbackTitle: 'Write the interview summary',
};

/**
 * The Edit task slide-out (Figma Slide-out Form 17972:147077, frames Slide-out:Edit task 17972:163075 and Needs attention 17972:163242).
 * The Default frame shows the due date already changed to Thursday 12 November, and the updated detail (17972:163401) shows that date:
 * the field starts with it while the task still has its first due date, so pressing Save changes completes the flow.
 */
export const EDIT = {
  eyebrow: 'EDIT TASK',
  title: 'Edit this task',
  save: 'Save changes',
  cancel: 'Cancel',
  titleError: 'Add a title to continue.',
  dueSample: 'Thursday 12 November',
};

/** The "Needs review" block of the context panel (List and Milestone view). */
export const NEEDS_REVIEW = { title: 'Review the student onboarding draft', due: 'Due Friday 6 November', responsible: 'Responsible: Adaeze Okoye' };
export const WORKLOAD_NOTE = 'Based on the tasks your team agreed to, not on activity.';
export const SESSION = { title: 'Prototype review', when: 'Thursday, 4:00 PM, 45 minutes', who: 'With Adaeze, Tobi and Ngozi' };

/* ---------------------------------------------------------------- task detail (Write the guided onboarding questions) */

export type Stage = 'progress' | 'review' | 'done';
export const STAGE_STATUS: Record<Stage, Status> = { progress: 'In progress', review: 'In review', done: 'Completed' };
export const STAGE_PATH: Record<Stage, string> = { progress: TP.detail, review: TP.inReview, done: TP.completed };

export const DETAIL = {
  description: 'Write the questions that guide a student through the first onboarding screen. Keep each one short and in plain language.',
  responsible: 'Kemi Adeyemi (you)',
  supporting: 'Adaeze Okoye',
  due: 'Tuesday 10 November',
  criteria: ['Three questions written', 'Questions reviewed with Adaeze', 'Questions added to the onboarding draft'],
  files: [
    { name: 'Onboarding questions.docx', meta: 'Word, 42 KB, added by Kemi Adeyemi' },
    { name: 'Career interview notes.docx', meta: 'Word, 180 KB, shared by Ngozi Eze' },
  ],
  /** Criteria that are met in each stage (the frames: one of three, then all three). */
  criteriaMet: { progress: [true, false, false], review: [true, true, true], done: [true, true, true] } as Record<Stage, boolean[]>,
  notice: {
    review: (name: string) => `Review requested from ${name}. You will be told when it is done.`,
    done: 'Completed. Everyone on this task has been told.',
  },
  /** "On this task" in the context panel. The dots are as drawn in the design (Kemi green, Adaeze amber). */
  people: [
    { initials: 'KA', name: 'Kemi Adeyemi (responsible)', text: 'Working on a milestone', tone: 'green' as const },
    { initials: 'AO', name: 'Adaeze Okoye (supporting)', text: 'Available for review', tone: 'accent' as const },
  ],
  conversation: { title: 'Onboarding flow', line: 'Tobi Adeyemi, today at 10:42' },
};

export type TaskComment = { id: string; initials: string; name: string; time: string; text: string };

/** Comments of the three frames: two, then three (review requested), then four (approved). */
export const COMMENT_SEEDS: Record<Stage, TaskComment[]> = (() => {
  const a: TaskComment = { id: 'c1', initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday, 4:12 PM', text: 'I added the second screen to the draft. Can you look at the wording of the third question?' };
  const b: TaskComment = { id: 'c2', initials: 'AO', name: 'Adaeze Okoye', time: 'Today, 9:05 AM', text: 'The wording is clear. I would move the interest question to the end.' };
  const c: TaskComment = { id: 'c3', initials: 'KA', name: 'Kemi Adeyemi', time: 'Today, 10:20 AM', text: 'Ready for review. All three criteria are done.' };
  const d: TaskComment = { id: 'c4', initials: 'AO', name: 'Adaeze Okoye', time: 'Today, 11:05 AM', text: 'Reviewed and approved. This is ready to complete.' };
  return { progress: [a, b], review: [a, b, c], done: [a, b, c, d] };
})();

/* ---------------------------------------------------------------- per project data */

/** The three views under the root of a project (Career: PROJECT_PATH, Adire Stories: ART_PATH). The suffixes are the same in both. */
export const viewPaths = (root: string) => ({ list: `${root}/tasks`, board: `${root}/tasks/board`, milestones: `${root}/tasks/milestones` });

/**
 * Everything the Tasks pages show that belongs to a project: its milestones, people, sample tasks and the copy that names them.
 * Career Guidance for Everyone is the set above; Adire Stories has its own set of the same shape (same counts, same order, same ids).
 */
export type TasksData = {
  milestones: MilestoneInfo[];
  people: Person[];
  seed: Task[];
  copy: typeof COPY;
  needsReview: typeof NEEDS_REVIEW;
  workloadNote: string;
  /** What the Create task modal starts with: the placeholder of the title and the Responsible and Due date fields (the Milestone field starts with the first milestone). */
  create: { titlePlaceholder: string; who: string; due: string };
};

export const CAREER_TASKS: TasksData = {
  milestones: MILESTONES,
  people: PEOPLE,
  seed: SEED_TASKS,
  copy: COPY,
  needsReview: NEEDS_REVIEW,
  workloadNote: WORKLOAD_NOTE,
  create: { titlePlaceholder: 'For example, Write the interview summary', who: DETAIL.responsible, due: DETAIL.due },
};

/* ---- Adire Stories (the Digital Art project). Same shape and order as the Career set; no task has a detail screen on Adire. */

/** Same positions as PEOPLE: Adaeze is Amara, Tobi is Ayo, Ngozi is Yusuf. */
export const ART_PEOPLE: Person[] = [
  { name: 'Amara Obi', initials: 'AO', label: 'Amara Obi' },
  { name: 'Ayo Bello', initials: 'AB', label: 'Ayo Bello' },
  { name: 'Yusuf Danjuma', initials: 'YD', label: 'Yusuf Danjuma' },
  { name: 'Kemi Adeyemi', initials: 'KA', label: 'Kemi Adeyemi (you)' },
];

/** The third and fourth milestones of the project (none of them has a detail screen on Adire). */
export const ART_MILESTONES: MilestoneInfo[] = [
  { name: 'Headwrap Portrait', due: 'Due 26 November' },
  { name: 'Pattern Study Set', due: 'Due 10 December' },
];

const ART_HP = ART_MILESTONES[0].name;
const ART_PSS = ART_MILESTONES[1].name;

/** Days are counted from 1 November 2026, as for the Career tasks. */
export const ART_SEED_TASKS: Task[] = [
  { id: 'review-the-student-onboarding-draft', title: 'Review the headwrap colour layer', milestone: ART_HP, priority: 'High', owner: 'Amara Obi', status: 'In review', day: 6 },
  { id: 'collect-questions-students-ask-about-careers', title: 'Collect reference photos of headwrap cloth', milestone: ART_HP, priority: 'High', owner: 'Yusuf Danjuma', status: 'In progress', day: 11 },
  { id: WRITE_ID, title: 'Write the caption for the headwrap plate', milestone: ART_HP, priority: 'Medium', owner: 'Kemi Adeyemi', status: 'In progress', day: 12 },
  { id: 'build-the-second-onboarding-screen', title: 'Paint the headwrap highlight layer', milestone: ART_HP, priority: 'Medium', owner: 'Ayo Bello', status: 'In progress', day: 16 },
  { id: 'confirm-the-final-interest-questions', title: 'Confirm the pattern names with the dyers', milestone: ART_HP, priority: 'High', owner: 'Yusuf Danjuma', status: 'Not started', day: 18 },
  { id: 'invite-two-schools-to-the-review', title: 'Draft the palette for the pattern set', milestone: ART_PSS, priority: 'Medium', owner: 'Ayo Bello', status: 'Not started', day: 30 },
  { id: 'plan-the-prototype-review-session', title: 'Sketch the pattern study layouts', milestone: ART_PSS, priority: 'Low', owner: 'Amara Obi', status: 'Not started', day: 33 },
  { id: 'share-the-career-interview-notes', title: 'Share the dye pot notes from Abeokuta', milestone: ART_HP, priority: 'Low', owner: 'Yusuf Danjuma', status: 'Completed', day: 4, doneDay: 4 },
  { id: 'set-up-the-shared-canvas', title: 'Set up the plate template', milestone: ART_HP, priority: 'Low', owner: 'Kemi Adeyemi', status: 'Completed', day: 1, doneDay: 1 },
];

export const ART_TASKS: TasksData = {
  milestones: ART_MILESTONES,
  people: ART_PEOPLE,
  seed: ART_SEED_TASKS,
  copy: { ...COPY, fallbackTitle: 'Write the dyer interview summary' },
  needsReview: { title: 'Review the headwrap colour layer', due: 'Due Friday 6 November', responsible: 'Responsible: Amara Obi' },
  workloadNote: WORKLOAD_NOTE,
  create: { titlePlaceholder: 'For example, Write the dyer interview summary', who: 'Kemi Adeyemi (you)', due: longDate(12) },
};

/** The data of a project's Tasks pages. */
export const tasksDataFor = (key: ProjectKey): TasksData => (key === 'adire' ? ART_TASKS : CAREER_TASKS);
