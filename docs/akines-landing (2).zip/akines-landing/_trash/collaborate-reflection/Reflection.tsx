'use client';

import '../workspace/workspace.css';
import './reflection.css';
import { useEffect, useRef, useState } from 'react';
import { useNav } from '@/lib/nav';
import { Button, EmptyState, Modal, toast } from '@/ui';
import { PATHS } from '../workspace/data';
import { BackLink, CardLink, Ctx, Facts, PageHead, WorkspaceFrame, cx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import {
  NOT_AVAILABLE,
  NOT_AVAILABLE_FACTS,
  REFLECTION,
  REFLECTION_PATHS,
  SCALE,
  type Choice,
  type Level,
  type Question,
  type Suggestion,
  type Theme,
} from './data';
import { checkIn, useCheckInStore } from './store';

/**
 * 12.23 Reflection: Not available yet, Reflection (open), Check-in, Submitted, Team summary and the overlay frames
 * Modal:Submit check-in, Toast:Check-in saved and Toast:Check-in submitted. Every class is prefixed rf-; the page frame, header,
 * facts, back link, card link and context panel blocks come from the workspace (cw-) and the kit.
 *
 * Privacy: the person's own answers are shown only on the check-in screen. No screen renders anyone else's answers and the
 * team summary is made of combined themes (a word per theme), never a score or an answer of one person.
 * Controls with no destination in the design (the written note, the theme rows) do nothing beyond their hover and focus look.
 */

/**
 * Both projects with a Reflection (Career Guidance for Everyone and Adire Stories) render these same pages. `useReflection()` gives a page
 * the copy and the routes of its own project, and the check-in store keeps one check-in per project (see store.ts).
 */
function useReflection() {
  const { key } = useProject();
  return { key, ...REFLECTION[key], rp: REFLECTION_PATHS[key] };
}

const TOAST_MS = 2500;
/** The toasts of the "state-" frames stay longer so they can be looked at (the same choice as Conversations). */
const STATE_TOAST_MS = 8000;

/* ------------------------------------------------------------------ context panel (Context Panel / Reflection) */

/** Context=Open. The labels run at 1.7 percent letter spacing in this panel (see reflection.css). */
function OpenContext() {
  const c = useReflection().contextOpen;
  return (
    <>
      <Ctx label={c.private.label}>
        <p className="cw-session__title">{c.private.heading}</p>
        <p className="rf-cbody">{c.private.body}</p>
      </Ctx>
      <Ctx label={c.team.label}>
        <p className="cw-session__title">{c.team.heading}</p>
        <p className="rf-cbody">{c.team.body}</p>
      </Ctx>
      <Ctx label={c.why.label}>
        <p className="rf-cbody">{c.why.body}</p>
        <p className="rf-cbody rf-cbody--ink">{c.why.line}</p>
      </Ctx>
    </>
  );
}

/** Context=Summary. */
function SummaryContext() {
  const c = useReflection().contextSummary;
  return (
    <>
      <Ctx label={c.read.label}>
        <p className="cw-session__title">{c.read.heading}</p>
        <p className="rf-cbody">{c.read.body}</p>
      </Ctx>
      <Ctx label={c.never.label}>
        {c.never.lines.map((l) => (
          <p className="rf-cbody rf-cbody--ink" key={l}>
            {l}
          </p>
        ))}
      </Ctx>
      <Ctx label={c.next.label}>
        <p className="rf-cbody">{c.next.body}</p>
      </Ctx>
    </>
  );
}

/* ------------------------------------------------------------------ Not available yet */

/** Career only: the Not available yet frame is a "state-" route that Adire Stories does not mirror (it is not the Adire Reflection page). */
export function ReflectionNotAvailable() {
  const { openHead } = useReflection();
  return (
    <WorkspaceFrame active="reflection" context={<OpenContext />}>
      <div className="rf-page">
        <PageHead label={openHead.label} title={openHead.title} lead={openHead.lead}>
          <Facts compact items={NOT_AVAILABLE_FACTS} />
        </PageHead>
        <div data-m="up">
          <EmptyState
            className="cw-empty"
            title={NOT_AVAILABLE.title}
            text={NOT_AVAILABLE.text}
            action={
              <Button href={PATHS.milestone} arrow="up-right">
                {NOT_AVAILABLE.action}
              </Button>
            }
          />
        </div>
      </div>
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Reflection (open) */

export function ReflectionOpen() {
  const { openHead, openFacts, intro, lastSummary, rp } = useReflection();
  return (
    <WorkspaceFrame active="reflection" context={<OpenContext />}>
      <div className="rf-page">
        <PageHead label={openHead.label} title={openHead.title} lead={openHead.lead}>
          <Facts compact items={openFacts} />
        </PageHead>

        <section className="rf-card" data-m="up" aria-labelledby="rf-intro-title">
          <span className="rf-rule" aria-hidden="true" />
          <h2 className="rf-card__title" id="rf-intro-title">
            {intro.title}
          </h2>
          <p className="rf-card__copy">{intro.copy}</p>
          <p className="rf-card__note">{intro.note}</p>
          <Button href={rp.checkIn}>{intro.action}</Button>
        </section>

        <section className="rf-sec" data-m="up" aria-labelledby="rf-last-label">
          <h2 className="rf-label" id="rf-last-label">
            {lastSummary.label}
          </h2>
          <div className="rf-teaser">
            <p className="rf-teaser__text">{lastSummary.teaser}</p>
            <CardLink href={rp.summary} arrow>
              {lastSummary.link}
            </CardLink>
          </div>
        </section>
      </div>
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Check-in */

/**
 * Rating Option (Figma 17729:92760): Default, Hover, Selected, Pressed and Focus come from CSS. The chosen option is Selected,
 * and choosing it again clears the answer, so a question never holds more than one answer.
 */
function RatingOption({ label, selected, onClick }: { label: string; selected: boolean; onClick: () => void }) {
  return (
    <button type="button" className={cx('rf-opt', selected && 'rf-opt--on')} aria-pressed={selected} onClick={onClick}>
      {selected ? <i className="rf-opt__dot" aria-hidden="true" /> : null}
      <span>{label}</span>
    </button>
  );
}

/** Question Card (Figma 17729:97695): number, Answered tag once a choice is made, question, hint and the four options. */
function QuestionCard({ index, item, answer }: { index: number; item: Question; answer: Choice }) {
  const { key, questions } = useReflection();
  const titleId = `rf-q${index}-title`;
  const hintId = `rf-q${index}-hint`;
  return (
    <article className="rf-q" aria-labelledby={titleId}>
      <div className="rf-q__meta">
        <span className="rf-q__num">{`QUESTION ${index + 1} OF ${questions.length}`}</span>
        {answer !== null ? (
          <span className="rf-q__tag">
            <i className="rf-q__dot" aria-hidden="true" />
            Answered
          </span>
        ) : null}
      </div>
      <h3 className="rf-q__q" id={titleId}>
        {item.question}
      </h3>
      <p className="rf-q__hint" id={hintId}>
        {item.hint}
      </p>
      <div className="rf-q__scale" role="group" aria-labelledby={titleId} aria-describedby={hintId}>
        {SCALE.map((label, option) => (
          <RatingOption key={label} label={label} selected={answer === option} onClick={() => checkIn.pick(key, index, option)} />
        ))}
      </div>
    </article>
  );
}

/** Line Field (Figma 17372:14055): Default, Hover and Focus come from CSS. The field grows with what is typed. */
function NoteField() {
  const { key, improve } = useReflection();
  const note = useCheckInStore((s) => s.note);
  const field = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = field.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight + 2}px`;
  }, [note]);

  return (
    <div className="rf-field">
      <label className="rf-field__title" htmlFor="rf-improve">
        {improve.title}
      </label>
      <textarea
        ref={field}
        id="rf-improve"
        className="rf-field__input"
        rows={1}
        value={note}
        placeholder={improve.placeholder}
        aria-describedby="rf-improve-help"
        autoComplete="off"
        onChange={(e) => checkIn.setNote(key, e.target.value)}
      />
      <p className="rf-field__help" id="rf-improve-help">
        {improve.help}
      </p>
    </div>
  );
}

/** Modal:Submit check-in (Figma 17729:120776). Cancel, the close button and the scrim close it. */
function SubmitModal({ open, onClose, onSubmit }: { open: boolean; onClose: () => void; onSubmit: () => void }) {
  const { submitModal: m } = useReflection();
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={m.eyebrow}
      title={m.title}
      description={m.description}
      footer={
        <>
          <Button onClick={onSubmit}>{m.submit}</Button>
          <CardLink onClick={onClose}>{m.cancel}</CardLink>
        </>
      }
    >
      <dl className="rf-priv">
        {m.facts.map((f) => (
          <div className="rf-priv__item" key={f.label}>
            <dt>{f.label}</dt>
            <dd>{f.value}</dd>
          </div>
        ))}
      </dl>
    </Modal>
  );
}

function CheckInScreen({ startOpen, savedToast }: { startOpen?: boolean; savedToast?: boolean }) {
  const nav = useNav();
  const { checkInHead, checkInActions, questions, savedToast: savedMessage, submittedToast: submittedMessage, rp } = useReflection();
  const answers = useCheckInStore((s) => s.answers);
  const [modal, setModal] = useState(Boolean(startOpen));

  // the "state-check-in-saved" frame: the check-in with the toast already showing
  useEffect(() => {
    if (savedToast) toast.show({ message: savedMessage, duration: STATE_TOAST_MS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [savedToast]);

  // Save for later shows the toast and stays on the check-in
  const save = () => toast.show({ message: savedMessage, duration: TOAST_MS });

  // Submit privately in the modal goes to Submitted and shows the toast there
  const submit = () => {
    setModal(false);
    nav.push(rp.submitted);
    toast.show({ message: submittedMessage, duration: TOAST_MS });
  };

  return (
    <WorkspaceFrame active="reflection" context={<OpenContext />}>
      <div className="rf-page">
        <PageHead back={<BackLink href={rp.open}>{checkInHead.back}</BackLink>} label={checkInHead.label} title={checkInHead.title} lead={checkInHead.lead} />

        <ol className="rf-qs" aria-label="Questions" data-m="up">
          {questions.map((item, i) => (
            <li key={item.question}>
              <QuestionCard index={i} item={item} answer={answers[i] ?? null} />
            </li>
          ))}
        </ol>

        <div data-m="up">
          <NoteField />
        </div>

        <div className="rf-actions" data-m="up">
          <Button onClick={() => setModal(true)}>{checkInActions.submit}</Button>
          <Button variant="secondary" onClick={save}>
            {checkInActions.save}
          </Button>
        </div>
      </div>
      <SubmitModal open={modal} onClose={() => setModal(false)} onSubmit={submit} />
    </WorkspaceFrame>
  );
}

export const CheckIn = () => <CheckInScreen />;
/** Frame "Modal:Submit check-in": the check-in with the modal open. */
export const CheckInSubmitModal = () => <CheckInScreen startOpen />;
/** Frame "Toast:Check-in saved": the check-in with the toast showing. */
export const CheckInSaved = () => <CheckInScreen savedToast />;

/* ------------------------------------------------------------------ Submitted */

function SubmittedScreen({ toastOnLoad }: { toastOnLoad?: boolean }) {
  const { submitted, submittedToast, rp } = useReflection();
  // the "state-check-in-submitted" frame: Submitted with the toast already showing
  useEffect(() => {
    if (toastOnLoad) toast.show({ message: submittedToast, duration: STATE_TOAST_MS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toastOnLoad]);

  return (
    <WorkspaceFrame active="reflection" context={<OpenContext />}>
      <div className="rf-page">
        <PageHead back={<BackLink href={rp.open}>{submitted.back}</BackLink>} label={submitted.label} title={submitted.title} lead={submitted.lead} />

        <section className="rf-card" data-m="up" aria-labelledby="rf-done-title">
          <span className="rf-rule" aria-hidden="true" />
          <h2 className="rf-card__title rf-card__title--sm" id="rf-done-title">
            {submitted.headline}
          </h2>
          <p className="rf-card__copy">{submitted.copy}</p>
          <CardLink href={rp.summary} arrow>
            {submitted.link}
          </CardLink>
        </section>
      </div>
    </WorkspaceFrame>
  );
}

export const Submitted = () => <SubmittedScreen />;
/** Frame "Toast:Check-in submitted": Submitted with the toast showing. */
export const SubmittedToast = () => <SubmittedScreen toastOnLoad />;

/* ------------------------------------------------------------------ Team summary */

const LEVEL_KEY: Record<Level, 'strong' | 'steady' | 'attention'> = { Strong: 'strong', Steady: 'steady', 'Needs attention': 'attention' };

/** Theme Row (Figma 17729:92810): Strong, Steady and Needs attention, each Default and Hover. The row is not a control. */
function ThemeRow({ theme }: { theme: Theme }) {
  return (
    <tr className="rf-theme">
      <td>
        <p className="rf-theme__name">{theme.name}</p>
        <p className="rf-theme__meaning">{theme.meaning}</p>
      </td>
      <td>
        <span className="rf-theme__level">
          <i className={cx('rf-lvl', `rf-lvl--${LEVEL_KEY[theme.level]}`)} aria-hidden="true" />
          {theme.level}
        </span>
      </td>
    </tr>
  );
}

function SuggestionRow({ s }: { s: Suggestion }) {
  return (
    <li className="rf-sug">
      <div className="rf-sug__text">
        <p className="rf-theme__name">{s.title}</p>
        <p className="rf-theme__meaning">{s.meaning}</p>
      </div>
      <CardLink href={s.href}>{s.link}</CardLink>
    </li>
  );
}

export function TeamSummary() {
  const { summaryHead, themeHeads, themes, suggestionsHead, suggestions, privacyNote, rp } = useReflection();
  return (
    <WorkspaceFrame active="reflection" context={<SummaryContext />}>
      <div className="rf-page">
        <PageHead back={<BackLink href={rp.open}>{summaryHead.back}</BackLink>} label={summaryHead.label} title={summaryHead.title} lead={summaryHead.lead} />

        <div className="rf-themes" data-m="up">
          <table className="rf-table" aria-label="Team themes">
            <thead>
              <tr>
                <th scope="col">{themeHeads.theme}</th>
                <th scope="col">{themeHeads.level}</th>
              </tr>
            </thead>
            <tbody>
              {themes.map((t) => (
                <ThemeRow key={t.name} theme={t} />
              ))}
            </tbody>
          </table>
        </div>

        <section className="rf-sec" data-m="up" aria-labelledby="rf-sugg-label">
          <h2 className="rf-label" id="rf-sugg-label">
            {suggestionsHead.label}
          </h2>
          <p className="rf-sugg-support">{suggestionsHead.support}</p>
          <ul className="rf-sugg">
            {suggestions.map((s) => (
              <SuggestionRow key={s.title} s={s} />
            ))}
          </ul>
        </section>

        <div className="rf-note" data-m="up">
          <p className="rf-note__title">{privacyNote.title}</p>
          <p className="rf-note__text">{privacyNote.text}</p>
        </div>
      </div>
    </WorkspaceFrame>
  );
}
