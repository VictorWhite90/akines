import type { RouteDef } from '@/routes.types';
import { RP } from './data';
import { CheckIn, CheckInSaved, CheckInSubmitModal, ReflectionNotAvailable, ReflectionOpen, Submitted, SubmittedToast, TeamSummary } from './Reflection';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * Reflection 12.23: Reflection (17729:112456, the page the Project navigation opens), Not available yet (17729:111793),
 * Check-in (17729:114784), Submitted (17729:118573), Team summary (17729:119229) and the overlay frames Modal:Submit check-in
 * (17729:120776), Toast:Check-in saved (17729:120830) and Toast:Check-in submitted (17729:120837).
 * The open page, the check-in, the submitted page and the team summary are reached from the UI (Start check-in, Submit privately,
 * View team summary, the back links). The "state-" routes are the Figma frames that have no natural trigger in the prototype:
 * Not available yet, and the overlay frames, which open with the modal or the toast already showing.
 */
export const routes: RouteDef[] = [
  { path: RP.open, title: 'Reflection', shell: 'app', nav, component: ReflectionOpen },
  { path: RP.notAvailable, title: 'Reflection', shell: 'app', nav, component: ReflectionNotAvailable },
  { path: RP.checkIn, title: 'Check-in', shell: 'app', nav, component: CheckIn },
  { path: RP.submitted, title: 'Check-in submitted', shell: 'app', nav, component: Submitted },
  { path: RP.summary, title: 'Team summary', shell: 'app', nav, component: TeamSummary },
  { path: RP.submitModal, title: 'Check-in', shell: 'app', nav, component: CheckInSubmitModal },
  { path: RP.savedToast, title: 'Check-in', shell: 'app', nav, component: CheckInSaved },
  { path: RP.submittedToast, title: 'Check-in submitted', shell: 'app', nav, component: SubmittedToast },
];
