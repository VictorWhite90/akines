import type { RouteDef } from '@/routes.types';
import { PATHS } from '../workspace/data';
import { MilestoneDetailTwo } from '../workspace/Overview';
// Studio removed 5 Nov 2026: import { CanvasAddModal, CanvasAdded, WorkDetailJourney, WorkDetailQuestions } from '../workspace/Studio';
import { CommunityLearningPage, MentorshipCirclePage } from './SampleProject';
import {
  StateArchive,
  StateArchived,
  StateCommunitySwitcher,
  StateCreateAI,
  StateCreateAIAnswer,
  StateCreateAIThinking,
  StateDetailsSaved,
  StateEditDetails,
  StateLeave,
  StateLeft,
  StateMentorshipSwitcher,
  StateNotifications,
  StateNotificationsRead,
  StatePreferences,
  StatePreferencesSaved,
  StateSettings,
  StateSwitcher,
} from './states';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * 12.25 Project header, 12.26 Sample projects and the page added to 12.11 (Milestone 2). The Studio pages it also held (Work detail 2 and 3,
 * Add to canvas) were removed 5 Nov 2026. The sample projects live here so workspace/routes and routes.ts stay as they are.
 * The "state-" routes are the Figma state frames that have no natural trigger in the prototype (they are not linked from
 * the UI): each opens one overlay over its page. Every overlay is opened from the Project header.
 */
export const routes: RouteDef[] = [
  /* 12.11 addition */
  { path: PATHS.milestone2, title: 'Prototype Review', shell: 'app', nav, component: MilestoneDetailTwo },
  // Studio removed 5 Nov 2026. Routes kept as comments:
  // { path: PATHS.work2, title: 'Map the student journey', shell: 'app', nav, component: WorkDetailJourney },
  // { path: PATHS.work3, title: 'Questions students ask about careers', shell: 'app', nav, component: WorkDetailQuestions },
  // { path: `${PATHS.canvas}/state-add-to-canvas`, title: 'Shared canvas', shell: 'app', nav, component: CanvasAddModal },
  // { path: `${PATHS.canvas}/state-added-to-canvas`, title: 'Shared canvas', shell: 'app', nav, component: CanvasAdded },

  /* 12.26 Sample projects */
  { path: PATHS.communityLearning, title: 'Community Learning Initiative', shell: 'app', nav, component: CommunityLearningPage },
  { path: PATHS.mentorshipCircle, title: 'Mentorship Circle', shell: 'app', nav, component: MentorshipCirclePage },
  { path: `${PATHS.communityLearning}/state-project-switcher`, title: 'Community Learning Initiative', shell: 'app', nav, component: StateCommunitySwitcher },
  { path: `${PATHS.mentorshipCircle}/state-project-switcher`, title: 'Mentorship Circle', shell: 'app', nav, component: StateMentorshipSwitcher },

  /* 12.25 Project header: dropdowns and Create AI over the Project overview */
  { path: `${PATHS.overview}/state-project-switcher`, title: 'Project overview', shell: 'app', nav, component: StateSwitcher },
  { path: `${PATHS.overview}/state-notifications`, title: 'Project overview', shell: 'app', nav, component: StateNotifications },
  { path: `${PATHS.overview}/state-notifications-read`, title: 'Project overview', shell: 'app', nav, component: StateNotificationsRead },
  { path: `${PATHS.overview}/state-project-settings`, title: 'Project overview', shell: 'app', nav, component: StateSettings },
  { path: `${PATHS.overview}/state-create-ai`, title: 'Project overview', shell: 'app', nav, component: StateCreateAI },
  { path: `${PATHS.overview}/state-create-ai-thinking`, title: 'Project overview', shell: 'app', nav, component: StateCreateAIThinking },
  { path: `${PATHS.overview}/state-create-ai-answer`, title: 'Project overview', shell: 'app', nav, component: StateCreateAIAnswer },

  /* 12.25 Project header: modals and their toasts */
  { path: `${PATHS.overview}/state-edit-project-details`, title: 'Project overview', shell: 'app', nav, component: StateEditDetails },
  { path: `${PATHS.overview}/state-project-details-saved`, title: 'Project overview', shell: 'app', nav, component: StateDetailsSaved },
  { path: `${PATHS.overview}/state-archive-project`, title: 'Project overview', shell: 'app', nav, component: StateArchive },
  { path: `${PATHS.list}/state-project-archived`, title: 'My projects', shell: 'app', nav, component: StateArchived },
  { path: `${PATHS.overview}/state-leave-project`, title: 'Project overview', shell: 'app', nav, component: StateLeave },
  { path: `${PATHS.list}/state-left-project`, title: 'My projects', shell: 'app', nav, component: StateLeft },
  { path: `${PATHS.overview}/state-notification-preferences`, title: 'Project overview', shell: 'app', nav, component: StatePreferences },
  { path: `${PATHS.overview}/state-notification-preferences-saved`, title: 'Project overview', shell: 'app', nav, component: StatePreferencesSaved },
];
