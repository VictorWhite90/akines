'use client';

/**
 * Every Community modal, drawer and result panel (Figma "Modal:" frames, 17103:7092 to 17104:7225), opened by the same
 * triggers as the prototype reactions. One host serves all screens: it is mounted by NotificationsModal, which the app
 * shell always renders. Screens only call openModal(id).
 */
import { useRef, type ReactNode } from 'react';
import { Button, Chip, Drawer, Modal, Tag, Toggle } from '@/ui';
import { useNav } from '@/lib/nav';
import {
  acceptInvite, closeModal, dismissContinue, dismissIntro, dismissInvite, openModal, sendIntro, setCommunity, setDraft, setReminder, setSlot, useCommunity,
  type CommunityState, type ModalId,
} from './store';
import { AV, IMG, P, type AvKey } from './data';
import { AvatarStack, ICalendar, ICheck, ICheckCircle, ILock, IShield, IArrow, TextLink } from './ui';

/* ---------- content ---------- */

type Plan = {
  kind: 'plan';
  image: string;
  eyebrow: string;
  title: string;
  lead: string;
  people: AvKey[];
  peopleText: string;
  times: [string, string, string];
  note: string;
  /** placeholder shown if the note is cleared (Figma: the Create Call frames word it per person) */
  ph?: string;
  send?: string;
};
const T_NOW: Plan['times'] = ['Right now', 'Today, 5:00 PM', 'Tomorrow, 10:00 AM'];
const T_EVE: Plan['times'] = ['Today, 6:30 PM', 'Tomorrow, 12:30 PM', 'Another time'];
const PRIVACY_PLAN = 'They will see your invitation and choose whether to join. Nothing starts until they accept.';

const PLANS: Partial<Record<ModalId, Plan>> = {
  quick: { kind: 'plan', image: 'friends', eyebrow: 'About 15 minutes', title: 'Quick Catch-up', lead: 'A short, easy conversation with someone from your circle.', people: ['folake'], peopleText: 'Suggested: Folake', times: T_NOW, note: 'Hi Folake, do you have a few minutes for a quick catch-up?' },
  'cc-amara': { kind: 'plan', image: 'amara', eyebrow: 'Create Call', title: 'Arrange a Create Call with Amara', lead: 'Pick a time to work on the Community Health Initiative together.', people: ['amara'], peopleText: 'Amara', times: T_EVE, note: 'Let us draft the outreach plan and agree the first clinic visit.', ph: 'Add what you would like to work on (optional)' },
  'cc-folake': { kind: 'plan', image: 'folake', eyebrow: 'Create Call', title: 'Arrange a Create Call with Folake', lead: 'Make something small together, or start planning the next zine.', people: ['folake'], peopleText: 'Folake', times: T_EVE, note: 'Shall we sketch ideas for the next zine together?', ph: 'Add what you would like to make (optional)' },
  'cc-zine': { kind: 'plan', image: 'zine', eyebrow: 'Create Call', title: 'Arrange a Create Call for the zine', lead: 'Gather the Lagos Makers Zine team for a working session.', people: ['folake', 'chuka'], peopleText: 'Folake and Chuka', times: T_EVE, note: 'Let us go through the contributions so far and plan the layout.' },
  talk: { kind: 'plan', image: 'ngozi', eyebrow: 'About 30 minutes', title: 'Talk Something Through', lead: 'Think out loud with one person who will listen well.', people: ['chuka'], peopleText: 'Suggested: Chuka', times: T_EVE, note: 'I have an idea I would like to talk through with you.' },
  create: { kind: 'plan', image: 'zine', eyebrow: 'About 20 minutes', title: 'Create Together', lead: 'Work through an idea with someone who shares your interests.', people: ['amara', 'tunde'], peopleText: 'Suggested: Amara and Tunde', times: T_EVE, note: 'I would love to build something small with you this week.' },
  circle: { kind: 'plan', image: 'kincircle', eyebrow: 'About 45 minutes', title: 'Circle Call', lead: 'A small, structured conversation with your Cliq.', people: ['tunde', 'ngozi', 'chuka'], peopleText: 'Food Systems Cliq', times: T_EVE, note: 'Shall we pick up the shared project plan together?' },
  play: { kind: 'plan', image: 'chuka', eyebrow: 'About 30 minutes', title: 'Play Call', lead: 'Games and play with people who like to laugh.', people: ['folake', 'chuka'], peopleText: 'University friends', times: T_EVE, note: 'Up for a few light rounds this evening?' },
  support: { kind: 'plan', image: 'amara', eyebrow: 'About 20 minutes', title: 'Support Call', lead: 'A listening ear when something is weighing on you. You choose who is asked.', people: ['amara', 'folake'], peopleText: 'People you trust', times: T_NOW, note: 'Something has been weighing on me and I would value a listening ear.', send: 'Send request' },
};

type Why = { image: string; person: string; tags: string[]; why: string; now: string; together: string; used: string; intro: ModalId; idx: 0 | 1 | 2 };
const WHY: Partial<Record<ModalId, Why>> = {
  'why-tunde': { image: 'tunde', person: 'Tunde', idx: 0, intro: 'intro-tunde', tags: ['Community health', 'Small-group work'], why: 'You and Tunde are both developing community-health initiatives and prefer practical, small-group collaboration.', now: 'You both chose collaboration this week, and Tunde has room for a new Create Call on Thursday.', together: 'Compare how you each plan outreach in a 30-minute Create Call, then decide whether to keep working together.', used: 'Interests you both chose: community health and small groups. Your collaboration intention. Times you both shared.' },
  'why-ngozi': { image: 'ngozi', person: 'Ngozi', idx: 1, intro: 'intro-ngozi', tags: ['Storytelling', 'Zine-making'], why: 'You and Ngozi both write to remember the people in your lives, and you both prefer a quiet, one-to-one conversation.', now: 'You both chose evenings as a good time to talk this week.', together: 'Start with a Quick Catch-up and see whether you would like to write together.', used: 'Interests you both chose: storytelling and zine-making. Conversation style: slow and one to one. Times you both shared.' },
  'why-chuka': { image: 'chuka', person: 'Chuka', idx: 2, intro: 'intro-chuka', tags: ['Small business', 'Thinking out loud'], why: 'You and Chuka are both starting something of your own and like talking ideas through with one person at a time.', now: 'Chuka has joined the KinCircle on starting a purpose-driven business, the one you were invited to.', together: 'Talk Something Through for about 20 minutes, with no pressure to continue.', used: 'Interests you both chose: small business and thinking out loud. Your KinCircle invitations. Times you both shared.' },
};

type Intro = { image: string; person: string; idx: 0 | 1 | 2; lead: string; note: string };
const INTRO: Partial<Record<ModalId, Intro>> = {
  'intro-tunde': { image: 'tunde', person: 'Tunde', idx: 0, lead: 'Akines will send a short note on your behalf. Tunde chooses whether to reply.', note: 'Hi Tunde, we are both building community-health projects and like working in small groups. Would you like to compare notes?' },
  'intro-ngozi': { image: 'ngozi', person: 'Ngozi', idx: 1, lead: 'Akines will send a short note on your behalf. Ngozi chooses whether to reply.', note: 'Hi Ngozi, I noticed we both write to remember the people in our lives. Would you like a quiet catch-up?' },
  'intro-chuka': { image: 'chuka', person: 'Chuka', idx: 2, lead: 'Akines will send a short note on your behalf. Chuka chooses whether to reply.', note: 'Hi Chuka, we are both starting something of our own. Would you like to talk ideas through for a while?' },
};

type Up = { image: string; eyebrow: string; title: string; when: string; people: AvKey[]; peopleText: string; text: string; agenda: string[]; open: string; to: string; idx: 0 | 1 | 2 | 3 };
const UP: Partial<Record<ModalId, Up>> = {
  'up-project': { image: 'health', eyebrow: 'Create Call · Food Systems Cliq', title: 'Project Call with the Food Systems Cliq', when: 'Today · 2:00 PM · 60 minutes', people: ['tunde', 'ngozi', 'chuka'], peopleText: 'Tunde, Ngozi and 6 others', text: "A working session on the Cliq's shared project plan. Bring your notes from last week.", agenda: ["Review last week's notes", 'Agree the next three tasks', 'Decide who leads each one'], open: 'Open Cliq conversation', to: P.thread('food-systems-cliq'), idx: 0 },
  'up-banter': { image: 'friends', eyebrow: 'Banter · Open conversation', title: 'Banter: Can ambition and rest coexist?', when: 'Today · 6:00 PM · 45 minutes', people: ['folake', 'amara', 'chuka'], peopleText: 'Folake, Amara and 10 others', text: 'An open conversation. Listen first, or join in when you feel like it.', agenda: ['A short prompt from the host', 'Open conversation', 'A quiet minute to close'], open: 'Open Banter', to: P.banter, idx: 1 },
  'up-kin': { image: 'kincircle-wide', eyebrow: 'KinCircle · Reflection circle', title: 'KinCircle Reflection', when: 'Tomorrow · 12:30 PM · 40 minutes', people: ['ngozi', 'tunde'], peopleText: 'Ngozi, Tunde and 4 others', text: 'A gentle circle to reflect on the week with people you trust.', agenda: ['One thing that went well', 'One thing that was hard', 'What you would like to carry forward'], open: 'Open KinCircle conversation', to: P.thread('kincircle-reflection'), idx: 2 },
  'up-game': { image: 'zine', eyebrow: 'Play · University friends', title: 'Game night with university friends', when: 'Friday · 8:00 PM · 90 minutes', people: ['folake', 'chuka'], peopleText: 'Folake, Chuka and 5 others', text: 'Easy company and a few good games. Bring snacks, not strategy.', agenda: ['Warm-up round', 'Team games', 'Open chat'], open: 'Open group conversation', to: P.thread('university-friends'), idx: 3 },
};

type Inv = { image: string; eyebrow: string; title: string; meta: string; text: string; people: AvKey[]; peopleText: string; expect: string[]; idx: 0 | 1 };
const INV: Partial<Record<ModalId, Inv>> = {
  'inv-kin': { image: 'kincircle-wide', eyebrow: 'KinCircle invitation', title: 'Starting a purpose-driven business', meta: 'KinCircle · Thursday · Two places available', text: 'Five members are gathering to discuss building businesses around meaningful problems.', people: ['tunde', 'ngozi', 'chuka'], peopleText: 'Tunde, Ngozi and 3 others', expect: ['A 60-minute conversation on Thursday evening', 'A small group of five, with no presentations', 'Leave at any time without explanation'], idx: 0 },
  'inv-walk': { image: 'folake', eyebrow: 'Folake invited you', title: 'A Sunday walk by the lagoon', meta: 'Friend · Next Sunday · 8:00 AM', text: 'Folake is walking with two friends and would love you to join for an easy, unhurried morning.', people: ['folake', 'chuka'], peopleText: 'Folake and Chuka', expect: ['An easy pace, about 90 minutes', 'The meeting point is shared once you accept', 'You can change your mind at any time'], idx: 1 },
};

const WHO: { key: string; name: string; av: AvKey }[] = [
  { key: '1', name: 'Amara', av: 'amara' },
  { key: '2', name: 'Folake', av: 'folake' },
  { key: '3', name: 'Chuka', av: 'chuka' },
];

/* ---------- parts ---------- */

function People({ people, text }: { people: AvKey[]; text: string }) {
  return (
    <div className="ch-ppl">
      <AvatarStack people={people} size={40} overlap={10} />
      <span className="ch-ppl__text">{text}</span>
    </div>
  );
}
const Label = ({ children }: { children: ReactNode }) => <p className="ch-ov__label">{children}</p>;
const Privacy = ({ children }: { children: ReactNode }) => (
  <p className="ch-ov__privacy">
    <ILock />
    <span>{children}</span>
  </p>
);

function Note({ id, def, rows = 2, label, ph = 'Add a short note (optional)' }: { id: string; def: string; rows?: number; label: string; ph?: string }) {
  const s = useCommunity();
  return (
    <textarea
      className="ch-note"
      aria-label={label}
      placeholder={ph}
      rows={rows}
      value={s.draft[id] ?? def}
      onChange={(e) => setDraft(id, e.target.value)}
    />
  );
}

function Times({ id, times }: { id: string; times: Plan['times'] }) {
  const s = useCommunity();
  const cur = s.slot[id] ?? 1;
  return (
    <div className="ch-ov__field">
      <Label>Choose a time</Label>
      <div className="ch-chips" role="group" aria-label="Choose a time">
        {times.map((t, i) => (
          <Chip key={t} variant="choice" selected={cur === i + 1} onClick={() => setSlot(id, (i + 1) as 1 | 2 | 3)}>
            {t}
          </Chip>
        ))}
      </div>
    </div>
  );
}

function Actions({ children }: { children: ReactNode }) {
  return <div className="ch-ov__actions">{children}</div>;
}

/* ---------- the host ---------- */

export function CommunityOverlays() {
  const s = useCommunity();
  const nav = useNav();
  /* keep the last panel mounted while it plays its exit animation */
  const last = useRef<ModalId | null>(null);
  if (s.modal) last.current = s.modal;
  const id = s.modal ?? last.current;
  const open = s.modal !== null;
  const go = (path: string) => {
    closeModal();
    nav.push(path);
  };

  const plan = id ? PLANS[id] : undefined;
  const why = id ? WHY[id] : undefined;
  const intro = id ? INTRO[id] : undefined;
  const up = id ? UP[id] : undefined;
  const inv = id ? INV[id] : undefined;

  /* plan modals: 560 wide, photo header */
  if (plan && id) {
    return (
      <Modal key={id} open={open} onClose={closeModal} width={560} image={IMG(plan.image)} eyebrow={plan.eyebrow} title={plan.title} className="ch-ov ch-ov--modal">
        <div className="ch-ov__body">
          <p className="ch-ov__lead">{plan.lead}</p>
          <People people={plan.people} text={plan.peopleText} />
          <Times id={id} times={plan.times} />
          <Note id={id} def={plan.note} label="Add a short note" ph={plan.ph} />
          <Privacy>{PRIVACY_PLAN}</Privacy>
          <Actions>
            <Button iconRight={<IArrow />} onClick={() => openModal('sent-invitation')}>
              {plan.send ?? 'Send invitation'}
            </Button>
            <Button variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
          </Actions>
        </div>
      </Modal>
    );
  }

  /* introduce us: 560 wide */
  if (intro && id) {
    const on = s.share[intro.idx];
    return (
      <Modal key={id} open={open} onClose={closeModal} width={560} image={IMG(intro.image)} eyebrow="Introduction" title={`Introduce yourself to ${intro.person}`} className="ch-ov ch-ov--modal">
        <div className="ch-ov__body">
          <p className="ch-ov__lead">{intro.lead}</p>
          <People people={[intro.image as AvKey]} text={intro.person} />
          <Note id={id} def={intro.note} rows={3} label={`Your note to ${intro.person}`} />
          <div className="ch-share">
            <div className="ch-share__text">
              <span className="ch-share__title">Share why we matched</span>
              <span className="ch-share__desc">{intro.person} will see the reasons you were suggested to each other.</span>
            </div>
            <Toggle checked={on} aria-label="Share why we matched" onChange={(v) => setCommunity((st) => ({ share: st.share.map((x, k) => (k === intro.idx ? v : x)) as CommunityState['share'] }))} />
          </div>
          <Actions>
            <Button
              iconRight={<IArrow />}
              onClick={() => {
                sendIntro(intro.idx);
                openModal('sent-intro');
              }}
            >
              Send introduction
            </Button>
            <Button variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
          </Actions>
        </div>
      </Modal>
    );
  }

  /* encourage and message someone I trust: 560 wide */
  if (id === 'encourage' || id === 'trust') {
    const enc = id === 'encourage';
    const who = enc ? s.encourageWho : s.trustWho;
    return (
      <Modal key={id} open={open} onClose={closeModal} width={560} image={IMG(enc ? 'folake' : 'ngozi')} eyebrow="Wellbeing" title={enc ? 'Encourage someone' : 'Message someone I trust'} className="ch-ov ch-ov--modal">
        <div className="ch-ov__body">
          <p className="ch-ov__lead">{enc ? "A few kind words can change someone's day. They will know it came from you." : 'Choose who you would like to reach. Only they will see your message.'}</p>
          <div className="ch-ov__field">
            <Label>{enc ? 'Who would you like to encourage?' : 'Who do you trust?'}</Label>
            <div className="ch-chips" role="group" aria-label={enc ? 'Who would you like to encourage?' : 'Who do you trust?'}>
              {WHO.map((w, i) => (
                <Chip key={w.key} variant="choice" selected={who === i + 1} onClick={() => setCommunity(enc ? { encourageWho: (i + 1) as 1 | 2 | 3 } : { trustWho: (i + 1) as 1 | 2 | 3 })}>
                  {w.name}
                </Chip>
              ))}
            </div>
          </div>
          <Note id={id} def={enc ? 'Thinking of you. I hope your week is gentle.' : 'Hi, it has been a heavy week. Could we talk for a little while tonight?'} rows={enc ? 2 : 3} label="Your message" ph={enc ? 'Write a few kind words.' : 'Write a few words. You choose what to share.'} />
          {enc ? null : <Privacy>Your check-in stays private. This message is sent only because you chose to send it.</Privacy>}
          <Actions>
            <Button iconRight={<IArrow />} onClick={() => openModal(enc ? 'sent-encourage' : 'sent-message')}>
              {enc ? 'Send encouragement' : 'Send message'}
            </Button>
            <Button variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
          </Actions>
        </div>
      </Modal>
    );
  }

  /* result panels: 480 wide, centred */
  if (id === 'sent-invitation' || id === 'sent-intro' || id === 'sent-encourage' || id === 'sent-message') {
    const copy = {
      'sent-invitation': ['Invitation sent', PRIVACY_PLAN, false],
      'sent-intro': ['Introduction sent', 'They will see your note and choose whether to reply. The conversation will appear in Messages once they do.', true],
      'sent-encourage': ['Encouragement sent', "A kind word can change someone's day. They will see it in their Messages.", true],
      'sent-message': ['Message sent', 'Only the person you chose will see it. Your check-in stays private.', true],
    }[id] as [string, string, boolean];
    return (
      <Modal key={id} open={open} onClose={closeModal} width={480} hideClose label={copy[0]} className="ch-ov ch-ov--result">
        <div className="ch-result">
          <span className="ch-result__icon">
            <ICheckCircle s={40} />
          </span>
          <h2 className="ch-result__title">{copy[0]}</h2>
          <p className="ch-result__text">{copy[1]}</p>
          <div className="ch-result__actions">
            <Button onClick={closeModal}>Done</Button>
            {copy[2] ? (
              <Button variant="secondary" onClick={() => go(P.messages)}>
                Open Messages
              </Button>
            ) : null}
          </div>
        </div>
      </Modal>
    );
  }

  /* why we matched: 520 wide drawer */
  if (why) {
    return (
      <Drawer key={id} open={open} onClose={closeModal} width={520} image={IMG(why.image)} eyebrow="Why we matched" title={`You and ${why.person}`} className="ch-ov ch-ov--drawer ch-ov--why">
        <div className="ch-dbody ch-dbody--why">
          <div className="ch-tags">
            {why.tags.map((t) => (
              <Tag key={t}>{t}</Tag>
            ))}
          </div>
          <hr className="ch-rule" />
          {(
            [
              ['Why this person?', why.why],
              ['Why now?', why.now],
              ['What could we do together?', why.together],
              ['What information was used?', why.used],
            ] as const
          ).map(([q, a]) => (
            <div className="ch-qa" key={q}>
              <Label>{q}</Label>
              <p className="ch-qa__a">{a}</p>
            </div>
          ))}
          <p className="ch-ov__privacy ch-ov__privacy--shield">
            <IShield />
            <span>Not used: popularity, follower counts or relationship scores. Akines does not show them.</span>
          </p>
          <div className="ch-ov__actions ch-ov__actions--wrap ch-dbody__end">
            <Button iconRight={<IArrow />} onClick={() => openModal(why.intro)}>
              Introduce us
            </Button>
            <TextLink
              onClick={() => {
                dismissIntro(why.idx);
                closeModal();
              }}
            >
              Not now
            </TextLink>
            <TextLink onClick={() => go(P.settings)}>Recommendation preferences</TextLink>
          </div>
        </div>
      </Drawer>
    );
  }

  /* upcoming: 520 wide drawer */
  if (up) {
    const done = s.rem[up.idx];
    return (
      <Drawer key={id} open={open} onClose={closeModal} width={520} image={IMG(up.image)} eyebrow={up.eyebrow} title={up.title} className="ch-ov ch-ov--drawer ch-ov--up">
        <div className="ch-dbody ch-dbody--up">
          <p className="ch-when">
            <ICalendar s={20} />
            <span>{up.when}</span>
          </p>
          <People people={up.people} text={up.peopleText} />
          <p className="ch-ov__lead">{up.text}</p>
          <hr className="ch-rule" />
          <Label>What to expect</Label>
          <ul className="ch-agenda">
            {up.agenda.map((a) => (
              <li key={a}>
                <ICheck />
                <span>{a}</span>
              </li>
            ))}
          </ul>
          <div className="ch-dbody__end">
            {done ? (
              <p className="ch-confirm">
                <ICheckCircle />
                <span>Reminder set for 15 minutes before.</span>
              </p>
            ) : null}
            <div className="ch-ov__actions ch-ov__actions--wrap">
              <Button iconRight={<IArrow />} onClick={() => go(up.to)}>
                {up.open}
              </Button>
              {done ? null : (
                <Button variant="secondary" onClick={() => setReminder(up.idx)}>
                  Set a reminder
                </Button>
              )}
            </div>
          </div>
        </div>
      </Drawer>
    );
  }

  /* invitation: 520 wide drawer */
  if (inv) {
    const accepted = s.inv.acc[inv.idx];
    return (
      <Drawer key={id} open={open} onClose={closeModal} width={520} image={IMG(inv.image)} eyebrow={inv.eyebrow} title={inv.title} className="ch-ov ch-ov--drawer ch-ov--inv">
        <div className="ch-dbody ch-dbody--inv">
          <p className="ch-when">
            <ICalendar s={18} />
            <span>{inv.meta}</span>
          </p>
          <p className="ch-ov__lead">{inv.text}</p>
          <People people={inv.people} text={inv.peopleText} />
          <hr className="ch-rule" />
          <Label>What to expect</Label>
          <ul className="ch-agenda ch-agenda--sm">
            {inv.expect.map((a) => (
              <li key={a}>
                <ICheck />
                <span>{a}</span>
              </li>
            ))}
          </ul>
          <p className="ch-ov__note">You can review everything here before you decide.</p>
          <div className="ch-dbody__end">
            {accepted ? (
              <p className="ch-confirm">
                <ICheckCircle />
                <span>You are going. It is now in your upcoming moments.</span>
              </p>
            ) : (
              <div className="ch-ov__actions ch-ov__actions--wrap">
                <Button
                  iconRight={<IArrow />}
                  onClick={() => {
                    acceptInvite(inv.idx);
                    closeModal();
                  }}
                >
                  Accept invitation
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    dismissInvite(inv.idx);
                    closeModal();
                  }}
                >
                  Not this time
                </Button>
              </div>
            )}
          </div>
        </div>
      </Drawer>
    );
  }

  return null;
}

export { dismissContinue };
