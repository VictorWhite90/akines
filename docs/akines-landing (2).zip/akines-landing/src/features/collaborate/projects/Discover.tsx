'use client';

/**
 * 12.5 Discover projects (Figma 17311:18092) with its states: D1 Filtered by project type (17312:18544), D1 Search results (17312:18722),
 * D1 Search with no match (17312:18872), D1 No projects yet (17312:18957), D1 Loading (17312:19008) and Modal:More filters (17312:19924).
 * One component driven by state: the search text, the type chip and the modal filters narrow the six sample projects.
 */
import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { Button, Chip, Modal } from '@/ui';
import { useNav } from '@/lib/nav';
import { useMemoState } from '@/lib/hooks';
import {
  FILTER_GROUPS,
  PROJECTS,
  TYPE_CHIPS,
  figmaFilters,
  filterLabels,
  filtersActive,
  initialFilters,
  passesFilters,
  searchScore,
  type FilterKey,
  type FilterState,
} from './data';
import { LOADING_MS, takeFirstVisit, toggleSaved, useSavedState } from './store';
import { CardLink, CardSkeleton, IconSearch, IconX, PageHead, ProjectCard, StatePanel } from './ui';

type View = { query: string; type: string; filters: FilterState; touched: boolean };
const INITIAL_VIEW: View = { query: '', type: '', filters: initialFilters(), touched: false };

const plural = (n: number, one: string, many: string) => (n === 1 ? one : many);

/* ------------------------------------------------------------------ Modal:More filters (17312:19924) */

function FiltersModal({ open, onClose, value, touched, onApply }: { open: boolean; onClose: () => void; value: FilterState; touched: boolean; onApply: (f: FilterState) => void }) {
  const [draft, setDraft] = useState<FilterState>(value);
  const wasOpen = useRef(false);
  useEffect(() => {
    // each time the modal opens it starts from the applied filters (the first time: the selection drawn in the Figma frame)
    if (open && !wasOpen.current) setDraft(touched ? value : figmaFilters());
    wasOpen.current = open;
  }, [open, touched, value]);

  const toggle = (key: FilterKey, option: string) =>
    setDraft((d) => {
      const has = d[key].includes(option);
      let next = has ? d[key].filter((o) => o !== option) : [...d[key], option];
      if (key === 'location' && !has) {
        // "Anywhere in Nigeria" is the no-narrowing choice: it excludes My state and Remote
        next = option === 'Anywhere in Nigeria' ? ['Anywhere in Nigeria'] : next.filter((o) => o !== 'Anywhere in Nigeria');
      }
      return { ...d, [key]: next };
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="xl"
      width={1040}
      className="dsc-modal dsc-modal--filters"
      eyebrow="More filters"
      title="Narrow the projects"
      description="Choose what matters to you. Projects update when you show results."
      footer={
        <div className="dsc-modal__actions">
          <Button
            onClick={() => {
              onApply(draft);
              onClose();
            }}
          >
            Show projects
          </Button>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
        </div>
      }
    >
      <div className="dsc-filters">
        {FILTER_GROUPS.map((g) => {
          const selected = draft[g.key];
          return (
            <div className="dsc-filter" role="group" aria-label={g.name} key={g.key}>
              <div className="dsc-filter__label">
                <div className="dsc-filter__name">
                  <span>{g.name}</span>
                  <span className="dsc-filter__count">{selected.length ? `${selected.length} selected` : 'None selected'}</span>
                </div>
                <p className="dsc-filter__desc">{g.description}</p>
              </div>
              <div className="dsc-filter__options">
                {g.options.map((o) => (
                  <Chip key={o} selected={selected.includes(o)} onClick={() => toggle(g.key, o)}>
                    {o}
                  </Chip>
                ))}
              </div>
            </div>
          );
        })}
        <div className="dsc-filters__end" />
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ search and filters panel */

function SearchPanel({ query, onQuery, type, onType, onMore }: { query: string; onQuery: (q: string) => void; type: string; onType: (t: string) => void; onMore: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const id = useId();
  return (
    <section className="dsc-panel" aria-label="Search and filters">
      <div className="dsc-panel__row">
        <div className="dsc-search" data-filled={query ? 'true' : undefined}>
          <IconSearch className="dsc-search__icon" />
          <input
            ref={inputRef}
            id={id}
            className="dsc-search__input"
            type="search"
            value={query}
            placeholder="Search by project, skill or place"
            aria-label="Search by project, skill or place"
            autoComplete="off"
            onChange={(e) => onQuery(e.target.value)}
          />
          {query ? (
            <button
              type="button"
              className="dsc-search__clear"
              aria-label="Clear search"
              onClick={() => {
                onQuery('');
                inputRef.current?.focus();
              }}
            >
              <IconX />
            </button>
          ) : null}
        </div>
        <Button variant="secondary" onClick={onMore} aria-haspopup="dialog">
          More filters
        </Button>
      </div>
      <div className="dsc-panel__chips" role="group" aria-label="Project type">
        <Chip selected={!type} onClick={() => onType('')}>
          All projects
        </Chip>
        {TYPE_CHIPS.map((t) => (
          <Chip key={t} selected={type === t} onClick={() => onType(type === t ? '' : t)}>
            {t}
          </Chip>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ screen */

export function DiscoverScreen({ variant }: { variant?: 'loading' | 'empty' }) {
  const { replace } = useNav();
  const [view, setView] = useMemoState<View>('cd.discover', INITIAL_VIEW);
  const [modal, setModal] = useState(false);
  const { session } = useSavedState();
  const [loading, setLoading] = useState(() => (variant === 'loading' ? true : variant ? false : takeFirstVisit('discover')));

  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(() => {
      // Figma: Loading frame, after 2.5 s it dissolves into the screen
      if (variant === 'loading') replace('/collaborate/discover');
      else setLoading(false);
    }, LOADING_MS);
    return () => window.clearTimeout(t);
  }, [loading, variant, replace]);

  const { query, type, filters } = view;
  const results = useMemo(() => {
    const base = PROJECTS.filter((p) => (!type || p.type === type) && passesFilters(p, filters));
    const q = query.trim();
    if (!q) return base;
    return base
      .map((p, i) => ({ p, i, s: searchScore(p, q) }))
      .filter((r) => r.s > 0)
      .sort((a, b) => b.s - a.s || a.i - b.i)
      .map((r) => r.p);
  }, [query, type, filters]);

  const head = (
    <PageHead
      eyebrow="Projects looking for people"
      title="Find a project that needs you."
      lead="Explore projects from the Akines community and see where your skills could help."
      link={<CardLink href="/collaborate/saved">Saved projects</CardLink>}
    />
  );

  /* No projects yet (17312:18957): header and the empty panel, no search */
  if (variant === 'empty') {
    return (
      <div className="dsc-page">
        <div className="dsc-stack">
          {head}
          <StatePanel headline="No projects are open to collaborators yet." support="When a member starts a project and looks for people, it appears here. You could be the first.">
            <Button href="/collaborate/start">Start a project</Button>
          </StatePanel>
        </div>
      </div>
    );
  }

  const q = query.trim();
  const narrowed = Boolean(type) || filtersActive(filters);
  const clearAll = () => setView((v) => ({ ...v, type: '', filters: initialFilters() }));
  const parts = [type, ...filterLabels(filters)].filter(Boolean);

  const openCount = results.filter((p) => !p.closed).length;
  const countText =
    openCount === results.length
      ? `${results.length} ${plural(results.length, 'project', 'projects')} open to collaborators`
      : `${results.length} ${plural(results.length, 'project', 'projects')}, ${openCount} open to collaborators`;
  let summary: React.ReactNode = null;
  if (!loading) {
    if (q) {
      summary = (
        <div className="dsc-summary">
          <p className="dsc-summary__count" aria-live="polite">
            {results.length} {plural(results.length, 'project', 'projects')} for “{q}”
            {narrowed ? ` · ${parts.join(', ')}` : ''}
          </p>
          <CardLink onClick={() => setView((v) => ({ ...v, query: '' }))}>Clear search</CardLink>
        </div>
      );
    } else if (narrowed) {
      summary = (
        <div className="dsc-summary">
          <p className="dsc-summary__count" aria-live="polite">
            {countText} · {parts.join(', ')}
          </p>
          <CardLink onClick={clearAll}>Clear filters</CardLink>
        </div>
      );
    } else {
      summary = (
        <div className="dsc-summary">
          <p className="dsc-summary__count" aria-live="polite">
            {countText}
          </p>
          <span className="dsc-summary__note">Most relevant first</span>
        </div>
      );
    }
  }

  let body: React.ReactNode;
  if (loading) {
    body = (
      <section className="dsc-results" aria-busy="true" aria-label="Projects">
        <div className="dsc-summary">
          <p className="dsc-summary__count">Finding projects…</p>
        </div>
        <div className="dsc-grid">
          {Array.from({ length: 6 }, (_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      </section>
    );
  } else if (results.length === 0 && q) {
    // D1 Search with no match (17312:18872)
    body = (
      <StatePanel
        pair
        headline={`No projects match “${q}”.`}
        support="Try a different word, or clear the search to see every open project. You can also start a project of your own."
      >
        <Button href="/collaborate/start">Start a project</Button>
        <Button variant="secondary" onClick={() => setView((v) => ({ ...v, query: '' }))}>
          Clear search
        </Button>
      </StatePanel>
    );
  } else if (results.length === 0) {
    // not drawn in Figma: the same panel for filters that leave nothing
    body = (
      <StatePanel
        pair
        headline="No projects match these filters."
        support="Try fewer filters, or clear them to see every open project. You can also start a project of your own."
      >
        <Button href="/collaborate/start">Start a project</Button>
        <Button variant="secondary" onClick={clearAll}>
          Clear filters
        </Button>
      </StatePanel>
    );
  } else {
    body = (
      <section className="dsc-results" aria-label="Projects">
        {summary}
        <div className="dsc-grid" data-m="stagger">
          {results.map((p) => (
            <ProjectCard key={p.slug} project={p} mode="discover" saved={session.includes(p.slug)} onSave={() => toggleSaved(p.slug)} />
          ))}
        </div>
      </section>
    );
  }

  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        {head}
        <SearchPanel
          query={query}
          onQuery={(next) => setView((v) => ({ ...v, query: next }))}
          type={type}
          onType={(t) => setView((v) => ({ ...v, type: t }))}
          onMore={() => setModal(true)}
        />
        {body}
      </div>
      <FiltersModal
        open={modal}
        onClose={() => setModal(false)}
        value={filters}
        touched={view.touched}
        onApply={(f) => setView((v) => ({ ...v, filters: f, touched: true }))}
      />
    </div>
  );
}

export const Discover = () => <DiscoverScreen />;
export const DiscoverLoading = () => <DiscoverScreen variant="loading" />;
export const DiscoverEmpty = () => <DiscoverScreen variant="empty" />;
