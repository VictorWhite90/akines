'use client';

import { useSyncExternalStore } from 'react';
import { useProject, type ProjectKey } from '../workspace/project';
import { ART_SEED_TASKS, NO_FILTERS, SEED_TASKS, tasksDataFor, type Filters, type Status, type Task } from './data';

/**
 * Small store of the Tasks screens (same pattern as workspace/store.ts): the tasks of the project, the filters applied to the
 * List view and the reviewer named in the last review request. It lives for one visit (not across reloads).
 * The List, Board and Milestone views, the counts in the page header, the filter menu and the workload block all read the same tasks,
 * so a task created in the modal or a status changed on the detail screen shows everywhere.
 * Each project has its own store, started from its own sample tasks: a task created or changed on Adire Stories never shows on Career
 * Guidance for Everyone, and the other way round.
 */
type State = {
  tasks: Task[];
  filters: Filters;
  reviewer: string;
};

export const DEFAULT_REVIEWER = 'Adaeze Okoye';

function createStore(seed: Task[]) {
  let state: State = { tasks: seed, filters: NO_FILTERS, reviewer: DEFAULT_REVIEWER };
  const listeners = new Set<() => void>();
  const set = (patch: Partial<State>) => {
    state = { ...state, ...patch };
    listeners.forEach((l) => l());
  };
  const subscribe = (cb: () => void) => {
    listeners.add(cb);
    return () => {
      listeners.delete(cb);
    };
  };
  const actions = {
    add(task: Task) {
      if (state.tasks.some((t) => t.id === task.id)) return;
      set({ tasks: [...state.tasks, task] });
    },
    remove(id: string) {
      if (!state.tasks.some((t) => t.id === id)) return;
      set({ tasks: state.tasks.filter((t) => t.id !== id) });
    },
    /** Changes the status of a task. A task that becomes Completed is done on `doneDay`. Does nothing when nothing changes. */
    setStatus(id: string, status: Status, doneDay?: number) {
      const t = state.tasks.find((x) => x.id === id);
      if (!t || t.status === status) return;
      set({ tasks: state.tasks.map((x) => (x.id === id ? { ...x, status, doneDay: status === 'Completed' ? (doneDay ?? x.doneDay ?? x.day) : x.doneDay } : x)) });
    },
    /**
     * Saves what the Edit task form changed. Every view reads the same tasks, so the new title, due date, owner and milestone show on the
     * detail, the List, the Board and the Milestone view. A patch key that is present (even as undefined) replaces the value.
     */
    update(id: string, patch: Partial<Pick<Task, 'title' | 'description' | 'milestone' | 'owner' | 'day' | 'dueText'>>) {
      if (!state.tasks.some((t) => t.id === id)) return;
      set({ tasks: state.tasks.map((x) => (x.id === id ? { ...x, ...patch } : x)) });
    },
    setFilters(filters: Filters) {
      set({ filters });
    },
    setReviewer(name: string) {
      if (name && name !== state.reviewer) set({ reviewer: name });
    },
  };
  return { subscribe, get: () => state, actions };
}

const stores: Record<ProjectKey, ReturnType<typeof createStore>> = {
  career: createStore(SEED_TASKS),
  adire: createStore(ART_SEED_TASKS),
};

/** Select stable pieces only (`s.tasks`, `s.filters`, `s.reviewer`) and derive the rest in the component. Reads the store of the project of the page. */
export function useTasksStore<T>(select: (s: State) => T): T {
  const store = stores[useProject().key];
  return useSyncExternalStore(
    store.subscribe,
    () => select(store.get()),
    () => select(store.get()),
  );
}

/** The actions of the store of the project of the page (Create task, Filter tasks and the status changes act on this project only). */
export function useTasksActions() {
  return stores[useProject().key].actions;
}

/** The actions on Career Guidance for Everyone (the task detail screens exist there only). */
export const tasksStore = stores.career.actions;

/** The milestones, people, sample tasks and copy of the project of the page. */
export function useTasksData() {
  return tasksDataFor(useProject().key);
}
