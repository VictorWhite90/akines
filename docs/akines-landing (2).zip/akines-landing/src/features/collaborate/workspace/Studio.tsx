// Studio page, removed 5 Nov 2026 (Tasks, Conversations, Files and Workspace cover it). Commented out, not deleted. Figma: parked on the TRASH page.
// To bring it back: remove the leading "// " of every commented line below.
export {};

// 'use client';
//
// import './workspace.css';
// import { useEffect, useRef, useState, type FormEvent } from 'react';
// import { Link, useNav, usePath } from '@/lib/nav';
// import { asset } from '@/lib/assets';
// import { Button, Chip, EmptyState, Field, Modal, TextArea, TextInput, toast } from '@/ui';
// import {
//   CANVAS_FILTERS,
//   FILTER_TYPE,
//   HISTORY,
//   PATHS,
//   PRESENCE_TEXT,
//   WORK_DOC,
//   WORK_SCREENS,
//   WORK_TYPES,
//   type CanvasFilter,
//   type CanvasItem,
//   type StudioWork,
//   type WorkType,
// } from './data';
// import { useWorkspace, workspace } from './store';
// import { canvasStore, useAddedCanvas } from './canvas-store';
// import { STUDIO_DATA, studioPaths } from './art-studio-data';
// import { useProject } from './project';
// import { WORK_JOURNEY, WORK_QUESTIONS, type CanvasAddType, type WorkNote } from '../project-header/data';
// import { ActionButton, ArrowUpRight, Av, Availability, BackLink, Band, CardLink, Ctx, CtxItem, Dot, Facts, MilestoneCard, Over, PageHead, PeopleRows, SectionHeader, UpcomingSession, WorkRow, WorkspaceFrame, countWord, cx } from './parts';
//
// /**
//  * 12.12 Studio: Studio, Empty, Shared canvas, Work detail (and its two note variants), Modal: Create new work, Modal: Request changes,
//  * Modal: Add to canvas, and the toasts Work created, Changes requested, Work approved and Added to canvas.
//  */
//
// /**
//  * Career Guidance for Everyone and Adire Stories share these components. The Studio data, the pages of the Studio and the stores of the
//  * work and of the canvas follow the project of the path (see project.ts and art-studio-data.ts). The work detail pages, the Milestone
//  * detail and the Empty state are Career only, so the Adire Studio has no link to them.
//  */
// function useStudio() {
//   const { key, root } = useProject();
//   return { key, data: STUDIO_DATA[key], paths: studioPaths(root) };
// }
//
// const TOAST_MS = 2500;
// /** The toast of a "state-" frame stays longer so it can be looked at (same as Conversations). */
// const STATE_TOAST_MS = 8000;
//
// /* ------------------------------------------------------------------ Modal: Create new work */
//
// function CreateWorkModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated?: () => void }) {
//   const { key, data } = useStudio();
//   const [type, setType] = useState<WorkType>('Idea');
//   const [title, setTitle] = useState(data.createTitle);
//   const [error, setError] = useState('');
//
//   // every opening starts again from the prefilled values
//   useEffect(() => {
//     if (open) {
//       setType('Idea');
//       setTitle(data.createTitle);
//       setError('');
//     }
//   }, [open, data.createTitle]);
//
//   const create = (e?: FormEvent) => {
//     e?.preventDefault();
//     const name = title.trim();
//     if (!name) {
//       setError('Give your work a title to continue.');
//       return;
//     }
//     const id = `new-${Date.now()}`;
//     workspace.addWork({ id, title: name, kind: type, status: 'In progress', member: 'Kemi Adeyemi', updated: 'Updated just now', action: 'Open work' }, key);
//     onClose();
//     onCreated?.();
//     toast.show({ message: 'Work created. Your team can see it.', actionLabel: 'Undo', duration: TOAST_MS, onAction: () => workspace.removeWork(id, key) });
//   };
//
//   return (
//     <Modal
//       open={open}
//       onClose={onClose}
//       width={640}
//       eyebrow="CREATE NEW WORK"
//       title="What are you starting?"
//       description="Start with an idea, a draft or a shared question. Your team will see it in the Studio."
//       footer={
//         <>
//           <Button type="submit" form="cw-create-form">
//             Create work
//           </Button>
//           <CardLink onClick={onClose}>Cancel</CardLink>
//         </>
//       }
//     >
//       <form id="cw-create-form" className="cw-form" onSubmit={create} noValidate>
//         <div className="cw-form__group" role="group" aria-labelledby="cw-type-label">
//           <span className="cw-form__label" id="cw-type-label">
//             Type
//           </span>
//           <div className="cw-chips">
//             {WORK_TYPES.map((t) => (
//               <Chip key={t} selected={type === t} onClick={() => setType(t)}>
//                 {t}
//               </Chip>
//             ))}
//           </div>
//         </div>
//         <Field label="Title" hint="A few words are enough." error={error || undefined}>
//           <TextInput
//             value={title}
//             placeholder="Give it a short name"
//             onChange={(e) => {
//               setTitle(e.target.value);
//               if (error) setError('');
//             }}
//           />
//         </Field>
//       </form>
//     </Modal>
//   );
// }
//
// /* ------------------------------------------------------------------ Modal: Add to canvas */
//
// function AddToCanvasModal({ open, onClose, onAdded }: { open: boolean; onClose: () => void; onAdded: () => void }) {
//   const nav = useNav();
//   const { key, data, paths } = useStudio();
//   const copy = data.addToCanvas;
//   const [type, setType] = useState<CanvasAddType>('Note');
//   const [title, setTitle] = useState('');
//   const [error, setError] = useState('');
//
//   // every opening starts empty (Figma: the Title field shows its placeholder)
//   useEffect(() => {
//     if (open) {
//       setType('Note');
//       setTitle('');
//       setError('');
//     }
//   }, [open]);
//
//   const add = (e?: FormEvent) => {
//     e?.preventDefault();
//     const name = title.trim();
//     if (!name) {
//       setError('Give it a title to continue.');
//       return;
//     }
//     const id = `added-${Date.now()}`;
//     canvasStore.add(key, { id, type, title: name, body: '', initials: 'KA', name: 'Kemi Adeyemi', time: 'Just now', comments: 'No comments', link: type === 'Reference' });
//     onClose();
//     onAdded();
//     // Undo takes the card away again and goes to the Studio (Figma: Undo navigates to the Studio)
//     toast.show({
//       message: copy.done,
//       actionLabel: 'Undo',
//       duration: TOAST_MS,
//       onAction: () => {
//         canvasStore.remove(key, id);
//         nav.push(paths.studio);
//       },
//     });
//   };
//
//   return (
//     <Modal
//       open={open}
//       onClose={onClose}
//       width={640}
//       eyebrow={copy.eyebrow}
//       title={copy.title}
//       description={copy.description}
//       footer={
//         <>
//           <Button type="submit" form="cw-add-canvas-form">
//             {copy.confirm}
//           </Button>
//           <CardLink onClick={onClose}>{copy.cancel}</CardLink>
//         </>
//       }
//     >
//       <form id="cw-add-canvas-form" className="cw-form" onSubmit={add} noValidate>
//         <div className="cw-form__group" role="group" aria-labelledby="cw-canvas-type-label">
//           <span className="cw-form__label" id="cw-canvas-type-label">
//             Type
//           </span>
//           <div className="cw-chips">
//             {copy.types.map((t) => (
//               <Chip key={t} selected={type === t} onClick={() => setType(t)}>
//                 {t}
//               </Chip>
//             ))}
//           </div>
//         </div>
//         <Field label={copy.titleField.label} hint={copy.titleField.hint} error={error || undefined}>
//           <TextInput
//             value={title}
//             placeholder={copy.titleField.placeholder}
//             onChange={(e) => {
//               setTitle(e.target.value);
//               if (error) setError('');
//             }}
//           />
//         </Field>
//       </form>
//     </Modal>
//   );
// }
//
// /* ------------------------------------------------------------------ canvas cards */
//
// function CanvasCard({ item, href }: { item: CanvasItem; href?: string }) {
//   const { key } = useProject();
//   const body = (
//     <>
//       {item.type === 'Image' && item.id === 'classroom' ? (
//         <div className="cw-cc__media">
//           {/* Figma 17374:26028 "Canvas / Classroom visit, Kaduna", layer Media 17373:14182 (cropped from the card screenshot). On Adire Stories the layer holds the photo of cloth drying on a line after the indigo dip. */}
//           <img
//             src={asset(key === 'adire' ? '/images/app/feed/post1-a.jpg' : '/images/app/collab-workspace/classroom-visit.jpg')}
//             alt=""
//             loading="lazy"
//             decoding="async"
//           />
//         </div>
//       ) : null}
//       <div className="cw-cc__content">
//         <Over>{item.type.toUpperCase()}</Over>
//         <h3 className="cw-cc__title">{item.title}</h3>
//         {item.body ? <p className="cw-cc__body">{item.body}</p> : null}
//         {item.link ? (
//           <span className="cw-cc__source">
//             <ArrowUpRight />
//             Shared link
//           </span>
//         ) : null}
//         {item.needsReview ? (
//           <span className="cw-cc__review">
//             <Dot size={7} />
//             Needs review
//           </span>
//         ) : null}
//       </div>
//       <div className="cw-cc__foot">
//         <span className="cw-cc__who">
//           <Av initials={item.initials} size={28} tone="muted" />
//           <span className="cw-cc__name">{item.name}</span>
//           <span className="cw-cc__time">{item.time}</span>
//         </span>
//         <span className="cw-cc__count">{item.comments}</span>
//       </div>
//     </>
//   );
//   return href ? (
//     <Link href={href} className="cw-cc">
//       {body}
//     </Link>
//   ) : (
//     <article className="cw-cc">{body}</article>
//   );
// }
//
// /* ------------------------------------------------------------------ Studio */
//
// /** "Review work" goes to the work detail on Career. Adire Stories has no work detail page, so there it has no destination. */
// function StudioContext() {
//   const { data } = useStudio();
//   return (
//     <>
//       <Availability label="WORKING NOW" only={['AO', 'TA']} />
//       <Ctx label="NEEDS YOUR REVIEW" rule={false}>
//         <CtxItem title={data.review.title} status={data.review.status}>
//           <CardLink href={data.review.href} arrow>
//             Review work
//           </CardLink>
//         </CtxItem>
//       </Ctx>
//       <UpcomingSession rule />
//     </>
//   );
// }
//
// const rowOf = (w: StudioWork, milestone: string) => ({ title: w.title, next: `${w.kind}. For ${milestone}.`, status: w.status, member: w.member, phase: w.updated, action: w.action, href: w.href });
//
// export function Studio() {
//   const { key, data, paths } = useStudio();
//   const works = useWorkspace((s) => s.works[key]);
//   const [creating, setCreating] = useState(false);
//   const n = works.length;
//   const m = data.milestone;
//   const byId = (id: string) => data.canvas.find((c) => c.id === id)!;
//   return (
//     <WorkspaceFrame active="studio" context={<StudioContext />}>
//       <PageHead label="STUDIO" title="The studio." lead="A shared space for the work in progress. Everyone on the team can see it, add to it and comment on it.">
//         <Facts
//           compact
//           items={[
//             { label: 'CURRENT MILESTONE', value: m.title },
//             { label: 'ACTIVE WORK', value: `${n} ${n === 1 ? 'piece' : 'pieces'}` },
//             { label: 'TEAM', value: '4 members' },
//           ]}
//         />
//         <div className="cw-actions cw-actions--btns">
//           <ActionButton onClick={() => setCreating(true)}>Create new work</ActionButton>
//           <ActionButton variant="secondary" href={paths.canvas}>
//             Open shared canvas
//           </ActionButton>
//           <CardLink href={m.href} arrow>
//             View milestone
//           </CardLink>
//         </div>
//       </PageHead>
//
//       <Band label="SHARED CANVAS" title="Ideas, drafts and references." support="Anything the team is thinking about, in one shared space.">
//         <div className="cw-preview">
//           <CanvasCard item={byId('classroom')} href={paths.canvas} />
//           <CanvasCard item={byId('questions')} href={paths.canvas} />
//         </div>
//         <div>
//           <CardLink href={paths.canvas} arrow>
//             Open shared canvas
//           </CardLink>
//         </div>
//       </Band>
//
//       <Band label="CURRENT WORK" title="What the team is making." support={`${countWord(n)} ${n === 1 ? 'piece' : 'pieces'} of work ${n === 1 ? 'is' : 'are'} in progress.`}>
//         <div className="cw-rows">
//           {works.map((w) => (
//             <WorkRow key={w.id} item={rowOf(w, m.title)} />
//           ))}
//         </div>
//         <div>
//           <CardLink arrow onClick={() => setCreating(true)}>
//             Create new work
//           </CardLink>
//         </div>
//       </Band>
//
//       <Band label="MILESTONE PROGRESS" title="Where the milestone stands." support="The work above is connected to this milestone.">
//         <MilestoneCard m={m} />
//         <Facts
//           compact
//           bare
//           items={[
//             { label: 'COMPLETION CRITERIA', value: '1 of 3 met' },
//             { label: 'OUTSTANDING ITEMS', value: '2 items' },
//             { label: 'RELATED WORK', value: `${n} ${n === 1 ? 'piece' : 'pieces'}` },
//           ]}
//         />
//       </Band>
//
//       <CreateWorkModal open={creating} onClose={() => setCreating(false)} />
//     </WorkspaceFrame>
//   );
// }
//
// export function StudioEmpty() {
//   const nav = useNav();
//   const { paths } = useStudio();
//   const [creating, setCreating] = useState(false);
//   return (
//     <WorkspaceFrame active="studio" context={<Availability />}>
//       <PageHead label="STUDIO" title="The studio." lead="A shared space for the work in progress. Everyone on the team can see it, add to it and comment on it." />
//       <div data-m="up">
//         <EmptyState className="cw-empty" title="A blank space for something meaningful." text="Start with an idea, a draft or a shared question." action={<ActionButton onClick={() => setCreating(true)} arrow>Create new work</ActionButton>} />
//       </div>
//       {/* Create work goes to the Studio (Figma): the new piece is in the list there */}
//       <CreateWorkModal open={creating} onClose={() => setCreating(false)} onCreated={() => nav.push(paths.studio)} />
//     </WorkspaceFrame>
//   );
// }
//
// /* ------------------------------------------------------------------ Shared canvas */
//
// function CanvasScreen({ addOpen, addedToast }: { addOpen?: boolean; addedToast?: boolean }) {
//   const nav = useNav();
//   const path = usePath();
//   const { key, data, paths } = useStudio();
//   const added = useAddedCanvas(key);
//   const [filter, setFilter] = useState<CanvasFilter>('All');
//   const [adding, setAdding] = useState(Boolean(addOpen));
//   const byId = (id: string) => data.canvas.find((c) => c.id === id)!;
//   const shown = filter === 'All' ? [...added, ...data.canvas] : [...added, ...data.canvas].filter((c) => c.type === FILTER_TYPE[filter]);
//   // all cards keep the two columns of the design; new cards go on top, one per column in turn. A filter deals the cards out again, left to right
//   const columns: CanvasItem[][] = filter === 'All' ? data.columns.map((ids) => ids.map(byId)) : [shown.filter((_, i) => i % 2 === 0), shown.filter((_, i) => i % 2 === 1)];
//   if (filter === 'All') for (let i = added.length - 1; i >= 0; i--) columns[i % 2].unshift(added[i]);
//
//   // the "state-added-to-canvas" frame: the canvas with the toast already showing
//   useEffect(() => {
//     if (addedToast) toast.show({ message: data.addToCanvas.done, actionLabel: 'Undo', duration: STATE_TOAST_MS, onAction: () => nav.push(paths.studio) });
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [addedToast]);
//
//   return (
//     <WorkspaceFrame active="studio" context={<StudioContext />}>
//       <PageHead back={<BackLink href={paths.studio}>Back to studio</BackLink>} label="SHARED CANVAS" title="The shared canvas." lead="Ideas, drafts and references from the whole team. Every addition carries the name of the person who made it.">
//         <div>
//           <ActionButton onClick={() => setAdding(true)}>Add to canvas</ActionButton>
//         </div>
//       </PageHead>
//
//       <div className="cw-filters" role="group" aria-label="Filter the canvas" data-m="up">
//         {CANVAS_FILTERS.map((f) => (
//           <Chip key={f} selected={filter === f} onClick={() => setFilter(f)}>
//             {f}
//           </Chip>
//         ))}
//       </div>
//
//       <div className="cw-canvas" data-m="stagger" aria-live="polite">
//         {columns.map((col, i) => (
//           <div className="cw-canvas__col" key={i}>
//             {col.map((item) => (
//               <CanvasCard key={item.id} item={item} href={item.href} />
//             ))}
//           </div>
//         ))}
//       </div>
//
//       {/* Add to canvas goes to the canvas (from any other frame too) and shows the toast */}
//       <AddToCanvasModal open={adding} onClose={() => setAdding(false)} onAdded={() => path !== paths.canvas && nav.push(paths.canvas)} />
//     </WorkspaceFrame>
//   );
// }
//
// export const Canvas = () => <CanvasScreen />;
// /** Frame "Modal: Add to canvas": the shared canvas with the modal open. */
// export const CanvasAddModal = () => <CanvasScreen addOpen />;
// /** Frame "Toast: Added to canvas": the shared canvas with the toast showing. */
// export const CanvasAdded = () => <CanvasScreen addedToast />;
//
// /* ------------------------------------------------------------------ Work detail */
//
// const REQUEST_TEXT = 'The second screen asks two things at once. Could we keep the first question on its own?';
//
// function RequestChangesModal({ open, onClose }: { open: boolean; onClose: () => void }) {
//   const [text, setText] = useState(REQUEST_TEXT);
//   const [error, setError] = useState('');
//
//   useEffect(() => {
//     if (open) {
//       setText(REQUEST_TEXT);
//       setError('');
//     }
//   }, [open]);
//
//   const send = (e?: FormEvent) => {
//     e?.preventDefault();
//     if (!text.trim()) {
//       setError('Write a short message to continue.');
//       return;
//     }
//     onClose();
//     toast.show({ message: 'Changes requested from Adaeze.', actionLabel: 'Undo', duration: TOAST_MS });
//   };
//
//   return (
//     <Modal
//       open={open}
//       onClose={onClose}
//       width={640}
//       eyebrow="REQUEST CHANGES"
//       title="Student onboarding draft"
//       description="Tell Adaeze what to change. She will be notified and can reply here."
//       footer={
//         <>
//           <Button type="submit" form="cw-request-form">
//             Send request
//           </Button>
//           <CardLink onClick={onClose}>Cancel</CardLink>
//         </>
//       }
//     >
//       <form id="cw-request-form" onSubmit={send} noValidate>
//         <Field label="What needs to change" hint="Adaeze will see your name with the request." error={error || undefined}>
//           <TextArea
//             rows={3}
//             className="cw-ta"
//             value={text}
//             placeholder="Describe the changes you would like."
//             onChange={(e) => {
//               setText(e.target.value);
//               if (error) setError('');
//             }}
//           />
//         </Field>
//       </form>
//     </Modal>
//   );
// }
//
// function WorkContext() {
//   return (
//     <>
//       <Availability label="CONTRIBUTORS" only={['AO', 'TA']} />
//       <Ctx label="RELATED MILESTONE">
//         <p className="cw-session__title">First Student Experience</p>
//         <p className="cw-ctx__line">In progress, due 28 November</p>
//         <p className="cw-ctx__line">Responsible: Kemi Adeyemi</p>
//       </Ctx>
//       <Ctx label="RELATED DECISION">
//         <CtxItem title="Choose the onboarding approach" status="Awaiting acknowledgement">
//           <CardLink arrow>Review decision</CardLink>
//         </CtxItem>
//       </Ctx>
//       <Ctx label="RELATED CONVERSATION">
//         <CtxItem title="Onboarding flow" status="5 messages, latest at 10:48">
//           <CardLink href={PATHS.conversations} arrow>
//             Open conversation
//           </CardLink>
//         </CtxItem>
//       </Ctx>
//     </>
//   );
// }
//
// function Entry({ initials, name, time, kind, text, review }: { initials: string; name: string; time: string; kind: string; text: string; /** The amber dot and style of a Review entry; the note pages show it on a CONTRIBUTION label (Figma). */ review?: boolean }) {
//   const marked = review ?? kind === 'REVIEW';
//   return (
//     <li className="cw-entry">
//       <Av initials={initials} size={40} tone="muted" />
//       <div className="cw-entry__body">
//         <div className="cw-entry__head">
//           <span className="cw-entry__name">{name}</span>
//           <span className="cw-entry__time">{time}</span>
//           <span className={cx('cw-entry__kind', marked && 'cw-entry__kind--review')}>
//             {marked ? <Dot size={6} /> : null}
//             {kind}
//           </span>
//         </div>
//         <p className="cw-entry__text">{text}</p>
//       </div>
//     </li>
//   );
// }
//
// export function WorkDetail() {
//   const nav = useNav();
//   const comments = useWorkspace((s) => s.comments);
//   const [requesting, setRequesting] = useState(false);
//   const [draft, setDraft] = useState('I can look at the third screen tomorrow morning.');
//   const [error, setError] = useState('');
//   const field = useRef<HTMLInputElement>(null);
//   const c = comments.length;
//
//   const approve = () => {
//     nav.push(PATHS.studio);
//     toast.show({ message: 'Work approved.', actionLabel: 'Undo', duration: TOAST_MS, onAction: () => nav.push(PATHS.work) });
//   };
//
//   const post = (e?: FormEvent) => {
//     e?.preventDefault();
//     const text = draft.trim();
//     if (!text) {
//       setError('Write a comment to continue.');
//       return;
//     }
//     workspace.addComment({ initials: 'KA', name: 'Kemi Adeyemi', time: 'Just now', text });
//     setDraft('');
//     setError('');
//     field.current?.focus();
//   };
//
//   return (
//     <WorkspaceFrame active="studio" context={<WorkContext />}>
//       <PageHead back={<BackLink href={PATHS.studio}>Back to studio</BackLink>} label="DRAFT" title="Student onboarding draft">
//         <Facts
//           compact
//           narrow
//           items={[
//             { label: 'STATUS', value: 'Needs your review' },
//             { label: 'RESPONSIBLE', value: 'Adaeze Okoye' },
//             { label: 'LAST UPDATE', value: '2 hours ago' },
//             { label: 'RELATED MILESTONE', value: 'First Student Experience' },
//           ]}
//         />
//         <div className="cw-actions cw-actions--btns cw-actions--g16">
//           <ActionButton onClick={approve}>Approve work</ActionButton>
//           <ActionButton variant="secondary" onClick={() => setRequesting(true)}>
//             Request changes
//           </ActionButton>
//         </div>
//       </PageHead>
//
//       <Band label="THE WORK" title="Onboarding, screen by screen." support="Version 4. Last edited by Adaeze Okoye.">
//         <article className="cw-doc">
//           <h3 className="cw-doc__title">{WORK_DOC.title}</h3>
//           {WORK_DOC.paragraphs.map((p) => (
//             <p key={p} className="cw-doc__p">
//               {p}
//             </p>
//           ))}
//           <ol className="cw-screens">
//             {WORK_SCREENS.map((s, i) => (
//               <li key={s}>
//                 <span className="cw-screens__n">{String(i + 1).padStart(2, '0')}</span>
//                 <span>{s}</span>
//               </li>
//             ))}
//           </ol>
//         </article>
//       </Band>
//
//       <section className="cw-band" data-m="up">
//         <SectionHeader label="COMMENTS" title="What the team said." support={`${countWord(c)} ${c === 1 ? 'comment' : 'comments'} on this draft.`} />
//         <ul className="cw-entries">
//           {comments.map((e, i) => (
//             <Entry key={`${e.name}-${i}`} initials={e.initials} name={e.name} time={e.time} kind="COMMENT" text={e.text} />
//           ))}
//         </ul>
//         <form className="cw-addcomment" onSubmit={post} noValidate>
//           <Field label="Add a comment" hint="Your name appears with the comment." error={error || undefined}>
//             <TextInput
//               ref={field}
//               value={draft}
//               placeholder="Write a comment"
//               onChange={(e) => {
//                 setDraft(e.target.value);
//                 if (error) setError('');
//               }}
//             />
//           </Field>
//           <div>
//             <Button type="submit" variant="secondary">
//               Post comment
//             </Button>
//           </div>
//         </form>
//       </section>
//
//       <Band label="CONTRIBUTION HISTORY" title="Who has shaped this work." support="Every change keeps the name of the person who made it.">
//         <ul className="cw-entries">
//           {HISTORY.map((h) => (
//             <Entry key={h.name} initials={h.initials} name={h.name} time={h.time} kind={h.kind.toUpperCase()} text={h.text} />
//           ))}
//         </ul>
//       </Band>
//
//       <RequestChangesModal open={requesting} onClose={() => setRequesting(false)} />
//     </WorkspaceFrame>
//   );
// }
//
// /* ------------------------------------------------------------------ Work detail, note variants (Map the student journey, Questions students ask about careers) */
//
// const PRESENCE_TONE = { available: 'green', working: 'accent', away: 'gray' } as const;
//
// function NoteContext({ note }: { note: WorkNote }) {
//   return (
//     <>
//       <Ctx label="CONTRIBUTORS">
//         <PeopleRows people={note.contributors.map((c) => ({ initials: c.initials, name: c.name, text: PRESENCE_TEXT[c.presence], tone: PRESENCE_TONE[c.presence] }))} />
//       </Ctx>
//       <Ctx label="RELATED MILESTONE">
//         <p className="cw-session__title">First Student Experience</p>
//         <p className="cw-ctx__line">In progress, due 28 November</p>
//         <p className="cw-ctx__line">Responsible: Kemi Adeyemi</p>
//       </Ctx>
//       <Ctx label="RELATED DECISION">
//         {/* "Review decision" has no destination on these two screens in the design */}
//         <CtxItem title="Choose the onboarding approach" status="Awaiting acknowledgement">
//           <CardLink arrow>Review decision</CardLink>
//         </CtxItem>
//       </Ctx>
//       <Ctx label="RELATED CONVERSATION">
//         <CtxItem title={note.conversation.title} status={note.conversation.status}>
//           <CardLink href={PATHS.conversations} arrow>
//             Open conversation
//           </CardLink>
//         </CtxItem>
//       </Ctx>
//     </>
//   );
// }
//
// /** The two notes of the Studio list. They have no Approve or Request changes buttons and start with an empty comment field. */
// function NotePage({ note }: { note: WorkNote }) {
//   const [comments, setComments] = useState(note.comments);
//   const [draft, setDraft] = useState('');
//   const [error, setError] = useState('');
//   const field = useRef<HTMLInputElement>(null);
//   const c = comments.length;
//
//   const post = (e?: FormEvent) => {
//     e?.preventDefault();
//     const text = draft.trim();
//     if (!text) {
//       setError('Write a comment to continue.');
//       return;
//     }
//     setComments((list) => [...list, { initials: 'KA', name: 'Kemi Adeyemi', time: 'Just now', text }]);
//     setDraft('');
//     setError('');
//     field.current?.focus();
//   };
//
//   return (
//     <WorkspaceFrame active="studio" context={<NoteContext note={note} />}>
//       <PageHead back={<BackLink href={PATHS.studio}>Back to studio</BackLink>} label={note.label} title={note.title}>
//         <Facts compact narrow items={note.facts} />
//       </PageHead>
//
//       <Band label="THE WORK" title={note.workTitle} support={note.workSupport}>
//         <article className="cw-doc">
//           <h3 className="cw-doc__title">{note.doc.title}</h3>
//           {note.doc.paragraphs.map((p) => (
//             <p key={p} className="cw-doc__p">
//               {p}
//             </p>
//           ))}
//           <ol className="cw-screens">
//             {note.doc.screens.map((s, i) => (
//               <li key={s}>
//                 <span className="cw-screens__n">{String(i + 1).padStart(2, '0')}</span>
//                 <span>{s}</span>
//               </li>
//             ))}
//           </ol>
//         </article>
//       </Band>
//
//       <section className="cw-band" data-m="up">
//         <SectionHeader label="COMMENTS" title="What the team said." support={`${countWord(c)} ${c === 1 ? 'comment' : 'comments'} on this note.`} />
//         <ul className="cw-entries">
//           {comments.map((e, i) => (
//             <Entry key={`${e.name}-${i}`} initials={e.initials} name={e.name} time={e.time} kind="COMMENT" text={e.text} />
//           ))}
//         </ul>
//         <form className="cw-addcomment" onSubmit={post} noValidate>
//           <Field label="Add a comment" hint="Your name appears with the comment." error={error || undefined}>
//             <TextInput
//               ref={field}
//               value={draft}
//               placeholder="Write a comment"
//               onChange={(e) => {
//                 setDraft(e.target.value);
//                 if (error) setError('');
//               }}
//             />
//           </Field>
//           <div>
//             <Button type="submit" variant="secondary">
//               Post comment
//             </Button>
//           </div>
//         </form>
//       </section>
//
//       <Band label="CONTRIBUTION HISTORY" title="Who has shaped this work." support="Every change keeps the name of the person who made it.">
//         <ul className="cw-entries">
//           {note.history.map((h, i) => (
//             <Entry key={`${h.name}-${i}`} initials={h.initials} name={h.name} time={h.time} kind="CONTRIBUTION" text={h.text} review={i === 0} />
//           ))}
//         </ul>
//       </Band>
//     </WorkspaceFrame>
//   );
// }
//
// /** Frame "Work detail (Map the student journey)". */
// export const WorkDetailJourney = () => <NotePage note={WORK_JOURNEY} />;
// /** Frame "Work detail (Questions students ask about careers)". */
// export const WorkDetailQuestions = () => <NotePage note={WORK_QUESTIONS} />;
