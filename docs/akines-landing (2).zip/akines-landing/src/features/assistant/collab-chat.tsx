'use client';

/**
 * Create AI explores collaborators and opens a project inside the thread (Figma section 16, journeys 16.4 and 16.5).
 * Both are two step machines in the style of 16.3 (project-chat.tsx): the frame shows the person's last answer and the
 * assistant's current message, nothing older. The state lives in `useCollabChat`, called by CreateAI, so closing and
 * reopening the panel keeps the conversation and starting another journey replaces it.
 *
 *   16.4 Explore collaborators   ask   17568:63093  "Sure. What kind of help are you looking for?" plus the seven need chips
 *                                ready 17568:63820  "Got it. I found people who ..." plus See my matches (12.3 B2 Matching context)
 *   16.5 Open a project          ask   17568:64515  "Which project would you like to open?" plus the project chips
 *                                ready 17568:65222  "Here it is. Tap to open it." plus Open project (12.11 Project overview)
 *
 * Entry: the buttons "Explore collaborators" and "Open a project" under the Ask anything answer (16.2), see knowledge.ts.
 * Lists: the seven needs are those of the Start a project flow (flow-data.ts), the projects are the sample projects of
 * My projects (workspace/data.ts). The Figma frame shows three project chips, so only the first three are offered.
 */
import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowUp } from 'lucide-react';
import './collab-chat.css';
import { Button, IconButton } from '@/ui';
import { useNav } from '@/lib/nav';
import { NEEDS, PATHS } from '@/features/collaborate/start/flow-data';
import { PROJECTS } from '@/features/collaborate/workspace/data';

export type CollabJourney = 'explore' | 'open';
type CollabStep = 'ask' | 'ready';
type View = { step: CollabStep; you: string; pick: string | null };

/**
 * The buttons "Explore collaborators" and "Open a project" of the Ask anything answer carry these two paths (the routes
 * of the pages they stand for, like START_PATH for Start a project). CreateAI opens the chat journey instead of the page.
 */
export const EXPLORE_PATH: string = PATHS.collaborators;
export const OPEN_PATH: string = PATHS.myProjects;

/** The person's first message, the label of the button that started the journey (Figma "Message / you" of the entry frames). */
const ENTRY: Record<CollabJourney, string> = { explore: 'Explore collaborators', open: 'Open a project' };

/** Figma 16.5 shows three project chips: Career Guidance for Everyone, Community Learning Initiative, Mentorship Circle. */
const OFFERED = PROJECTS.slice(0, 3);

/**
 * "Got it. I found people who could offer mentorship and fit your project." is the sentence of the Figma frame. Every chip
 * leads to that one frame, so the other six chips use the same sentence with their own words in place of "could offer mentorship".
 */
const OFFER: Record<string, string> = {
  collaborators: 'could work with you',
  mentorship: 'could offer mentorship',
  technical: 'could offer technical expertise',
  research: 'could offer research support',
  funding: 'could offer funding',
  distribution: 'could help with distribution',
  customers: 'could be customers or users',
};

export type CollabChat = ReturnType<typeof useCollabChat>;

export function useCollabChat() {
  const [journey, setJourney] = useState<CollabJourney | null>(null);
  const [view, setView] = useState<View>({ step: 'ask', you: ENTRY.explore, pick: null });
  const [draft, setDraft] = useState('');

  const begin = useCallback((j: CollabJourney) => {
    setView({ step: 'ask', you: ENTRY[j], pick: null });
    setDraft('');
    setJourney(j);
  }, []);
  const stop = useCallback(() => setJourney(null), []);
  const choose = useCallback((id: string, title: string) => setView({ step: 'ready', you: title, pick: id }), []);

  return { active: journey !== null, journey, view, begin, stop, choose, draft, setDraft };
}

/* ------------------------------------------------------------------ pieces */

/** Figma "Create AI / Option chips": plain pills, 44 high, one tap picks the answer. */
function Pills({ label, items, onPick }: { label: string; items: { id: string; title: string }[]; onPick: (id: string, title: string) => void }) {
  return (
    <div className="cai-cpills" role="group" aria-label={label}>
      {items.map((it) => (
        <button key={it.id} type="button" className="cai-cpill" onClick={() => onPick(it.id, it.title)}>
          {it.title}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ view */

type ViewProps = {
  chat: CollabChat;
  /** closes the panel (before a navigation) */
  hide: () => void;
  /** a free question typed in the field ("Ask Create AI anything"): the thread goes back to the open chat and answers it */
  onAsk: (text: string) => void;
};

export function CollabChatView({ chat, hide, onAsk }: ViewProps) {
  const nav = useNav();
  const { journey, view, choose, draft, setDraft } = chat;
  const { step, you, pick } = view;
  const bodyRef = useRef<HTMLDivElement>(null);

  // every step is a fresh view: back to the top
  useEffect(() => {
    bodyRef.current?.scrollTo({ top: 0, behavior: 'auto' });
  }, [journey, step]);

  const leave = (path: string) => {
    hide();
    nav.push(path);
  };

  const canSend = draft.trim().length > 0;
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setDraft('');
    onAsk(text);
  };

  let assistant: ReactNode = null;
  if (journey === 'explore') {
    if (step === 'ask') {
      assistant = (
        <>
          <p className="cai-ctext">Sure. What kind of help are you looking for?</p>
          <Pills label="What kind of help are you looking for?" items={NEEDS} onPick={choose} />
        </>
      );
    } else {
      const need = NEEDS.find((n) => n.id === pick);
      const offer = (pick && OFFER[pick]) || `could help with ${(need?.title ?? 'this').toLowerCase()}`;
      assistant = (
        <>
          <p className="cai-ctext">Got it. I found people who {offer} and fit your project.</p>
          <div className="cai-cgo">
            <Button size="sm" arrow="right" onClick={() => leave(PATHS.matching)}>
              See my matches
            </Button>
          </div>
        </>
      );
    }
  } else if (journey === 'open') {
    if (step === 'ask') {
      assistant = (
        <>
          <p className="cai-ctext">Which project would you like to open?</p>
          <Pills label="Which project would you like to open?" items={OFFERED.map((p) => ({ id: p.slug, title: p.title }))} onPick={choose} />
        </>
      );
    } else {
      // Figma wires every chip to the Career Guidance for Everyone frame, whose button opens 12.11 Project overview.
      // Adire Stories would open its own Workspace; the two projects without a page open that same Overview, so the button never dead ends.
      const project = OFFERED.find((p) => p.slug === pick);
      assistant = (
        <>
          <p className="cai-ctext">Here it is. Tap to open it.</p>
          <div className="cai-cgo">
            <Button size="sm" arrow="up-right" onClick={() => leave(project?.href ?? PATHS.project)}>
              Open project
            </Button>
          </div>
        </>
      );
    }
  }

  return (
    <>
      <div className="cai-body" ref={bodyRef} aria-live="polite">
        <div className="cai-cmsg cai-cmsg--you" key={`you-${journey}-${step}`}>
          <p className="cai-cbubble">{you}</p>
        </div>
        <div className="cai-cmsg" key={`bot-${journey}-${step}`}>
          {assistant}
        </div>
      </div>

      <form className="cai-form" onSubmit={submit}>
        <label className="cai-field">
          <span className="sr-only">Message Create AI</span>
          <input
            className="cai-input"
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Ask Create AI anything"
            autoComplete="off"
            enterKeyHint="send"
            maxLength={600}
          />
          <IconButton label="Send" size="sm" variant="solid" type="submit" disabled={!canSend}>
            <ArrowUp strokeWidth={1.6} />
          </IconButton>
        </label>
        <p className="cai-foot">Create AI can get things wrong. Please check anything important.</p>
      </form>
    </>
  );
}
