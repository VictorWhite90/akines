/** Image URL helper for Discover. Plain module: the preview build swaps @/lib/assets for its relative-path twin. */
import { asset } from '@/lib/assets';
import type { DiscoverImg } from './data';

export const src = (img: DiscoverImg) => asset(`/images/app/${img}.jpg`);
