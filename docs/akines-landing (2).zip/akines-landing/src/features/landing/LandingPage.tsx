import { Community } from '@/components/Community';
import { Experiences } from '@/components/Experiences';
import { FinalCta } from '@/components/FinalCta';
import { Footer } from '@/components/Footer';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { Intention } from '@/components/Intention';
import { Motion } from '@/components/Motion';
import { Rhythm } from '@/components/Rhythm';
import { Trust } from '@/components/Trust';
import { SignInPanelHost } from '@/features/auth/SignInPanel';

/** The editorial landing page. The sign-in panel slides out over it (opened by any Sign in button). */
export function LandingPage() {
  return (
    <>
      <a className="skip-link" href="#intention">
        Skip to content
      </a>
      <Header />
      <main>
        <Hero />
        <Intention />
        <Rhythm />
        <Experiences />
        <Trust />
        <Community />
        <FinalCta />
      </main>
      <Footer />
      <SignInPanelHost />
      <Motion />
    </>
  );
}
