import type { RouteDef } from '@/routes.types';
import { JoinPage } from './JoinPage';
import { JoinStateFrame } from './JoinStates';
import { SignInStateFrame } from './SignInStates';
import { JOIN_FRAMES } from './join-frames';
import { SIGN_IN_FRAMES } from './signin-frames';

/**
 * "/join" is the whole create-account flow (five steps, one route). The static "/join/state-*" and "/sign-in/state-*"
 * routes open the same screens in the state of a Figma frame; every one of them is also reachable by its trigger.
 * The sign-in panel itself is not a route: it opens over any page through panel-store.ts ("/sign-in" shows it over the landing page).
 */
export const routes: RouteDef[] = [
  { path: '/join', title: 'Join Akines', shell: 'site', component: JoinPage },
  ...JOIN_FRAMES.map((f): RouteDef => ({ path: `/join/state-${f.slug}`, title: f.title, shell: 'site', component: JoinStateFrame })),
  ...SIGN_IN_FRAMES.map((f): RouteDef => ({ path: `/sign-in/state-${f.slug}`, title: 'Sign in', shell: 'site', component: SignInStateFrame })),
];
