/**
 * Entry of the single-file preview artifact (built by scripts/build-preview.mjs). The same screens as the Next.js app,
 * routed by the address hash (see src/lib/nav.hash.tsx). CSS is imported in the same order as src/app/layout.tsx.
 */
import '../styles/tokens.css';
import '../styles/app-tokens.css';
import '../styles/base.css';
import '../styles/header.css';
import '../styles/hero.css';
import '../styles/intention.css';
import '../styles/rhythm.css';
import '../styles/experiences.css';
import '../styles/trust.css';
import '../styles/closing.css';
import '../styles/menu.css';
import '../styles/motion.css';
import '../styles/notfound.css';
import '../styles/app-shell.css';
import '../styles/ui.css';
import '../features/assistant/assistant.css';

import { createRoot } from 'react-dom/client';
import { useEffect } from 'react';
import { RouteFrame } from '@/app-shell/RouteFrame';
import { findRoute, routes } from '@/routes';
import { registerPaths, usePath } from '@/lib/nav';
import { NotFoundView } from '@/features/landing/NotFoundView';
import { CreateAI } from '@/features/assistant/CreateAI';

registerPaths(routes.map((r) => r.path));
// Read by scripts/check-routes.mjs (visits every screen); harmless in the published page.
(window as unknown as { __AKINES_ROUTES__: string[] }).__AKINES_ROUTES__ = routes.map((r) => r.path);

function App() {
  const path = usePath();
  const route = findRoute(path);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [path]);
  if (!route) {
    return (
      <RouteFrame meta={{ path, title: 'Page not found', shell: 'bare' }}>
        <NotFoundView />
      </RouteFrame>
    );
  }
  const Screen = route.component;
  return (
    <RouteFrame meta={{ path: route.path, title: route.title, shell: route.shell, nav: route.nav, mobile: route.mobile }}>
      <Screen />
    </RouteFrame>
  );
}

createRoot(document.getElementById('root')!).render(
  <>
    <App />
    <CreateAI />
  </>,
);
