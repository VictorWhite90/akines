'use client';

import { useState } from 'react';
import { Avatar, Button, Field, TextArea, toast } from '@/ui';
import { asset } from '@/lib/assets';
import { BackLink, Heading, StatusPill } from './cc-ui';
import { PEOPLE, PERSON_COPY, PROJECT, R, personRoutes, requestRoute, type PersonId } from './data';
import { CcOverlays, type OverlayId } from './overlays';
import { ccStore } from './store';

/**
 * B9 Introduction request of Amina (Figma 17218:16571, route /collaborate/collaborators/request) and the requests of 12.28 to 12.30
 * (Kunle 17706:74647, Funmi 17706:75416, Chidi 17706:76185), route /collaborate/collaborators/<id>/request. Same screen, the name,
 * role, portrait and message come from the person.
 */
export function IntroRequestScreen({ id }: { id: PersonId }) {
  const [ov, setOv] = useState<OverlayId | null>(null);
  const copy = PERSON_COPY[id];
  const [message, setMessage] = useState(copy.requestMessage);
  const [error, setError] = useState(false);
  const person = PEOPLE[id];
  const routes = personRoutes(id);

  const send = () => {
    if (!message.trim()) {
      setError(true);
      return;
    }
    setOv('confirm');
  };
  const save = () => {
    const undo = ccStore.save(id);
    toast.show({ message: 'Saved to your collaborators.', actionLabel: 'Undo', onAction: undo });
  };

  return (
    <>
      <div className="cc-page cc-req">
        <div className="cc-req__col">
          <BackLink href={routes.profile}>Back to profile</BackLink>
          <Heading
            eyebrow="Make a connection"
            title="Start with a conversation."
            support="Introduce yourself, explain what you’re creating and tell them why you think you could work well together."
          />

          <section className="cc-summary-row" aria-label="Request summary" data-m="up">
            <div className="cc-summary-row__half">
              <p className="cc-eyebrow">Project</p>
              <p className="cc-summary-row__project">{PROJECT.name}</p>
            </div>
            <span className="cc-summary-row__rule" aria-hidden="true" />
            <div className="cc-summary-row__half cc-summary-row__half--person">
              {/* Figma 56 px round portrait, the photo of the profile */}
              <Avatar name={person.name} src={asset(person.photo)} size={56} />
              <div className="cc-summary-row__info">
                <p className="cc-eyebrow">Collaborator</p>
                <p className="cc-summary-row__name">{person.name}</p>
                <p className="cc-summary-row__role">{person.role}</p>
              </div>
            </div>
          </section>

          <div data-m="up">
            <Field
              label="Your message"
              hint="You can edit this message before it is sent."
              error={error ? 'Write a short message to continue.' : undefined}
              htmlFor="cc-message"
            >
              <TextArea
                id="cc-message"
                className={`cc-message${message.trim() ? ' cc-message--filled' : ''}`}
                rows={8}
                placeholder="Tell them why you’d like to collaborate..."
                value={message}
                invalid={error}
                onChange={(e) => {
                  setMessage(e.target.value);
                  if (e.target.value.trim()) setError(false);
                }}
              />
            </Field>
          </div>

          <aside className="cc-notice" data-m="up">
            <h2 className="cc-notice__title">Nothing is sent until you confirm.</h2>
            <p className="cc-notice__text">{copy.requestNotice}</p>
          </aside>

          <div className="cc-actions" data-m="up">
            <Button arrow="up-right" onClick={send}>
              Send introduction request
            </Button>
            <Button variant="secondary" onClick={save}>
              Save for later
            </Button>
          </div>
        </div>
      </div>
      <CcOverlays open={ov} onClose={() => setOv(null)} person={id} />
    </>
  );
}

export default function IntroRequest() {
  return <IntroRequestScreen id="amina" />;
}

/**
 * B10 Introduction sent of Amina (Figma 17218:16816, route /collaborate/collaborators/request-sent) and the sent screens of 12.28 to 12.30
 * (Kunle 17706:74672, Funmi 17706:75441, Chidi 17706:76210), route /collaborate/collaborators/<id>/request-sent.
 * View request opens the Pending page of that person (12.47 Introduction request: Amina 17974:158093, Kunle 17974:165381, Funmi 17974:165496,
 * Chidi 17974:165611).
 */
export function RequestSentScreen({ id }: { id: PersonId }) {
  const person = PEOPLE[id];
  const copy = PERSON_COPY[id];
  return (
    <div className="cc-split">
      <div className="cc-split__content">
        <div className="cc-heading cc-heading--hero">
          <p className="cc-eyebrow" data-m="up">
            Request sent
          </p>
          <h1 className="cc-h cc-h--sent" data-m="words">
            Your introduction request is on its way.
          </h1>
          <p className="cc-support" data-m="up">
            {copy.sentSupport}
          </p>
        </div>

        <section className="cc-sent" aria-label="Request status" data-m="up">
          <div className="cc-sent__row">
            <Avatar name={person.name} src={asset(person.photo)} size={72} style={{ width: 64, height: 64 }} />
            <div className="cc-sent__who">
              <p className="cc-sent__name">{person.name}</p>
              <p className="cc-sent__project">{PROJECT.name}</p>
            </div>
            <StatusPill status="pending" />
          </div>
          <hr className="cc-rule" />
          <p className="cc-sent__note">{copy.sentNote}</p>
        </section>

        <div className="cc-actions" data-m="up">
          <Button href={R.discovery} arrow="up-right">
            Return to collaborators
          </Button>
          <Button variant="secondary" href={requestRoute(id)}>
            View request
          </Button>
        </div>
      </div>
      <div className="cc-split__photo" data-m="frame">
        {/* Figma node 17218:16844 "Photo" (605 x 762), the same photograph as the entry screen */}
        <img className="cover" src={asset('/images/app/collab-people/hero-collaborators.jpg')} alt="" decoding="async" width={605} height={762} />
      </div>
    </div>
  );
}

export function RequestSent() {
  return <RequestSentScreen id="amina" />;
}
