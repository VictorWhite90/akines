'use client';

import './applicants.css';
import '../workspace/workspace.css';
import { Button } from '@/ui';
import { ART_REQUEST } from '../project-team/data';
import { CardLink, Over } from '../workspace/atoms';
import { useProject } from '../workspace/project';
import { Portrait } from './parts';
import { APPLICANTS, APPLICANT_PATHS, BAND } from './data';
import { peopleOf, useApplicantState } from './store';

/**
 * The Interest requests band of the Overview pages (Figma "02b Interest requests", Career 17976:173489 and Adire 17976:173570), between the metric
 * cards and Project progress: the label, "N waiting", Review all, and a Request Card for each person who waits for an answer. Every card and
 * Review all open the Applicants page. Adire Stories has no applicants page of its own, so its card goes to the Applicants page of
 * Career Guidance for Everyone, as in the design.
 */

type Request = { key: string; name: string; role: string; message: string; photo: string };

export function InterestRequestsBand() {
  const { key } = useProject();
  const s = useApplicantState();

  // Career Guidance: the people whose status is New wait for an answer. Adire Stories: the one request of its Team page.
  const requests: Request[] =
    key === 'career'
      ? peopleOf(s, 'project')
          .filter((p) => p.status === 'New')
          .map((p) => {
            const a = APPLICANTS[p.id];
            return { key: a.id, name: a.name, role: a.wants, message: a.short ?? a.message, photo: a.photo };
          })
      : [{ key: 'bisi', name: ART_REQUEST.name, role: ART_REQUEST.wants, message: ART_REQUEST.message, photo: ART_REQUEST.photo }];
  if (requests.length === 0) return null;

  return (
    <section className="ap-band" aria-label="Interest requests" data-m="up">
      <div className="ap-band__head">
        <div className="ap-band__title">
          <Over className="cw-over--12">{BAND.label}</Over>
          <p className="ap-band__count">{BAND.waiting(requests.length)}</p>
        </div>
        <CardLink href={APPLICANT_PATHS.list}>{BAND.reviewAll}</CardLink>
      </div>
      <ul className={requests.length === 1 ? 'ap-band__cards ap-band__cards--one' : 'ap-band__cards'}>
        {requests.map((r) => (
          <li key={r.key}>
            <article className="ap-req">
              <div className="ap-req__top">
                <Portrait src={r.photo} size={48} />
                <div className="ap-req__text">
                  <h3 className="ap-req__name">{r.name}</h3>
                  <p className="ap-req__wants">{BAND.wants(r.role)}</p>
                </div>
              </div>
              <p className="ap-req__msg">{r.message}</p>
              <Button size="sm" variant="secondary" href={APPLICANT_PATHS.list} className="ap-req__review">
                {BAND.review}
                <span className="sr-only"> {r.name}</span>
              </Button>
            </article>
          </li>
        ))}
      </ul>
    </section>
  );
}
