'use client';

import { useSyncExternalStore, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft } from 'lucide-react';
import { Link } from '@/lib/nav';
import { useLayout } from '@/lib/hooks';

/* The right slot of the bar, shared with MobileTopBarAction (the page renders its action into it through a portal). */
let slot: HTMLElement | null = null;
const listeners = new Set<() => void>();
const setSlot = (el: HTMLElement | null) => {
  if (slot === el) return;
  slot = el;
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};
const useSlot = () =>
  useSyncExternalStore(
    subscribe,
    () => slot,
    () => null,
  );

/**
 * Phone top bar for sub-pages (Figma "Top Bar Mobile", Title align=Center): 56 high, back chevron (Top Bar Button / Mobile, 44 x 44),
 * centred title in Manrope Semi Bold 17, and a 44 x 44 action slot on the right that keeps the title centred when it is empty.
 * The shell renders it from `route.mobile` (bar "top"); it sticks to the top like the mobile header.
 */
export function MobileTopBar({ title, back }: { title: string; back?: string }) {
  return (
    <header className="mtb" data-layout="mobile">
      <div className="mtb__slot">
        {back ? (
          <Link href={back} className="mtb__btn" aria-label="Back">
            <ChevronLeft size={24} strokeWidth={1.5} aria-hidden="true" focusable="false" />
          </Link>
        ) : null}
      </div>
      <p className="mtb__title">{title}</p>
      <div className="mtb__slot mtb__slot--action" ref={setSlot} />
    </header>
  );
}

/**
 * Lets a page put its action (for example "Arrange a Create Call" as a calendar icon on a chat thread) into the right side of the
 * phone top bar. Renders nothing on tablet and desktop, or when the screen has no top bar.
 */
export function MobileTopBarAction({ label, icon, onClick }: { label: string; icon: ReactNode; onClick: () => void }) {
  const layout = useLayout();
  const target = useSlot();
  if (layout !== 'mobile' || !target) return null;
  return createPortal(
    <button type="button" className="mtb__btn" aria-label={label} onClick={onClick}>
      {icon}
    </button>,
    target,
  );
}
