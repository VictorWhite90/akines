'use client';

/** Community Home (Figma 10.1, frame 17095:5812, 1512 x 9159): bands 01 to 10, all driven by the store. */
import './community.css';
import { useCommunity } from './store';
import { CollabsBand, ContinueBand, ControlsBand, Hero, Intentions, IntrosBand, InvitesBand, MemoriesBand, ResultBand, UpcomingBand, WaysBand, WellbeingBand } from './bands';

export default function CommunityHome() {
  const s = useCommunity();
  return (
    <div className="ch-page ch-home">
      <Hero />
      <Intentions />
      {s.intention > 0 ? <ResultBand /> : null}
      <div className="ch-main">
        <ContinueBand />
        <IntrosBand />
        <UpcomingBand />
        <InvitesBand />
      </div>
      <div className="ch-rest">
        <WaysBand />
        <CollabsBand />
        <WellbeingBand />
        <MemoriesBand />
        <ControlsBand />
      </div>
    </div>
  );
}
