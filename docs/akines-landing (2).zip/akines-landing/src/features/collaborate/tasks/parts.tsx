'use client';

import '../workspace/workspace.css';
import './tasks.css';
import { useEffect, useLayoutEffect, useRef, type ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { CheckIcon, WorkspaceFrame, cx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { TP, WRITE_ID, dueLabel, initialsOf, viewPaths, type Priority, type Status, type Task } from './data';
import { useTasksData } from './store';

/**
 * Pieces of the Tasks screens. Figma components: Priority Tag 17669:19311, Task Status 17669:19292, Task Row 17670:19352,
 * Board Card 17670:19408, Studio Tab 17171:10966 (the view tabs), Milestone Group Header 17669:19315, Board Column Header 17669:19312.
 * Every class is prefixed tk- and lives in tasks.css.
 */

/* ------------------------------------------------------------------ frame */

/**
 * The project page frame, with "Tasks" highlighted. List and Milestone view show the shared project rail (`rail`; the Empty frame the
 * short one), the Board view has no right column at all (`wide`, a 1088 centre) and the task detail keeps its own context panel.
 */
export function TasksFrame({ context, rail, wide, children }: { context?: ReactNode; rail?: boolean | 'short'; wide?: boolean; children: ReactNode }) {
  return (
    <WorkspaceFrame active="tasks" context={context} rail={rail} wide={wide}>
      {children}
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ atoms */

/** Priority Tag: three bars show the level. */
export function PriorityTag({ priority }: { priority: Priority }) {
  const level = priority === 'High' ? 3 : priority === 'Medium' ? 2 : 1;
  return (
    <span className="tk-pri">
      <span className="tk-pri__bars" aria-hidden="true">
        <i className="on" />
        <i className={level >= 2 ? 'on' : undefined} />
        <i className={level >= 3 ? 'on' : undefined} />
      </span>
      <span>{priority}</span>
    </span>
  );
}

const DOT: Record<Status, string> = { 'Not started': 'not', 'In progress': 'progress', 'In review': 'review', Completed: 'done' };

/** Task Status: a dot and the status. Not started is a ring, In progress amber, In review ink, Completed green. */
export function StatusTag({ status }: { status: Status }) {
  return (
    <span className="tk-status">
      <i className={cx('tk-dot', `tk-dot--${DOT[status]}`)} aria-hidden="true" />
      <span>{status}</span>
    </span>
  );
}

/** Owner circle: 32 in the list, 28 on the board cards. */
export function Owner({ name, small }: { name: string; small?: boolean }) {
  return (
    <span className={cx('tk-owner', small && 'tk-owner--sm')} role="img" aria-label={`Responsible: ${name}`}>
      {initialsOf(name)}
    </span>
  );
}

/** Where a task opens. Only the task of the design has a detail screen; its three frames are its stages. Other tasks go nowhere. */
export function taskHref(t: Task): string | undefined {
  if (t.id !== WRITE_ID) return undefined;
  return t.status === 'Completed' ? TP.completed : t.status === 'In review' ? TP.inReview : TP.detail;
}

/** The destination of a task row or card in the project of the page. Adire Stories has no task detail screens, so none of its tasks is a link. */
function useTaskHref(t: Task): string | undefined {
  const { key } = useProject();
  return key === 'career' ? taskHref(t) : undefined;
}

/** Task Row: Default, Hover, Pressed and Focus come from CSS. A row with no destination in the design reacts but goes nowhere. */
export function TaskRow({ task, withMilestone }: { task: Task; withMilestone?: boolean }) {
  const href = useTaskHref(task);
  const body = (
    <>
      <span className="tk-row__content">
        <span className="tk-row__title">{task.title}</span>
        <span className="tk-row__meta">
          {withMilestone ? <span className="tk-row__ms">{task.milestone}</span> : null}
          <PriorityTag priority={task.priority} />
        </span>
      </span>
      <Owner name={task.owner} />
      <span className="tk-row__status">
        <StatusTag status={task.status} />
      </span>
      <span className="tk-row__due">{dueLabel(task)}</span>
    </>
  );
  if (href) {
    return (
      <Link href={href} className="tk-row">
        {body}
      </Link>
    );
  }
  return (
    <button type="button" className="tk-row" aria-disabled="true">
      {body}
    </button>
  );
}

/** Board Card: priority, title, milestone, owner and due date. */
export function BoardCard({ task }: { task: Task }) {
  const href = useTaskHref(task);
  const body = (
    <>
      <PriorityTag priority={task.priority} />
      <span className="tk-card__title">{task.title}</span>
      <span className="tk-card__ms">{task.milestone}</span>
      <span className="tk-card__foot">
        <Owner name={task.owner} small />
        <span className="tk-card__due">{dueLabel(task)}</span>
      </span>
    </>
  );
  if (href) {
    return (
      <Link href={href} className="tk-card">
        {body}
      </Link>
    );
  }
  return (
    <button type="button" className="tk-card" aria-disabled="true">
      {body}
    </button>
  );
}

/* ------------------------------------------------------------------ view tabs */

export type View = 'list' | 'board' | 'milestones';

/** The three views (Figma Studio Tab). Each tab opens its own screen (of the project of the page); the active tab has no destination. */
export function ViewTabs({ active }: { active: View }) {
  const paths = viewPaths(useProject().root);
  const VIEWS: { key: View; label: string; href: string }[] = [
    { key: 'list', label: 'List', href: paths.list },
    { key: 'board', label: 'Board', href: paths.board },
    { key: 'milestones', label: 'Milestones', href: paths.milestones },
  ];
  return (
    <nav className="tk-tabs" aria-label="Task views">
      {VIEWS.map((v) =>
        v.key === active ? (
          <span key={v.key} className="tk-tab" aria-current="page">
            <span className="tk-tab__label">{v.label}</span>
            <span className="tk-tab__rule" />
          </span>
        ) : (
          <Link key={v.key} href={v.href} className="tk-tab">
            <span className="tk-tab__label">{v.label}</span>
            <span className="tk-tab__rule" />
          </Link>
        ),
      )}
    </nav>
  );
}

/* ------------------------------------------------------------------ milestone group */

/** Milestone Group Header: title, "View milestone", the due date with the count of tasks done, and a progress line. */
export function MilestoneHead({ name, done, total }: { name: string; done: number; total: number }) {
  const ms = useTasksData().milestones.find((m) => m.name === name);
  const pct = total > 0 ? Math.round((done / total) * 10000) / 100 : 0;
  return (
    <header className="tk-mh">
      <div className="tk-mh__top">
        <h2 className="tk-mh__title">{name}</h2>
        {ms?.href ? (
          <Link href={ms.href} className="cw-link">
            <span className="cw-link__label">View milestone</span>
          </Link>
        ) : (
          <button type="button" className="cw-link">
            <span className="cw-link__label">View milestone</span>
          </button>
        )}
      </div>
      <p className="tk-mh__meta">
        {ms ? `${ms.due}. ` : ''}
        {done} of {total} {total === 1 ? 'task' : 'tasks'} done.
      </p>
      <div className="tk-mh__bar" style={{ ['--tk-p' as string]: `${pct}%` }} role="img" aria-label={`${done} of ${total} tasks done`} />
    </header>
  );
}

/* ------------------------------------------------------------------ form pieces */

/** Checkbox of the criteria and of the filter options. */
export function Box({ on }: { on: boolean }) {
  return (
    <span className={cx('tk-box', on && 'tk-box--on')} aria-hidden="true">
      {on ? <CheckIcon size={14} sw={1.5} /> : null}
    </span>
  );
}

/* ------------------------------------------------------------------ popover that hangs from its trigger */

/**
 * A panel anchored under its trigger (8 px below, left edges aligned, as in the Dropdown frames), so it follows the trigger when the page
 * scrolls. Closes on Escape (focus goes back to the trigger) and on a press outside. The trigger carries `data-tk-trigger`.
 */
export function Popover({ open, onClose, trigger, children }: { open: boolean; onClose: () => void; trigger: ReactNode; children: ReactNode }) {
  const wrap = useRef<HTMLSpanElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;

  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => {
      if (wrap.current && !wrap.current.contains(e.target as Node)) close.current();
    };
    const key = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      close.current();
      wrap.current?.querySelector<HTMLElement>('[data-tk-trigger]')?.focus({ preventScroll: true });
    };
    document.addEventListener('pointerdown', down);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', down);
      document.removeEventListener('keydown', key);
    };
  }, [open]);

  // keep the panel on screen when its trigger sits close to the right edge of a narrow window
  useLayoutEffect(() => {
    const el = panel.current;
    if (!open || !el) return;
    el.style.translate = '';
    const r = el.getBoundingClientRect();
    const over = r.right - (window.innerWidth - 16);
    if (over > 0) el.style.translate = `${-Math.min(over, Math.max(0, r.left - 16))}px 0`;
  }, [open]);

  // move focus into the panel (the chosen option, else the first one) when it was opened from its trigger;
  // a frame that loads with the panel already open keeps the focus where it is
  useEffect(() => {
    if (!open) return;
    if (!wrap.current?.contains(document.activeElement)) return;
    const el = panel.current;
    const target = el?.querySelector<HTMLElement>('[role="menuitemradio"][aria-checked="true"]') ?? el?.querySelector<HTMLElement>('button:not([disabled])');
    target?.focus({ preventScroll: true });
  }, [open]);

  return (
    <span className="tk-pop" ref={wrap}>
      {trigger}
      {open ? (
        <div className="tk-pop__panel" ref={panel}>
          {children}
        </div>
      ) : null}
    </span>
  );
}
