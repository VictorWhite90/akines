# Community Home feed: build spec (3 Nov 2026, approved by the user)

Source: the user's PDF "Home feed Content" plus the 11 section names from their screenshot. Visual language is OURS
(Dior card system: square cards, Alice serif titles, Manrope body, underlined text links, charcoal pill primary, left aligned
text, hairlines), the PDF supplies only the CONTENT and the arrangement. No em dashes or en dashes anywhere in copy.

## 1. What changes
- `/community` (Community Home) is replaced by a feed page. Hero is constant. Below it the feed shows SIX of the ELEVEN
  sections, in one of FOUR arrangements. A new arrangement is chosen every time the page is visited.
- The old Home (10 bands) was moved to `_trash/community-previous` (not compiled, no route). Notifications and the other overlays (`Overlays.tsx`, `store.ts`) stay.
- Layout (desktop 1512, updated 5 Nov 2026): the hero is a full width carousel of vertical portrait cards (section 3), 527 high, first card at
  the page padding 64. 96 px under it the body starts: page padding 64, left column 984 (the feed), right rail 360, gap 40.
  The rail STARTS below the hero, level with the first section, and is STICKY: it pins under the app header
  (`position: sticky; top: <app header height> + 32 = 112`) while the feed scrolls. Rail card order: Your Circles, You two would get along (slideshow).
  "Trending now" was removed from the rail.
- Below 1280 the rail leaves the side: single column, order = hero, match slideshow, your circles, then the feed (hero to body 72, 48 under 768).
  Below 768, card rows (3 up) become horizontal scroll-snap rows (card 78% wide) and posts are full width. The hero cards keep their 316 width at every size.
  Never any horizontal page scroll (the carousel scrolls inside itself).

## 2. Arrangements (position 1 is the most important)
| pos | A Discover | B Belong | C Make together | D Heritage and craft |
|---|---|---|---|---|
| 1 | explore | kincircle | collaborate | stories |
| 2 | kincircle | rooms | dna | studios |
| 3 | banter | collaborate | rooms | wellbeing |
| 4 | stories | activities | studios | shop |
| 5 | studios | wellbeing | banter | dna |
| 6 | shop | explore | shop | activities |
Keys: explore (Explore), banter (Banter), kincircle (KinCircle), rooms (Rooms), activities (Activities), collaborate (Collaborate),
shop (Shop Art), studios (Studio Visits), stories (Stories and Legacy), wellbeing (Creative Wellbeing), dna (Creative DNA).

Rotation: localStorage key `akines.feed.last.v1` stores the last version shown. On every mount of the feed page pick uniformly at
random from the three versions that are NOT the last one (first visit: any of the four), store it, render it. Re-pick on each new
visit (client navigation back to /community counts), never on a re-render. Render hero + rail + a feed skeleton on the server and
first paint, then the feed after mount (avoids a hydration mismatch). Forced preview routes for review and tests (do not write the
key): `/community/feed/a`, `/b`, `/c`, `/d`. Also `/community/feed/state-loading`, `/community/feed/state-error` (one section
shows an error panel with "Try again", the others live), `/community/feed/state-empty` (match card says nothing to suggest today).

## 3. Hero (constant, redesigned 5 Nov 2026)
A full width carousel of vertical portrait cards. The cards are not only Banters: Banters, Live rooms, Games and Activities. Eight cards (`HERO_CARDS` in `content.ts`):
| # | kind | title | meta line |
|---|---|---|---|
| 1 | Banter | Can ambition and rest coexist? | 18 people talking · Banter |
| 2 | Live room | Evening Studio Hour | 12 in the room · Hosted by Tunde |
| 3 | Game | Name That Pattern | Starts 6:30 PM · 14 playing |
| 4 | Activity | Indigo dyeing for beginners | Sat 8 Nov · Yaba, Lagos |
| 5 | Banter | What makes collaboration work? | 24 people talking · Banter |
| 6 | Live room | Poetry Open Mic | Starts 7:00 PM · Hosted by Amara |
| 7 | Game | Story Chain | Open now · 9 playing |
| 8 | Live room | Textile Swap Circle | 21 in the room · Hosted by Ayo |
Card: 316 x 527. Photo 316 x 448 (`feed/hero-card-1.jpg` to `hero-card-8.jpg`, 632 x 896), tag pill at 16, 16 (radius 100, padding 7 / 20, Manrope Medium 14),
then title (Alice 20 / 28) and meta line (Alice 16 / 19, secondary), 16 above the title, 4 between, 12 below. 24 gap between cards.
Tag colours: Banter amber (`--surface-secondary-strong`), Live room dark (`--surface-inverse`, white text) with an 8 px amber dot, Game ivory (`--surface-brand`), Activity white.
Banter cards open `/community/banter`, the others `/connect`. The whole card is one link.
The first card sits at the page padding (at the edge of the 1512 column on wider windows) and the carousel runs to the window edge, so at 1512 four cards and a half show and the fifth bleeds off the right edge.
Motion: it steps one card (340 px) to the left every 5 s with a smooth scroll and goes back to the first card after the last. The reader can scroll it sideways at any time
(touch, trackpad, shift + wheel, dragging with the mouse, or Tab to a card). Autoplay waits while the mouse is over the carousel, while a card has focus or is pressed, while the reader is scrolling
(the next step comes 5 s after the last movement) and while the tab is hidden; with reduced motion it never moves by itself. No arrows, dots or buttons.
Hover: photo zooms 1.04 and a 2 px rule draws in under the card. Focus: 2 px ink ring outside the card. Pressed: rule stays, title 70%.
The page has no visible headline any more, so a screen reader only h1 "Community home" sits in the hero. The old hero (slideshow with headline and the "Start a KinCircle" and
"See how it works" actions) and its photographs (`feed/hero.jpg`, `hero-2..4`) were removed (photos moved to `_trash/feed-hero-photos`).
Figma: component sets "Feed Hero Card" (Type x State) and "Feed Hero Carousel" (Page=1 to 4, each moves one card after 5 s, Smart animate 0.8 s, the last goes back to the first in 1.2 s)
on the Components page, Feed system. Tunables: `HERO.interval` in `content.ts`; `--fd-hcard-*` and `--fd-hero-gap` in `feed.css`.

## 4. Rail
Cards: width 360, padding 24, 1px hairline border, Surface/Default fill, radius 0, gap 24 between cards. Titles Alice 20.
- Your Circles (2) with link "See all" (to `/connect`). Rows (photo 56 square, name Manrope SemiBold 16, meta Manrope 14 secondary, chevron):
  Textiles & Adire, "416 members · 8 active", `circle-textiles.jpg`. Poetry and Wine talk, "20 members · 4 active", `circle-poetry.jpg`. Rows link to `/connect`.
- You two would get along (slideshow, section 5) with link "Why this match?" (goes to `/collaborate/collaborators/why-this-match`).
- Trending now on Akines was REMOVED from the rail on 5 Nov 2026.
All states: hover underline rule or photo zoom, pressed, focus ring (Border/Focus 2px).

## 5. Match slideshow ("You two would get along")
7 profiles (min 5, max 10 supported; the component accepts an array of 5 to 10 and clamps). Each slide: avatar 56 circle, name (Manrope SemiBold 16),
"role · place" (Manrope 14 secondary), quote (Alice 20, curly quotes), then the controls: dots, counter, arrows, then buttons "Not now" (secondary pill) and "Say hello" (charcoal primary pill).
| # | name | role | place | quote | image |
|---|---|---|---|---|---|
| 1 | Ayo Balogun | Textile artist | Ibadan | You both see textiles as living archives. | feed/avatar-ayo.jpg |
| 2 | Amara Okafor | Visual artist | Abuja | You both believe a poem can host a whole evening. | feed/avatar-amara.jpg |
| 3 | Yusuf Umar | Multidisciplinary artist | Kwara | You both want collaboration that challenges an idea without flattening it. | feed/avatar-yusuf.jpg |
| 4 | Ngozi Eze | Writer and zine maker | Lagos | You both write to remember the people in your lives. | community/av-ngozi.jpg |
| 5 | Tunde Bakare | Community health designer | Abuja | You both prefer practical, small-group work. | community/av-tunde.jpg |
| 6 | Chuka Nwosu | Founder and maker | Port Harcourt | You both like thinking an idea through with one person at a time. | community/av-chuka.jpg |
| 7 | Folake Adeniran | Storyteller | Lagos | You both keep Sunday for slow walks and long talks. | community/av-folake.jpg |
Behaviour: NO autoplay. Navigation indicator = dots (8 px circles, active one is a 24 x 8 pill) plus a counter "2 / 7" plus previous/next arrows (44 px circles, wrap around).
The user can also swipe or drag (pointer events, 40 px threshold), press Left/Right when the card has focus, and click a dot. Slides move with a 0.6 s ease-in-out
translate (the landing `--ease-io`), reduced motion switches at once. "Not now" moves to the next profile. "Say hello" turns that profile's buttons into the
confirmation "Hello sent to <first name>. We will let you know when they reply." (kept for the visit, in memory) and fires `toast.show({message: 'Hello sent to <first name>'})`.
Accessibility: `aria-roledescription="carousel"`, each slide `role="group"` with `aria-label="2 of 7"`, live region off (no autoplay), inactive slides `inert`.
Empty state: "Nothing to suggest today. Check back tomorrow." with a quiet link "Update recommendation preferences" (goes to `/community/settings/recommendations`).

## 6. Section content (copy is final, do not reword)
Section header = title (Alice 32), support (Manrope 16 secondary) and a right aligned underlined link with arrow. 96 px between sections, 32 under the header.
Card row = 3 cards of 312 with 24 gap. Feed card = photo 312 x 312, 16, optional tag (Manrope Medium 12, caps, tracking .08em, Accent text), title (Alice 24, max 2 lines, fixed 62 px), 8, description (Manrope 14 secondary, max 2 lines, fixed 45 px), 16, hairline, 12, meta row (Manrope Medium 12 secondary, left and right). Hover: photo zooms 1.04 over 0.8 s and a 2 px rule appears under the card. Whole card is one link.

1. explore. Title "These might resonate with you." Support "Discover stories, ideas, and conversations worth your time." Link "Explore all" (/explore). Cards (no tag; meta "128 felt this" left, "24 Reflections" right):
   - "I almost painted over this" / "A work about my grandmother, indigo cloth and the things families leave unsaid." / feed/story-1.jpg
   - "The painting that made my daughter ask" / "One talk over breakfast changed how my family speaks about identity." / feed/story-2.jpg
   - "Five voices reshaping portraiture" / "Beyond the gaze: a personal walk through the artists changing the conversation." / feed/story-3.jpg
2. kincircle. Title "Your circles' feed." Support "What people are sharing in the circles you've joined." Link "Explore all" (/connect). Three posts, full column width (984), each: padding 32, hairline border, Surface/Default.
   Header row: avatar 48 circle, name (Manrope SemiBold 16), "role · place · time" (Manrope 14 secondary), right: circle name as a quiet tag. Body Manrope 16/1.6. Optional media row (2 images 452 x 300, or 3 images 296 x 240, gap 16). Footer: reactions (emoji chips) and "+ React", right "N replies".
   - Ayo Balogun, avatar feed/avatar-ayo.jpg, "Textile artist · Ibadan · 2h", circle "Textiles and adire circle". Body: "Seven dye baths in, and the blue finally came out the way I've been chasing all year. Hung it in the yard for an hour just to watch the light change it." Media post1-a.jpg, post1-b.jpg. Reactions: clap 3, heart 2. "2 replies".
   - Amara Okafor, avatar-amara.jpg, "Visual artist · Abuja · 3h", circle "Poetry and wine talk circle". Body paragraph 1: "There's something about a glass of wine, a room full of honest conversations, and poetry that says the things we struggle to admit out loud. Sometimes, the words of a stranger feel like they were written from the pages of our own lives." Paragraph 2: "If we hosted a poetry and wine evening, what poem would you bring to the table, and what story would you tell behind it?" Media post2-a.jpg, post2-b.jpg, post2-c.jpg. Reactions: thumbs-up 13, heart 20, surprised 5. "12 replies".
   - Yusuf Umar, avatar-yusuf.jpg, "Multidisciplinary artist · Kwara · 5h", circle none. Body: "One thing I'm learning is that collaboration isn't about finding people who think exactly like you. It's about finding people who can challenge your ideas without making you feel you have to abandon them." Paragraph 2: "How do you know when a creative partnership is worth pursuing?" No media. Reaction: thumbs-up 3. "No replies yet".
   Reaction chips toggle (count +1 when on), "+ React" opens a small menu of 5 emoji, replies link is inert (no Figma destination).
3. banter (NEW). Title "Conversations worth joining." Support "Open conversations happening across Akines right now." Link "Open Banter" (/community/banter). Three TEXT-LED conversation cards (no photo): 312 wide, padding 24, hairline border, Surface/Akines/Primary/Subtle fill, min height 340. Tag "BANTER · LIVE" (or "BANTER · OPEN"), title Alice 28 (3 lines max), excerpt Manrope 14 secondary (3 lines), bottom: avatar stack (3 x 32, overlap 8; use community av-*.jpg) + "18 people talking", underlined link "Join the conversation" with arrow (/community/banter).
   - LIVE, "Can ambition and rest coexist?", "I used to think resting meant falling behind. Lately my best work comes the morning after a real day off.", 18 people talking
   - LIVE, "What makes collaboration work?", "It is rarely the idea. It is whether you can disagree on a Tuesday and still show up on Wednesday.", 24 people talking
   - OPEN, "Who taught you to look closely?", "A teacher, a grandmother, a stranger at a market. Tell us who made you notice the small things.", 9 people talking
4. rooms (NEW). Title "Rooms open now." Support "Drop in, listen, or speak when you are ready." Link "See all rooms" (/connect). Feed cards with tag and meta (left, right):
   - tag "LIVE NOW", "Evening Studio Hour", "A quiet room to work alongside others, cameras optional.", meta "12 in the room" / "Hosted by Tunde", image community/zine-tall.jpg
   - tag "STARTS 7:00 PM", "Poetry Open Mic", "Bring a poem of your own, or just come to listen.", "8 going" / "Hosted by Amara", image feed/post2-a.jpg
   - tag "LIVE NOW", "Textile Swap Circle", "Trade scraps, dyes and techniques with makers across the country.", "21 in the room" / "Hosted by Ayo", image feed/circle-textiles.jpg
5. activities (NEW). Title "Things to do together." Support "Small, easy ways to meet people through making." Link "See all activities" (/connect). Feed cards, tag = date, meta = place / spots:
   - tag "SAT 8 NOV · 4:00 PM", "Indigo dyeing for beginners", "Learn the first three dye baths and take your cloth home.", "Yaba, Lagos" / "6 spots left", image feed/post1-a.jpg
   - tag "SUN 9 NOV · 10:00 AM", "Sunday sketch walk", "Two slow hours with a sketchbook and a small group.", "Freedom Park, Lagos" / "12 spots left", image feed/studio-3.jpg
   - tag "WED 12 NOV · 6:30 PM", "Writing together, online", "A gentle hour of quiet writing, then one shared paragraph.", "Online" / "Open to all", image feed/journal-1.jpg
6. collaborate (NEW). Title "Projects looking for you." Support "Open projects that match your interests and skills." Link "Discover projects" (/collaborate/discover). Feed cards, tag "LOOKING FOR: <role>", meta "<n> collaborators" / "<m>% match":
   - "LOOKING FOR: ILLUSTRATOR", "Lagos Makers Zine", "A printed zine celebrating independent makers across the city.", "5 collaborators" / "88% match", community/zine-tall.jpg, goes to /collaborate/projects/lagos-makers-zine (check the registry for the real slug)
   - "LOOKING FOR: COMMUNITY ORGANISER", "Community Health Initiative", "Mapping local health needs and the people already meeting them.", "9 collaborators" / "81% match", community/health-tall.jpg
   - "LOOKING FOR: FACILITATOR", "Career Guidance for Everyone", "Short, honest sessions that help students see what work could look like.", "4 collaborators" / "76% match", community/kincircle.jpg
7. shop (Shop Art). Title "Fresh from the makers." Support "Original work and made-to-order pieces, sold by the people who made them." Link "Shop all" (/explore). Product cards: photo 312 x 312, small tag (medium type, caps), title Alice 24 (1 line), maker row (avatar 24 + name Manrope 14), bottom row price (Alice 24) + edition "1 of 1" + secondary pill "Buy".
   - tag "CERAMICS", "Firing day vase", Thandi Dlamini, "$240", no edition, feed/studio-2.jpg (cream vases)
   - tag "PAINTING", "Indigo Room", Kwame Mensah, "$10,000", "1 of 1", feed/journal-3.jpg
   - tag "SCULPTURE", "The watching figure", Tunde Adeyemi, "$3,200", "1 of 1", feed/product-3.jpg
   Maker avatars: use community av-*.jpg (any three distinct). Buy shows toast "Added to your basket" (no basket page designed).
8. studios (Studio Visits). Title "Step inside the studio." Support "Live, virtual, 360° or VR. Talk to the maker directly." Link "Visit studios" (/explore). Feed cards (tag = format, meta = place / none):
   - tag "LIVE", "Tunde Adeyemi's studio", "Watch a firing day. Ask anything. Buy from the shelf if something follows you home.", "Yaba, Lagos", feed/studio-1.jpg
   - tag "360°", "Thandi Dlamini's studio", "Walk the workshop at your own pace. Tap any vessel to hear how it was made.", "Maboneng, Johannesburg", feed/studio-2.jpg
   - tag "VIRTUAL", "Kwame Mensah's studio", "A guided hour among works in progress, six visitors at a time.", "Osu, Accra", feed/studio-3.jpg
9. stories (Stories and Legacy). Title "Witness the journey." Support "Living journals and the legacy every artwork carries." Link "Open journals" (/explore). Feed cards (tag, meta "128 felt this" / "24 Reflections"):
   - tag "ARTIST JOURNAL", "Failed panel #3, kept anyway", "Scraped it back to the third layer.", feed/journal-1.jpg
   - tag "ARTIST JOURNAL", "Dyeing day 7: the green surprise", "The third batch came out greener than any I've ever mixed.", feed/journal-2.jpg
   - tag "ART LEGACY", "Where the painting lives", "Made in Accra, acquired in Casablanca and now asked about every morning.", feed/journal-3.jpg
10. wellbeing (NEW). Single wide band (984 x 440): left 592 text, right 392 photo flush (community/amara.jpg), hairline border. Eyebrow "CREATIVE WELLBEING", title (Alice 32) "A quiet moment.", support "How is your creative energy today? Only you can see your answer.", four option chips "Full", "Steady", "Low", "Running on empty" (single choice, uses the kit Chip), after a choice a calm one line reply appears (Full: "Lovely. Let it carry something small into the world."; Steady: "Steady is a good place to make from."; Low: "Then be gentle. A walk or ten quiet minutes can be enough."; Running on empty: "Thank you for saying so. Rest counts as part of the work."). Underlined link "Reflect privately" (/community/care/reflect). No header link row.
11. dna (NEW). Title "Your creative DNA." Support "Traits that shape how you make, and the people who share them." Link "See your full DNA" (/care). Three trait cards in a row (312 wide, hairline, padding 24, min height 300): eyebrow "TRAIT 01", title Alice 24, description 14 secondary, meta "Shared by 24 people in your circles" with avatar stack, link "See who shares it" with arrow.
   - "Patient maker" / "You return to a piece many times before it feels finished." 
   - "Story first" / "You start from the person or memory behind the work, then find the form."
   - "Better together" / "Your best ideas arrive in conversation, not alone at the desk."

## 7. Images (already converted, in `public/images/app/feed/`)
hero-card-1..8, story-1..3, post1-a, post1-b, post2-a..c, journal-1..3, studio-1..3, product-1, product-3, circle-textiles, circle-poetry, avatar-ayo, avatar-amara, avatar-yusuf (all `.jpg`). Existing: `public/images/app/community/*`.
NOTE `post2-c.jpg` does not exist yet: use `circle-poetry.jpg` for it for now (the PDF poem card was not converted). Use `@/lib/assets` `asset()` and the Next/preview image shim exactly like the other features.

## 8. Motion (landing language, no new motion style)
`data-m="up"` on section headers, `data-m="stagger"` on card rows, route fade/rise from the shell, hero cards rise one after another (0.07 s apart), slideshow 0.6 s ease-in-out, hover zoom 0.8 s, reduced motion safe.

## 9. Files and rules
Own: `src/features/community/feed/**`, `src/styles/feed.css` (or `feed/feed.css`; class prefix `fd-`), routes in `src/features/community/routes.tsx` (registry only: move old Home to `/community/previous`, add the new routes; keep all other community routes). Route data (arrangements, copy arrays) must live in plain `.ts` files, components in client files (see BUILD_GUIDE.md rule about 'use client' exports). Use the UI kit (`@/ui`, KIT_API.md), `@/lib/nav`, existing community `ui.tsx` helpers where they fit. Do not touch Figma. Do not use `pkill -f` or `pgrep -f`. Use ports 3210 (next start) and 8210 (preview http.server) only; stop them when done. Temp files go in the session scratchpad.
Verify: `npx tsc --noEmit`, `node scripts/build-preview.mjs <scratchpad>/feed-preview`, `node scripts/check-routes.mjs` against the preview and Next production (all routes, 1512 / 1194 / 402, no console errors, no overflow), plus Playwright checks of: each of the four versions renders its six sections in the spec order, rotation never repeats the last version over 20 reloads, sticky rail stays in view while the feed scrolls (1512 and 1280), slideshow (dots, arrows, swipe, keyboard, Not now, Say hello), reduced motion.
