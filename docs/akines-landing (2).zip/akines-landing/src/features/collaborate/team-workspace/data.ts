/**
 * Shared data of the two team Workspaces: 12.15 Research Workspace and 12.16 Digital Art Workspace (Figma frames 17585:51415 and 17594:51858
 * with their state and overlay frames). Copy is taken from the frames.
 */
import { BASE as PROJECTS_BASE, PATHS as PROJECT_PATHS } from '../workspace/data';
import { VISIBLE_NAV_ITEMS } from '../workspace/project';

export const TW_PATHS = {
  /** 12.15, the Workspace item of the project navigation opens this one. */
  research: PROJECT_PATHS.workspace,
  /** 12.16, the Workspace of the sample project Adire Stories (the fourth card in My Projects). */
  art: `${PROJECTS_BASE}/adire-stories/workspace`,
  overview: PROJECT_PATHS.overview,
  conversations: PROJECT_PATHS.conversations,
} as const;

/** Route of each state frame (Figma 12.15 state frames). */
export const R_PATHS = {
  main: TW_PATHS.research,
  saving: `${TW_PATHS.research}/state-saving`,
  collaboratorOffline: `${TW_PATHS.research}/state-collaborator-offline`,
  connectionLost: `${TW_PATHS.research}/state-connection-lost`,
  reconnecting: `${TW_PATHS.research}/state-reconnecting`,
  viewOnly: `${TW_PATHS.research}/state-view-only`,
  versionHistory: `${TW_PATHS.research}/state-version-history`,
  commentReply: `${TW_PATHS.research}/state-comment-reply`,
  /** A failed save (Figma Popover:Save status / Could not save, 17974:159850): no other frame shows it, so it has a route of its own. */
  couldNotSave: `${TW_PATHS.research}/state-could-not-save`,
} as const;

export type PersonId = 'kemi' | 'amara' | 'ayo' | 'yusuf';
export type Role = 'Owner' | 'Can edit' | 'Can comment' | 'View only';

export const PEOPLE: Record<PersonId, { id: PersonId; name: string; initials: string; photo?: string; role: Role }> = {
  kemi: { id: 'kemi', name: 'Kemi Adeyemi', initials: 'KA', role: 'Owner' },
  // Figma "Avatar / Amara", "Avatar / Ayo", "Avatar / Yusuf" (photo fills 17574:18585, 17574:18589, 17577:18595)
  amara: { id: 'amara', name: 'Amara Obi', initials: 'AO', photo: '/images/app/workspace/amara.jpg', role: 'Can edit' },
  ayo: { id: 'ayo', name: 'Ayo Bello', initials: 'AB', photo: '/images/app/workspace/ayo.jpg', role: 'Can comment' },
  yusuf: { id: 'yusuf', name: 'Yusuf Danjuma', initials: 'YD', photo: '/images/app/workspace/yusuf.jpg', role: 'View only' },
};

/** Figma Workspace / Avatar states: ring and dot colour, photo faded when the person is not here. */
export type AvatarState = 'editing' | 'viewing' | 'commenting' | 'offline' | 'away';

/**
 * The live state of the connection and of the person, one value per Figma frame:
 *  saved               default frame (12.15 and 12.16)
 *  saving              "Saving"
 *  collaboratorOffline "Collaborator offline" (Amara lost connection)
 *  connectionLost      "Connection lost"
 *  reconnecting        "Reconnecting"
 *  viewOnly            "View only"
 *  versionHistory      "Version history" (a preview of an older version, reads as view only)
 *  couldNotSave        "Could not save" (the pill and the save status popover of a failed save)
 */
export type WsState = 'saved' | 'saving' | 'collaboratorOffline' | 'connectionLost' | 'reconnecting' | 'viewOnly' | 'versionHistory' | 'couldNotSave';

/** Figma Workspace / Status variants (17574:18552 to 17574:18577). */
export type StatusTone = 'saved' | 'saving' | 'reconnecting' | 'lost' | 'view' | 'failed';
export const STATUS_OF: Record<WsState, { tone: StatusTone; label: string }> = {
  saved: { tone: 'saved', label: 'All changes saved' },
  saving: { tone: 'saving', label: 'Saving changes' },
  collaboratorOffline: { tone: 'saved', label: 'All changes saved' },
  connectionLost: { tone: 'lost', label: 'Connection lost' },
  reconnecting: { tone: 'reconnecting', label: 'Reconnecting' },
  viewOnly: { tone: 'view', label: 'View only' },
  versionHistory: { tone: 'view', label: 'View only' },
  couldNotSave: { tone: 'failed', label: 'Could not save' },
};

/**
 * The save status popover (Figma Save Status Popover 17972:143571) under the status pill. Its content follows the save state:
 * Saved ("Last saved just now", Save now, Version history), Saving, Offline ("Working offline") and Could not save ("Try again").
 * The pill of "Collaborator offline" still reads All changes saved, so it opens Saved; "Connection lost" opens Offline. Reconnecting, View only
 * and the Version preview have no popover.
 */
export type SaveKind = 'saved' | 'saving' | 'offline' | 'failed';
export const SAVE_KIND_OF: Partial<Record<WsState, SaveKind>> = {
  saved: 'saved',
  collaboratorOffline: 'saved',
  saving: 'saving',
  connectionLost: 'offline',
  couldNotSave: 'failed',
};
export const SAVE_COPY = {
  saved: { title: 'All changes saved', last: 'Last saved just now', note: 'Autosave is on', now: 'Save now', history: 'Version history' },
  saving: { title: 'Saving your changes', note: 'Autosave is on' },
  offline: { title: 'Working offline', note: 'Your changes are saved on this device and will sync when you are back online.' },
  failed: { title: 'We could not save your changes.', retry: 'Try again' },
};

/** Figma Banner frames (Reconnecting, Connection lost, View only, Version preview). */
export type BannerKind = 'collaborator' | 'reconnecting' | 'lost' | 'view' | 'version';
export const BANNER_OF: Partial<Record<WsState, BannerKind>> = {
  collaboratorOffline: 'collaborator',
  reconnecting: 'reconnecting',
  connectionLost: 'lost',
  viewOnly: 'view',
  versionHistory: 'version',
};

export const BANNER_COPY: Record<BannerKind, { title: string; detail: string }> = {
  collaborator: { title: 'Amara lost connection', detail: 'Her changes so far are saved. She will show up again when she is back online.' },
  reconnecting: { title: 'Reconnecting to the workspace', detail: 'Hold on. You can keep working and nothing will be lost.' },
  lost: { title: 'Connection lost', detail: 'Your changes are saved on this device. We will sync them when you are back online.' },
  view: { title: 'You can view and comment, but not edit', detail: 'Editing follows your role in this project. The project owner manages access.' },
  version: { title: 'Viewing the version from yesterday, 16:20', detail: 'This is a preview. The current version is not changed until you restore.' },
};

/** Project navigation shown in the Project menu (Figma 17602:6725). Every item links to its project page of the project the Workspace belongs to (NAV_PATHS in workspace/project.ts); the current page, Workspace, only closes the menu. */
/** The items of the Workspace project menu: the visible items of the project navigation (project.ts), Reflection and Launch were removed 5 Nov 2026. */
export const MENU_ITEMS = VISIBLE_NAV_ITEMS;

/** Version history rows (Figma "Workspace / Version row": Current, Default, Selected). */
export type VersionRow = { id: string; time: string; detail: string; current?: boolean };
export const VERSIONS: VersionRow[] = [
  { id: 'now', time: 'Today, 10:42', detail: 'Kemi Adeyemi, 3 changes', current: true },
  { id: 'today-0915', time: 'Today, 09:15', detail: 'Amara Obi, 12 changes' },
  { id: 'yest-1620', time: 'Yesterday, 16:20', detail: 'Ayo Bello, 5 changes' },
  { id: 'yest-1102', time: 'Yesterday, 11:02', detail: 'Kemi Adeyemi, 20 changes' },
  { id: 'oct12', time: '12 Oct, 15:40', detail: 'Amara Obi, 8 changes' },
  { id: 'oct11', time: '11 Oct, 09:30', detail: 'Kemi Adeyemi, first draft' },
];
export const DEFAULT_VERSION = 'yest-1620';

/** "Yesterday, 16:20" becomes "yesterday, 16:20" for the preview banner sentence. */
export const versionBannerTitle = (time: string) => `Viewing the version from ${time.charAt(0).toLowerCase()}${time.slice(1)}`;

/** One row of the People and access panel (Figma "Workspace / Person row"). */
export type PeopleRow = { id: PersonId; you?: boolean; note: string; avatar: AvatarState };
export const PEOPLE_ROWS: PeopleRow[] = [
  { id: 'kemi', you: true, note: 'Editing the executive summary', avatar: 'editing' },
  { id: 'amara', note: 'Editing the findings', avatar: 'editing' },
  { id: 'ayo', note: 'Commenting on the survey year', avatar: 'commenting' },
  { id: 'yusuf', note: 'Last seen yesterday', avatar: 'away' },
];
export const PEOPLE_SUMMARY = '4 people have access. 3 are here now.';
