'use client';

import { useState } from 'react';
import { Button, Radio } from '@/ui';
import { BackLink, Heading } from './cc-ui';
import { INTENTIONS, projectOption, R } from './data';
import { CcOverlays, type OverlayId } from './overlays';
import { ccStore, useCc } from './store';

/**
 * B2 Matching context (Figma 17215:15285). Route /collaborate/collaborators/matching.
 * Change project opens the Change project modal; the page then shows the chosen project (Figma 12.3 Project changed 17972:147145).
 */
export default function Matching() {
  const { intention, project } = useCc();
  const [ov, setOv] = useState<OverlayId | null>(null);
  const current = projectOption(project);
  return (
    <>
      <div className="cc-page cc-match">
        <div className="cc-match__intro">
          <Heading
            eyebrow="Your collaboration intention"
            title="Who would you like to work with?"
            support="Tell us what you’re looking for so we can recommend people who may be a meaningful fit."
          />
          <div className="cc-actions cc-actions--wide" data-m="up">
            <Button href={R.discovery} arrow="up-right">
              Show collaborators
            </Button>
            <BackLink href={R.entry}>Back</BackLink>
          </div>
        </div>

        <div className="cc-match__side">
          <div className="cc-options" role="radiogroup" aria-label="Who would you like to work with?" data-m="stagger">
            {INTENTIONS.map((o, i) => (
              <Radio
                key={o.id}
                variant="card"
                name="cc-intention"
                value={o.id}
                index={`0${i + 1}`}
                label={o.title}
                description={o.text}
                checked={intention === o.id}
                onChange={() => ccStore.setIntention(o.id)}
              />
            ))}
          </div>

          <section className="cc-with" aria-label="Matching with" data-m="up">
            <p className="cc-eyebrow">Matching with your approved brief</p>
            <h2 className="cc-with__name">{current.name}</h2>
            <p className="cc-with__line">{current.brief}</p>
            <div>
              <Button variant="link" onClick={() => setOv('project')}>
                Change project
              </Button>
            </div>
          </section>

          <p className="cc-note" data-m="up">
            No project yet? Choose “For my skills” or “For a shared interest” and we’ll use your profile and interests instead.
          </p>
        </div>
      </div>
      <CcOverlays open={ov} onClose={() => setOv(null)} />
    </>
  );
}
