'use client';

import type { ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { cx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { agreementsFor, type AgreementStatus, type Ack, type Stage } from './data';

/**
 * Pieces of the Agreements screens (12.22): Agreement Status 17729:92365, Stage Card 17729:92541 (the overview) and the member tiles of
 * the Acknowledgements card (Stage detail 17729:109768). The metric cards, the dashboard cards, the stage tracker and the segment bar
 * are the shared dashboard parts (workspace/dash.tsx). Every class is prefixed ag- and lives in agreements.css.
 */

/** The Agreements data of the project of the page being shown (Career Guidance for Everyone or Adire Stories). */
export const useAgreements = () => agreementsFor(useProject().key);

/* ------------------------------------------------------------------ Agreement Status */

const DOT: Record<AgreementStatus, string> = {
  'Not started': 'none',
  'In progress': 'progress',
  'Awaiting acknowledgement': 'awaiting',
  Acknowledged: 'done',
  'Needs review': 'review',
};

/** A dot and the status: filled green (Acknowledged), amber ring (Awaiting), amber dot (In progress), grey ring (Not started), ink dot (Needs review). */
export function StatusMark({ status }: { status: AgreementStatus }) {
  return (
    <span className="ag-status">
      <i className={cx('ag-status__dot', `ag-status__dot--${DOT[status]}`)} aria-hidden="true" />
      {status}
    </span>
  );
}

/* ------------------------------------------------------------------ headings */

/** Small uppercase heading above a block of the page (the section labels of the design). */
export const GroupLabel = ({ children }: { children: ReactNode }) => <h2 className="ag-label">{children}</h2>;

/* ------------------------------------------------------------------ Stage Card */

/**
 * Stage Card (Default, Hover, Pressed, Focus come from CSS). A card with a page of its own is one link; the others react to
 * hover and press but go nowhere, as in the prototype.
 */
export function StageCard({ stage }: { stage: Stage }) {
  const body = (
    <>
      <span className="ag-stage__top">
        <span className="ag-stage__label">{stage.label}</span>
        <StatusMark status={stage.status} />
      </span>
      <span className="ag-stage__title">{stage.title}</span>
      <span className="ag-stage__text">{stage.text}</span>
      <span className="ag-stage__note">{stage.note}</span>
    </>
  );
  return stage.href ? (
    <Link href={stage.href} className="ag-stage">
      {body}
    </Link>
  ) : (
    <button type="button" className="ag-stage">
      {body}
    </button>
  );
}

/* ------------------------------------------------------------------ member tile */

/**
 * A member of the Acknowledgements card: initials in a round muted avatar with a status dot (green acknowledged, amber waiting),
 * the name and role, then the status and its date. The tiles have no reaction in the design.
 */
export function AckTile({ ack }: { ack: Ack }) {
  return (
    <li className="ag-tile">
      <span className="ag-tile__av" aria-hidden="true">
        {ack.initials}
        <i className={cx('ag-tile__dot', ack.done ? 'ag-tile__dot--done' : 'ag-tile__dot--waiting')} />
      </span>
      <span className="ag-tile__text">
        <span className="ag-tile__name">{ack.name}</span>
        <span className="ag-tile__role">{ack.role}</span>
      </span>
      <span className="ag-tile__status">
        <span className={cx('ag-tile__state', ack.done && 'is-done')}>{ack.done ? 'Acknowledged' : 'Waiting'}</span>
        <span className="ag-tile__when">{ack.when}</span>
      </span>
    </li>
  );
}
