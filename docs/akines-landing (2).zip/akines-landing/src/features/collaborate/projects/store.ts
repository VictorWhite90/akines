'use client';

/**
 * In-memory state shared by the Discover, Project detail, Express interest and Saved screens.
 * It lives for the whole visit (module scope), so a project saved in Discover shows up in the Saved list.
 *
 * Saved projects: `saved` is the Saved list (most recent first). The Figma Saved list shows three projects while most Discover cards and
 * detail pages start unsaved, so `session` remembers which projects read as Saved on the cards (the bookmark turns into the Saved pill)
 * and `detail` which ones read as Saved on their detail page only. Figma draws Clean Water Mapping as Saved on its Discover card and detail
 * (12.5 and 17722:77401) but Voices of Lagos as Saved on its detail (17705:73482, "Akines shows it because you saved it") while its
 * Discover card still shows the bookmark. Buttons read the list that belongs to their screen; pressing one updates all three.
 */
import { useSyncExternalStore } from 'react';

type SavedState = { saved: string[]; session: string[]; detail: string[] };
let savedState: SavedState = {
  saved: ['a-better-way-to-learn', 'voices-of-lagos', 'clean-water-mapping'],
  session: ['clean-water-mapping'],
  detail: ['voices-of-lagos', 'clean-water-mapping'],
};
const savedListeners = new Set<() => void>();
const setSaved = (next: SavedState) => {
  savedState = next;
  savedListeners.forEach((l) => l());
};
const subSaved = (cb: () => void) => {
  savedListeners.add(cb);
  return () => {
    savedListeners.delete(cb);
  };
};
const getSaved = () => savedState;

export const useSavedState = () => useSyncExternalStore(subSaved, getSaved, getSaved);

/** Does the Save button of the detail page read Saved? */
export const isDetailSaved = (state: SavedState, slug: string) => state.session.includes(slug) || state.detail.includes(slug);

/** Save button of a card or a detail page: toggles. `view` says which screen the button is on. */
export function toggleSaved(slug: string, view: 'card' | 'detail' = 'card') {
  const { saved, session, detail } = savedState;
  const on = view === 'detail' ? isDetailSaved(savedState, slug) : session.includes(slug);
  if (on) {
    setSaved({ saved: saved.filter((s) => s !== slug), session: session.filter((s) => s !== slug), detail: detail.filter((s) => s !== slug) });
  } else {
    setSaved({ saved: saved.includes(slug) ? saved : [slug, ...saved], session: [...session, slug], detail });
  }
}
const removed = new Map<string, { session: boolean; detail: boolean }>();
/** Bookmark on the Saved list: removes the project. Returns the position it had so Undo can put it back. */
export function removeSaved(slug: string): number {
  const { saved, session, detail } = savedState;
  const at = saved.indexOf(slug);
  removed.set(slug, { session: session.includes(slug), detail: detail.includes(slug) });
  setSaved({ saved: saved.filter((s) => s !== slug), session: session.filter((s) => s !== slug), detail: detail.filter((s) => s !== slug) });
  return at < 0 ? 0 : at;
}
export function restoreSaved(slug: string, at: number) {
  const { saved, session, detail } = savedState;
  if (saved.includes(slug)) return;
  const next = saved.slice();
  next.splice(Math.min(at, next.length), 0, slug);
  const was = removed.get(slug);
  setSaved({ saved: next, session: was?.session ? [...session, slug] : session, detail: was?.detail ? [...detail, slug] : detail });
}

/* ---------------- interest requests ---------------- */

export type Interest = { role: string; time: string; message: string };
type InterestState = Record<string, Interest | undefined>;
let interestState: InterestState = {};
const interestListeners = new Set<() => void>();
const subInterest = (cb: () => void) => {
  interestListeners.add(cb);
  return () => {
    interestListeners.delete(cb);
  };
};
const getInterest = () => interestState;
export const useInterestState = () => useSyncExternalStore(subInterest, getInterest, getInterest);

export function setInterest(slug: string, value: Interest | undefined) {
  interestState = { ...interestState, [slug]: value };
  interestListeners.forEach((l) => l());
}

/* ---------------- first visit loading ---------------- */

const seen = new Set<string>();
/** True the first time `key` is asked for during this visit (the screen then shows its Loading frame). */
export const takeFirstVisit = (key: string): boolean => {
  if (seen.has(key)) return false;
  seen.add(key);
  return true;
};

/** Time the Loading frames stay up before the screen (Figma AFTER_TIMEOUT 2.5 s). */
export const LOADING_MS = 2500;
