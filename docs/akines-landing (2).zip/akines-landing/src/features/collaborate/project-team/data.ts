import { PATHS } from '../workspace/data';

/**
 * Sample data of the project Team pages (12.21): Team, Empty, Member detail, Interest request accepted, Request dismissed and the
 * overlays (Modal:Invite collaborator, Modal:Not now and the three toasts). Copy is taken word for word from the Figma frames.
 * Frames: Team 17729:100721, Empty 17729:110484, Member detail 17729:111084, Interest request accepted 17729:116651,
 * Request dismissed 17729:117247, Modal:Invite collaborator 17729:119986, Toast:Invitation sent 17729:120057,
 * Toast:Request accepted 17729:120064, Modal:Not now 17729:120071, Toast:Response sent 17729:120118.
 */

export const TEAM_PATHS = {
  team: PATHS.team,
  empty: `${PATHS.team}/state-empty`,
  member: `${PATHS.team}/adaeze-okoye`,
  accepted: `${PATHS.team}/state-request-accepted`,
  dismissed: `${PATHS.team}/state-request-dismissed`,
  /** Overlay frames: the parent page with the modal open or the toast showing. */
  inviteModal: `${PATHS.team}/state-invite-collaborator`,
  invitationSent: `${PATHS.team}/state-invitation-sent`,
  acceptedToast: `${PATHS.team}/state-request-accepted-toast`,
  notNowModal: `${PATHS.team}/state-not-now`,
  responseSent: `${PATHS.team}/state-response-sent`,
} as const;

export type Presence = 'working' | 'available' | 'away' | 'unshared';

export type TeamMember = {
  id: string;
  initials: string;
  name: string;
  role: string;
  presence: Presence;
  availability: string;
  skills: string[];
  recent: string;
  /** One line about what the person does on the project (the ABOUT block of the member slide-out). */
  about: string;
  /** Portrait photo (public/images/app/team); a member without one shows initials. */
  photo?: string;
  /** A wider crop of the portrait, for a card that has a whole row to itself (the fifth person of Interest request accepted). */
  photoWide?: string;
  /** The role of the person's own profile, when the member slide-out names it differently from the role they joined as (Amina Yusuf). */
  profileRole?: string;
  /** Only Adaeze Okoye has a member detail in the design. */
  href?: string;
};

export const KEMI: TeamMember = {
  id: 'kemi',
  initials: 'KA',
  name: 'Kemi Adeyemi (you)',
  role: 'Owner and Product Designer',
  presence: 'working',
  availability: 'Working on a milestone',
  skills: ['Product design', 'Facilitation', 'Prototyping'],
  recent: 'Set up the shared workspace.',
  about: 'Leads the project and shapes the product direction.',
  photo: '/images/app/team/kemi.jpg',
};

export const ADAEZE: TeamMember = {
  id: 'adaeze',
  initials: 'AO',
  name: 'Adaeze Okoye',
  role: 'Product Designer',
  presence: 'available',
  availability: 'Available for review',
  skills: ['Interface design', 'Prototyping', 'Design systems'],
  recent: 'Shared the second onboarding screen for review.',
  about: 'Designs the student-facing screens and helps the team review work.',
  photo: '/images/app/team/adaeze.jpg',
  href: TEAM_PATHS.member,
};

export const TOBI: TeamMember = {
  id: 'tobi',
  initials: 'TA',
  name: 'Tobi Adeyemi',
  role: 'Software Engineer',
  presence: 'working',
  availability: 'Working on a milestone',
  skills: ['Frontend engineering', 'Prototyping', 'Accessibility'],
  recent: 'Shared the student onboarding draft.',
  about: 'Builds the student onboarding screens in code.',
  photo: '/images/app/team/tobi.jpg',
};

export const NGOZI: TeamMember = {
  id: 'ngozi',
  initials: 'NE',
  name: 'Ngozi Eze',
  role: 'Career Researcher',
  presence: 'away',
  availability: 'Away',
  skills: ['Career research', 'Student interviews', 'Synthesis'],
  recent: 'Shared the career interview notes.',
  about: 'Runs the student interviews and turns them into findings.',
  photo: '/images/app/team/ngozi.jpg',
};

/** Amina's portrait (public/images/app/collab-people), used on her interest request and on her member card once she has joined. */
export const AMINA_PHOTO = '/images/app/collab-people/amina.jpg';
export const AMINA_PHOTO_WIDE = '/images/app/collab-people/amina-wide.jpg';

export const AMINA_MEMBER: TeamMember = {
  id: 'amina',
  initials: 'AY',
  name: 'Amina Yusuf',
  role: 'Product Designer',
  presence: 'unshared',
  availability: 'Availability not shared yet',
  skills: ['Career research', 'Student interviews', 'Survey design'],
  recent: 'Joined the project today.',
  about: 'Wants to help shape the first screens students see.',
  photo: AMINA_PHOTO,
  photoWide: AMINA_PHOTO_WIDE,
  profileRole: 'Career Researcher',
};

export const MEMBERS_BASE: TeamMember[] = [KEMI, ADAEZE, TOBI, NGOZI];
export const MEMBERS_ACCEPTED: TeamMember[] = [...MEMBERS_BASE, AMINA_MEMBER];

export const REQUEST = {
  name: 'Amina Yusuf',
  role: 'Career Researcher',
  photo: AMINA_PHOTO,
  sent: 'Interest sent 2 November',
  skills: ['Career research', 'Student interviews', 'Survey design'],
  wantsLabel: 'WANTS TO JOIN AS',
  wants: 'Product Designer',
  messageLabel: 'MESSAGE',
  message: 'I would like to help shape the first screens students see.',
};

/** The Team page in its four states (Team, Empty, Interest request accepted, Request dismissed). */
export type TeamView = 'team' | 'empty' | 'accepted' | 'dismissed';

export const HEAD = {
  label: 'TEAM',
  title: 'The people behind the work.',
  lead: 'Understand the strengths, roles and contributions that bring this project together.',
  invite: 'Invite collaborator',
  agreements: 'View team agreements',
  history: 'View contribution history',
};

/** The two metric cards of the page header (MEMBERS and INTEREST REQUESTS): the number and the caption under it; the amber dot marks a request that waits. */
export type TeamMetric = { value: string; caption: string; dot?: boolean };

export const FACTS: Record<TeamView, { members: TeamMetric; requests: TeamMetric }> = {
  team: { members: { value: '4', caption: 'people' }, requests: { value: '1', caption: 'waiting', dot: true } },
  empty: { members: { value: '1', caption: 'just you' }, requests: { value: '0', caption: 'none waiting' } },
  accepted: { members: { value: '5', caption: 'people' }, requests: { value: '0', caption: 'none waiting' } },
  dismissed: { members: { value: '4', caption: 'people' }, requests: { value: '0', caption: 'none waiting' } },
};

export const REQUESTS_BAND = {
  label: 'INTEREST REQUESTS',
  waiting: { title: 'One person would like to join.', support: 'People who pressed Express interest on this project. You decide who joins.' },
  none: { title: 'No requests waiting.', support: 'When someone expresses interest in joining, you will see it here.' },
};

export const CONFIRMATION = {
  accepted: 'Amina Yusuf joined the team as Product Designer.',
  dismissed: 'Response sent to Amina Yusuf.',
};

export const MEMBERS_BAND = {
  label: 'TEAM MEMBERS',
  support: 'Availability is shown only when a member chooses to share it.',
  four: 'Four people, one project.',
  five: 'Five people, one project.',
};

export const EMPTY = {
  title: 'Every project starts with someone.',
  text: 'Invite collaborators when you’re ready to build together.',
  action: 'Invite collaborator',
};

/* ---------------------------------------------------------------- context panel */

export const PANEL = {
  availability: 'TEAM AVAILABILITY',
  availabilityNote: 'Shown only for people who chose to share it.',
  soloNote: 'Shown only when a person chooses to share it.',
  health: 'TEAM HEALTH',
  healthTitle: 'Working well together.',
  themes: [
    { text: 'Strong alignment on purpose.', tone: 'green' as const },
    { text: 'Roles are clear to everyone.', tone: 'green' as const },
    { text: 'Workload needs further discussion.', tone: 'accent' as const },
  ],
  healthNote: 'Themes are combined from private check-ins. No one’s individual answers are shown.',
  soloHealth: 'When collaborators join and share private check-ins, a kind summary of how the team is working appears here.',
  session: 'UPCOMING SESSION',
  sessionTitle: 'Prototype review',
  sessionWhen: 'Thursday, 4:00 PM, 45 minutes',
  sessionWho: 'With Adaeze, Tobi and Ngozi',
};

/* ---------------------------------------------------------------- member detail */

export const DETAIL = {
  back: 'Back to team',
  label: 'TEAM MEMBER',
  name: 'Adaeze Okoye',
  initials: 'AO',
  lead: 'Product Designer. She designs the student-facing screens and helps the team review work.',
  fields: [
    [
      { label: 'PROJECT ROLE', value: 'Product Designer, supporting' },
      { label: 'EXPECTED CONTRIBUTION', value: 'Review work on the first student experience.' },
    ],
    [
      { label: 'RESPONSIBILITIES', value: 'Student-facing screens and design review.' },
      { label: 'WORKING PREFERENCES', value: 'Written feedback first, then a short call.' },
    ],
  ],
  skillsLabel: 'SKILLS',
  /** A dot marks a skill the member has used in project work. */
  skills: [
    { label: 'Interface design', used: true },
    { label: 'Prototyping', used: true },
    { label: 'Design systems', used: false },
    { label: 'Accessibility', used: false },
  ],
  skillsNote: 'A dot marks a skill Adaeze has used in project work.',
  availabilityLabel: 'AVAILABILITY',
  availabilityNote: 'Next planned session: Prototype review, Thursday at 4:00 PM. Shown because Adaeze chose to share it.',
  history: {
    label: 'CONTRIBUTION HISTORY',
    title: 'What Adaeze has contributed.',
    support: 'Recognises meaningful work. Hours online and message counts are never recorded.',
  },
};

export type Contribution = {
  id: string;
  type: string;
  work: string;
  context: string;
  date: string;
  acknowledgement?: string;
  /** Without it the row has no destination (the two Studio rows, since the Studio was removed 5 Nov 2026). */
  href?: string;
};

/** Contribution rows and where each goes in the prototype: nowhere (was the Studio), Decision discussion, Project brief, nowhere (was the Studio), Milestone detail, Agreements. */
export const CONTRIBUTIONS: Contribution[] = [
  { id: 'work', type: 'WORK SUBMITTED', work: 'Second onboarding screen', context: 'Shared the screen with the team for review.', date: 'Mon 2 Nov' },
  { id: 'decisions', type: 'DECISIONS INFLUENCED', work: 'Choose the onboarding approach', context: 'Argued for short, guided questions in the discussion.', date: 'Fri 30 Oct', href: PATHS.conversationsDecision },
  { id: 'milestones', type: 'MILESTONES COMPLETED', work: 'Project brief approved', context: 'Helped write the brief the team agreed on.', date: 'Mon 12 Oct', href: PATHS.brief },
  {
    id: 'peer',
    type: 'PEER ACKNOWLEDGEMENTS',
    work: 'Map the student journey',
    context: 'Clear annotations helped the team build from the map.',
    date: 'Tue 27 Oct',
    acknowledgement: 'Acknowledged by Tobi Adeyemi.',
  },
  { id: 'skills', type: 'SKILLS DEMONSTRATED', work: 'Interface design', context: 'Used on the first student experience screens.', date: 'Mon 2 Nov', href: PATHS.milestone },
  { id: 'credits', type: 'FINAL CREDITS', work: 'To be agreed', context: 'Final credits are agreed by the team before launch.', date: 'Not agreed yet', href: PATHS.agreements },
];

/* ---------------------------------------------------------------- overlays */

export const INVITE_MODAL = {
  eyebrow: 'INVITE COLLABORATOR',
  title: 'Who would you like to invite?',
  description: 'Invite someone by name or email. They choose whether to join.',
  name: { label: 'Name or email', placeholder: 'For example, name@example.com', hint: 'They will receive an invitation.' },
  role: { label: 'Role', placeholder: 'For example, Product Designer', hint: 'The role you have in mind for them.' },
  message: { label: 'Message', placeholder: 'Say why you would like them to join.', hint: 'Optional.' },
  send: 'Send invitation',
  cancel: 'Cancel',
};

export const NOT_NOW_MODAL = {
  eyebrow: 'NOT NOW',
  title: 'Reply to Amina?',
  description: 'This is not a no. Amina will see that now is not the right time.',
  to: { label: 'To', value: 'Amina Yusuf', hint: 'She will see your reply.' },
  message: { label: 'Message', placeholder: 'For example, We are not adding anyone just yet.', hint: 'Optional.' },
  send: 'Send',
  cancel: 'Cancel',
};

export const TOASTS = {
  invitation: 'Invitation sent. You will see their reply here.',
  accepted: 'Request accepted. Amina Yusuf is on the team.',
  response: 'Response sent. Amina Yusuf will see it.',
};

/* ---------------------------------------------------------------- Adire Stories */

/**
 * The same page for Adire Stories (the Digital Art project): the same shapes, counts and order as the Career data above, with the
 * Adire people and domain. Only the Team page is mirrored there. An answered request is shown in the page itself (see Team.tsx),
 * so the accepted and dismissed copy has an Adire version too. The member detail has none: Adire members have no `href`, so a
 * member card leads nowhere. Copy that names neither a person nor the domain is shared with the Career data, so the two stay in step.
 */

export const ART_KEMI: TeamMember = {
  id: 'kemi',
  initials: 'KA',
  name: 'Kemi Adeyemi (you)',
  role: 'Owner and Art Director',
  presence: 'working',
  availability: 'Working on a milestone',
  skills: ['Art direction', 'Facilitation', 'Sketching'],
  recent: 'Approved the series brief.',
  about: 'Leads the series and sets the art direction.',
  photo: '/images/app/team/kemi.jpg',
};

export const AMARA: TeamMember = {
  id: 'amara',
  initials: 'AO',
  name: 'Amara Obi',
  role: 'Illustrator',
  presence: 'available',
  availability: 'Available for review',
  skills: ['Line illustration', 'Sketching', 'Pattern repeats'],
  recent: 'Shared the headwrap colour layer for review.',
  about: 'Draws the line work for each headwrap illustration.',
  photo: '/images/app/team/amara.jpg',
};

export const AYO: TeamMember = {
  id: 'ayo',
  initials: 'AB',
  name: 'Ayo Bello',
  role: 'Colour Artist',
  presence: 'working',
  availability: 'Working on a milestone',
  skills: ['Colour palettes', 'Sketching', 'Print proofing'],
  recent: 'Shared the headwrap palette draft.',
  about: 'Chooses the colours and prepares the print proofs.',
  photo: '/images/app/team/ayo.jpg',
};

export const YUSUF: TeamMember = {
  id: 'yusuf',
  initials: 'YD',
  name: 'Yusuf Danjuma',
  role: 'Textile Historian',
  presence: 'away',
  availability: 'Away',
  skills: ['Resist patterns', 'Cloth documentation', 'Pattern notes'],
  recent: 'Shared the dyer interview notes.',
  about: 'Researches the history behind each resist pattern.',
  photo: '/images/app/team/yusuf.jpg',
};

/** Bisi's skills, shared by her interest request and her member card once she has joined. */
const BISI_SKILLS = ['Resist patterns', 'Cloth documentation', 'Dye pot notes'];

/** Bisi uses the same portrait as the Career request, so the Adire page looks like the Career frames it is cloned from. */
export const BISI_MEMBER: TeamMember = {
  id: 'bisi',
  initials: 'BA',
  name: 'Bisi Adeoye',
  role: 'Illustrator',
  presence: 'unshared',
  availability: 'Availability not shared yet',
  skills: BISI_SKILLS,
  recent: 'Joined the project today.',
  about: 'Wants to help draw the resist patterns for the next plates.',
  photo: AMINA_PHOTO,
  profileRole: 'Adire Dyer, Abeokuta',
};

export const ART_REQUEST: typeof REQUEST = {
  name: 'Bisi Adeoye',
  role: 'Adire Dyer, Abeokuta',
  photo: AMINA_PHOTO,
  sent: 'Interest sent 3 November',
  skills: BISI_SKILLS,
  wantsLabel: 'WANTS TO JOIN AS',
  wants: 'Illustrator',
  messageLabel: 'MESSAGE',
  message: 'I would like to help draw the resist patterns for the next plates.',
};

export const ART_MEMBERS_BASE: TeamMember[] = [ART_KEMI, AMARA, AYO, YUSUF];
export const ART_MEMBERS_ACCEPTED: TeamMember[] = [...ART_MEMBERS_BASE, BISI_MEMBER];

/** Everything the Team page reads from the data, per project (the same keys, counts and order). */
export type TeamData = {
  /** The four members of the team, owner first. */
  members: TeamMember[];
  /** The same four and the person whose request was accepted. */
  accepted: TeamMember[];
  request: typeof REQUEST;
  head: typeof HEAD;
  facts: typeof FACTS;
  requestsBand: typeof REQUESTS_BAND;
  confirmation: typeof CONFIRMATION;
  membersBand: typeof MEMBERS_BAND;
  empty: typeof EMPTY;
  panel: typeof PANEL;
  invite: typeof INVITE_MODAL;
  notNow: typeof NOT_NOW_MODAL;
  toasts: typeof TOASTS;
};

export const CAREER_TEAM: TeamData = {
  members: MEMBERS_BASE,
  accepted: MEMBERS_ACCEPTED,
  request: REQUEST,
  head: HEAD,
  facts: FACTS,
  requestsBand: REQUESTS_BAND,
  confirmation: CONFIRMATION,
  membersBand: MEMBERS_BAND,
  empty: EMPTY,
  panel: PANEL,
  invite: INVITE_MODAL,
  notNow: NOT_NOW_MODAL,
  toasts: TOASTS,
};

export const ART_TEAM: TeamData = {
  members: ART_MEMBERS_BASE,
  accepted: ART_MEMBERS_ACCEPTED,
  request: ART_REQUEST,
  head: HEAD,
  facts: FACTS,
  requestsBand: REQUESTS_BAND,
  confirmation: {
    accepted: 'Bisi Adeoye joined the team as Illustrator.',
    dismissed: 'Response sent to Bisi Adeoye.',
  },
  membersBand: MEMBERS_BAND,
  empty: EMPTY,
  panel: { ...PANEL, sessionTitle: 'Colour review', sessionWho: 'With Amara, Ayo and Yusuf' },
  invite: { ...INVITE_MODAL, role: { ...INVITE_MODAL.role, placeholder: 'For example, Illustrator' } },
  notNow: {
    ...NOT_NOW_MODAL,
    title: 'Reply to Bisi?',
    description: 'This is not a no. Bisi will see that now is not the right time.',
    to: { ...NOT_NOW_MODAL.to, value: 'Bisi Adeoye' },
  },
  toasts: {
    ...TOASTS,
    accepted: 'Request accepted. Bisi Adeoye is on the team.',
    response: 'Response sent. Bisi Adeoye will see it.',
  },
};

/** The Team data of a project (`key` is the project key of useProject(), 'career' or 'adire'). */
export const teamFor = (key: 'career' | 'adire'): TeamData => (key === 'adire' ? ART_TEAM : CAREER_TEAM);
