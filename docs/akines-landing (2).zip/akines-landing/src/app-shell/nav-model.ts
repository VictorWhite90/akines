import type { MainPage } from '@/routes.types';

export type NavTab = { label: string; path: string };
export type NavPage = { key: MainPage; label: string; path: string; icon: AppIconName; tabs: NavTab[] };
export type AppIconName =
  | 'home' | 'connect' | 'collaborate' | 'make-sell' | 'explore' | 'care'
  | 'messages' | 'notifications' | 'chevron-down' | 'user' | 'user-check' | 'settings' | 'help' | 'log-out';

/** Canonical paths of the six main pages and their sub tabs (the sub row of the header). Features register routes at these paths. */
export const NAV: NavPage[] = [
  { key: 'community', label: 'Community Home', path: '/community', icon: 'home', tabs: [] },
  {
    key: 'connect', label: 'Connect', path: '/connect', icon: 'connect',
    tabs: [
      { label: 'Discover', path: '/connect' },
      { label: 'KinCircle', path: '/connect/kincircle' },
      { label: 'Rooms', path: '/connect/rooms' },
      { label: 'Banter', path: '/connect/banter' },
      { label: 'Activities', path: '/connect/activities' },
    ],
  },
  {
    key: 'collaborate', label: 'Collaborate', path: '/collaborate', icon: 'collaborate',
    tabs: [
      { label: 'Home', path: '/collaborate' },
      { label: 'Discover Projects', path: '/collaborate/discover' },
      { label: 'My Projects', path: '/collaborate/my-projects' },
      { label: 'Collaborators', path: '/collaborate/collaborators' },
      { label: 'Opportunities', path: '/collaborate/opportunities' },
      { label: 'My Contributions', path: '/collaborate/contributions' },
    ],
  },
  {
    key: 'make-sell', label: 'Make & Sell', path: '/make-sell', icon: 'make-sell',
    tabs: [
      { label: 'My Studio', path: '/make-sell' },
      { label: 'My Journal', path: '/make-sell/journal' },
      { label: 'My Store', path: '/make-sell/store' },
    ],
  },
  {
    key: 'explore', label: 'Explore', path: '/explore', icon: 'explore',
    tabs: [
      { label: 'Shop Art', path: '/explore' },
      { label: 'Studio Visits', path: '/explore/studio-visits' },
      { label: 'Stories and Legacy', path: '/explore/stories' },
    ],
  },
  {
    key: 'care', label: 'Care', path: '/care', icon: 'care',
    tabs: [
      { label: 'Creative Wellbeing', path: '/care' },
      { label: 'Creative DNA', path: '/care/creative-dna' },
    ],
  },
];

export const pageOf = (key: MainPage) => NAV.find((p) => p.key === key)!;

/** Avatar menu and header icon destinations. */
export const DEST = {
  messages: '/community/messages',
  settings: '/community/settings',
  profile: '/profile',
  completeProfile: '/profile/complete',
  help: '/help',
} as const;

/** Sample counters shown in the header (design: Messages 3, Notifications 12). */
export const COUNTERS = { messages: 3, notifications: 12 } as const;
export const counterText = (n: number) => (n > 99 ? '99+' : String(n));
