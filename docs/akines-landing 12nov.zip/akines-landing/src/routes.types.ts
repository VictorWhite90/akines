import type { ComponentType } from 'react';

/** The six main pages of the signed-in header. */
export type MainPage = 'community' | 'connect' | 'collaborate' | 'make-sell' | 'explore' | 'care';

export type RouteDef = {
  /** Static path, starts with "/". */
  path: string;
  /** Browser tab title (without the " | Akines" suffix). */
  title: string;
  /**
   * site : public page, no app header (landing, join). Signed in or not.
   * app  : signed-in screen with the app header and (tablet, mobile) bottom bar. Signed-out visitors are sent to the sign-in panel.
   * bare : nothing around it (404).
   */
  shell: 'site' | 'app' | 'bare';
  /** Which main page and sub tab are active in the header (shell "app" only). Tab is the label shown in the sub row. */
  nav?: { page: MainPage; tab?: string };
  /**
   * Phone layout (below 768 px) of an app screen, from the Figma V2 Mobile designs.
   * bar "main" (default): the mobile header with logo, page title and avatar. bar "top": a top bar with a back button and `title`
   * instead (sub-pages); `back` is the path the back button opens. bottomBar false hides the bottom tab bar (chat threads).
   */
  mobile?: { bar?: 'main' | 'top'; title?: string; back?: string; bottomBar?: boolean };
  /** The screen. Must be a client component ('use client' at the top of its file). */
  component: ComponentType;
};
