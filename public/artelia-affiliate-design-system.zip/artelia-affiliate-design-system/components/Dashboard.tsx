"use client";

import {
  ArrowDownRight, ArrowUpRight, ArrowUpRightFromSquare, ChartNoAxesColumnIncreasing,
  ChevronDown, CircleDollarSign, Copy, Image as ImageIcon, LayoutDashboard,
  Palette, Plus, Settings2, ShoppingBag, Wallet, ExternalLink, Store
} from "lucide-react";

const navItems = [
  { label: "Overview", icon: LayoutDashboard, active: true, href: "/dashboard" },
  { label: "My storefront", icon: Palette, href: "/dashboard/storefront" },
  { label: "Orders", icon: ShoppingBag, href: "/dashboard/orders" },
  { label: "Earnings", icon: CircleDollarSign, href: "/dashboard/earnings" },
  { label: "Payouts", icon: Wallet, href: "/dashboard/payouts" },
  { label: "Settings", icon: Settings2, href: "/dashboard/settings" },
];

const stats = [
  { label: "Orders", value: "01", note: "Orders received", icon: ShoppingBag },
  { label: "Sales value", value: "₦1,868", note: "Total artwork sales", icon: ChartNoAxesColumnIncreasing },
  { label: "Commission earned", value: "₦0", note: "Total commission", icon: Wallet },
  { label: "Pieces live", value: "17", note: "Published artworks", icon: ImageIcon },
];

function Sidebar() {
  return (
    <aside className="sidebar">
      <a className="brand" href="/dashboard" aria-label="Artelia Affiliate home">
        <span className="brand-mark">A</span>
        <span>
          <span className="brand-name">Artelia</span>
          <span className="brand-subtitle" style={{ display: "block" }}>PRIVATE STORE</span>
        </span>
      </a>

      <div className="nav-label">WORKSPACE</div>
      <nav className="nav-list" aria-label="Main navigation">
        {navItems.map(({ label, icon: Icon, active, href }) => (
          <a key={label} href={href} className={`nav-link${active ? " active" : ""}`}>
            <Icon size={17} strokeWidth={1.8} />
            <span>{label}</span>
          </a>
        ))}
      </nav>

      <div className="sidebar-bottom">
        <div className="profile-row">
          <div className="avatar">V</div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div className="profile-name">Victor Chinedu</div>
            <div className="profile-caption">Artist account</div>
          </div>
          <ChevronDown size={15} color="var(--color-muted)" />
        </div>
      </div>
    </aside>
  );
}

function StatCard({ item }: { item: (typeof stats)[number] }) {
  const Icon = item.icon;
  return (
    <article className="card stat-card">
      <div className="stat-top">
        <span>{item.label}</span>
        <span className="icon-chip"><Icon size={16} strokeWidth={1.8} /></span>
      </div>
      <div className="stat-value">{item.value}</div>
      <div className="stat-note">{item.note}</div>
    </article>
  );
}

function ArtworkCard({ title, price, variant }: { title: string; price: string; variant: string }) {
  return (
    <article className="artwork-card">
      <div className={`artwork-image ${variant}`} role="img" aria-label={`Artwork preview for ${title}`} />
      <div className="artwork-info">
        <div className="artwork-title">{title}</div>
        <div className="artwork-meta">
          <span>{price}</span>
          <span className="status"><span className="status-dot" />Live</span>
        </div>
      </div>
    </article>
  );
}

export default function Dashboard() {
  return (
    <div className="app-shell">
      <Sidebar />
      <main className="main-area">
        <header className="topbar">
          <div className="topbar-title">Overview</div>
          <div className="topbar-actions">
            <a className="button" href="/storefront"><ExternalLink size={14} /> View storefront</a>
            <button className="button" aria-label="Open account menu">
              <span className="avatar" style={{ width: 28, height: 28, fontSize: 11 }}>V</span>
              <span>Account</span><ChevronDown size={14} />
            </button>
          </div>
        </header>

        <div className="dashboard-content">
          <section className="page-intro">
            <div>
              <div className="eyebrow">Monday, 9 November</div>
              <h1 className="page-heading">Your art. Your business.</h1>
              <p className="page-description">A look at how your private storefront is performing.</p>
            </div>
            <div className="actions">
              <a className="button" href="/dashboard/storefront">Manage storefront</a>
              <a className="button button-primary" href="/dashboard/artworks/new"><Plus size={15} /> Add artwork</a>
            </div>
          </section>

          <section className="stats-grid" aria-label="Store performance">
            {stats.map((item) => <StatCard key={item.label} item={item} />)}
          </section>

          <section className="dashboard-grid">
            <article className="card earnings-panel">
              <div className="earnings-label">AVAILABLE EARNINGS</div>
              <div className="earnings-value">₦0.00</div>
              <div className="earnings-meta">
                <div><span>Next payout</span><strong>1st of the month</strong></div>
                <div><span>Paid to date</span><strong>₦0.00</strong></div>
              </div>
              <div className="earnings-footer">
                <small><Wallet size={13} style={{ verticalAlign: "middle", marginRight: 6 }} /> Payout account ending ••8869</small>
                <a className="text-link" href="/dashboard/payouts">Payout history <ArrowUpRight size={14} /></a>
              </div>
            </article>

            <article className="card panel">
              <div className="panel-heading">
                <div>
                  <h2 className="panel-title">Your private store</h2>
                  <p className="panel-description">Your collection, ready to be discovered.</p>
                </div>
                <Store size={19} color="var(--color-muted)" />
              </div>
              <div className="eyebrow">YOUR STOREFRONT LINK</div>
              <div className="store-link-box">
                <span className="store-url">artelia.seismicconsults.com/a/VictorChinedu</span>
                <Copy size={15} color="var(--color-muted)" />
              </div>
              <div className="store-actions">
                <button className="button button-accent"><Copy size={14} /> Copy store link</button>
                <a className="button" href="/storefront" aria-label="Open storefront"><ArrowUpRightFromSquare size={15} /></a>
              </div>
            </article>
          </section>

          <section className="section-block card panel">
            <div className="panel-heading">
              <div>
                <h2 className="panel-title">Your collection</h2>
                <p className="panel-description">A quick look at the artworks currently on your storefront.</p>
              </div>
              <a className="text-link" href="/dashboard/storefront">Manage collection <ArrowUpRight size={14} /></a>
            </div>
            <div className="artwork-grid">
              <ArtworkCard title="Evening in the Highlands" price="₦85,000" variant="" />
              <ArtworkCard title="Quiet Forms" price="₦120,000" variant="artwork-two" />
              <ArtworkCard title="The Warmth Within" price="₦65,000" variant="artwork-three" />
            </div>
          </section>

          <section className="section-block card panel">
            <div className="panel-heading">
              <div>
                <h2 className="panel-title">Sales activity</h2>
                <p className="panel-description">Track how your collection is performing over time.</p>
              </div>
              <div className="segmented" aria-label="Sales period">
                <button className="selected">This week</button>
                <button>Last month</button>
                <button>6 months</button>
              </div>
            </div>
            <div className="chart-placeholder">
              <span>Sales activity chart will appear here</span>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
