/**
 * Where the meeting screens live, per project (the Lobby is the folder itself). Kept out of store.ts because routes.tsx calls it while the
 * route tables are built, which also happens on the server, and store.ts is a client module.
 */
export const meetPaths = (root: string) => ({
  lobby: `${root}/meet`,
  lobbyOff: `${root}/meet/state-camera-off`,
  call: `${root}/meet/call`,
  sharing: `${root}/meet/state-screen-sharing`,
  people: `${root}/meet/state-people`,
  chat: `${root}/meet/state-chat`,
  ended: `${root}/meet/ended`,
});
export type MeetPaths = ReturnType<typeof meetPaths>;
