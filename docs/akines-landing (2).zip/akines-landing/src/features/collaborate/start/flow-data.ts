/**
 * Copy, defaults and brief derivation for 12.2 Start a project (Figma frames 17212:12198 to 17219:17944).
 * Every field starts prefilled with the dummy project from the Figma frames, so pressing Next completes the flow.
 */

/** Where the controls go. Canonical Collaborate paths from BUILD_GUIDE; B2 (Matching context) belongs to the people part. */
export const PATHS = {
  home: '/collaborate',
  start: '/collaborate/start',
  /** Review brief / Draft removed (Figma 17974:155087): where Undo of the Draft saved toast leads. */
  draftRemoved: '/collaborate/start/state-draft-removed',
  collaborators: '/collaborate/collaborators',
  matching: '/collaborate/collaborators/matching',
  myProjects: '/collaborate/my-projects',
  project: '/collaborate/my-projects/career-guidance-for-everyone',
  /** Saved Adire Stories project: it opens its own Overview. */
  artProject: '/collaborate/my-projects/adire-stories',
  community: '/community',
} as const;

export type StepId =
  | 'entry'
  | 'idea'
  | 'q1'
  | 'q2'
  | 'q3'
  | 'q4'
  | 'stage'
  | 'people'
  | 'workspace'
  | 'workspace-accepted'
  | 'workspace-art'
  | 'workspace-art-accepted'
  | 'preparing'
  | 'error'
  | 'review'
  | 'ready';

/* ------------------------------------------------------------------ Step 1: idea */
export type Choice = { id: string; title: string; text?: string };

export const IDEA_TYPES: Choice[] = [
  { id: 'business', title: 'A business' },
  { id: 'application', title: 'An application' },
  { id: 'film', title: 'A film' },
  { id: 'research', title: 'A research project' },
  { id: 'community', title: 'A community initiative' },
  { id: 'book', title: 'A book' },
  { id: 'event', title: 'An event' },
  { id: 'course', title: 'A course' },
  { id: 'impact', title: 'A social-impact intervention' },
  { id: 'other', title: 'Something else' },
];

/* ------------------------------------------------------------------ Step 2: purpose */
export type Question = { id: 'q1' | 'q2' | 'q3' | 'q4'; title: string; label: string; placeholder: string };

export const QUESTIONS: Question[] = [
  { id: 'q1', title: 'What problem are you trying to solve?', label: 'The problem', placeholder: 'Describe the challenge or opportunity you’ve identified...' },
  { id: 'q2', title: 'Who is this for?', label: 'Who benefits', placeholder: 'Tell us about the people this project is intended to help...' },
  { id: 'q3', title: 'What would success look like?', label: 'Desired outcome', placeholder: 'What would you like to achieve?' },
  { id: 'q4', title: 'Why do you care about this?', label: 'Why it matters', placeholder: 'What makes this idea meaningful to you?' },
];

/* ------------------------------------------------------------------ Step 3 and 4 */
export const STAGES: (Choice & { sentence: string })[] = [
  { id: 'idea', title: 'Just an idea', text: 'I have an idea, but I haven’t started developing it.', sentence: 'The idea is still taking shape and has not been developed yet.' },
  { id: 'exploring', title: 'Exploring', text: 'I’m researching the opportunity and understanding what is possible.', sentence: 'The opportunity is being researched and the possibilities are becoming clearer.' },
  { id: 'planning', title: 'Ready to plan', text: 'I have a clearer direction and want to establish the next steps.', sentence: 'A clearer direction is in place and the next steps are still to be established.' },
  { id: 'building', title: 'Already building', text: 'I’m actively working on the project.', sentence: 'Work on the project is already under way.' },
  { id: 'skills', title: 'Looking for missing skills', text: 'The project is moving, but I need additional expertise.', sentence: 'The project is moving and needs additional expertise.' },
  { id: 'launch', title: 'Preparing to launch', text: 'The project is approaching completion and needs support to reach its audience.', sentence: 'The project is approaching completion and needs support to reach its audience.' },
];

export const NEEDS: Choice[] = [
  { id: 'collaborators', title: 'Collaborators', text: 'People who can work with you to develop and deliver the project.' },
  { id: 'mentorship', title: 'Mentorship', text: 'Experienced people who can provide guidance and perspective.' },
  { id: 'technical', title: 'Technical expertise', text: 'People with specialist technical skills.' },
  { id: 'research', title: 'Research', text: 'People who can investigate, analyse or validate the project.' },
  { id: 'funding', title: 'Funding', text: 'Resources or financial support to help the project progress.' },
  { id: 'distribution', title: 'Distribution', text: 'People or resources that can help the project reach its audience.' },
  { id: 'customers', title: 'Customers or users', text: 'People who can provide feedback, validate the idea or use the outcome.' },
];

/* ------------------------------------------------------------------ answers */
export type Answers = {
  type: string;
  idea: string;
  q: Record<Question['id'], string>;
  stage: string;
  needs: string[];
};

export const DEFAULT_ANSWERS: Answers = {
  type: 'application',
  idea: 'I want to build a career guidance platform for Nigerian students who are choosing what to study.',
  q: {
    q1: 'Many secondary school students in Nigeria choose what to study without reliable guidance, and often only learn about their options after they have committed.',
    q2: 'Secondary school and early university students in Nigeria, and the teachers and parents who support their decisions.',
    q3: 'Students explore careers with confidence and make study choices they understand and can explain.',
    q4: 'I remember choosing my own path with very little guidance, and I want the next generation to have more.',
  },
  stage: 'planning',
  needs: ['collaborators', 'research'],
};

/**
 * The second sample project, Adire Stories (the Digital Art Workspace of 12.16). The 12.18 route starts with these answers,
 * and typing an art idea in step 1 leads to the same recommendation.
 */
export const ART_ANSWERS: Answers = {
  type: 'other',
  idea: 'I want to create an illustrated series that celebrates adire textile patterns and the people who make them.',
  q: {
    q1: 'Adire patterns carry stories, but few contemporary illustrators draw them, so younger people rarely see those stories told.',
    q2: 'Young Nigerians and the diaspora who love textiles and illustration, and the dyers who keep the craft alive.',
    q3: 'A finished series of illustrated portraits and patterns that people want to print, share and keep.',
    q4: 'My grandmother dyed adire cloth, and I want its patterns to be seen and remembered.',
  },
  stage: 'building',
  needs: ['collaborators', 'distribution'],
};

const same = (a: string, b: string) => a.trim() === b.trim();
/** True when the answers after the idea (the four answers, the stage and the people) are still exactly the sample project's. */
const restIsSample = (a: Answers, s: Answers) =>
  (['q1', 'q2', 'q3', 'q4'] as const).every((k) => same(a.q[k], s.q[k])) && a.stage === s.stage && [...a.needs].sort().join() === [...s.needs].sort().join();
/** True when the answers are still exactly the given sample project's answers (the chosen type does not matter, the brief does not use it). */
export const isSample = (a: Answers, s: Answers) => same(a.idea, s.idea) && restIsSample(a, s);

/* ------------------------------------------------------------------ brief */
export type BriefId = 'name' | 'overview' | 'purpose' | 'problem' | 'audience' | 'outcome' | 'stage' | 'support';
export type Brief = Record<BriefId, string>;

export const BRIEF_SECTIONS: { id: BriefId; label: string; title?: boolean }[] = [
  { id: 'name', label: 'Project name', title: true },
  { id: 'overview', label: 'Project overview' },
  { id: 'purpose', label: 'Purpose' },
  { id: 'problem', label: 'Problem' },
  { id: 'audience', label: 'Audience' },
  { id: 'outcome', label: 'Desired outcome' },
  { id: 'stage', label: 'Current stage' },
  { id: 'support', label: 'Support needed' },
];

/** The brief as designed (Figma 17212:13803 frame A7), used while the answers are the dummy answers. */
export const FIGMA_BRIEF: Brief = {
  name: 'Career Guidance for Everyone',
  overview: 'A career guidance platform that helps Nigerian secondary school students explore careers, understand their options and make confident decisions about what to study.',
  purpose: 'Many students choose their path without reliable guidance. This project exists to make career guidance accessible to every student, wherever they are.',
  problem: 'Students in Nigeria often choose subjects and courses with limited information, and only learn about their options after they have committed.',
  audience: 'Secondary school and early university students in Nigeria, and the teachers and parents who support their decisions.',
  outcome: 'Students explore careers with confidence and make study choices they understand and can explain.',
  stage: 'Ready to plan. A clearer direction is in place and the next steps are still to be established.',
  support: 'Collaborators with research and product design skills, technical expertise, and mentors who understand how students make career decisions.',
};

/** The brief of the second sample project, used while the answers are the Adire Stories answers. */
export const ART_BRIEF: Brief = {
  name: 'Adire Stories',
  overview: 'A shared illustration series that celebrates adire textile patterns and the people who make them.',
  purpose: 'Adire patterns carry stories that few illustrators have drawn. This project exists to bring those patterns, and the people behind them, to a wider audience.',
  problem: 'Adire is part of everyday Nigerian life, yet younger people rarely see its patterns told as stories in contemporary illustration.',
  audience: 'Young Nigerians and the diaspora who love textiles and illustration, and the dyers and makers who keep the craft alive.',
  outcome: 'A finished series of illustrated portraits and patterns that people want to print, share and keep.',
  stage: 'Already building. Work on the project is already under way.',
  support: 'Collaborators with illustration and colour skills, and help to share the series with its audience.',
};

const firstSentence = (s: string) => {
  const t = s.trim().replace(/\s+/g, ' ');
  const m = t.match(/^.*?[.!?](?=\s|$)/);
  return (m ? m[0] : t).trim();
};
const ensureStop = (s: string) => (/[.!?]$/.test(s.trim()) ? s.trim() : s.trim() + '.');
const cap = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const lower = (s: string) => (s ? s.charAt(0).toLowerCase() + s.slice(1) : s);

export const typeOf = (id: string) => IDEA_TYPES.find((t) => t.id === id);
export const stageOf = (id: string) => STAGES.find((s) => s.id === id);

/** "Collaborators and research", "Mentorship, research and funding": first word capitalised, the rest lower case. */
export function needsPhrase(ids: string[]): string {
  const names = NEEDS.filter((n) => ids.includes(n.id)).map((n, i) => (i === 0 ? n.title : lower(n.title)));
  if (names.length === 0) return 'Nothing chosen yet';
  if (names.length === 1) return names[0];
  return names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1];
}

/** "Collaborators, research" (A8 meta row). */
export const needsShort = (ids: string[]): string => {
  const names = NEEDS.filter((n) => ids.includes(n.id)).map((n, i) => (i === 0 ? n.title : lower(n.title)));
  return names.length ? names.join(', ') : 'To be decided';
};

const WORDS = ['No', 'One', 'Two', 'Three', 'Four'];

/** Value of the "Your idea" row on the Preparing panel (A6): "An application: a career guidance platform for Nigerian students". */
export function ideaLine(a: Answers): string {
  const type = typeOf(a.type)?.title ?? 'Your idea';
  if (same(a.idea, DEFAULT_ANSWERS.idea) && a.type === DEFAULT_ANSWERS.type) return 'An application: a career guidance platform for Nigerian students';
  if (same(a.idea, ART_ANSWERS.idea) && a.type === ART_ANSWERS.type) return 'Something else: an illustrated series that celebrates adire textile patterns';
  const s = stripIntro(firstSentence(a.idea).replace(/[.!?]$/, ''));
  if (!s) return type;
  const short = s.length > 90 ? s.slice(0, 88).trimEnd() + '...' : s;
  return `${type}: ${lower(short)}`;
}

/** Value of the "Your purpose" row on the Preparing panel (A6). */
export function purposeLine(a: Answers): string {
  const n = (['q1', 'q2', 'q3', 'q4'] as const).filter((k) => a.q[k].trim()).length;
  if (n === 4) return 'Four answers about the problem, the people and the change you hope to make';
  if (n === 0) return 'Not added yet. You can still add this later';
  return `${WORDS[n]} ${n === 1 ? 'answer' : 'answers'} about the problem, the people and the change you hope to make`;
}

const FALLBACK_NAME = 'My project idea';

/** "I want to build a career guidance platform" becomes "build a career guidance platform". */
const stripIntro = (s: string) =>
  s.replace(/^(i['’]ve been thinking about|i have been thinking about|i['’]m thinking about|i am thinking about|i want to|i would like to|i['’]d like to|i hope to|i plan to)\s+/i, '');

function deriveName(a: Answers): string {
  const raw = firstSentence(a.idea).replace(/[.!?]$/, '');
  if (!raw) return FALLBACK_NAME;
  const stripped = stripIntro(raw).replace(/^(build|create|make|start|launch|write|run|design|develop|organise|organize|explore)(ing)?\s+((an|a|the)\s+)?/i, '');
  const words = stripped.split(/\s+/).filter(Boolean).slice(0, 5);
  if (words.length < 2) return FALLBACK_NAME;
  return cap(words.join(' ').replace(/[,;:]$/, ''));
}

/**
 * The brief shown on A7. With the dummy answers it is the Figma copy (or the Adire Stories brief for the art sample); with other answers each section is built from what
 * the person wrote, so editing an answer changes the brief.
 */
export function buildBrief(a: Answers): Brief {
  if (isSample(a, DEFAULT_ANSWERS)) return { ...FIGMA_BRIEF };
  if (isSample(a, ART_ANSWERS)) return { ...ART_BRIEF };
  const stage = stageOf(a.stage);
  const none = 'Not added yet. Use Edit to add it.';
  const idea = a.idea.trim();
  const overview = idea ? (idea.length > 220 ? ensureStop(firstSentence(idea)) : ensureStop(idea)) : none;
  const needs = NEEDS.filter((n) => a.needs.includes(n.id));
  return {
    name: deriveName(a),
    overview,
    purpose: a.q.q4.trim() ? ensureStop(a.q.q4) : none,
    problem: a.q.q1.trim() ? ensureStop(a.q.q1) : none,
    audience: a.q.q2.trim() ? ensureStop(a.q.q2) : none,
    outcome: a.q.q3.trim() ? ensureStop(a.q.q3) : none,
    stage: stage ? `${stage.title}. ${stage.sentence}` : none,
    support: needs.length ? `${needsPhrase(a.needs)} to help move this project forward.` : none,
  };
}

/* ------------------------------------------------------------------ Workspace recommendation (12.17 Research, 12.18 Digital art) */
export type WorkspaceKind = 'research' | 'art';

/** Words that point to visual creation. The Q1 project types have no art type, so the idea and the four answers decide. */
const ART_WORDS =
  /\b(art|arts|artist|artists|artwork|artworks|illustrat\w*|paint\w*|draw|drawing|drawings|sketch\w*|canvas|mural\w*|comic|comics|cartoon\w*|animation|animations|animated|textile|textiles|adire|ankara|poster|posters|graphic|graphics|photograph\w*|visual|visuals|collage\w*)\b/i;

/**
 * Which Workspace Create AI recommends once the person has said who they need: Digital art when the idea or the answers
 * are about making visual work, Research otherwise (a research project always gets Research). Used by the web flow
 * (12.17, 12.18) and by the Create AI chat so both recommend the same thing.
 */
export function recommendWorkspace(a: Answers): WorkspaceKind {
  if (isSample(a, ART_ANSWERS)) return 'art';
  if (a.type === 'research') return 'research';
  const text = [a.idea, a.q.q1, a.q.q2, a.q.q3, a.q.q4].join(' ');
  return ART_WORDS.test(text) ? 'art' : 'research';
}

/**
 * The prefilled answers follow the idea. While the steps after it still hold a sample project's answers, an art idea brings the
 * Adire Stories answers and any other idea brings the first sample's again, so pressing Continue all the way through completes
 * the flow for either idea. Answers the person has changed are never touched.
 */
export function followIdea(a: Answers): Answers {
  const art = a.type !== 'research' && ART_WORDS.test(a.idea);
  if (art && restIsSample(a, DEFAULT_ANSWERS)) return { ...a, q: { ...ART_ANSWERS.q }, stage: ART_ANSWERS.stage, needs: [...ART_ANSWERS.needs] };
  if (!art && restIsSample(a, ART_ANSWERS)) return { ...a, q: { ...DEFAULT_ANSWERS.q }, stage: DEFAULT_ANSWERS.stage, needs: [...DEFAULT_ANSWERS.needs] };
  return a;
}

export type WorkspaceCopy = {
  name: string;
  why: string;
  /** four features, shown two per row */
  features: [string, string, string, string];
  /** Figma "Photo / workspace / preview-research" 17609:920 and "preview-art" 17609:1258 (crop of the Workspace screens 12.15 and 12.16) */
  photo: string;
};

export const WORKSPACES: Record<WorkspaceKind, WorkspaceCopy> = {
  research: {
    name: 'Research Workspace',
    why: 'Your brief involves research, shared writing and a report the team edits together.',
    features: [
      'Rich text with headings, lists, links and tables',
      'Comments on selected text, with replies',
      'Document outline and version history',
      'See who is editing, live',
    ],
    photo: '/images/app/collab-start/workspace-research.jpg',
  },
  art: {
    name: 'Digital Art Workspace',
    why: 'Your brief involves visual creation, illustration and artwork the team makes together.',
    features: [
      'Shared canvas with brushes, layers and colour',
      'Comments pinned to the artwork',
      'Layers, undo and version history',
      'See who is on the canvas, live',
    ],
    photo: '/images/app/collab-start/workspace-art.jpg',
  },
};

/** Memory key of the accepted Workspace type, shared with the Create AI chat: 'research' | 'art' | null. */
export const WORKSPACE_KEY = 'cs-workspace';

/* ------------------------------------------------------------------ preparing */
export const PREPARING_MESSAGES = ['Understanding your idea.', 'Clarifying your purpose.', 'Organising your project details.', 'Preparing your brief.'];
/** Figma AFTER_TIMEOUT on the Preparing frame. */
export const PREPARING_MS = 3000;

/* ------------------------------------------------------------------ suggestions (A7) */
export type Suggestion = { id: string; title: string; text: string };
export const SUGGESTIONS: Suggestion[] = [
  { id: 'who', title: 'Clarify who this is for', text: 'Naming the students, teachers and parents you want to help makes it easier to find the right collaborators.' },
  { id: 'describe', title: 'Improve the project description', text: 'Add one sentence about how the platform will work, so people can picture what they would help build.' },
  { id: 'missing', title: 'Add missing information', text: 'You haven’t said yet how you plan to reach schools. A short note could help collaborators understand the scope.' },
  { id: 'skills', title: 'Skills that may be relevant', text: 'Career research, product design, mobile engineering and community partnerships may all help this project.' },
  { id: 'milestones', title: 'Possible first milestones', text: 'Interview ten students, map the first student journey and test a simple prototype with one school.' },
];
export type SuggestionState = 'default' | 'applied' | 'dismissed';
