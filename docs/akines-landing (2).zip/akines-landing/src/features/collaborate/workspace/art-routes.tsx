import type { RouteDef } from '@/routes.types';
import { PATHS, PROJECT_PATH } from './data';
import { ART_PATH } from './project';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Mirrored: Project overview (the Overview page itself). Not mirrored: the Empty state, the Shared project brief and the Milestone detail
 * pages, so nothing on the Adire Overview links to them.
 */
const mirrored: string[] = [PATHS.overview];

export const artRoutes: RouteDef[] = routes.filter((r) => mirrored.includes(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
