import { PATHS } from '../workspace/data';
import type { ProjectKey } from '../workspace/project';

/**
 * Sample data and copy of 12.19 Files: Files (17729:109139), Empty (17729:116171), File preview (17729:120125) and the overlays
 * Modal:Upload file (17730:87292), Toast:File uploaded (17730:87372), Modal:Create document (17730:87379), Toast:Document created (17730:87445).
 * Every text is the Figma text word for word.
 */

/** Paths of the journey. The four overlay frames have a "state-" route that shows the Files page with the overlay open. */
export const FP = {
  list: PATHS.files,
  empty: `${PATHS.files}/state-empty`,
  preview: `${PATHS.files}/student-onboarding-draft-pdf`,
  upload: `${PATHS.files}/state-upload-file`,
  uploaded: `${PATHS.files}/state-file-uploaded`,
  createDoc: `${PATHS.files}/state-create-document`,
  docCreated: `${PATHS.files}/state-document-created`,
} as const;

export const COPY = {
  label: 'FILES',
  /** The Figma headline is broken after "project" (the text node holds a line break). */
  title: 'Everything the project\nis built on.',
  lead: 'Shared documents, references and materials in one place.',
  search: 'Search files',
  group: 'ALL FILES',
  empty: {
    title: 'Your project materials\nwill live here.',
    text: 'Add documents, references and resources for your team.',
  },
  uploaded: 'File uploaded. It is in Files now.',
  created: 'Document created. It is in Files now.',
  /**
   * Search and category filters (Figma Search results 17972:152046, No results 17972:153278, Filtered: Documents 17972:152664 and
   * Filtered: Project references 17972:159432). The results line is set in capitals by the list header.
   */
  clearSearch: 'Clear search',
  results: (n: number, q: string) => `${n} ${n === 1 ? 'file' : 'files'} for '${q}'`,
  noResults: {
    title: (q: string) => `No files match '${q}'`,
    text: 'Try a different word, or clear the search to see all your files.',
  },
  /** An empty category: "No project references yet." and "No other materials yet." The support line and the button are those of the Empty frame. */
  categoryEmpty: (category: string) => `No ${category.toLowerCase()} yet.`,
};

/** Category Chip row. "All" is selected in the design. On Career Guidance for Everyone a category chip shows the files of that category. */
export const CATEGORIES = ['All', 'Documents', 'Images', 'Research', 'Design files', 'Presentations', 'Project references', 'Other materials'];

/** The category of a file follows its type icon: documents (PDF, Word), images, research notes, design files and presentations. */
const CATEGORY_OF_ICON: Record<FileIcon, string> = { text: 'Documents', image: 'Images', notes: 'Research', shapes: 'Design files', layers: 'Presentations' };
export const categoryOf = (f: Pick<FileItem, 'icon'>): string => CATEGORY_OF_ICON[f.icon];

/** Search over the file names: every word typed has to be in the name, in any case ("onboarding" finds two Career files, "dye" two Adire files). */
export function matchesName(name: string, query: string): boolean {
  const n = name.toLowerCase();
  return query
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((w) => n.includes(w));
}

/* ---------------------------------------------------------------- related work and milestones */

type Related = { text: string; href?: string };

/**
 * The related work of a row: the draft opens its file (File preview); the two research notes had Studio work details, which were removed
 * 5 Nov 2026, so they are text without a destination (as in the Figma frames). Milestones open their detail page.
 */
const WORK: Record<string, Related> = {
  journey: { text: 'Map the student journey' },
  questions: { text: 'Questions students ask about careers' },
  review: { text: 'Review the student onboarding draft', href: PATHS.draftFile },
};
const MILESTONE: Record<string, Related> = {
  prototype: { text: 'Prototype Review', href: PATHS.milestone2 },
  first: { text: 'First Student Experience', href: PATHS.milestone },
};

/* ---------------------------------------------------------------- File Row */

export type FileIcon = 'text' | 'image' | 'notes' | 'shapes' | 'layers';

/** A related work or milestone of a file row. Without `href` it has no destination (Adire Stories has no work detail or milestone detail page). */
export type RelatedLink = { text: string; href?: string };

export type FileItem = {
  id: string;
  name: string;
  meta: string;
  icon: FileIcon;
  work: RelatedLink;
  milestone: RelatedLink;
  /** Initials of the person who shared the file (the avatar at the right of the row). */
  owner: string;
  /** Only the first row has a destination in the design (File preview). */
  href?: string;
};

export const FILES: FileItem[] = [
  {
    id: 'student-onboarding-draft',
    name: 'Student onboarding draft.pdf',
    meta: 'PDF, 2.4 MB, shared by Tobi Adeyemi, Wed 4 Nov',
    icon: 'text',
    work: WORK.journey,
    milestone: MILESTONE.prototype,
    owner: 'TO',
    href: FP.preview,
  },
  {
    id: 'career-interview-notes',
    name: 'Career interview notes.docx',
    meta: 'Word, 180 KB, shared by Ngozi Eze, Tue 3 Nov',
    icon: 'text',
    work: WORK.questions,
    milestone: MILESTONE.first,
    owner: 'NE',
  },
  {
    id: 'student-journey-map',
    name: 'Student journey map.png',
    meta: 'Image, 1.1 MB, shared by Adaeze Okoye, Mon 2 Nov',
    icon: 'image',
    work: WORK.journey,
    milestone: MILESTONE.first,
    owner: 'AO',
  },
  {
    id: 'onboarding-research-summary',
    name: 'Onboarding research summary',
    meta: 'Research, shared by Ngozi Eze, Fri 30 Oct',
    icon: 'notes',
    work: WORK.questions,
    milestone: MILESTONE.first,
    owner: 'NE',
  },
  {
    id: 'prototype-screens',
    name: 'Prototype screens.fig',
    meta: 'Design file, 8.6 MB, shared by Adaeze Okoye, Thu 29 Oct',
    icon: 'shapes',
    work: WORK.review,
    milestone: MILESTONE.prototype,
    owner: 'AO',
  },
  {
    id: 'stakeholder-presentation',
    name: 'Stakeholder presentation.pptx',
    meta: 'Presentation, 4.1 MB, shared by Kemi Adeyemi, Wed 28 Oct',
    icon: 'layers',
    work: WORK.review,
    milestone: MILESTONE.prototype,
    owner: 'KA',
  },
];

/* ---------------------------------------------------------------- Context Panel / Files */

export const SHARED_WITH = [
  { name: 'Kemi Adeyemi', role: 'Project owner (you)' },
  { name: 'Adaeze Okoye', role: 'Product design' },
  { name: 'Tobi Adeyemi', role: 'Software Engineer' },
  { name: 'Ngozi Eze', role: 'Career Researcher' },
];
export const SHARED_NOTE = "Files stay inside this project. Nothing becomes public without the team's consent.";

export const RECENT = [
  { name: 'Student onboarding draft.pdf', meta: 'Tobi Adeyemi, Wed 4 Nov' },
  { name: 'Career interview notes.docx', meta: 'Ngozi Eze, Tue 3 Nov' },
  { name: 'Student journey map.png', meta: 'Adaeze Okoye, Mon 2 Nov' },
];

export const KEEPS = {
  title: 'Briefs, research, drafts and designs.',
  when: 'Each file is linked to the work and milestone it supports.',
  who: 'Private files stay private unless you share them.',
};

/* ---------------------------------------------------------------- File preview */

export const PREVIEW = {
  label: 'FILE',
  name: 'Student onboarding draft.pdf',
  lead: 'A first draft of the guided onboarding, shared with the team for review.',
  /** The File Preview Panel, Kind=Document: the page drawn inside the ivory panel. */
  page: {
    eyebrow: 'CAREER GUIDANCE FOR EVERYONE',
    title: 'Student onboarding draft',
    question: 'What do you enjoy doing when nobody is asking you to?',
    /** Widths of the grey text lines, in px at the design size of the page (276 wide). */
    linesA: [276, 262, 276, 240, 180],
    linesB: [276, 250, 276, 120],
    label: 'Page 1 of 5',
  },
  info: [
    [
      { label: 'TYPE', value: 'PDF document' },
      { label: 'SIZE', value: '2.4 MB' },
      { label: 'ADDED', value: 'Wednesday 4 November' },
    ],
    [
      { label: 'VISIBLE TO', value: 'Project team only' },
      { label: 'VERSION', value: 'Version 1' },
      { label: 'PAGES', value: '5 pages' },
    ],
  ],
  related: [
    { label: 'RELATED WORK', ...WORK.journey },
    { label: 'RELATED MILESTONE', ...MILESTONE.prototype },
  ],
  contributor: {
    initials: 'TO',
    name: 'Tobi Adeyemi',
    meta: 'Software Engineer. Shared this file on Wednesday 4 November.',
  },
};

export type FileComment = { id: string; initials: string; name: string; time: string; text: string };

export const COMMENTS: FileComment[] = [
  { id: 'c1', initials: 'TA', name: 'Tobi Adeyemi', time: 'Today, 8:50 AM', text: 'This is the latest draft with all five screens. Comments are welcome before Friday.' },
  { id: 'c2', initials: 'AO', name: 'Adaeze Okoye', time: 'Today, 9:20 AM', text: 'Thank you, Tobi. I will read the wording of the third screen first.' },
];

/* ---------------------------------------------------------------- overlays */

export const UPLOAD = {
  eyebrow: 'UPLOAD FILE',
  title: 'Add a file to the project.',
  description: 'Choose a file and say which work it supports.',
  work: { label: 'Related work', hint: 'The work this file supports.', value: 'Map the student journey' },
  milestone: { label: 'Related milestone', hint: 'The milestone it belongs to.', value: 'Prototype Review' },
  cta: 'Upload',
};

/** File Drop Area: Default, and Chosen after a click (the design shows this sample file). */
export const DROP = {
  title: 'Choose a file',
  copy: 'or drag it here. PDF, Word, images, design files and presentations.',
  chosen: { name: 'Student onboarding draft.pdf', meta: 'PDF, 2.4 MB', change: 'Choose a different file' },
};

export const CREATE = {
  eyebrow: 'NEW DOCUMENT',
  title: 'Start a shared document.',
  description: 'Give it a title and say where it belongs.',
  docTitle: { label: 'Document title', hint: 'A short, clear name.', placeholder: 'For example, Onboarding research summary' },
  category: { label: 'Category', hint: 'Where your team will find it.', value: 'Documents' },
  cta: 'Create document',
};

/* ---------------------------------------------------------------- Adire Stories */

/**
 * The Files page of Adire Stories (the Digital Art project): the same page as above with the same keys, the same six rows in the same
 * order and the same ids, in the words of the series. Amara Obi stands in for Adaeze Okoye, Ayo Bello for Tobi Adeyemi and Yusuf Danjuma
 * for Ngozi Eze. Only the Files page is mirrored: the file preview, the work detail and the milestone detail are not, so no Adire row has
 * an `href` and the related work and milestone are text without a destination. The related names are those of the Adire Studio and of
 * the milestones (art-studio-data.ts).
 */
const ART_WORK: Record<string, RelatedLink> = {
  journey: { text: 'Map the pattern repeats' },
  questions: { text: 'Questions to ask the dyers about cloth' },
  review: { text: 'Review the headwrap colour layer' },
};
const ART_MILESTONE: Record<string, RelatedLink> = {
  prototype: { text: 'Pattern Study Set' },
  first: { text: 'Headwrap Portrait' },
};

export const ART_FILES: FileItem[] = [
  {
    id: 'student-onboarding-draft',
    name: 'Pattern repeats sheet.pdf',
    meta: 'PDF, 2.4 MB, shared by Ayo Bello, Wed 4 Nov',
    icon: 'text',
    work: ART_WORK.journey,
    milestone: ART_MILESTONE.prototype,
    owner: 'AB',
  },
  {
    id: 'career-interview-notes',
    name: 'Dyer interview notes.docx',
    meta: 'Word, 180 KB, shared by Yusuf Danjuma, Tue 3 Nov',
    icon: 'text',
    work: ART_WORK.questions,
    milestone: ART_MILESTONE.first,
    owner: 'YD',
  },
  {
    id: 'student-journey-map',
    name: 'Pattern repeat map.png',
    meta: 'Image, 1.1 MB, shared by Amara Obi, Mon 2 Nov',
    icon: 'image',
    work: ART_WORK.journey,
    milestone: ART_MILESTONE.first,
    owner: 'AO',
  },
  {
    id: 'onboarding-research-summary',
    name: 'Dye pot research summary',
    meta: 'Research, shared by Yusuf Danjuma, Fri 30 Oct',
    icon: 'notes',
    work: ART_WORK.questions,
    milestone: ART_MILESTONE.first,
    owner: 'YD',
  },
  {
    id: 'prototype-screens',
    name: 'Pattern study sketches.psd',
    meta: 'Design file, 8.6 MB, shared by Amara Obi, Thu 29 Oct',
    icon: 'shapes',
    work: ART_WORK.review,
    milestone: ART_MILESTONE.prototype,
    owner: 'AO',
  },
  {
    id: 'stakeholder-presentation',
    name: 'Series presentation.pptx',
    meta: 'Presentation, 4.1 MB, shared by Kemi Adeyemi, Wed 28 Oct',
    icon: 'layers',
    work: ART_WORK.review,
    milestone: ART_MILESTONE.prototype,
    owner: 'KA',
  },
];

export const ART_SHARED_WITH = [
  { name: 'Kemi Adeyemi', role: 'Project owner (you)' },
  { name: 'Amara Obi', role: 'Illustration' },
  { name: 'Ayo Bello', role: 'Colour Artist' },
  { name: 'Yusuf Danjuma', role: 'Textile Historian' },
];

export const ART_RECENT = [
  { name: 'Pattern repeats sheet.pdf', meta: 'Ayo Bello, Wed 4 Nov' },
  { name: 'Dyer interview notes.docx', meta: 'Yusuf Danjuma, Tue 3 Nov' },
  { name: 'Pattern repeat map.png', meta: 'Amara Obi, Mon 2 Nov' },
];

export const ART_KEEPS = {
  title: 'Briefs, sketches, references and proofs.',
  when: KEEPS.when,
  who: KEEPS.who,
};

export const ART_UPLOAD = {
  ...UPLOAD,
  work: { ...UPLOAD.work, value: 'Map the pattern repeats' },
  milestone: { ...UPLOAD.milestone, value: 'Pattern Study Set' },
};

export const ART_DROP = {
  ...DROP,
  chosen: { ...DROP.chosen, name: 'Pattern repeats sheet.pdf' },
};

export const ART_CREATE = {
  ...CREATE,
  docTitle: { ...CREATE.docTitle, placeholder: 'For example, Dye pot research summary' },
};

/** Everything the Files page and its two modals read, per project. */
export type FilesData = {
  copy: typeof COPY;
  /** Career Guidance for Everyone filters by category; Adire Stories has search and results only (its chips keep toggling their look). */
  filterByCategory: boolean;
  files: FileItem[];
  sharedWith: { name: string; role: string }[];
  sharedNote: string;
  recent: { name: string; meta: string }[];
  keeps: typeof KEEPS;
  upload: typeof UPLOAD;
  drop: typeof DROP;
  create: typeof CREATE;
};

export const FILES_DATA: Record<ProjectKey, FilesData> = {
  career: { copy: COPY, filterByCategory: true, files: FILES, sharedWith: SHARED_WITH, sharedNote: SHARED_NOTE, recent: RECENT, keeps: KEEPS, upload: UPLOAD, drop: DROP, create: CREATE },
  adire: { copy: COPY, filterByCategory: false, files: ART_FILES, sharedWith: ART_SHARED_WITH, sharedNote: SHARED_NOTE, recent: ART_RECENT, keeps: ART_KEEPS, upload: ART_UPLOAD, drop: ART_DROP, create: ART_CREATE },
};
