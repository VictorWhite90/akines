'use client';

import { useEffect } from 'react';
import { asset } from '@/lib/assets';
import { useNav } from '@/lib/nav';
import { Button } from '@/ui';
import { callStore, useCall } from './call-store';
import { CameraIcon, CameraOffIcon, MicIcon, MicOffIcon, PresentIcon } from './CallIcons';
import { RoundButton, SelfTile, TopBar, useCast, useLeaveGuard, useSelf } from './parts';

/**
 * Lobby (Figma 12.43 Lobby 17809:111216) and Lobby / Camera off (17809:111347): your self-view with the mic and camera buttons, and the
 * meeting to join. The Lobby asks the browser for the camera and microphone as it opens; when they are refused or not there the self-view is the
 * camera-off tile with a quiet note. `cameraOff` is the frame reached by its own address: no devices are asked for, the camera starts off.
 */
export function LobbyScreen({ cameraOff = false }: { cameraOff?: boolean }) {
  const cast = useCast();
  const nav = useNav();
  const call = useCall();
  const self = useSelf(cameraOff, !cameraOff);
  useLeaveGuard();

  useEffect(() => {
    callStore.clearScreenNote();
    if (!cameraOff) void callStore.request();
  }, [cameraOff]);

  // The note that Present did not start fades after a few seconds.
  useEffect(() => {
    if (!call.screenNote) return;
    const id = window.setTimeout(() => callStore.clearScreenNote(), 6000);
    return () => window.clearTimeout(id);
  }, [call.screenNote]);

  const present = async () => {
    if (await callStore.present()) nav.push(cast.paths.sharing);
  };

  const { meeting, others } = cast;

  return (
    <div className="mc-page">
      <TopBar project={cast.project} />
      <main className="mc-lobby">
        <div className="mc-lobby__preview">
          <SelfTile self={self} person={cast.you} name={cast.youName} />
          <div className="mc-lobby__controls" role="group" aria-label="Your microphone and camera">
            <RoundButton label={self.micMuted ? 'Turn on microphone' : 'Turn off microphone'} tone={self.micMuted ? 'alert' : 'default'} onClick={self.toggleMic}>
              {self.micMuted ? <MicOffIcon /> : <MicIcon />}
            </RoundButton>
            <RoundButton label={self.camOff ? 'Turn on camera' : 'Turn off camera'} tone={self.camOff ? 'alert' : 'default'} onClick={self.toggleCam}>
              {self.camOff ? <CameraOffIcon /> : <CameraIcon />}
            </RoundButton>
          </div>
        </div>

        <section className="mc-join" aria-labelledby="mc-join-title">
          <p className="mc-eyebrow">{meeting.name.toUpperCase()}</p>
          <h1 id="mc-join-title" className="mc-join__title">
            Ready to join?
          </h1>
          <p className="mc-join__when">
            {meeting.when}, {meeting.minutes} minutes
          </p>
          <div className="mc-join__who">
            <span className="mc-faces" aria-hidden="true">
              {others.map((p) => (p.photo ? <img key={p.id} className="mc-faces__img" src={asset(p.photo)} alt="" width={32} height={32} draggable={false} /> : null))}
            </span>
            <span className="mc-join__who-text">{cast.firstNames} are here</span>
          </div>
          <div className="mc-join__actions">
            <Button size="lg" href={cast.paths.call} className="mc-grow">
              Join now
            </Button>
            <Button size="lg" variant="secondary" icon={<PresentIcon size={16} />} onClick={present} className="mc-grow">
              Present
            </Button>
            {call.screenNote ? (
              <p className="mc-join__note" role="status">
                {call.screenNote}
              </p>
            ) : null}
          </div>
        </section>
      </main>
    </div>
  );
}
