import type { RouteDef, MainPage } from '@/routes.types';
import { Placeholder } from '@/app-shell/Placeholder';
import { NAV } from '@/app-shell/nav-model';

/** Placeholder pages (Figma sections 11, 13, 14, 15: eyebrow, title and one line, content designed later) for every tab of a main page. */
export function placeholderRoutes(page: MainPage, skipPaths: string[] = []): RouteDef[] {
  const p = NAV.find((n) => n.key === page)!;
  const tabs = p.tabs.length ? p.tabs : [{ label: p.label, path: p.path }];
  return tabs
    .filter((t) => !skipPaths.includes(t.path))
    .map((t) => {
      const Screen = () => <Placeholder eyebrow={p.tabs.length ? p.label : undefined} title={t.label} />;
      Screen.displayName = `Placeholder(${t.label})`;
      return { path: t.path, title: t.label, shell: 'app', nav: { page, tab: p.tabs.length ? t.label : undefined }, component: Screen } satisfies RouteDef;
    });
}
