'use client';

/**
 * One interest card (Figma Interest Card set 17896:20747, 228 x 320): photograph, progressive blur and scrim, title, text and "Explore".
 * Every interest opens the one Interest page (Visual Arts, Figma 11.69), as drawn. Styles: interests.css (dxi-).
 * Pressing a card tracks interest_card_click { interest_id, position } (1-based), on Discover and on All interests alike.
 */
import { Link } from '@/lib/nav';
import { IArrow } from '@/features/community/ui';
import { track } from './analytics';
import { PATHS, type Interest } from './data';
import { src } from './images';

export function InterestCard({ interest, index }: { interest: Interest; index: number }) {
  return (
    <Link className="dxi-card" href={PATHS.interest} draggable={false} onClick={() => track('interest_card_click', { interest_id: interest.id, position: index + 1 })}>
      <img className="dxi-photo" src={src(interest.image)} alt="" loading="lazy" decoding="async" draggable={false} />
      <span className="dxi-blur" aria-hidden="true">
        <i />
        <i />
        <i />
      </span>
      <span className="dxi-scrim" aria-hidden="true" />
      <span className="dxi-title">{interest.title}</span>
      <span className="dxi-desc">{interest.text}</span>
      <span className="dxi-action">
        Explore
        <IArrow s={16} />
      </span>
    </Link>
  );
}
