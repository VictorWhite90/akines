import type { RouteDef } from '@/routes.types';
import { MyProjectsDraftsScreen, MyProjectsEmptyScreen, MyProjectsErrorScreen, MyProjectsLoadingScreen, MyProjectsScreen } from './MyProjects';
import { Brief, MilestoneDetail, Overview, OverviewEmpty } from './Overview';
// Studio removed 5 Nov 2026: import { Canvas, Studio, StudioEmpty, WorkDetail } from './Studio';
import { Conversations, ConversationsDecision, ConversationsEmpty, ConversationsStartModal, ConversationsStarted } from './conversations/Conversations';
import { conversationStateRoutes } from './conversations/routes';
import { PATHS } from './data';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * Project workspace: 12.10 My projects, 12.11 Project overview, 12.13 Conversations (12.12 Studio was removed 5 Nov 2026).
 * The "state-" routes are the Figma state frames that have no natural trigger in the prototype (they are not linked from the UI):
 * the list also shows Loading on a first visit and Empty is reachable only here. The Start conversation modal opens from the
 * buttons of Conversations and Empty; its state frame and the toast frame have their own routes.
 */
export const routes: RouteDef[] = [
  { path: PATHS.list, title: 'My projects', shell: 'app', nav, component: MyProjectsScreen },
  { path: PATHS.drafts, title: 'Drafts', shell: 'app', nav, component: MyProjectsDraftsScreen },
  { path: `${PATHS.list}/state-empty`, title: 'My projects', shell: 'app', nav, component: MyProjectsEmptyScreen },
  { path: `${PATHS.list}/state-loading`, title: 'My projects', shell: 'app', nav, component: MyProjectsLoadingScreen },
  { path: `${PATHS.list}/state-error`, title: 'My projects', shell: 'app', nav, component: MyProjectsErrorScreen },

  { path: PATHS.overview, title: 'Project overview', shell: 'app', nav, component: Overview },
  { path: `${PATHS.overview}/state-empty`, title: 'Project overview', shell: 'app', nav, component: OverviewEmpty },
  { path: PATHS.brief, title: 'Project brief', shell: 'app', nav, component: Brief },
  { path: PATHS.milestone, title: 'First Student Experience', shell: 'app', nav, component: MilestoneDetail },

  // Studio removed 5 Nov 2026 (Figma: parked on the TRASH page). Routes kept as comments:
  // { path: PATHS.studio, title: 'Studio', shell: 'app', nav, component: Studio },
  // { path: `${PATHS.studio}/state-empty`, title: 'Studio', shell: 'app', nav, component: StudioEmpty },
  // { path: PATHS.canvas, title: 'Shared canvas', shell: 'app', nav, component: Canvas },
  // { path: PATHS.work, title: 'Student onboarding draft', shell: 'app', nav, component: WorkDetail },

  { path: PATHS.conversations, title: 'Conversations', shell: 'app', nav, component: Conversations },
  { path: PATHS.conversationsDecision, title: 'Decision discussion', shell: 'app', nav, component: ConversationsDecision },
  { path: PATHS.conversationsEmpty, title: 'Conversations', shell: 'app', nav, component: ConversationsEmpty },
  { path: PATHS.conversationsStart, title: 'Conversations', shell: 'app', nav, component: ConversationsStartModal },
  { path: PATHS.conversationsStarted, title: 'Conversations', shell: 'app', nav, component: ConversationsStarted },
  // Dropdown:Meet, Panel:Conversation info, Modal:Schedule meeting and Toast:Meeting scheduled
  ...conversationStateRoutes,
];
