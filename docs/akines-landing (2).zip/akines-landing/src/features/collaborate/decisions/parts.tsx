'use client';

import '../workspace/workspace.css';
import './decisions.css';
import { Link } from '@/lib/nav';
import { CardLink, Ctx, cx } from '../workspace/parts';
import { PATHS } from '../workspace/data';
import { useProject } from '../workspace/project';
import {
  ACKNOWLEDGE_NOTE,
  DISCUSSION_PANEL,
  MILESTONE,
  decisionPaths,
  decisionsDataFor,
  type DecisionItem,
  type DecisionStatus,
} from './data';

/**
 * Shared pieces of the Decisions screens (12.20): Status Tag (17729:92228), Decision Row (17729:92466), the view tabs (Studio Tab)
 * and the Detail state of Context Panel / Decisions (17729:99198). The list pages show the shared project rail instead of the List and
 * Empty states of that panel. Every class is prefixed dc-.
 */

/** The rows, context panel and modal copy of the project of the page (Career Guidance for Everyone or Adire Stories). */
export function useDecisionsData() {
  return decisionsDataFor(useProject().key);
}

/* ------------------------------------------------------------------ Status Tag */

const TONE: Record<DecisionStatus, string> = {
  Proposed: 'ring',
  'Under discussion': 'ink',
  'Awaiting acknowledgement': 'amber',
  Approved: 'green',
  Rejected: 'ring-ink',
  Superseded: 'grey',
};

/** Dot and label. Proposed: grey ring. Under discussion: ink dot. Awaiting: amber dot. Approved: green dot. Rejected: ink ring. Superseded: grey dot. */
export function StatusTag({ status }: { status: DecisionStatus }) {
  return (
    <span className="dc-status">
      <i className={cx('dc-status__dot', `dc-status__dot--${TONE[status]}`)} aria-hidden="true" />
      <span className="dc-status__text">{status}</span>
    </span>
  );
}

/* ------------------------------------------------------------------ view tabs */

export type DecisionView = 'list' | 'history';

/**
 * The two views are two pages: the open one is marked and does nothing, the other one is a link (Studio Tab: label with a 2 px rule).
 */
export function ViewTabs({ view }: { view: DecisionView }) {
  const paths = decisionPaths(useProject().root);
  const tabs: { key: DecisionView; label: string; href: string }[] = [
    { key: 'list', label: 'Needs attention', href: paths.list },
    { key: 'history', label: 'History', href: paths.history },
  ];
  return (
    <nav className="dc-tabs" aria-label="Decision views" data-m="up">
      {tabs.map((t) =>
        t.key === view ? (
          <span className="dc-tab" key={t.key} aria-current="page">
            <span className="dc-tab__label">{t.label}</span>
            <span className="dc-tab__rule" />
          </span>
        ) : (
          <Link className="dc-tab" key={t.key} href={t.href}>
            <span className="dc-tab__label">{t.label}</span>
            <span className="dc-tab__rule" />
          </Link>
        ),
      )}
    </nav>
  );
}

/* ------------------------------------------------------------------ Decision Row */

/**
 * Decision Row (Figma 17729:92466): title and status, then who proposed it and the milestone on the left, how many have acknowledged
 * and the date on the right. Default, Hover (subtle fill), Pressed (muted fill) and Focus (2 px ink border) come from CSS.
 * A row with `href` opens that page; the others react to hover and press and go nowhere. The milestone link sits above the row link.
 */
export function DecisionRow({ item }: { item: DecisionItem }) {
  const title = item.href ? (
    <Link href={item.href} className="dc-row__hit">
      {item.title}
    </Link>
  ) : (
    <button type="button" className="dc-row__hit dc-row__hit--inert" aria-disabled="true">
      {item.title}
    </button>
  );
  return (
    <li className="dc-row">
      <div className="dc-row__top">
        {title}
        <StatusTag status={item.status} />
      </div>
      <div className="dc-row__bottom">
        <div className="dc-row__meta">
          <span>Proposed by {item.proposedBy}</span>
          <span aria-hidden="true">·</span>
          {item.milestoneHref ? (
            <Link href={item.milestoneHref} className="dc-row__ms">
              {item.milestone}
            </Link>
          ) : (
            // no destination in the design
            <button type="button" className="dc-row__ms dc-row__ms--inert">
              {item.milestone}
            </button>
          )}
        </div>
        <div className="dc-row__meta">
          <span>{item.acknowledged}</span>
          <span aria-hidden="true">·</span>
          <span>{item.date}</span>
        </div>
      </div>
    </li>
  );
}

/** The bordered list of a view: a group header with the count, then the rows. */
export function DecisionList({ id, group, items, tight }: { id: string; group: string; items: DecisionItem[]; tight?: boolean }) {
  return (
    <section className="dc-list" id={id} aria-labelledby={`${id}-group`} data-m="up">
      <h2 className={cx('dc-list__group', tight && 'dc-list__group--tight')} id={`${id}-group`}>
        {group}
      </h2>
      <ul className="dc-list__rows">
        {items.map((d) => (
          <DecisionRow key={d.id} item={d} />
        ))}
      </ul>
    </section>
  );
}

/* ------------------------------------------------------------------ Context Panel / Decisions */

function WhoAcknowledges() {
  const { acknowledgers } = useDecisionsData();
  return (
    <Ctx label="WHO ACKNOWLEDGES">
      {acknowledgers.map((a) => (
        <div className="dc-ack" key={a.name}>
          <p className="dc-ack__name">{a.name}</p>
          <p className="dc-ack__line">{a.status}</p>
        </div>
      ))}
      <p className="dc-ctx__small">{ACKNOWLEDGE_NOTE}</p>
    </Ctx>
  );
}

/** Context=Detail. */
export function DetailContext() {
  return (
    <>
      <WhoAcknowledges />
      <Ctx label={MILESTONE.label}>
        <p className="cw-session__title">{MILESTONE.title}</p>
        <p className="cw-ctx__line">{MILESTONE.note}</p>
        <CardLink href={PATHS.milestone} arrow>
          {MILESTONE.link}
        </CardLink>
      </Ctx>
      <Ctx label={DISCUSSION_PANEL.label}>
        <p className="cw-ctx__item">{DISCUSSION_PANEL.title}</p>
        <p className="dc-ctx__note">{DISCUSSION_PANEL.count}</p>
        <p className="dc-ctx__note">{DISCUSSION_PANEL.last}</p>
        <CardLink href={PATHS.conversationsDecision} arrow>
          {DISCUSSION_PANEL.link}
        </CardLink>
      </Ctx>
    </>
  );
}
