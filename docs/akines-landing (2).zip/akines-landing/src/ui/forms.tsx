'use client';

import {
  Children,
  cloneElement,
  forwardRef,
  isValidElement,
  useId,
  useState,
  type CSSProperties,
  type InputHTMLAttributes,
  type ReactElement,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react';
import { cx, IconAlert, IconCheck, IconChevronDown, IconCircleCheck } from './internal';

/* ------------------------------------------------------------------ Field */
export type FieldProps = {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  htmlFor?: string;
  children?: ReactNode;
  className?: string;
};

/**
 * Label above, hint or error below (an error replaces the hint and is announced with role="alert").
 * When the only child is a kit input or a plain form element without an id, Field wires `id`, `aria-describedby`,
 * `aria-invalid` and (for kit inputs) `invalid` for you.
 */
export function Field({ label, hint, error, required, htmlFor, children, className }: FieldProps) {
  const auto = useId();
  const only = Children.count(children) === 1 && isValidElement(children) ? (children as ReactElement<Record<string, unknown>>) : null;
  const id = htmlFor ?? (only && typeof only.props.id === 'string' ? (only.props.id as string) : `${auto}-f`);
  const msgId = `${id}-msg`;
  const hasMsg = Boolean(error || hint);
  let content = children;
  if (only) {
    const kit = only.type === TextInput || only.type === TextArea || only.type === Select;
    const props: Record<string, unknown> = {};
    if (only.props.id === undefined && htmlFor === undefined) props.id = id;
    if (hasMsg) props['aria-describedby'] = [only.props['aria-describedby'], msgId].filter(Boolean).join(' ');
    if (error) {
      props['aria-invalid'] = true;
      if (kit) props.invalid = true;
    }
    if (required && only.props.required === undefined && (kit || typeof only.type === 'string')) props['aria-required'] = true;
    content = cloneElement(only, props);
  }
  return (
    <div className={cx('k-field', error && 'k-field--error', className)}>
      {label ? (
        <label className="k-field__label" htmlFor={id}>
          {label}
          {required ? <span className="k-field__req" aria-hidden="true"> *</span> : null}
        </label>
      ) : null}
      {content}
      {error ? (
        <p className="k-field__msg k-field__msg--error" id={msgId} role="alert">
          <span className="k-field__msg-icon" aria-hidden="true">
            <IconAlert size={16} strokeWidth={1.4} />
          </span>
          <span>{error}</span>
        </p>
      ) : hint ? (
        <p className="k-field__msg" id={msgId}>
          {hint}
        </p>
      ) : null}
    </div>
  );
}

/* -------------------------------------------------------------- TextInput */
export type TextInputProps = InputHTMLAttributes<HTMLInputElement> & {
  invalid?: boolean;
  iconLeft?: ReactNode;
  iconRight?: ReactNode;
  /** 'rect' is the in-app Line Field and Search Field (square, 60 high). 'pill' is the sign-in Email Input (52 high, fully rounded). Default 'rect'. */
  shape?: 'rect' | 'pill';
  /** Verified state of the sign-in field: green border and a check icon. */
  valid?: boolean;
};

/** Single line field. `className` and `style` go to the outer box (layout), everything else to the `<input>`. */
export const TextInput = forwardRef<HTMLInputElement, TextInputProps>(function TextInput(
  { invalid, valid, shape = 'rect', iconLeft, iconRight, className, style, disabled, ...rest },
  ref,
) {
  // the pill field shows its own state icon on the right (alert or check) unless the screen passes one
  const stateIcon = !iconRight && shape === 'pill' ? (invalid ? <IconAlert size={20} strokeWidth={1.4} className="k-input__state k-input__state--error" /> : valid ? <IconCircleCheck size={20} strokeWidth={1.4} className="k-input__state k-input__state--ok" /> : null) : null;
  const right = iconRight ?? stateIcon;
  return (
    <span
      className={cx(
        'k-input',
        `k-input--${shape}`,
        invalid && 'k-input--invalid',
        valid && !invalid && 'k-input--valid',
        disabled && 'k-input--disabled',
        iconLeft ? 'k-input--left' : '',
        right ? 'k-input--right' : '',
        className,
      )}
      style={style}
    >
      {iconLeft ? <span className="k-input__icon k-input__icon--left" aria-hidden="true">{iconLeft}</span> : null}
      <input {...rest} ref={ref} disabled={disabled} aria-invalid={invalid || rest['aria-invalid']} className="k-input__el" />
      {right ? <span className="k-input__icon k-input__icon--right">{right}</span> : null}
    </span>
  );
});

/* --------------------------------------------------------------- TextArea */
export type TextAreaProps = TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean; maxLength?: number };

/** Multi line field. With `maxLength` a live "12/280" counter is shown under the field. */
export const TextArea = forwardRef<HTMLTextAreaElement, TextAreaProps>(function TextArea(
  { invalid, maxLength, className, style, disabled, onChange, value, defaultValue, ...rest },
  ref,
) {
  const [typed, setTyped] = useState(() => String(value ?? defaultValue ?? '').length);
  const len = value !== undefined ? String(value).length : typed;
  return (
    <span className={cx('k-textarea', maxLength && 'k-textarea--counter', invalid && 'k-textarea--invalid', disabled && 'k-textarea--disabled', className)} style={style}>
      <textarea
        rows={4}
        {...rest}
        ref={ref}
        value={value}
        defaultValue={defaultValue}
        disabled={disabled}
        maxLength={maxLength}
        aria-invalid={invalid || rest['aria-invalid']}
        className="k-textarea__el"
        onChange={(e) => {
          setTyped(e.target.value.length);
          onChange?.(e);
        }}
      />
      {maxLength ? (
        <span className={cx('k-textarea__count', len >= maxLength && 'k-textarea__count--full')} aria-hidden="true">
          {len}/{maxLength}
        </span>
      ) : null}
    </span>
  );
});

/* ----------------------------------------------------------------- Select */
export type SelectProps = SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean };

/** Native `<select>` with the Akines box and a chevron. `className` and `style` go to the outer box. */
export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select({ invalid, className, style, disabled, children, ...rest }, ref) {
  return (
    <span className={cx('k-select', invalid && 'k-select--invalid', disabled && 'k-select--disabled', className)} style={style}>
      <select {...rest} ref={ref} disabled={disabled} aria-invalid={invalid || rest['aria-invalid']} className="k-select__el">
        {children}
      </select>
      <span className="k-select__chev" aria-hidden="true">
        <IconChevronDown size={20} />
      </span>
    </span>
  );
});

/* --------------------------------------------------------------- Checkbox */
export type CheckboxProps = {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: ReactNode;
  description?: ReactNode;
  disabled?: boolean;
  id?: string;
  /** Error state (red box), for a required checkbox that was left empty. */
  invalid?: boolean;
  className?: string;
  style?: CSSProperties;
} & Omit<InputHTMLAttributes<HTMLInputElement>, 'checked' | 'onChange' | 'type' | 'children' | 'className' | 'style' | 'id' | 'disabled'>;

export function Checkbox({ checked, onChange, label, description, disabled, id, invalid, className, style, ...rest }: CheckboxProps) {
  const auto = useId();
  const cid = id ?? auto;
  return (
    <label className={cx('k-check', disabled && 'k-check--disabled', invalid && 'k-check--invalid', className)} style={style} htmlFor={cid}>
      <input {...rest} id={cid} type="checkbox" className="k-check__input" checked={checked} disabled={disabled} aria-invalid={invalid || undefined} onChange={(e) => onChange(e.target.checked)} />
      <span className="k-check__box" aria-hidden="true">
        <IconCheck size={14} strokeWidth={1.8} />
      </span>
      <span className="k-check__text">
        <span className="k-check__label">{label}</span>
        {description ? <span className="k-check__desc">{description}</span> : null}
      </span>
    </label>
  );
}

/* ------------------------------------------------------------------ Radio */
export type RadioProps = {
  checked: boolean;
  onChange: () => void;
  label: ReactNode;
  description?: ReactNode;
  name: string;
  value: string;
  disabled?: boolean;
  /** 'row' is the Figma Radio Row (divided list row, default). 'plain' has no padding or divider. 'card' is the Option Card (bordered card with a serif title). */
  variant?: 'row' | 'plain' | 'card';
  /** Small number shown top left of a card ("01"). */
  index?: string;
  className?: string;
  style?: CSSProperties;
} & Omit<InputHTMLAttributes<HTMLInputElement>, 'checked' | 'onChange' | 'type' | 'children' | 'className' | 'style' | 'name' | 'value' | 'disabled'>;

export function Radio({ checked, onChange, label, description, name, value, disabled, variant = 'row', index, className, style, ...rest }: RadioProps) {
  return (
    <label className={cx('k-radio', `k-radio--${variant}`, disabled && 'k-radio--disabled', className)} style={style}>
      <input {...rest} type="radio" className="k-radio__input" name={name} value={value} checked={checked} disabled={disabled} onChange={() => onChange()} />
      {variant === 'card' ? (
        <span className="k-radio__meta" aria-hidden="true">
          <span className="k-radio__index">{index}</span>
          <span className="k-radio__dot">
            <IconCheck size={14} strokeWidth={1.8} />
          </span>
        </span>
      ) : (
        <span className="k-radio__dot" aria-hidden="true" />
      )}
      <span className="k-radio__text">
        <span className="k-radio__label">{label}</span>
        {description ? <span className="k-radio__desc">{description}</span> : null}
      </span>
    </label>
  );
}

/* ----------------------------------------------------------------- Toggle */
export type ToggleProps = {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: ReactNode;
  disabled?: boolean;
  'aria-label'?: string;
  className?: string;
  id?: string;
};

/** Switch (role="switch"). With a `label` the whole row toggles. */
export function Toggle({ checked, onChange, label, disabled, className, id, 'aria-label': ariaLabel }: ToggleProps) {
  const auto = useId();
  const tid = id ?? auto;
  const sw = (
    <button
      type="button"
      role="switch"
      id={tid}
      aria-checked={checked}
      aria-label={label ? undefined : ariaLabel}
      disabled={disabled}
      className="k-toggle__track"
      onClick={() => onChange(!checked)}
    >
      <span className="k-toggle__check" aria-hidden="true">
        <IconCheck size={12} strokeWidth={1.5} />
      </span>
      <span className="k-toggle__thumb" aria-hidden="true" />
    </button>
  );
  if (!label) return <span className={cx('k-toggle', disabled && 'k-toggle--disabled', className)}>{sw}</span>;
  return (
    <span className={cx('k-toggle', 'k-toggle--labelled', disabled && 'k-toggle--disabled', className)}>
      {sw}
      <label className="k-toggle__label" htmlFor={tid}>
        {label}
      </label>
    </span>
  );
}
