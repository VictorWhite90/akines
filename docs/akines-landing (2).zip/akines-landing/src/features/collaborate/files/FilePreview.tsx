'use client';

import '../workspace/workspace.css';
import './files.css';
import './preview.css';
import { useEffect, useRef, type FormEvent } from 'react';
import { Link } from '@/lib/nav';
import { useMemoState } from '@/lib/hooks';
import { Button } from '@/ui';
import { DashCard, MetricCard, MetricRow } from '../workspace/dash';
import { ActionButton, Av, BackLink, CardLink, Icon, PageHead, WorkspaceFrame } from '../workspace/parts';
import { COMMENTS, FP, type FileComment } from './data';
import { FilePreviewPanel } from './parts';
import { FPD, FP_IDS } from './preview-data';

/**
 * 12.19 File preview (17729:120125) in the dashboard look: the shared rail on the right (without its Needs review row for this file),
 * the header with Download, four metric cards that scroll to their card, the preview, file information beside connected work, and the
 * comments with their composer. Shared by moved into File information (the separate Contributor card is gone).
 * Links from the prototype: Related milestone opens the milestone (Prototype Review), Back to files returns to Files. Without a
 * destination in the design (shown, they do nothing): Download, Related work, Reply, Attach file, Link task and Link decision.
 * Career Guidance for Everyone only.
 */

/** The 24 px up-right arrow of a value (Figma icon/arrow-up-right, 10 px arrow, 1.5 stroke). */
const ArrowUpRight24 = () => (
  <Icon size={24} sw={1}>
    <path d="M4.5 11.5 11.5 4.5M5.5 4.5h6v6" />
  </Icon>
);

/* ------------------------------------------------------------------ comments */

/** Message (Figma 17384:14222, Type=Text): avatar, name and time, text. Hover (or focus) reveals the Reply action, which has no destination. */
function Comment({ c }: { c: FileComment }) {
  return (
    <li className="fl-msg">
      <Av initials={c.initials} size={36} tone="muted" />
      <div className="fl-msg__body">
        <div className="fl-msg__head">
          <span className="fl-msg__who">
            <span className="fl-msg__name">{c.name}</span>
            <span className="fl-msg__time">{c.time}</span>
          </span>
          <button type="button" className="fl-msg__reply" aria-label={`Reply to ${c.name}`}>
            Reply
          </button>
        </div>
        <p className="fl-msg__text">{c.text}</p>
      </div>
    </li>
  );
}

/**
 * Composer (Figma 17385:14191): Default, Focus (2 px ink border while the field has focus) and Filled (Send turns primary once something
 * is typed). Send adds the comment to the end of the thread for this visit.
 */
function Composer({ draft, onDraft, onSend }: { draft: string; onDraft: (v: string) => void; onSend: () => void }) {
  const field = useRef<HTMLTextAreaElement>(null);
  const filled = draft.trim().length > 0;

  // the field grows with what is typed (92 px at least, as in the design)
  useEffect(() => {
    const el = field.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight + 2}px`;
  }, [draft]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!filled) return;
    onSend();
    field.current?.focus();
  };

  return (
    <form className="fl-composer" onSubmit={submit} noValidate>
      <textarea ref={field} className="fl-composer__field" rows={1} value={draft} placeholder="Add a comment." aria-label="Add a comment" onChange={(e) => onDraft(e.target.value)} />
      <div className="fl-composer__actions">
        <div className="fl-composer__refs">
          <CardLink>Attach file</CardLink>
          <CardLink>Link task</CardLink>
          <CardLink>Link decision</CardLink>
        </div>
        {/* Send looks disabled (the design's secondary disabled pill) until something is typed, then it is the primary button */}
        <Button type="submit" variant={filled ? 'primary' : 'secondary'} disabled={!filled}>
          Send
        </Button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ screen */

export function FilePreview() {
  const [draft, setDraft] = useMemoState<string>('fl.draft', '');
  const [sent, setSent] = useMemoState<FileComment[]>('fl.sent', []);
  const comments = [...COMMENTS, ...sent];

  const send = () => {
    const text = draft.trim();
    if (!text) return;
    setSent((prev) => [...prev, { id: `sent-${prev.length}`, initials: 'KA', name: 'Kemi Adeyemi', time: 'Just now', text }]);
    setDraft('');
  };

  const m = FPD.metrics;
  const work = FPD.connected.work;
  const ms = FPD.connected.milestone;

  return (
    <WorkspaceFrame active="files" rail railHide={['file']}>
      <div className="fp-page">
        <PageHead back={<BackLink href={FP.list}>{FPD.back}</BackLink>} label={FPD.label} title={FPD.name} lead={FPD.lead}>
          <div className="cw-actions cw-actions--btns">
            {/* Download has no destination in the design */}
            <ActionButton>{FPD.download}</ActionButton>
          </div>
        </PageHead>

        <MetricRow>
          <MetricCard label={m.size.label} value={m.size.value} caption={m.size.caption} scrollTo={FP_IDS.info} />
          <MetricCard label={m.pages.label} value={m.pages.value} caption={m.pages.caption} scrollTo={FP_IDS.info} />
          <MetricCard label={m.version.label} value={m.version.value} caption={m.version.caption} scrollTo={FP_IDS.info} />
          <MetricCard label={m.comments.label} value={comments.length} caption={m.comments.caption} dot scrollTo={FP_IDS.comments} />
        </MetricRow>

        <section className="fp-sec" data-m="up">
          <h2 className="cw-over">{FPD.previewLabel}</h2>
          <FilePreviewPanel />
        </section>

        <div className="fp-pair" id={FP_IDS.info}>
          <DashCard title={FPD.info.title} className="fp-info">
            <ul className="fp-lines">
              {FPD.info.rows.map((r) => (
                <li className="fp-line" key={r.label}>
                  <div className="fp-line__in">
                    <span className="fp-line__k">{r.label}</span>
                    <span className="fp-line__v">{r.value}</span>
                  </div>
                </li>
              ))}
            </ul>
          </DashCard>

          <DashCard title={FPD.connected.title} className="fp-info">
            <ul className="fp-lines">
              <li className="fp-line">
                {/* Related work has no destination in the design */}
                <div className="fp-line__in">
                  <span className="fp-line__k">{work.label}</span>
                  <span className="fp-line__v">{work.value}</span>
                </div>
              </li>
              <li className="fp-line">
                {ms.href ? (
                  <Link href={ms.href} className="fp-line__in fp-line__in--link">
                    <span className="fp-line__k">{ms.label}</span>
                    <span className="fp-line__v">
                      {ms.value}
                      <ArrowUpRight24 />
                    </span>
                  </Link>
                ) : (
                  <div className="fp-line__in">
                    <span className="fp-line__k">{ms.label}</span>
                    <span className="fp-line__v">{ms.value}</span>
                  </div>
                )}
              </li>
            </ul>
          </DashCard>
        </div>

        <section className="fp-sec fp-anchor" id={FP_IDS.comments} data-m="up">
          <h2 className="cw-over">{`COMMENTS (${comments.length})`}</h2>
          <div className="fl-thread">
            <ul className="fl-msgs" aria-label="Comments">
              {comments.map((c) => (
                <Comment key={c.id} c={c} />
              ))}
            </ul>
            <Composer draft={draft} onDraft={setDraft} onSend={send} />
          </div>
        </section>
      </div>
    </WorkspaceFrame>
  );
}
