'use client';

import './meetings.css';
import { useEffect, useState, type FormEvent } from 'react';
import { Button, Chip, Field, Modal, Select, TextInput, toast } from '@/ui';
import { CardLink } from '../workspace/atoms';
import { useProject } from '../workspace/project';
import { meetings, useMeeting } from './store';

/** Modal:Schedule meeting (Figma 17808:110053): length, name, date and time. Schedule meeting makes it the project's upcoming meeting and shows the toast. */
const LENGTHS = [15, 30, 45, 60];
export const WHEN_OPTIONS = ['Thursday, 4:00 PM', 'Friday, 10:00 AM', 'Monday, 2:00 PM', 'Tuesday, 11:00 AM'];

export function ScheduleModal({ open, onClose, name: defaultName }: { open: boolean; onClose: () => void; /** The name the field starts with (the sample meeting's name). */ name?: string }) {
  const { key } = useProject();
  const current = useMeeting(key);
  const start = defaultName ?? (current.status === 'none' ? 'Prototype review' : current.name);
  const [minutes, setMinutes] = useState(45);
  const [name, setName] = useState(start);
  const [when, setWhen] = useState(WHEN_OPTIONS[0]);

  // every opening starts again from the frame: 45 min, the meeting name, Thursday 4:00 PM
  useEffect(() => {
    if (open) {
      setMinutes(45);
      setName(start);
      setWhen(WHEN_OPTIONS[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    const before = meetings.get(key);
    meetings.schedule(key, { name, minutes, when });
    onClose();
    toast.show({ message: `Meeting scheduled for ${when}.`, actionLabel: 'Undo', duration: 4000, onAction: () => meetings.restore(key, before) });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow="SCHEDULE A MEETING"
      title="When should the team meet?"
      description="Everyone on this project is invited."
      footer={
        <>
          <Button type="submit" form="mt-schedule-form">
            Schedule meeting
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="mt-schedule-form" className="cw-form" onSubmit={submit} noValidate>
        <div className="cw-form__group" role="group" aria-labelledby="mt-length-label">
          <span className="cw-form__label" id="mt-length-label">
            Length
          </span>
          <div className="cw-chips">
            {LENGTHS.map((l) => (
              <Chip key={l} selected={minutes === l} onClick={() => setMinutes(l)}>
                {l} min
              </Chip>
            ))}
          </div>
        </div>
        <Field label="Meeting name" hint="Shown to everyone who is invited.">
          <TextInput value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Date and time" hint="The team is notified in the conversation.">
          <Select className="mt-plain-select" value={when} onChange={(e) => setWhen(e.target.value)}>
            {WHEN_OPTIONS.map((w) => (
              <option key={w} value={w}>
                {w}
              </option>
            ))}
          </Select>
        </Field>
      </form>
    </Modal>
  );
}
