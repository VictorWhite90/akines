'use client';

import type { CSSProperties, HTMLAttributes, ReactNode } from 'react';
import { Button } from './Button';
import { cx, IconAlert, IconRefresh } from './internal';

export type SkeletonProps = {
  width?: number | string;
  height?: number | string;
  radius?: number | string;
  className?: string;
  style?: CSSProperties;
} & Omit<HTMLAttributes<HTMLSpanElement>, 'children' | 'className' | 'style'>;

/** Soft shimmer block for loading states (static under reduced motion). Decorative: hidden from assistive tech. */
export function Skeleton({ width, height = 16, radius = 8, className, style, ...rest }: SkeletonProps) {
  return <span {...rest} aria-hidden="true" className={cx('k-skel', className)} style={{ width, height, borderRadius: radius, ...style }} />;
}

export type EmptyStateProps = {
  title: string;
  text?: string;
  action?: ReactNode;
  icon?: ReactNode;
  className?: string;
  /** 'start' is the Figma Empty State (bordered card, amber rule, left aligned). 'center' centres the block. Default 'start'. */
  align?: 'start' | 'center';
};

/** Empty block: amber rule (or your icon), serif title, text and one action. */
export function EmptyState({ title, text, action, icon, className, align = 'start' }: EmptyStateProps) {
  return (
    <div className={cx('k-empty', align === 'center' && 'k-empty--center', className)}>
      {icon ? <div className="k-empty__icon" aria-hidden="true">{icon}</div> : <span className="k-empty__rule" aria-hidden="true" />}
      <h3 className="k-empty__title">{title}</h3>
      {text ? <p className="k-empty__text">{text}</p> : null}
      {action ? <div className="k-empty__action">{action}</div> : null}
    </div>
  );
}

export type InlineErrorProps = { title?: string; text: string; onRetry?: () => void; retryLabel?: string; className?: string };

/** "Could not load" row with a retry button. */
export function InlineError({ title, text, onRetry, retryLabel = 'Try again', className }: InlineErrorProps) {
  return (
    <div className={cx('k-error', className)} role="alert">
      <span className="k-error__icon" aria-hidden="true">
        <IconAlert size={20} />
      </span>
      <div className="k-error__copy">
        {title ? <p className="k-error__title">{title}</p> : null}
        <p className="k-error__text">{text}</p>
      </div>
      {onRetry ? (
        <Button variant="secondary" size="sm" icon={<IconRefresh size={16} />} onClick={onRetry}>
          {retryLabel}
        </Button>
      ) : null}
    </div>
  );
}
