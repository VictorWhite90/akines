'use client';

/**
 * Connect / Discover analytics (PRD section 13).
 *
 * track(event, props) does two things, in development and production alike:
 *   1. dispatches window event `akines:analytics` (CustomEvent, detail = { name, props, at }), which any provider can listen to;
 *   2. pushes the same detail onto window.__akinesEvents (an array, newest last, capped at 1000 entries).
 *
 * Props carry only ids, types and positions: never names, text or conversation content. Positions are 1-based.
 * As a safety net, track() drops props with a free-text key (name, text, message, ...) and any string longer than 64 characters.
 *
 * Event names are the 18 of the PRD plus one addition, `recommendation_undo` (Undo after "Not now" has no PRD event).
 */
import { useEffect, useRef, type RefObject } from 'react';
import {
  CARD_BY_ID,
  cardActionId,
  cardPosition,
  recPosition,
  type CardActionId,
  type CardType,
  type ExploreId,
  type ForYouFilter,
  type InterestId,
  type SectionId,
} from './data';

export const EVENT_NAMES = [
  'discover_page_view',
  'discover_section_view',
  'discover_category_click',
  'discover_carousel_interaction',
  'for_you_filter_select',
  'for_you_card_click',
  'for_you_card_action',
  'your_circle_click',
  'your_circles_see_all_click',
  'recommendation_view',
  'recommendation_next',
  'recommendation_previous',
  'recommendation_dismiss',
  'recommendation_say_hello',
  'recommendation_profile_click',
  'recommendation_see_all',
  'interest_card_click',
  'interest_explore_all_click',
  // addition to the PRD list: Undo after "Not now"
  'recommendation_undo',
] as const;
export type EventName = (typeof EVENT_NAMES)[number];

type Carousel = 'explore' | 'interests';
/** Where a For you card sits: its id, its kind, its 1-based position in the list of the active filter and that filter. */
type CardProps = { card_id: string; card_type: CardType; position?: number; filter: ForYouFilter };
/** `rail` is the "You two would get along" card, `section` the "People whose journeys complement yours" cards. */
type RecSource = 'rail' | 'section';
type RecProps = { recommendation_id: string; position?: number; source: RecSource };
type None = Record<never, never>;

/** The props each event carries. */
export type EventPropsMap = {
  discover_page_view: { variant: 'live' | 'loading' | 'error' | 'empty'; filter: ForYouFilter };
  discover_section_view: { section: SectionId };
  discover_category_click: { category: ExploreId; position: number };
  discover_carousel_interaction: { carousel: Carousel; action: 'scroll' | 'previous' | 'next'; position?: number };
  for_you_filter_select: { filter: ForYouFilter; previous: ForYouFilter };
  for_you_card_click: CardProps;
  for_you_card_action: CardProps & { action: CardActionId };
  your_circle_click: { circle_id: string; position: number };
  your_circles_see_all_click: None;
  recommendation_view: RecProps;
  /** position = the recommendation the member moved to */
  recommendation_next: { position: number; source: RecSource };
  recommendation_previous: { position: number; source: RecSource };
  recommendation_dismiss: RecProps;
  recommendation_say_hello: RecProps;
  recommendation_undo: RecProps;
  recommendation_profile_click: RecProps;
  recommendation_see_all: None;
  interest_card_click: { interest_id: InterestId; position: number };
  interest_explore_all_click: None;
};
type Args<E extends EventName> = keyof EventPropsMap[E] extends never ? [props?: EventPropsMap[E]] : [props: EventPropsMap[E]];

export type AnalyticsDetail = { name: EventName; props: Record<string, string | number | boolean>; at: number };
declare global {
  interface Window {
    __akinesEvents?: AnalyticsDetail[];
  }
}

const LOG_CAP = 1000;
const MAX_STRING = 64;
/** Keys that would carry free text or personal data. They are dropped even if a caller passes them. */
const FREE_TEXT_KEYS = new Set(['name', 'first_name', 'full_name', 'text', 'message', 'body', 'title', 'label', 'prompt', 'reason', 'quote', 'email', 'query', 'note']);

function clean(props: object | undefined): AnalyticsDetail['props'] {
  const out: AnalyticsDetail['props'] = {};
  if (!props) return out;
  for (const [k, v] of Object.entries(props)) {
    if (FREE_TEXT_KEYS.has(k)) continue;
    if (typeof v === 'string') {
      if (v.length <= MAX_STRING) out[k] = v;
    } else if (typeof v === 'number' || typeof v === 'boolean') {
      out[k] = v;
    }
  }
  return out;
}

export function track<E extends EventName>(event: E, ...args: Args<E>): void {
  if (typeof window === 'undefined') return;
  const detail: AnalyticsDetail = { name: event, props: clean(args[0]), at: Date.now() };
  try {
    const log = (window.__akinesEvents ??= []);
    log.push(detail);
    if (log.length > LOG_CAP) log.splice(0, log.length - LOG_CAP);
  } catch {
    /* a page that froze the array must not break the screen */
  }
  try {
    window.dispatchEvent(new CustomEvent<AnalyticsDetail>('akines:analytics', { detail }));
  } catch {
    /* a listener that throws must not break the screen */
  }
}

/* ---------------------------------------------------------------- once per visit */
/** Keys already sent during this visit (a visit is one mount of the Discover page, see beginVisit). */
const seen = new Set<string>();
/** The Discover page calls this when it mounts: sections and recommendations count as seen again. */
export function beginVisit() {
  seen.clear();
}
function once(key: string, fire: () => void) {
  if (seen.has(key)) return;
  seen.add(key);
  fire();
}

/**
 * Fires `fire` once per `key` per visit, when the element comes into the upper 70% of the window (so a tall section counts as
 * seen as soon as its top part shows, whatever its height). Without IntersectionObserver it fires at once.
 */
function useViewOnce(ref: RefObject<Element | null>, key: string, fire: () => void) {
  const latest = useRef(fire);
  latest.current = fire;
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const run = () => once(key, () => latest.current());
    if (typeof IntersectionObserver === 'undefined') {
      run();
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          run();
          io.disconnect();
        }
      },
      { rootMargin: '0px 0px -30% 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [ref, key]);
}

/** `discover_section_view`, once per section per visit. Call it in each section component with the ref of its <section>. */
export function useSectionView(ref: RefObject<Element | null>, section: SectionId) {
  useViewOnce(ref, `section:${section}`, () => track('discover_section_view', { section }));
}

/** `recommendation_view`, once per recommendation per visit. Call it in each recommendation card with the ref of its card. */
export function useRecommendationView(ref: RefObject<Element | null>, recommendationId: string) {
  useViewOnce(ref, `rec:${recommendationId}`, () => track('recommendation_view', { recommendation_id: recommendationId, position: recPosition(recommendationId), source: 'section' }));
}

/* ---------------------------------------------------------------- For you cards */
const cardProps = (id: string, filter: ForYouFilter): CardProps | null => {
  const card = CARD_BY_ID.get(id);
  return card ? { card_id: id, card_type: card.kind, position: cardPosition(id, filter), filter } : null;
};
/** The member opened a card (the card itself, not its button). */
export function trackCardClick(id: string, filter: ForYouFilter) {
  const p = cardProps(id, filter);
  if (p) track('for_you_card_click', p);
}
/** The member pressed a card's button (Connect, Join, Request to join, Buy, View project, Request a visit, Read story, View event). */
export function trackCardAction(id: string, filter: ForYouFilter) {
  const p = cardProps(id, filter);
  const card = CARD_BY_ID.get(id);
  if (p && card) track('for_you_card_action', { ...p, action: cardActionId(card) });
}

/* ---------------------------------------------------------------- carousels (Explore, Explore by interest) */
/** While set, scroll events are the result of an arrow press that was tracked already. */
let quietUntil = 0;

/** Arrow buttons: call this instead of track(). The scroll the arrow causes is not reported a second time. */
export function trackCarouselStep(carousel: Carousel, action: 'previous' | 'next', position?: number) {
  quietUntil = Date.now() + 1000;
  track('discover_carousel_interaction', { carousel, action, position });
}

/** 1-based index of the first card that is still (at least partly) inside the scroller. */
function firstVisible(el: HTMLElement) {
  const left = el.getBoundingClientRect().left;
  const kids = Array.from(el.children) as HTMLElement[];
  const i = kids.findIndex((k) => k.getBoundingClientRect().right > left + 8);
  return i < 0 ? 1 : i + 1;
}

/**
 * Reports a horizontal scroll of the carousel once it settles (200 ms after the last scroll event), with the position of the first
 * visible card. The cards must be the direct children of the scroller. Nothing is sent when the position did not change.
 */
export function useCarouselTracking(ref: RefObject<HTMLElement | null>, carousel: Carousel) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let timer: number | undefined;
    let last = firstVisible(el);
    const onScroll = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        if (Date.now() < quietUntil) {
          last = firstVisible(el);
          return;
        }
        const position = firstVisible(el);
        if (position === last) return;
        last = position;
        track('discover_carousel_interaction', { carousel, action: 'scroll', position });
      }, 200);
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.clearTimeout(timer);
      el.removeEventListener('scroll', onScroll);
    };
  }, [ref, carousel]);
}
