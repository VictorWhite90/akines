'use client';

/** Small pieces shared by the 12.2 steps and the Home bands: icons, option cards, progress, fields, notices. */
import { useEffect, useId, useLayoutEffect, useRef, type KeyboardEvent, type ReactNode } from 'react';
import { ArrowLeft, ArrowRight, Check, ChevronLeft, ChevronRight, CircleAlert, CircleCheck, Eye, Lock, Pencil, SlidersHorizontal, Sparkle, X } from 'lucide-react';
import { Field, TextArea } from '@/ui';

type IconProps = { size?: number; className?: string; stroke?: number };
/** Figma icons: 1.25 px strokes at 16 to 20 px, 1.5 px at 24 px (absolute widths, so the weight does not scale with the size). */
const mk = (Cmp: typeof ArrowRight, def: number, stroke?: number) =>
  function CsIcon({ size = def, className, stroke: sw }: IconProps) {
    return <Cmp size={size} strokeWidth={sw ?? stroke ?? (size >= 24 ? 1.5 : 1.25)} absoluteStrokeWidth className={className} aria-hidden="true" focusable="false" />;
  };
export const IcArrowRight = mk(ArrowRight, 16);
export const IcArrowLeft = mk(ArrowLeft, 16, 1);
export const IcCheck = mk(Check, 14);
export const IcChevronLeft = mk(ChevronLeft, 24);
export const IcChevronRight = mk(ChevronRight, 24);
export const IcAlert = mk(CircleAlert, 16);
export const IcCircleCheck = mk(CircleCheck, 16);
export const IcPencil = mk(Pencil, 14);
export const IcSparkles = mk(Sparkle, 16);
export const IcEye = mk(Eye, 20);
export const IcSliders = mk(SlidersHorizontal, 20);
export const IcLock = mk(Lock, 20);
export const IcClose = mk(X, 16);

/* ------------------------------------------------------------------ builder progress */
const BUILDER_STEPS = ['Your idea', 'Your purpose', 'Your progress', 'Your people'];

/** The four-part progress bar of the builder (Figma "Builder progress"): current and finished parts are ink, later parts grey. */
export function BuilderProgress({ step }: { step: 1 | 2 | 3 | 4 }) {
  return (
    <ol className="cs-bp" aria-label="Project builder progress">
      {BUILDER_STEPS.map((name, i) => {
        const n = i + 1;
        const state = n === step ? 'current' : n < step ? 'done' : 'todo';
        return (
          <li key={name} className="cs-bp__cell" data-state={state} aria-current={state === 'current' ? 'step' : undefined}>
            <span className="cs-bp__bar" />
            <span className="cs-bp__label">
              <span className="cs-bp__num">{String(n).padStart(2, '0')}</span>
              <span className="cs-bp__name">{name}</span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}

/* ------------------------------------------------------------------ heading */
export function StepHeading({ eyebrow, title, support, big, focusRef }: { eyebrow: string; title: string; support: string; big?: boolean; focusRef?: React.Ref<HTMLHeadingElement> }) {
  return (
    <div className={'cs-head' + (big ? ' cs-head--big' : '')}>
      <p className="cs-eyebrow">{eyebrow}</p>
      <h1 className="cs-title" tabIndex={-1} ref={focusRef} data-m="words">
        {title}
      </h1>
      <p className="cs-support">{support}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ option cards */
export type OptionItem = { id: string; title: string; text?: string };

type GroupProps = {
  items: OptionItem[];
  /** selected ids (one for a single choice) */
  value: string[];
  onChange: (next: string[]) => void;
  multi?: boolean;
  label: string;
  /** ids that span the whole row */
  wide?: string[];
  /** single choice only: pressing the chosen card again clears it (how the empty A2 frame is reached) */
  deselectable?: boolean;
};

/**
 * Option Card grid (Figma "Option Card": Default, Hover, Pressed, Focus, Selected). Single choice is a radio group with arrow keys,
 * multiple choice is a set of checkboxes.
 */
export function OptionGroup({ items, value, onChange, multi, label, wide = [], deselectable }: GroupProps) {
  const refs = useRef<Array<HTMLButtonElement | null>>([]);
  const checked = (id: string) => value.includes(id);
  const toggle = (id: string) => {
    if (multi) onChange(checked(id) ? value.filter((v) => v !== id) : [...value, id]);
    else onChange(deselectable && checked(id) ? [] : [id]);
  };
  const onKey = (e: KeyboardEvent<HTMLButtonElement>, i: number) => {
    if (multi) return;
    const k = e.key;
    const next = k === 'ArrowRight' || k === 'ArrowDown' ? i + 1 : k === 'ArrowLeft' || k === 'ArrowUp' ? i - 1 : null;
    if (next === null) return;
    e.preventDefault();
    const j = (next + items.length) % items.length;
    refs.current[j]?.focus();
    onChange([items[j].id]);
  };
  // roving tab stop for a radio group: the selected card (or the first) is the one in the tab order
  const stop = multi ? -1 : Math.max(0, items.findIndex((it) => checked(it.id)));
  return (
    <div className="cs-opts" role={multi ? 'group' : 'radiogroup'} aria-label={label}>
      {items.map((it, i) => {
        const on = checked(it.id);
        return (
          <button
            key={it.id}
            ref={(el) => {
              refs.current[i] = el;
            }}
            type="button"
            role={multi ? 'checkbox' : 'radio'}
            aria-checked={on}
            tabIndex={multi || i === stop ? 0 : -1}
            className="cs-opt"
            data-selected={on || undefined}
            data-wide={wide.includes(it.id) || undefined}
            onClick={() => toggle(it.id)}
            onKeyDown={(e) => onKey(e, i)}
          >
            <span className="cs-opt__meta">
              <span className="cs-opt__num">{String(i + 1).padStart(2, '0')}</span>
              <span className="cs-opt__mark" aria-hidden="true">
                <IcCheck size={14} />
              </span>
            </span>
            <span className="cs-opt__title">{it.title}</span>
            {it.text ? <span className="cs-opt__text">{it.text}</span> : null}
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ notice */
export function Notice({ title, children, tone = 'accent' }: { title: string; children: ReactNode; tone?: 'accent' | 'error' }) {
  return (
    <div className="cs-notice" data-tone={tone}>
      <span className="cs-notice__rule" aria-hidden="true" />
      <div className="cs-notice__body">
        <p className="cs-notice__title">{title}</p>
        <p className="cs-notice__text">{children}</p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ text field */
type TextFieldProps = {
  label: string;
  hint: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  /** minimum height of the box in px (idea 120, purpose answers 144) */
  min: number;
  error?: string;
  onBlur?: () => void;
  autoFocus?: boolean;
  fieldRef?: React.Ref<HTMLTextAreaElement>;
  name?: string;
  rows?: number;
};

/** Text Field from the kit with the builder's behaviour: grows with its text, ink border once filled, error row from the kit. */
export function TextField({ label, hint, value, onChange, placeholder, min, error, onBlur, name, fieldRef, rows }: TextFieldProps) {
  const id = useId();
  const own = useRef<HTMLTextAreaElement | null>(null);
  const fit = () => {
    const el = own.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.max(min, el.scrollHeight + 2) + 'px';
  };
  useLayoutEffect(fit, [value, min]);
  useEffect(() => {
    // fonts load after the first paint and change the wrapping
    const f = document.fonts?.ready;
    if (f) void f.then(fit);
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <Field label={label} hint={hint} error={error} htmlFor={id} className="cs-field">
      <TextArea
        id={id}
        name={name}
        ref={(el) => {
          own.current = el;
          if (typeof fieldRef === 'function') fieldRef(el);
          else if (fieldRef) (fieldRef as React.MutableRefObject<HTMLTextAreaElement | null>).current = el;
        }}
        value={value}
        rows={rows ?? 1}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onBlur}
        style={{ ['--cs-ta-min' as string]: min + 'px' }}
      />
    </Field>
  );
}

/* ------------------------------------------------------------------ back link and actions */
/** Figma "Back Link": arrow and label, no box. */
export function BackLink({ onClick, children = 'Back' }: { onClick?: () => void; children?: ReactNode }) {
  return (
    <button type="button" className="cs-back" onClick={onClick}>
      <IcArrowLeft />
      <span>{children}</span>
    </button>
  );
}

export function QuestionProgress({ n }: { n: 1 | 2 | 3 | 4 }) {
  return (
    <div className="cs-qp" role="img" aria-label={`Question ${n} of 4`}>
      <p className="cs-qp__text" aria-hidden="true">
        Question {n} of 4
      </p>
      <div className="cs-qp__bars" aria-hidden="true">
        {[1, 2, 3, 4].map((i) => (
          <span key={i} className="cs-qp__bar" data-on={i <= n || undefined} />
        ))}
      </div>
    </div>
  );
}
