'use client';

import { useSyncExternalStore } from 'react';
import { useProject, type ProjectKey } from '../workspace/project';
import { REFLECTION, type Choice } from './data';

/**
 * The person's own check-in, kept for this visit only (not across reloads), like workspace/store.ts.
 * It is private by design: the answers and the written note live in this module and are read only by the check-in screen.
 * They are never sent anywhere and no other screen of the journey shows them. The team summary is made of combined themes.
 * Each project has its own check-in: what is answered on Career Guidance for Everyone never shows on Adire Stories, and the
 * other way round. Adire Stories starts from its own sample answers.
 */
type State = { answers: Choice[]; note: string };

const states: Record<ProjectKey, State> = {
  career: { answers: REFLECTION.career.initialAnswers, note: '' },
  adire: { answers: REFLECTION.adire.initialAnswers, note: '' },
};
const listeners = new Set<() => void>();
const set = (project: ProjectKey, patch: Partial<State>) => {
  states[project] = { ...states[project], ...patch };
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};

/** The check-in of the project of the page being shown. */
export function useCheckInStore<T>(select: (s: State) => T): T {
  const { key } = useProject();
  return useSyncExternalStore(
    subscribe,
    () => select(states[key]),
    () => select(states[key]),
  );
}

export const checkIn = {
  /** One answer per question. Choosing the chosen option again clears the answer (Rating Option, State=Selected). */
  pick(project: ProjectKey, question: number, option: number) {
    const next = states[project].answers.slice();
    next[question] = next[question] === option ? null : option;
    set(project, { answers: next });
  },
  setNote(project: ProjectKey, note: string) {
    set(project, { note });
  },
};
