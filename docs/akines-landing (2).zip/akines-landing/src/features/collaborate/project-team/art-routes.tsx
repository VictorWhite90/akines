import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { TEAM_PATHS } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Only the Team page is mirrored. The member detail, the empty team, the answered states and the overlay frames are not: Adire members have
 * no member detail, and the invite and Not now modals, their toasts and the answered request all happen on the Team page itself.
 */
const MIRRORED: string[] = [TEAM_PATHS.team];

export const artRoutes: RouteDef[] = routes.filter((r) => MIRRORED.includes(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
