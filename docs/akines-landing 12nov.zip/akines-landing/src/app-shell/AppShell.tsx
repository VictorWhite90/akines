'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { useNav, usePath } from '@/lib/nav';
import { useSession } from '@/lib/auth';
import { useLayout } from '@/lib/hooks';
import { NotificationsModal } from '@/features/community/NotificationsModal';
import type { RouteDef, MainPage } from '@/routes.types';
import { DesktopHeader, MobileHeader, TabletHeader } from './AppHeader';
import { BottomBar, PageSheet, ProfileSheet } from './BottomNav';
import { MobileTopBar } from './MobileTopBar';
import { ToastHost } from '@/ui/toast';
import { Motion } from '@/components/Motion';
import { rememberNext } from '@/lib/next-path';

export { NEXT_KEY, rememberNext, takeNext } from '@/lib/next-path';

/**
 * Phones without the bottom bar (chat threads) have a composer pinned at the bottom instead. Its height is published as
 * `--m-composer-h` on <html> so the Create AI launcher can sit above it. The composer is found by `data-mobile-composer`
 * (or the Community `.ch-composer`).
 */
function useComposerHeight(active: boolean, path: string) {
  useEffect(() => {
    if (!active) return;
    const html = document.documentElement;
    html.dataset.mBottombar = 'off';
    let el: Element | null = null;
    let ro: ResizeObserver | null = null;
    const attach = () => {
      const next = document.querySelector('[data-mobile-composer]') ?? document.querySelector('.ch-composer');
      if (next === el) return;
      ro?.disconnect();
      ro = null;
      el = next;
      if (!el) {
        html.style.removeProperty('--m-composer-h');
        return;
      }
      const measure = () => {
        if (el) html.style.setProperty('--m-composer-h', `${Math.round(el.getBoundingClientRect().height)}px`);
      };
      measure();
      ro = new ResizeObserver(measure);
      ro.observe(el);
    };
    attach();
    const mo = new MutationObserver(attach);
    mo.observe(document.body, { childList: true, subtree: true });
    return () => {
      mo.disconnect();
      ro?.disconnect();
      delete html.dataset.mBottombar;
      html.style.removeProperty('--m-composer-h');
    };
  }, [active, path]);
}

/**
 * Signed-in frame: header (desktop), header and bottom bar (tablet), header or top bar, bottom bar and sheets (mobile),
 * plus the page content. Signed-out visitors are sent to the sign-in panel and come back to the page they asked for.
 * Phones follow `route.mobile`: bar "top" shows the top bar (back button and title) instead of the header, and
 * `bottomBar: false` hides the bottom bar (chat threads).
 */
export function AppShell({ route, children }: { route: RouteDef; children: ReactNode }) {
  const session = useSession();
  const nav = useNav();
  const path = usePath();
  const layout = useLayout();
  const [mounted, setMounted] = useState(false);
  const [sheet, setSheet] = useState<MainPage | null>(null);
  const [profile, setProfile] = useState(false);
  const [notifications, setNotifications] = useState(false);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (mounted && !session.signedIn) {
      rememberNext(path);
      nav.replace('/sign-in');
    }
  }, [mounted, session.signedIn, path, nav]);
  // close sheets when the screen changes
  useEffect(() => {
    setSheet(null);
    setProfile(false);
  }, [path]);

  const active = route.nav;
  const openNotifications = () => setNotifications(true);
  // Lets overlay styles (portalled outside .app) follow the section: Community modals use a flat 28% scrim, Collaborate a blurred 35% one.
  const activePage = active?.page;
  useEffect(() => {
    if (!activePage) return;
    document.documentElement.dataset.page = activePage;
    return () => {
      delete document.documentElement.dataset.page;
    };
  }, [activePage]);

  const phone = layout === 'mobile';
  const m = route.mobile;
  const topBar = phone && m?.bar === 'top';
  const bottomBar = layout === 'tablet' || (phone && m?.bottomBar !== false);
  useComposerHeight(phone && !bottomBar, path);

  return (
    <div
      className="app"
      data-layout={layout}
      data-ready={mounted && session.signedIn ? 'true' : 'false'}
      data-bar={topBar ? 'top' : undefined}
      data-bottombar={phone && !bottomBar ? 'off' : undefined}
    >
      <a className="skip-link" href="#main">Skip to content</a>
      {layout === 'desktop' ? <DesktopHeader active={active} onNotifications={openNotifications} /> : null}
      {layout === 'tablet' ? <TabletHeader active={active} onNotifications={openNotifications} /> : null}
      {phone && topBar ? <MobileTopBar title={m?.title ?? route.title} back={m?.back} /> : null}
      {phone && !topBar ? <MobileHeader active={active} open={profile} onProfile={() => setProfile(true)} /> : null}
      <main id="main" className="app__main" tabIndex={-1}>
        {mounted && session.signedIn ? (
          <div className="route-stage" key={path}>{children}</div>
        ) : null}
      </main>
      {bottomBar ? <BottomBar active={active} onOpenPage={setSheet} /> : null}
      {layout !== 'desktop' ? <PageSheet page={sheet} active={active} onClose={() => setSheet(null)} /> : null}
      {phone ? <ProfileSheet open={profile} onClose={() => setProfile(false)} onNotifications={openNotifications} /> : null}
      <NotificationsModal open={notifications} onClose={() => setNotifications(false)} />
      <ToastHost />
      {mounted && session.signedIn ? <Motion key={path} /> : null}
    </div>
  );
}
