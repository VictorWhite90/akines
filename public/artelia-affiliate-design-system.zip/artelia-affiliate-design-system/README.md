# Artelia Affiliate — Editorial Luxury Design System

A drop-in Next.js App Router + React + TypeScript starter for the Artelia Affiliate dashboard.

## Design direction
- Gallery Ivory canvas: `#F7F4EE`
- White surfaces: `#FFFFFF`
- Gallery Charcoal: `#242824`
- Terracotta accent: `#C77B36`
- Warm Stone borders: `#E9E3D9`
- Muted Sage positive states: `#607A66`
- Display font: DM Serif Display
- Interface font: DM Sans

## Requirements
- Next.js App Router
- React
- TypeScript
- `lucide-react`

Install the icon package if it is not already installed:

```bash
npm install lucide-react
```

## Add to your project

1. Copy `app/globals.css` into your app's global stylesheet (or merge the tokens and component styles into your existing file).
2. Copy `components/` into your project.
3. In your existing `app/layout.tsx`, load the fonts using the snippet below.
4. Render `<Dashboard />` from a page or use the individual components in your existing dashboard.
5. Replace the sample values and artwork placeholders with your API data.

### Font setup for `app/layout.tsx`

```tsx
import type { Metadata } from "next";
import { DM_Sans, DM_Serif_Display } from "next/font/google";
import "./globals.css";

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-dm-sans",
  display: "swap",
});

const dmSerif = DM_Serif_Display({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-dm-serif",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Artelia Affiliate",
  description: "Your private Artelia workspace",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${dmSans.variable} ${dmSerif.variable}`}>
        {children}
      </body>
    </html>
  );
}
```

## Suggested typography scale

| Token | Size | Use |
|---|---:|---|
| `--text-xs` | 12px | Supporting labels |
| `--text-sm` | 14px | Body, navigation |
| `--text-base` | 16px | Main body |
| `--text-lg` | 18px | Card titles |
| `--text-xl` | 24px | Section headings |
| `--text-2xl` | 32px | Metrics |
| `--text-display` | clamp(30px, 3vw, 40px) | Page heading |

## Important integration notes
- This is a presentation starter. It does not replace your authentication, API calls, payout logic, artwork management, or routing.
- Keep your existing data-fetching and business logic. Replace only the visual layer.
- The artwork tiles use CSS placeholders so the page works immediately. Replace them with your actual artwork images using `next/image`.
- Sidebar links are sample links; connect them to your existing routes.
- The dashboard is responsive: the sidebar becomes a horizontal mobile navigation strip.

## Customization
Edit the CSS variables at the top of `app/globals.css` to change the visual identity globally.
