'use client';

import './applicants.css';
import { useRef } from 'react';
import { Button, Field, TextArea } from '@/ui';
import { toast } from '@/ui/toast';
import { StatusPill } from '../applications/shared';
import { CardLink, Dot, Over } from '../workspace/atoms';
import { SlideOut } from '../workspace/slideout';
import { APPLICANTS, ROW, SLIDE, subline, type ApplicantId, type Status } from './data';
import { Portrait } from './parts';
import { applicants, noteState, useApplicantState } from './store';

/**
 * Slide-out:Applicant (Applicant Detail, 17972:147955): the same 480 wide right panel as the member slide-out. Portrait, name, subline and
 * status, what the person wants to join as, availability, message, skills, a Private Note and the actions of the status:
 *   New          Shortlist, Not now
 *   Shortlisted  Propose times, Send offer (off until a talk is booked), Not now as a link
 *   Talk booked  Send offer, Not now
 * A person in another status has no slide-out in the design (their View applicant stays plain), so none is opened for them.
 * Shortlist changes the status in place, which swaps the slide-out for the Shortlisted one (the frames "Amina Yusuf, shortlisted").
 */

export type SlideHandlers = {
  shortlist?: (id: ApplicantId) => void;
  propose?: (id: ApplicantId) => void;
  offer?: (id: ApplicantId) => void;
  notNow?: (id: ApplicantId) => void;
};

function Footer({ id, status, h }: { id: ApplicantId; status: Status; h: SlideHandlers }) {
  const call = APPLICANTS[id].group === 'call';
  if (status === 'New') {
    return (
      <>
        <Button size="sm" onClick={() => h.shortlist?.(id)}>
          {ROW.shortlist}
        </Button>
        <Button size="sm" variant="secondary" onClick={() => h.notNow?.(id)}>
          {ROW.notNow}
        </Button>
      </>
    );
  }
  if (call) return null;
  if (status === 'Shortlisted') {
    return (
      <>
        <Button size="sm" onClick={() => h.propose?.(id)}>
          {ROW.proposeTimes}
        </Button>
        <Button size="sm" variant="secondary" disabled>
          {ROW.sendOffer}
        </Button>
        <CardLink onClick={() => h.notNow?.(id)}>{ROW.notNow}</CardLink>
      </>
    );
  }
  if (status === 'Talk booked') {
    return (
      <>
        <Button size="sm" onClick={() => h.offer?.(id)}>
          {ROW.sendOffer}
        </Button>
        <Button size="sm" variant="secondary" onClick={() => h.notNow?.(id)}>
          {ROW.notNow}
        </Button>
      </>
    );
  }
  return null;
}

export function ApplicantSlideOut({ id, onClose, h }: { id: ApplicantId | null; onClose: () => void; h: SlideHandlers }) {
  const s = useApplicantState();
  // the panel keeps its person while it leaves
  const last = useRef<{ id: ApplicantId; status: Status } | null>(null);
  if (id) last.current = { id, status: s.status[id] };
  const shown = last.current;
  if (!shown) return null;
  const a = APPLICANTS[shown.id];
  const { status } = shown;
  const draft = s.drafts[a.id] ?? '';
  const ns = noteState(s, a.id);

  const save = () => {
    applicants.saveNote(a.id);
    toast.show({ message: SLIDE.noteToast });
  };

  return (
    <SlideOut open={id !== null} onClose={onClose} eyebrow={SLIDE.eyebrow} label={`${SLIDE.eyebrow} ${a.name}`} footer={<Footer id={a.id} status={status} h={h} />}>
      <div className="cd-member ap-slide">
        <div className="cd-member__body">
          <div className="ap-id">
            <Portrait src={a.photo} size={72} />
            <div className="ap-id__text">
              <h2 className="ap-id__name" tabIndex={-1} data-autofocus>
                {a.name}
              </h2>
              <p className="ap-id__sub">{subline(a, status)}</p>
              <StatusPill status={status} />
            </div>
          </div>
          <div className="ap-facts">
            <div className="ap-field">
              <Over className="cw-over--12">{ROW.wants}</Over>
              <p className="ap-field__value">{a.wants}</p>
            </div>
            <div className="ap-field">
              <Over className="cw-over--12">{ROW.availability}</Over>
              <p className="ap-field__value">{a.availability}</p>
            </div>
          </div>
          <div className="ap-block">
            <Over className="cw-over--12">{ROW.message}</Over>
            <p className="ap-field__value">{a.message}</p>
          </div>
          <div className="ap-block">
            <Over className="cw-over--12">{SLIDE.skills}</Over>
            <ul className="cd-chips" aria-label="Skills">
              {a.skills.map((sk) => (
                <li key={sk}>{sk}</li>
              ))}
            </ul>
          </div>
          <div className="ap-note">
            <Field label={SLIDE.note.label} hint={SLIDE.note.helper}>
              <TextArea className="ap-ta" value={draft} placeholder={SLIDE.note.placeholder} onChange={(e) => applicants.setDraft(a.id, e.target.value)} />
            </Field>
            <div className="ap-note__actions">
              <Button size="sm" variant="secondary" disabled={ns !== 'draft'} onClick={save}>
                {SLIDE.note.save}
              </Button>
              {ns === 'saved' ? (
                <span className="ap-note__saved" role="status">
                  <Dot tone="green" size={8} />
                  {SLIDE.note.saved}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </SlideOut>
  );
}
