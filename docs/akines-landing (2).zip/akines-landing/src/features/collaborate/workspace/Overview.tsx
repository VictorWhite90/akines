'use client';

import './workspace.css';
import './overview.css';
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { Button, EmptyState, Field, Modal, TextArea, toast } from '@/ui';
import { BRIEF_PARTS, CRITERIA, MILESTONES, MILESTONE_WORK, OUTSTANDING, PATHS, type BriefPart, type Step, type WorkItem } from './data';
import { useOverviewDash } from './art-data';
import { DashCard, DashLabel, DashPair, Glance, MetricCard, MetricRow, SlimRow, StageTracker, StatusBar, WeekBars, type Stage } from './dash';
import { EMPTY_METRICS, type OverviewDash } from './overview-data';
import { useProject } from './project';
import { DEFAULT_DETAILS, MILESTONE_2 } from '../project-header/data';
import { useHeaderState } from '../project-header/store';
import { InterestRequestsBand } from '../applicants/band';
import { ActionButton, Availability, BackLink, Band, CardLink, Ctx, Decision, Dot, PageHead, Steps, UpcomingSession, WorkRow, WorkspaceFrame } from './parts';

/**
 * 12.11 Project overview: Overview, Empty, Shared project brief (with Modal: Suggest a change and Toast: Suggestion sent), Milestone detail
 * and Milestone detail (Prototype Review). The Overview is a dashboard (Figma 17364:24207): the header, four metric cards, project progress,
 * task status beside this week, the brief at a glance and the two rows of "Continue working". Its right column is the shared project rail.
 */

/** The pages the cards of the dashboard open. A card without an entry has no destination in the design and is a plain card. */
export type OverviewLinks = {
  milestones?: string;
  tasks?: string;
  review?: string;
  decisions?: string;
  /** The three progress stages, in order. */
  stages?: (string | undefined)[];
  /** The task status card. */
  board?: string;
  /** "View full brief". */
  brief?: string;
  /** The two "Continue working" rows. */
  work?: (string | undefined)[];
};

function Metrics({ m, links }: { m: OverviewDash['metrics']; links: Pick<OverviewLinks, 'milestones' | 'tasks' | 'review' | 'decisions'> }) {
  return (
    <MetricRow>
      <MetricCard label="MILESTONES" value={m.milestones.value} caption={m.milestones.caption} dot={m.milestones.dot} href={links.milestones} />
      <MetricCard label="OPEN TASKS" value={m.tasks.value} caption={m.tasks.caption} dot={m.tasks.dot} href={links.tasks} />
      <MetricCard label="TO REVIEW" value={m.review.value} caption={m.review.caption} dot={m.review.dot} href={links.review} />
      <MetricCard label="DECISIONS" value={m.decisions.value} caption={m.decisions.caption} dot={m.decisions.dot} href={links.decisions} />
    </MetricRow>
  );
}

/** The Task status card: the whole card opens the board view of Tasks (Figma Task status reaction). */
function TaskStatusCard({ d, href }: { d: OverviewDash; href?: string }) {
  const body = (
    <>
      <header className="cd-card__head">
        <h3 className="cd-card__title">TASK STATUS</h3>
      </header>
      <StatusBar items={d.status} />
    </>
  );
  return href ? (
    <Link href={href} className="cd-card ov-linkcard" data-m="up">
      {body}
    </Link>
  ) : (
    <section className="cd-card" data-m="up">
      {body}
    </section>
  );
}

/**
 * The centre column of the Overview of a project (also the sample projects of 12.26): header, metric cards, project progress, task status
 * and this week, brief at a glance, continue working. The caller puts it in a frame with the project rail.
 */
export function OverviewBody({ name, lead, d, links = {}, requests }: { name: string; lead: string; d: OverviewDash; links?: OverviewLinks; requests?: ReactNode }) {
  const stages: Stage[] = d.stages.map((s, i) => ({ ...s, href: links.stages?.[i] }));
  return (
    <div className="ov">
      <PageHead label="OVERVIEW" title={name} lead={lead} />
      <Metrics m={d.metrics} links={links} />
      {requests}
      <DashCard title="PROJECT PROGRESS" id="progress">
        <StageTracker stages={stages} />
      </DashCard>
      <DashPair>
        <TaskStatusCard d={d} href={links.board} />
        <DashCard title="THIS WEEK" id="this-week">
          <WeekBars total={d.week.total} caption={d.week.caption} bars={d.week.bars} today={d.week.today} />
        </DashCard>
      </DashPair>
      <DashCard title="BRIEF AT A GLANCE" id="brief-glance">
        <Glance items={d.glance} link={<CardLink href={links.brief}>View full brief</CardLink>} />
      </DashCard>
      <section className="ov-continue" data-m="up" aria-label="Continue working">
        <DashLabel>CONTINUE WORKING</DashLabel>
        <div className="cd-rows">
          {d.work.map((w, i) => (
            <SlimRow key={w.title} title={w.title} status={w.status} href={links.work?.[i]} />
          ))}
        </div>
      </section>
    </div>
  );
}

/**
 * Name and line under the title. Career Guidance for Everyone shows the saved project details when they were edited (Edit project details in the
 * project header); the design line is shown until then. The other projects show their own copy.
 */
function useHead(d: OverviewDash) {
  const { key } = useProject();
  const { details } = useHeaderState();
  const career = key === 'career';
  return { name: career ? details.name : d.name, lead: career && details.summary !== DEFAULT_DETAILS.summary ? details.summary : d.lead };
}

/* ------------------------------------------------------------------ Overview */

export function Overview() {
  const { key, nav } = useProject();
  const d = useOverviewDash();
  const head = useHead(d);
  // the brief page is a Career Guidance page only: on Adire Stories the first stage and "View full brief" have no destination
  const career = key === 'career';
  const milestones = `${nav.tasks}/milestones`;
  const links: OverviewLinks = {
    milestones,
    tasks: nav.tasks,
    review: nav.tasks,
    decisions: nav.decisions,
    stages: career ? [PATHS.brief, PATHS.milestone, milestones] : [undefined, milestones, milestones],
    board: `${nav.tasks}/board`,
    brief: career ? PATHS.brief : undefined,
    work: career ? [PATHS.draftFile, nav.conversations] : [nav.files, nav.conversations],
  };
  return (
    <WorkspaceFrame active="overview" rail>
      {/* Interest requests (Figma 02b) sit between the metric cards and Project progress, on the Career and Adire overviews */}
      <OverviewBody name={head.name} lead={head.lead} d={d} links={links} requests={<InterestRequestsBand />} />
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Overview, Empty */

/** Overview Empty (17364:24822): the four cards at zero, the empty state, and the short rail (meeting card and team availability). */
export function OverviewEmpty() {
  const { nav } = useProject();
  const d = useOverviewDash();
  const head = useHead(d);
  return (
    <WorkspaceFrame active="overview" rail="short">
      <div className="ov">
        <PageHead label="OVERVIEW" title={head.name} lead={head.lead} />
        <Metrics m={EMPTY_METRICS} links={{ milestones: `${nav.tasks}/milestones`, tasks: `${nav.tasks}/state-empty`, review: nav.tasks, decisions: `${nav.decisions}/state-empty` }} />
        <div data-m="up">
          <EmptyState
            className="cw-empty"
            title="Your project is ready for its next step."
            text="Once your team begins creating, you'll find your progress and priorities here."
            action={
              <ActionButton href={`${nav.tasks}/state-empty`} arrow>
                Open tasks
              </ActionButton>
            }
          />
        </div>
      </div>
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Shared project brief */

const SUGGESTION = 'Add that teachers can see the shortlist too, so they can support the student after the first conversation.';

function SuggestModal({ part, open, onClose }: { part: BriefPart | null; open: boolean; onClose: () => void }) {
  const [text, setText] = useState(SUGGESTION);
  const [error, setError] = useState('');
  const last = useRef<BriefPart | null>(null);
  if (part) last.current = part;
  const shown = part ?? last.current;

  // every opening starts again from the prefilled suggestion
  useEffect(() => {
    if (open) {
      setText(SUGGESTION);
      setError('');
    }
  }, [open, part]);

  const send = (e?: FormEvent) => {
    e?.preventDefault();
    if (!text.trim()) {
      setError('Write a short message to continue.');
      return;
    }
    onClose();
    toast.show({ message: 'Suggestion sent to the team.', actionLabel: 'Undo', duration: 2500 });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow="SUGGEST A CHANGE"
      title={shown ? `${shown.number} ${shown.heading}` : ''}
      description="Tell the team what you would change and why. Significant changes need the team's acknowledgement."
      footer={
        <>
          <Button type="submit" form="cw-suggest-form">
            Send suggestion
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="cw-suggest-form" onSubmit={send} noValidate>
        <Field label="Your suggestion" hint="The team will see your name with the suggestion." error={error || undefined}>
          <TextArea
            rows={3}
            className="cw-ta"
            value={text}
            placeholder="Describe the change you suggest and why."
            onChange={(e) => {
              setText(e.target.value);
              if (error) setError('');
            }}
          />
        </Field>
      </form>
    </Modal>
  );
}

function BriefContext() {
  return (
    <>
      <Ctx label="BRIEF VERSION">
        <p className="cw-session__title">Version 3</p>
        <p className="cw-ctx__line">Updated 2 days ago by Adaeze Okoye</p>
        <CardLink arrow>View version history</CardLink>
      </Ctx>
      <Ctx label="WAITING FOR THE TEAM">
        <p className="cw-ctx__item">1 change needs acknowledgement.</p>
        <p className="cw-ctx__line">2 of 4 members have acknowledged it.</p>
      </Ctx>
      <Availability />
      <Ctx label="CREATE AI">
        <span className="cw-aitag">AI SUGGESTIONS</span>
        <p className="cw-ctx__line">Create AI can suggest improvements to the brief. It never changes the brief without your approval.</p>
      </Ctx>
    </>
  );
}

export function Brief() {
  const [part, setPart] = useState<BriefPart | null>(null);
  const [open, setOpen] = useState(false);
  const show = (p: BriefPart) => {
    setPart(p);
    setOpen(true);
  };
  return (
    <WorkspaceFrame active="overview" context={<BriefContext />}>
      <PageHead back={<BackLink href={PATHS.overview}>Back to overview</BackLink>} label="SHARED PROJECT BRIEF" title="The project brief." lead="A living document that defines the project's direction. Every member can suggest changes.">
        <p className="cw-pagehead__meta">Version 3. Updated 2 days ago by Adaeze Okoye.</p>
        <div>
          <Button variant="secondary" onClick={() => show(BRIEF_PARTS[0])}>
            Suggest a change
          </Button>
        </div>
      </PageHead>

      <ol className="cw-parts" data-m="stagger">
        {BRIEF_PARTS.map((p) => (
          <li key={p.number}>
            <button type="button" className="cw-part" onClick={() => show(p)} aria-haspopup="dialog">
              <span className="cw-part__n">{p.number}</span>
              <span className="cw-part__text">
                <span className="cw-part__main">
                  <span className="cw-over">{p.title}</span>
                  <span className="cw-part__body">{p.body}</span>
                </span>
                {/* Brief Part hover and focus: the row grows to show the action (Figma Brief Part, State=Hover) */}
                <span className="cw-part__hint" aria-hidden="true">
                  <span className="cw-part__hintin">
                    <span className="cw-link">
                      <span className="cw-link__label">Suggest a change</span>
                    </span>
                  </span>
                </span>
              </span>
            </button>
          </li>
        ))}
      </ol>
      <SuggestModal part={part} open={open} onClose={() => setOpen(false)} />
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Milestone detail */

function MilestoneContext() {
  return (
    <>
      <Availability label="RESPONSIBLE" only={['AO', 'TA']} />
      <UpcomingSession />
      <Decision />
    </>
  );
}

function MilestoneContextTwo() {
  return (
    <>
      <Availability label="RESPONSIBLE" only={['TA', 'NE']} />
      <UpcomingSession />
      <Decision />
    </>
  );
}

/** One milestone page: header with its status, completion criteria, related work and outstanding items. */
function MilestonePage({
  title,
  status,
  tone,
  due,
  description,
  criteria,
  work,
  outstanding,
  context,
}: {
  title: string;
  status: string;
  tone: 'accent' | 'gray';
  due: string;
  description: string;
  criteria: Step[];
  work: WorkItem[];
  outstanding: { title: string; caption: string }[];
  context: ReactNode;
}) {
  return (
    <WorkspaceFrame active="overview" context={context}>
      <PageHead back={<BackLink href={PATHS.overview}>Back to overview</BackLink>} label="MILESTONE" title={title}>
        <div className="cw-mstatus">
          <span className="cw-mstatus__state">
            <Dot tone={tone} />
            {status}
          </span>
          <span>{due}</span>
        </div>
        <p className="cw-pagehead__lead">{description}</p>
      </PageHead>

      <Band label="COMPLETION CRITERIA" title="What done looks like." support="The milestone is complete when all three are true.">
        <Steps steps={criteria} />
      </Band>

      <Band label="RELATED WORK" title="The work behind this milestone." support="Open any item to continue where it stands.">
        <div className="cw-rows">
          {work.map((w) => (
            <WorkRow key={w.id} item={w} />
          ))}
        </div>
      </Band>

      <Band label="OUTSTANDING ITEMS" title="Still to be settled." support="Items that need attention before the milestone closes.">
        <ul className="cw-outstanding">
          {outstanding.map((o) => (
            <li key={o.title}>
              <Dot />
              <div>
                <p className="cw-outstanding__title">{o.title}</p>
                <p className="cw-outstanding__cap">{o.caption}</p>
              </div>
            </li>
          ))}
        </ul>
      </Band>
    </WorkspaceFrame>
  );
}

export function MilestoneDetail() {
  const m = MILESTONES[0];
  return <MilestonePage title={m.title} status="IN PROGRESS" tone="accent" due={m.due} description={m.description} criteria={CRITERIA} work={MILESTONE_WORK} outstanding={OUTSTANDING} context={<MilestoneContext />} />;
}

/** Frame "Milestone detail (Prototype Review)". Its related work has no destination in the design. */
export function MilestoneDetailTwo() {
  const m = MILESTONE_2;
  return <MilestonePage title={m.title} status={m.status} tone="gray" due={m.due} description={m.description} criteria={m.criteria} work={m.work} outstanding={m.outstanding} context={<MilestoneContextTwo />} />;
}
