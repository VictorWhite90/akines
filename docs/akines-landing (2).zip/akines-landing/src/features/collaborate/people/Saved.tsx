'use client';

import { Button, toast } from '@/ui';
import { asset } from '@/lib/assets';
import { BackLink, EmptyCard, Heading, StatusPill } from './cc-ui';
import { PEOPLE, R, REQUESTS, requestRoute, type PersonId } from './data';
import { PersonCard } from './PersonCard';
import { ccStore, useCc } from './store';

function SavedView({ staticEmpty }: { staticEmpty?: boolean }) {
  const { saved } = useCc();
  const list = staticEmpty ? [] : saved;

  const remove = (id: PersonId) => {
    const undo = ccStore.unsave(id);
    toast.show({ message: 'Removed from your saved collaborators.', actionLabel: 'Undo', onAction: undo });
  };

  return (
    <div className="cc-page cc-list">
      <BackLink href={R.discovery}>Back to collaborators</BackLink>
      <div className="cc-list__head">
        <Heading eyebrow="Saved for later" title="People worth a conversation." support="Saving never contacts anyone. Request an introduction whenever you’re ready." className="cc-list__heading" />
        <div className="cc-list__link" data-m="up">
          <Button variant="link" href={staticEmpty ? R.requestsEmpty : R.requests}>
            Introduction requests
          </Button>
        </div>
      </div>

      {list.length ? (
        <div className="cc-grid" data-m="stagger">
          {list.map((id) => (
            <PersonCard key={id} person={PEOPLE[id]} saved saveLabel="Remove from saved" hideNotRelevant onSave={() => remove(id)} />
          ))}
        </div>
      ) : (
        <EmptyCard
          title="Your next collaborator is waiting to be discovered."
          text="Save people whose skills and interests may complement your projects."
          action={
            <div>
              <Button href={R.discovery}>Explore collaborators</Button>
            </div>
          }
        />
      )}
    </div>
  );
}

/** B11 Saved collaborators (Figma 17218:16992; Toast 17219:17965; empty 17218:17369). Route /collaborate/saved-collaborators. */
export default function Saved() {
  return <SavedView />;
}

/** B11 Empty (Figma 17218:17369), reached from B12 empty. */
export function SavedEmpty() {
  return <SavedView staticEmpty />;
}

function RequestsView({ staticEmpty }: { staticEmpty?: boolean }) {
  const { withdrawn } = useCc();
  // a request withdrawn on its 12.47 page is no longer listed (B12 after withdrawn, Figma 17974:164047)
  const list = staticEmpty ? [] : REQUESTS.filter((r) => !withdrawn.includes(r.key));
  return (
    <div className="cc-page cc-list">
      <BackLink href={R.discovery}>Back to collaborators</BackLink>
      <div className="cc-list__head">
        <Heading
          eyebrow="Your introductions"
          title="Where each introduction stands."
          support="You decide who to contact. Each person decides whether to connect."
          className="cc-list__heading"
        />
        <div className="cc-list__link" data-m="up">
          <Button variant="link" href={staticEmpty ? R.savedEmpty : R.saved}>
            Saved collaborators
          </Button>
        </div>
      </div>

      {list.length ? (
        <ul className="cc-reqs" data-m="stagger">
          {list.map((r) => (
            <li className="cc-req-row" key={r.key}>
              <div className="cc-req-row__photo">
                <img src={asset(PEOPLE[r.id].photo)} alt="" loading="lazy" decoding="async" width={96} height={120} />
              </div>
              <div className="cc-req-row__info">
                <h2 className="cc-req-row__name">{r.name}</h2>
                <p className="cc-req-row__role">{r.role}</p>
                <p className="cc-req-row__project">For Career Guidance for Everyone</p>
                <p className="cc-req-row__msg">{r.message}</p>
              </div>
              <div className="cc-req-row__status">
                <StatusPill status={r.status} />
                <p className="cc-req-row__date">{r.date}</p>
                <Button variant="link" href={requestRoute(r.id, r.status)}>
                  View request
                </Button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyCard
          title="No introductions yet."
          text="When you request a connection, you’ll be able to follow its progress here."
        />
      )}
    </div>
  );
}

/** B12 Introduction requests (Figma 17218:17542). Route /collaborate/introduction-requests. */
export function Requests() {
  return <RequestsView />;
}

/** B12 Empty (Figma 17218:17742). No trigger in the prototype, so it has its own route. */
export function RequestsEmpty() {
  return <RequestsView staticEmpty />;
}
