/**
 * Sample data of the project workspace (12.10 My projects, 12.11 Project overview, 12.12 Studio; the Conversations data of 12.13 lives in conversations/data.ts).
 * Copy is taken from the Figma frames. One sample workspace exists: "Career Guidance for Everyone".
 */

export const BASE = '/collaborate/my-projects';
export const SLUG = 'career-guidance-for-everyone';
export const PROJECT_PATH = `${BASE}/${SLUG}`;
export const PATHS = {
  list: BASE,
  drafts: `${BASE}/drafts`,
  overview: PROJECT_PATH,
  brief: `${PROJECT_PATH}/brief`,
  milestone: `${PROJECT_PATH}/milestones/first-student-experience`,
  /* Studio page removed 5 Nov 2026 (Tasks, Conversations, Files and Workspace cover it). Its files and routes are commented out, see workspace/Studio.tsx.
  studio: `${PROJECT_PATH}/studio`,
  canvas: `${PROJECT_PATH}/studio/canvas`,
  */
  workspace: `${PROJECT_PATH}/workspace`,
  conversations: `${PROJECT_PATH}/conversations`,
  tasks: `${PROJECT_PATH}/tasks`,
  files: `${PROJECT_PATH}/files`,
  decisions: `${PROJECT_PATH}/decisions`,
  team: `${PROJECT_PATH}/team`,
  agreements: `${PROJECT_PATH}/agreements`,
  // Reflection and Launch removed 5 Nov 2026 (files in _trash):
  // reflection: `${PROJECT_PATH}/reflection`,
  // launch: `${PROJECT_PATH}/launch`,
  conversationsDecision: `${PROJECT_PATH}/conversations/decision-discussion`,
  conversationsEmpty: `${PROJECT_PATH}/conversations/state-empty`,
  conversationsStart: `${PROJECT_PATH}/conversations/state-start-conversation`,
  conversationsStarted: `${PROJECT_PATH}/conversations/state-conversation-started`,
  /** Every link that used to open the Studio work detail of the onboarding draft now opens its file (Files, File preview 17729:120125). */
  draftFile: `${PROJECT_PATH}/files/student-onboarding-draft-pdf`,
  /** Milestone detail (Prototype Review) 17699:72309 */
  milestone2: `${PROJECT_PATH}/milestones/prototype-review`,
  /* Studio work details, removed with the Studio page:
  work: `${PROJECT_PATH}/studio/student-onboarding-draft`,
  work2: `${PROJECT_PATH}/studio/map-the-student-journey`,
  work3: `${PROJECT_PATH}/studio/questions-students-ask-about-careers`,
  */
  /** The two sample projects of 12.26, and Adire Stories (the Digital Art project) with its own Overview and project pages (see project.ts). */
  communityLearning: `${BASE}/community-learning-initiative`,
  mentorshipCircle: `${BASE}/mentorship-circle`,
  adireOverview: `${BASE}/adire-stories`,
  adireWorkspace: `${BASE}/adire-stories/workspace`,
  start: '/collaborate/start',
  discover: '/collaborate/discover',
  home: '/collaborate',
} as const;

/* ---------------------------------------------------------------- 12.10 */

export type ProjectCard = {
  slug: string;
  stage: string;
  activity: string;
  title: string;
  description: string;
  milestone: string;
  next: string;
  progressLabel: string;
  done: number;
  team: string;
  initials: string[];
  /** The first project opens its Overview, the second and third their sample project pages (12.26), the fourth (Adire Stories) its own Overview. */
  href?: string;
};

export const PROJECTS: ProjectCard[] = [
  {
    slug: 'career-guidance-for-everyone',
    stage: 'BUILDING',
    activity: 'Owner. Active 2 hours ago',
    title: 'Career Guidance for Everyone',
    description: 'A digital career guidance platform helping Nigerian students make informed career decisions.',
    milestone: 'Define the first student experience.',
    next: 'Review the onboarding flow.',
    progressLabel: '2 of 5 milestones',
    done: 2,
    team: '4 members',
    initials: ['KA', 'AY', 'TO'],
    href: PROJECT_PATH,
  },
  {
    slug: 'community-learning-initiative',
    stage: 'PLANNING',
    activity: 'Team member. Active yesterday',
    title: 'Community Learning Initiative',
    description: 'A weekend learning programme that pairs local tutors with students who need extra support.',
    milestone: 'Agree the weekend session format.',
    next: 'Confirm the tutor list.',
    progressLabel: '1 of 5 milestones',
    done: 1,
    team: '5 members',
    initials: ['KA', 'AY', 'TO'],
    href: `${BASE}/community-learning-initiative`,
  },
  {
    slug: 'mentorship-circle',
    stage: 'PLANNING',
    activity: 'Owner. Active 3 days ago',
    title: 'Mentorship Circle',
    description: 'A peer mentoring programme connecting final-year students with early-career professionals.',
    milestone: 'Recruit the first six mentors.',
    next: 'Draft the mentor guide.',
    progressLabel: '1 of 5 milestones',
    done: 1,
    team: '3 members',
    initials: ['KA', 'AY', 'TO'],
    href: `${BASE}/mentorship-circle`,
  },
  {
    slug: 'adire-stories',
    stage: 'BUILDING',
    activity: 'Owner. Active 1 hour ago',
    title: 'Adire Stories',
    description: 'A shared illustration series that celebrates adire textile patterns and the people who make them.',
    milestone: 'Finish the headwrap portrait.',
    next: 'Review the colour layer.',
    progressLabel: '2 of 5 milestones',
    done: 2,
    team: '4 members',
    initials: ['KA', 'AO', 'AB'],
    href: `${BASE}/adire-stories`,
  },
];

export type DraftCard = {
  id: string;
  title: string;
  description: string;
  edited: string;
  step: number;
};

export const DRAFTS: DraftCard[] = [
  {
    id: 'teaching-tools',
    title: 'Teaching Tools for Rural Schools',
    description: 'Low-cost teaching aids that help teachers in schools with few resources bring lessons to life.',
    edited: 'Last edited 3 days ago',
    step: 2,
  },
  {
    id: 'youth-radio',
    title: 'Youth Radio Workshop',
    description: 'A weekly radio workshop where young people tell stories from their neighbourhoods.',
    edited: 'Last edited 2 weeks ago',
    step: 1,
  },
];

/* ---------------------------------------------------------------- shared workspace */

export const PROJECT = {
  name: 'Career Guidance for Everyone',
  phase: 'BUILDING',
  phaseWord: 'Building',
  pulse: 'Strong alignment',
  nextMilestone: 'Define the first student experience.',
  description: 'A digital career guidance platform helping Nigerian students make informed career decisions.',
};

export type Presence = 'available' | 'working' | 'away';
export type Member = { initials: string; name: string; role: string; presence?: Presence };

export const MEMBERS: Member[] = [
  { initials: 'KA', name: 'Kemi Adeyemi', role: 'Owner' },
  { initials: 'AO', name: 'Adaeze Okoye', role: 'Product Designer', presence: 'available' },
  { initials: 'TA', name: 'Tobi Adeyemi', role: 'Software Engineer', presence: 'working' },
  { initials: 'NE', name: 'Ngozi Eze', role: 'Career Researcher', presence: 'away' },
];

export const PRESENCE_TEXT: Record<Presence, string> = {
  available: 'Available for review',
  working: 'Working on a milestone',
  away: 'Away',
};

export const AVAILABILITY = MEMBERS.filter((m) => m.presence);

/* ---------------------------------------------------------------- 12.11 */

export type Step = { title: string; caption: string; status: 'Completed' | 'In progress' | 'Next' };

export const PROGRESS_STEPS: Step[] = [
  { title: 'Project brief approved', caption: 'Completed 12 October', status: 'Completed' },
  { title: 'Student experience definition', caption: 'In progress. Due 28 November', status: 'In progress' },
  { title: 'Prototype review', caption: 'Next. Planned for 12 December', status: 'Next' },
];

export const BRIEF_SUMMARY: { label: string; value: string }[][] = [
  [
    { label: 'PROJECT PURPOSE', value: 'Help Nigerian students make informed career decisions.' },
    { label: 'PROBLEM', value: 'Students choose paths with little guidance.' },
  ],
  [
    { label: 'INTENDED AUDIENCE', value: 'Secondary school students aged 14 to 18.' },
    { label: 'EXPECTED OUTCOME', value: 'A guidance platform students use on their phones.' },
  ],
  [
    { label: 'CURRENT SCOPE', value: 'Career exploration, an interest check and a personal shortlist.' },
    { label: 'DEFINITION OF SUCCESS', value: '200 students complete the interest check.' },
  ],
];

export type BriefPart = { number: string; title: string; heading: string; body: string };

/** `heading` is the part title in sentence case, shown in the "Suggest a change" modal ("01 Project purpose"). */
export const BRIEF_PARTS: BriefPart[] = [
  { number: '01', title: 'PROJECT PURPOSE', heading: 'Project purpose', body: 'Help Nigerian students make informed career decisions by connecting what they enjoy with the paths open to them.' },
  { number: '02', title: 'PROBLEM', heading: 'Problem', body: 'Many students choose subjects and careers with little guidance. Advice depends on who they happen to know and rarely reflects the jobs that exist in Nigeria today.' },
  { number: '03', title: 'INTENDED USERS', heading: 'Intended users', body: 'Secondary school students aged 14 to 18, and the teachers and parents who support their decisions.' },
  { number: '04', title: 'EXPECTED OUTCOME', heading: 'Expected outcome', body: 'A guidance platform students can use on their own phones, with clear next steps for every path they explore.' },
  { number: '05', title: 'SCOPE', heading: 'Scope', body: 'Includes career exploration, a short interest check and a personal shortlist. Excludes university admissions and job listings for now.' },
  { number: '06', title: 'TEAM', heading: 'Team', body: 'Kemi Adeyemi (owner), Adaeze Okoye (product design), Tobi Adeyemi (engineering) and Ngozi Eze (research).' },
  { number: '07', title: 'MILESTONES', heading: 'Milestones', body: 'Project brief approved. First student experience. Prototype review. Pilot with two schools. Launch to students.' },
  { number: '08', title: 'RISKS', heading: 'Risks', body: 'Reaching students with limited data access. Keeping career information accurate. Finding schools willing to pilot.' },
  { number: '09', title: 'REQUIRED RESOURCES', heading: 'Required resources', body: 'A researcher to validate career information, a school partner for the pilot and hosting for the first release.' },
  { number: '10', title: 'DEFINITION OF SUCCESS', heading: 'Definition of success', body: 'At least 200 students complete the interest check, and most say they know their next step.' },
];

export type WorkItem = {
  id: string;
  title: string;
  next: string;
  status: string;
  member: string;
  phase: string;
  action: string;
  /** Only work with a detail screen links anywhere. */
  href?: string;
};

/** "Continue working" on the overview. */
export const CONTINUE_WORK: WorkItem[] = [
  {
    id: 'onboarding-review',
    title: 'Review the student onboarding draft',
    next: 'Next: read the second screen and leave your comments.',
    status: 'Needs your review',
    member: 'Adaeze Okoye',
    phase: 'Building',
    action: 'Continue working',
    href: PATHS.draftFile,
  },
  {
    id: 'research-findings',
    title: 'Respond to the research findings',
    next: 'Next: reply to Ngozi about the first five interviews.',
    status: 'Waiting for your reply',
    member: 'Ngozi Eze',
    phase: 'Building',
    action: 'Continue working',
    href: `${PROJECT_PATH}/conversations`,
  },
];

export type Milestone = {
  status: 'In progress' | 'Upcoming';
  due: string;
  title: string;
  description: string;
  people: { initials: string; name: string }[];
  href?: string;
};

export const MILESTONES: Milestone[] = [
  {
    status: 'In progress',
    due: 'Due 28 November',
    title: 'First Student Experience',
    description: 'Define the first version of the student-facing product experience.',
    people: [
      { initials: 'AO', name: 'Adaeze Okoye' },
      { initials: 'TA', name: 'Tobi Adeyemi' },
    ],
    href: PATHS.milestone,
  },
  {
    status: 'Upcoming',
    due: 'Due 12 December',
    title: 'Prototype Review',
    description: 'Test the first prototype with five students and record what we learn.',
    people: [
      { initials: 'TA', name: 'Tobi Adeyemi' },
      { initials: 'NE', name: 'Ngozi Eze' },
    ],
    href: `${PROJECT_PATH}/milestones/prototype-review`,
  },
];

export const ACKNOWLEDGEMENTS = ['Tobi acknowledged the project brief. 2 days ago.', 'Adaeze acknowledged the milestone plan. Last week.'];

export const CRITERIA: Step[] = [
  { title: 'The first five screens are drafted', caption: 'Reviewed by Adaeze', status: 'Completed' },
  { title: 'The onboarding flow is agreed', caption: 'One decision is waiting for the team', status: 'In progress' },
  { title: 'Five students try the draft', caption: 'After the prototype review', status: 'Next' },
];

export const MILESTONE_WORK: WorkItem[] = [
  CONTINUE_WORK[0],
  {
    id: 'student-journey',
    title: 'Map the student journey',
    next: 'Next: add the questions students ask at each step.',
    status: 'In progress',
    member: 'Tobi Adeyemi',
    phase: 'Building',
    action: 'Continue working',
  },
];

export const OUTSTANDING = [
  { title: 'Agree the onboarding approach', caption: 'Decision. Awaiting acknowledgement.' },
  { title: 'Confirm the final interest questions', caption: 'Task. Due 20 November.' },
];

// Studio data (shared canvas, studio work, work detail, comments, history), commented out 5 Nov 2026 with the Studio page. Used only by workspace/Studio.tsx.
// To bring it back: remove the leading "// " of every commented line below.
// /* ---------------------------------------------------------------- 12.12 */
//
// export type CanvasType = 'Image' | 'Note' | 'Reference' | 'Draft';
// export type CanvasItem = {
//   id: string;
//   type: CanvasType;
//   title: string;
//   body: string;
//   initials: string;
//   name: string;
//   time: string;
//   comments: string;
//   /** Reference cards show a "Shared link" line, Draft cards a "Needs review" status. */
//   link?: boolean;
//   needsReview?: boolean;
//   href?: string;
// };
//
// export const CANVAS: CanvasItem[] = [
//   { id: 'classroom', type: 'Image', title: 'Classroom visit, Kaduna', body: 'Photo from the first school visit. Students try the early draft together.', initials: 'NE', name: 'Ngozi Eze', time: '3 days ago', comments: '2 comments' },
//   { id: 'questions', type: 'Note', title: 'Questions students ask about careers', body: 'Collected from the first school interviews. Added for the onboarding draft.', initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday', comments: '3 comments', href: `${PROJECT_PATH}/studio/questions-students-ask-about-careers` },
//   { id: 'subjects', type: 'Reference', title: 'How students choose subjects', body: 'A short article on subject choices in senior secondary. Useful for the question set.', initials: 'AO', name: 'Adaeze Okoye', time: '4 days ago', comments: '1 comment', link: true },
//   { id: 'unknown', type: 'Note', title: 'What we still do not know', body: 'Do students trust a recommendation more when a teacher confirms it? Ask in the next round.', initials: 'KA', name: 'Kemi Adeyemi', time: 'Last week', comments: '4 comments' },
//   { id: 'onboarding', type: 'Draft', title: 'Student onboarding draft', body: 'Five screens from the first question to a saved shortlist. Ready for review.', initials: 'AO', name: 'Adaeze Okoye', time: '2 hours ago', comments: '5 comments', needsReview: true, href: PATHS.work },
//   { id: 'interviews', type: 'Reference', title: 'Interview notes, school two', body: 'Notes from the second round of interviews with teachers.', initials: 'NE', name: 'Ngozi Eze', time: '5 days ago', comments: 'No comments', link: true },
// ];
//
// /** Shared canvas columns, in the order of the design (column A first). */
// export const CANVAS_COLUMNS: string[][] = [
//   ['classroom', 'subjects', 'unknown'],
//   ['questions', 'onboarding', 'interviews'],
// ];
//
// export const CANVAS_FILTERS = ['All', 'Notes', 'Images', 'References', 'Drafts'] as const;
// export type CanvasFilter = (typeof CANVAS_FILTERS)[number];
// export const FILTER_TYPE: Record<Exclude<CanvasFilter, 'All'>, CanvasType> = {
//   Notes: 'Note',
//   Images: 'Image',
//   References: 'Reference',
//   Drafts: 'Draft',
// };
//
// export type StudioWork = {
//   id: string;
//   title: string;
//   kind: string;
//   status: string;
//   member: string;
//   updated: string;
//   action: string;
//   href?: string;
// };
//
// export const STUDIO_WORK: StudioWork[] = [
//   { id: 'onboarding', title: 'Review the student onboarding draft', kind: 'Draft', status: 'Needs your review', member: 'Adaeze Okoye', updated: 'Updated 2 hours ago', action: 'Review work', href: PATHS.work },
//   { id: 'journey', title: 'Map the student journey', kind: 'Research note', status: 'In progress', member: 'Tobi Adeyemi', updated: 'Updated yesterday', action: 'Open work', href: `${PROJECT_PATH}/studio/map-the-student-journey` },
//   { id: 'questions', title: 'Questions students ask about careers', kind: 'Note', status: 'In progress', member: 'Ngozi Eze', updated: 'Updated 3 days ago', action: 'Open work', href: `${PROJECT_PATH}/studio/questions-students-ask-about-careers` },
// ];
//
// export const WORK_TYPES = ['Idea', 'Draft', 'Shared question'] as const;
// export type WorkType = (typeof WORK_TYPES)[number];
//
// export const WORK_DOC = {
//   title: 'Five screens, one question at a time.',
//   paragraphs: [
//     'Students begin with a single question: what do you enjoy doing when nobody is asking you to?',
//     'Each answer opens the next question. After five, the student sees a short list of paths that fit, with one clear next step for each.',
//     'The last screen lets them save the shortlist and share it with a teacher or a parent.',
//   ],
// };
//
// export const WORK_SCREENS = ['Welcome', 'The first question', 'Follow up questions', 'Your shortlist', 'Next steps'];
//
// export type CommentEntry = { initials: string; name: string; time: string; text: string };
//
// export const COMMENTS: CommentEntry[] = [
//   { initials: 'AO', name: 'Adaeze Okoye', time: '2 hours ago', text: 'The second screen is clearer now. I would keep the first question on its own.' },
//   { initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday', text: 'The journey map matches these screens. We can test with five students next week.' },
// ];
//
// export type HistoryEntry = { kind: 'Review' | 'Contribution'; initials: string; name: string; time: string; text: string };
//
// export const HISTORY: HistoryEntry[] = [
//   { kind: 'Review', initials: 'AO', name: 'Adaeze Okoye', time: '2 hours ago', text: 'Edited the second screen and asked Kemi to review the draft.' },
//   { kind: 'Contribution', initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday', text: 'Added the journey map that the screens follow.' },
//   { kind: 'Contribution', initials: 'KA', name: 'Kemi Adeyemi', time: '3 days ago', text: 'Created the work and linked it to the First Student Experience milestone.' },
// ];
