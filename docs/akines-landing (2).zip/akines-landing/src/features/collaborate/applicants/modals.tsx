'use client';

import './applicants.css';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Button, Field, Modal, TextArea, TextInput } from '@/ui';
import { CardLink } from '../workspace/atoms';
import { CLOSE_MODAL, NOT_NOW, OFFER, START_MODAL, TIMES, type Applicant } from './data';

/**
 * The overlays of the applicant journeys, all 640 wide with the eyebrow, headline and support line of the design:
 * Modal:Propose times (17974:177785), Modal:Send offer (17974:177860), Modal:Not now (17974:177933, a clone of the Team one),
 * Modal:Close call (17976:173387) and Modal:Start project (17976:173434). The person acted on is named in the headline; the frames draw one
 * sample (Kunle, Funmi, Amina) and the same wording is used for whoever the button belongs to. The scrim, the close button, Escape and
 * Cancel close a modal. The person is kept while the modal leaves, so its headline does not change during the exit.
 */

/** Keeps the last person while a modal is closing. */
function useKept<T>(value: T | null): T | null {
  const last = useRef<T | null>(null);
  if (value) last.current = value;
  return value ?? last.current;
}

const filled = (v: string) => (v.trim() ? 'ap-filled' : undefined);

/* ------------------------------------------------------------------ Modal:Propose times */

export function ProposeTimesModal({ open, person, onClose, onSend }: { open: boolean; person: Applicant | null; onClose: () => void; onSend: () => void }) {
  const p = useKept(person);
  // every opening starts again from the frame: three slots chosen (Propose Times Form, Ready), no message
  const [chosen, setChosen] = useState<string[]>(TIMES.chosen);
  const [message, setMessage] = useState('');
  useEffect(() => {
    if (open) {
      setChosen(TIMES.chosen);
      setMessage('');
    }
  }, [open]);

  const toggle = (key: string) => setChosen((c) => (c.includes(key) ? c.filter((x) => x !== key) : c.length >= TIMES.max ? c : [...c, key]));
  const send = (e?: FormEvent) => {
    e?.preventDefault();
    if (chosen.length > 0) onSend();
  };
  if (!p) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={TIMES.eyebrow}
      title={TIMES.title(p.first)}
      description={TIMES.description}
      footer={
        <>
          <Button type="submit" form="ap-times-form" disabled={chosen.length === 0}>
            {TIMES.send}
          </Button>
          <CardLink onClick={onClose}>{TIMES.cancel}</CardLink>
        </>
      }
    >
      <form id="ap-times-form" className="ap-form" onSubmit={send} noValidate>
        <fieldset className="ap-slots">
          <legend className="sr-only">Times</legend>
          {TIMES.days.map((d) => (
            <div className="ap-day" key={d.day}>
              <span className="ap-day__name">{d.day}</span>
              {d.slots.map((s) => {
                const key = `${d.day} ${s}`;
                const on = chosen.includes(key);
                return (
                  <button type="button" key={key} className="ap-slot" aria-pressed={on} aria-disabled={!on && chosen.length >= TIMES.max ? true : undefined} onClick={() => toggle(key)}>
                    {s}
                    <span className="sr-only"> on {d.day}</span>
                  </button>
                );
              })}
            </div>
          ))}
        </fieldset>
        <p className="ap-count" aria-live="polite">
          {TIMES.count(chosen.length)}
        </p>
        <Field label={TIMES.message.label} hint={TIMES.message.hint}>
          <TextArea className="ap-ta" value={message} placeholder={TIMES.message.placeholder} onChange={(e) => setMessage(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal:Send offer */

export function SendOfferModal({ open, person, onClose, onSend }: { open: boolean; person: Applicant | null; onClose: () => void; onSend: () => void }) {
  const p = useKept(person);
  // every opening starts again from the frame (Send Offer Form, Ready): the role the person asked for, the hours, the start date and a note
  const [role, setRole] = useState('');
  const [hours, setHours] = useState('');
  const [start, setStart] = useState('');
  const [note, setNote] = useState('');
  useEffect(() => {
    if (open && person) {
      setRole(person.wants);
      setHours(OFFER.hours.value);
      setStart(OFFER.start.value);
      setNote(OFFER.note.value);
    }
  }, [open, person]);

  const ready = Boolean(role.trim() && hours.trim() && start.trim());
  const send = (e?: FormEvent) => {
    e?.preventDefault();
    if (ready) onSend();
  };
  if (!p) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={OFFER.eyebrow}
      title={OFFER.title(p.first)}
      description={OFFER.description(p.first)}
      footer={
        <>
          <Button type="submit" form="ap-offer-form" disabled={!ready}>
            {OFFER.send}
          </Button>
          <CardLink onClick={onClose}>{OFFER.cancel}</CardLink>
        </>
      }
    >
      <form id="ap-offer-form" className="ap-form" onSubmit={send} noValidate>
        <Field label={OFFER.role.label} hint={OFFER.role.hint}>
          <TextInput className={filled(role)} value={role} placeholder={OFFER.role.placeholder} onChange={(e) => setRole(e.target.value)} />
        </Field>
        <div className="ap-form__pair">
          <Field label={OFFER.hours.label} hint={OFFER.hours.hint}>
            <TextInput className={filled(hours)} value={hours} placeholder={OFFER.hours.placeholder} onChange={(e) => setHours(e.target.value)} />
          </Field>
          {/* Start date is a field with a calendar mark; the design draws no date picker, so the date is typed */}
          <Field label={OFFER.start.label} hint={OFFER.start.hint}>
            <TextInput className={`ap-date ${filled(start) ?? ''}`.trim()} value={start} placeholder={OFFER.start.placeholder} onChange={(e) => setStart(e.target.value)} iconRight={<CalendarIcon />} />
          </Field>
        </div>
        <Field label={OFFER.note.label} hint={OFFER.note.hint}>
          <TextArea className="ap-ta" value={note} placeholder={OFFER.note.placeholder} onChange={(e) => setNote(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

function CalendarIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      <path d="M6 2.5V5.5M14 2.5V5.5" />
      <rect x="2.5" y="4.5" width="15" height="13" rx="1.5" />
      <path d="M2.5 8.5H17.5" />
    </svg>
  );
}

/* ------------------------------------------------------------------ Modal:Not now */

export function NotNowModal({ open, person, onClose, onSend }: { open: boolean; person: Applicant | null; onClose: () => void; onSend: () => void }) {
  const p = useKept(person);
  const [message, setMessage] = useState('');
  useEffect(() => {
    if (open) setMessage('');
  }, [open]);
  const send = (e?: FormEvent) => {
    e?.preventDefault();
    onSend();
  };
  if (!p) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={NOT_NOW.eyebrow}
      title={NOT_NOW.title(p.first)}
      description={NOT_NOW.description(p.first)}
      footer={
        <>
          <Button type="submit" form="ap-notnow-form">
            {NOT_NOW.send}
          </Button>
          <CardLink onClick={onClose}>{NOT_NOW.cancel}</CardLink>
        </>
      }
    >
      <form id="ap-notnow-form" className="ap-form" onSubmit={send} noValidate>
        {/* the recipient is fixed; the field shows the Filled state of the design */}
        <Field label={NOT_NOW.to.label} hint={NOT_NOW.to.hint(p.pronoun)}>
          <TextInput className="ap-filled" value={p.name} readOnly />
        </Field>
        <Field label={NOT_NOW.message.label} hint={NOT_NOW.message.hint}>
          <TextInput className={filled(message)} value={message} placeholder={NOT_NOW.message.placeholder} onChange={(e) => setMessage(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal:Close call */

export function CloseCallModal({ open, onClose, onConfirm }: { open: boolean; onClose: () => void; onConfirm: () => void }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={CLOSE_MODAL.eyebrow}
      title={CLOSE_MODAL.title}
      description={CLOSE_MODAL.description}
      footer={
        <>
          <Button onClick={onConfirm}>{CLOSE_MODAL.confirm}</Button>
          <CardLink onClick={onClose}>{CLOSE_MODAL.cancel}</CardLink>
        </>
      }
    />
  );
}

/* ------------------------------------------------------------------ Modal:Start project */

/** The headline names the shortlisted people ("Start a project with Folake and Tunde?"); the people are kept while the modal leaves. */
export function StartProjectModal({ open, names, onClose, onConfirm }: { open: boolean; names: string[]; onClose: () => void; onConfirm: () => void }) {
  const last = useRef<string[]>(names);
  if (names.length > 0) last.current = names;
  const shown = names.length > 0 ? names : last.current;
  if (shown.length === 0) return null;
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={START_MODAL.eyebrow}
      title={START_MODAL.title(shown)}
      description={START_MODAL.description(shown)}
      footer={
        <>
          <Button onClick={onConfirm}>{START_MODAL.confirm}</Button>
          <CardLink onClick={onClose}>{START_MODAL.cancel}</CardLink>
        </>
      }
    />
  );
}
