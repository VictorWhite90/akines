'use client';

/**
 * Community Home feed (replaced the old Home, which now lives in _trash/community-previous).
 * A full width hero carousel; below it the right rail (Your circles, You two would get along; sticky, it starts beside the first
 * section) and six of the eleven sections in one of four arrangements, a new one on every visit.
 * Layout and copy: FEED_SPEC.md and the final Figma values. All geometry is in the first block of feed.css.
 * Phones (below 768): no rail at all, a short swipe hero and swipe rows of cards (Figma V2 Mobile, section 10; feed-mobile.css,
 * scoped to .fd-home because Connect Discover also carries .fd-page).
 */
import './feed.css';
import './feed-mobile.css';
import { useEffect, useState } from 'react';
import { useLayout } from '@/lib/hooks';
import { ARRANGEMENTS, type FeedVersion } from './arrangements';
import { Hero } from './Hero';
import { MatchSlideshow } from './MatchSlideshow';
import { LOADING_MS } from './content';
import { YourCircles } from './Rail';
import { FeedSkeleton } from './parts';
import { FeedSection } from './Sections';
import { useFeedVersion } from './useFeedVersion';

export type FeedState = 'loading' | 'error' | 'empty';

/**
 * `force` shows one arrangement without touching the rotation (preview routes /community/feed/a to d).
 * `state` is one of the three state routes: they use arrangement A and do not touch the rotation either.
 * Loading: hero and rail are live, the feed shows its skeletons and continues to the live feed after LOADING_MS.
 * Error: the Banter section (position 3 of A) shows its error panel under its header. Empty: only the match card is empty.
 */
export function FeedPage({ force, state }: { force?: FeedVersion; state?: FeedState }) {
  const version = useFeedVersion(force ?? (state ? 'a' : undefined));
  const [settled, setSettled] = useState(state !== 'loading');
  useEffect(() => {
    if (state !== 'loading') return;
    const t = window.setTimeout(() => setSettled(true), LOADING_MS);
    return () => window.clearTimeout(t);
  }, [state]);
  const sections = version ? ARRANGEMENTS[version].sections : null;
  // Phones show no rail (Your circles and the match card); tablet keeps them above the feed, desktop at the side.
  const rail = useLayout() !== 'mobile';

  return (
    <div className="fd-page fd-home" data-feed-version={version ?? undefined} data-feed-state={state}>
      <Hero />
      <div className="fd-layout">
        {rail ? (
          <aside className="fd-rail" aria-label="Your circles and a match">
            <YourCircles />
            <MatchSlideshow empty={state === 'empty'} />
          </aside>
        ) : null}
        <div className="fd-feed">
          {sections && settled ? (
            sections.map((key, i) => <FeedSection key={key} name={key} first={i === 0} failing={state === 'error' && key === 'banter'} />)
          ) : (
            <FeedSkeleton note={state === 'loading'} />
          )}
        </div>
      </div>
    </div>
  );
}
