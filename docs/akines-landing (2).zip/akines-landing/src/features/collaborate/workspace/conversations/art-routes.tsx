import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../data';
import { ART_PATH } from '../project';
import { routes } from '../routes';
import { CONV_PATHS } from './data';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Mirrored: Conversations (the main page) and the state frames that come with its Meet button and info button (Dropdown:Meet,
 * Panel:Conversation info, Modal:Schedule meeting, Toast:Meeting scheduled). Not mirrored: Decision discussion (a thread page) and the
 * Empty, Start conversation and Conversation started state frames. The Start conversation modal opens from the + of the page itself.
 */
const mirrored: string[] = [CONV_PATHS.list, CONV_PATHS.meetMenu, CONV_PATHS.info, CONV_PATHS.schedule, CONV_PATHS.scheduled];

export const artRoutes: RouteDef[] = routes.filter((r) => mirrored.includes(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
