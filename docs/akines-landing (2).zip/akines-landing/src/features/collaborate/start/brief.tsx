'use client';

/** The brief half of 12.2: Preparing (A6), Brief error (A6), Review your brief (A7) and Ready for the next step (A8). */
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/ui';
import { BackLink, IcArrowRight, IcCheck, IcClose, IcEye, IcLock, IcPencil, IcSliders, IcSparkles, IcCircleCheck, Notice, StepHeading } from './parts';
import {
  BRIEF_SECTIONS,
  PATHS,
  PREPARING_MESSAGES,
  PREPARING_MS,
  SUGGESTIONS,
  WORKSPACES,
  ideaLine,
  needsPhrase,
  needsShort,
  purposeLine,
  stageOf,
  type Answers,
  type Brief,
  type BriefId,
  type StepId,
  type SuggestionState,
  type WorkspaceKind,
} from './flow-data';

/* ------------------------------------------------------------------ A6 panel and messages */
type MsgState = 'done' | 'active' | 'pending';

function Messages({ states }: { states: MsgState[] }) {
  return (
    <ol className="cs-msgs" aria-label="Progress">
      {PREPARING_MESSAGES.map((m, i) => (
        <li key={m} className="cs-msg" data-state={states[i]} aria-current={states[i] === 'active' ? 'step' : undefined}>
          <span className="cs-msg__ind" aria-hidden="true">
            {states[i] === 'done' ? <IcCheck size={14} /> : states[i] === 'active' ? <span className="cs-msg__dot" /> : null}
          </span>
          <span className="cs-msg__text">{m}</span>
        </li>
      ))}
    </ol>
  );
}

function WorkingFrom({ answers }: { answers: Answers }) {
  const rows: [string, string][] = [
    ['Your idea', ideaLine(answers)],
    ['Your purpose', purposeLine(answers)],
    ['Your progress', stageOf(answers.stage)?.title ?? 'Not chosen yet'],
    ['Your people', needsPhrase(answers.needs)],
  ];
  return (
    <aside className="cs-panel" aria-label="What we are working from">
      <p className="cs-eyebrow">What we’re working from</p>
      <dl className="cs-panel__rows">
        {rows.map(([k, v]) => (
          <div key={k} className="cs-panel__row">
            <dt className="cs-eyebrow">{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
      <p className="cs-panel__note">Your answers are saved. You can return to edit them at any time.</p>
    </aside>
  );
}

/* ------------------------------------------------------------------ A6 preparing */
const STEP_MS = PREPARING_MS / 4;

export function PreparingStep({ answers, go }: { answers: Answers; go: (s: StepId) => void }) {
  const [active, setActive] = useState(0);
  const goRef = useRef(go);
  goRef.current = go;
  useEffect(() => {
    const timers: number[] = [];
    for (let i = 1; i < PREPARING_MESSAGES.length; i++) timers.push(window.setTimeout(() => setActive(i), STEP_MS * i));
    // Figma AFTER_TIMEOUT 3 s moves on to the review. An offline visitor gets the interrupted brief instead.
    timers.push(
      window.setTimeout(() => {
        setActive(PREPARING_MESSAGES.length);
        goRef.current(typeof navigator !== 'undefined' && navigator.onLine === false ? 'error' : 'review');
      }, PREPARING_MS),
    );
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, []);
  const states = PREPARING_MESSAGES.map((_, i): MsgState => (i < active ? 'done' : i === active ? 'active' : 'pending'));
  return (
    <section className="cs-split" aria-busy="true">
      <div className="cs-split__main">
        <div className="cs-split__text cs-split__text--wide">
          <div className="cs-head">
            <p className="cs-eyebrow">Preparing your brief</p>
            <h1 className="cs-hero cs-hero--sm" tabIndex={-1} data-m="words">
              Bringing your idea into focus.
            </h1>
            <p className="cs-hero__support">
              We’re organising your thoughts into a project brief you can review, refine and share with potential collaborators.
            </p>
          </div>
          <Messages states={states} />
          <BackLink onClick={() => go('people')}>Back to my answers</BackLink>
        </div>
      </div>
      <WorkingFrom answers={answers} />
    </section>
  );
}

/* ------------------------------------------------------------------ A6 brief error */
export function BriefErrorStep({ answers, go }: { answers: Answers; go: (s: StepId) => void }) {
  return (
    <section className="cs-split">
      <div className="cs-split__main">
        <div className="cs-split__text cs-split__text--wide">
          <div className="cs-head">
            <p className="cs-eyebrow">Brief interrupted</p>
            <h1 className="cs-hero cs-hero--sm" tabIndex={-1} data-m="words">
              We couldn’t finish your brief.
            </h1>
            <p className="cs-hero__support">Nothing has been lost. Your answers are saved, so you can try again or go back and edit them.</p>
          </div>
          <Messages states={['done', 'done', 'pending', 'pending']} />
          <Notice title="Something interrupted the brief." tone="error">
            This is on our side. Please try again in a moment.
          </Notice>
          <div className="cs-btnrow">
            <Button onClick={() => go('preparing')}>Try again</Button>
            <Button variant="secondary" onClick={() => go('idea')}>
              Edit my answers
            </Button>
          </div>
        </div>
      </div>
      <WorkingFrom answers={answers} />
    </section>
  );
}

/* ------------------------------------------------------------------ A7 review */
function BriefSection({
  id,
  label,
  title,
  text,
  editing,
  onEdit,
  onSave,
  onCancel,
}: {
  id: BriefId;
  label: string;
  title?: boolean;
  text: string;
  editing: boolean;
  onEdit: () => void;
  onSave: (v: string) => void;
  onCancel: () => void;
}) {
  const [draft, setDraft] = useState(text);
  const area = useRef<HTMLTextAreaElement | null>(null);
  useEffect(() => {
    if (!editing) return;
    setDraft(text);
    const el = area.current;
    if (el) {
      el.focus();
      el.setSelectionRange(el.value.length, el.value.length);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);
  useEffect(() => {
    const el = area.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = el.scrollHeight + 2 + 'px';
  }, [draft, editing]);
  const ok = draft.trim().length > 0;
  return (
    <section className="cs-bs" data-editing={editing || undefined} data-kind={title ? 'title' : undefined} aria-label={label}>
      <div className="cs-bs__head">
        <h3 className="cs-bs__label">{label}</h3>
        {!editing ? (
          <button type="button" className="cs-bs__edit" onClick={onEdit} aria-label={`Edit ${label.toLowerCase()}`}>
            <IcPencil size={14} />
            <span>Edit</span>
          </button>
        ) : null}
      </div>
      {editing ? (
        <>
          <textarea
            ref={area}
            className="cs-bs__input"
            value={draft}
            rows={1}
            aria-label={label}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onCancel();
            }}
          />
          <div className="cs-bs__actions">
            <Button disabled={!ok} onClick={() => onSave(draft.trim())}>
              Save changes
            </Button>
            <Button variant="link" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </>
      ) : (
        <p className={'cs-bs__text' + (title ? ' cs-bs__text--title' : '')} id={`cs-bs-${id}`}>
          {text}
        </p>
      )}
    </section>
  );
}

function SuggestionCard({ title, text, state, set }: { title: string; text: string; state: SuggestionState; set: (s: SuggestionState) => void }) {
  return (
    <article className="cs-sg" data-state={state}>
      <header className="cs-sg__head">
        <span className="cs-sg__icon" aria-hidden="true">
          {state === 'applied' ? <IcCircleCheck size={16} /> : state === 'dismissed' ? <IcClose size={16} /> : <IcSparkles size={16} />}
        </span>
        <span className="cs-sg__cap">{state === 'applied' ? 'Added to your brief' : state === 'dismissed' ? 'Set aside' : 'Akines suggests'}</span>
      </header>
      <h4 className="cs-sg__title">{title}</h4>
      <p className="cs-sg__text">{text}</p>
      <div className="cs-sg__actions">
        {state === 'default' ? (
          <>
            <Button variant="secondary" onClick={() => set('applied')}>
              Add to my brief
            </Button>
            <Button variant="link" onClick={() => set('dismissed')}>
              Not now
            </Button>
          </>
        ) : (
          <Button variant="link" onClick={() => set('default')}>
            Undo
          </Button>
        )}
      </div>
    </article>
  );
}

export function ReviewStep({
  brief,
  workspace,
  setBrief,
  suggestions,
  setSuggestion,
  go,
  onDraft,
}: {
  brief: Brief;
  /** The accepted Workspace: shown as a plain line after the brief sections (it is changed on its own step, not edited here). */
  workspace: WorkspaceKind;
  setBrief: (id: BriefId, v: string) => void;
  suggestions: Record<string, SuggestionState>;
  setSuggestion: (id: string, s: SuggestionState) => void;
  go: (s: StepId) => void;
  onDraft: () => void;
}) {
  const [editing, setEditing] = useState<BriefId | null>(null);
  return (
    <section className="cs-review">
      <div className="cs-review__brief">
        <StepHeading eyebrow="Your project brief" title="Here’s what we’re creating." support="Review your idea and make any changes before finding your collaborators." />
        <div className="cs-bs__list">
          {BRIEF_SECTIONS.map((s) => (
            <BriefSection
              key={s.id}
              id={s.id}
              label={s.label}
              title={s.title}
              text={brief[s.id]}
              editing={editing === s.id}
              onEdit={() => setEditing(s.id)}
              onCancel={() => setEditing(null)}
              onSave={(v) => {
                setBrief(s.id, v);
                setEditing(null);
              }}
            />
          ))}
          <section className="cs-bs" data-kind="fixed" aria-label="Workspace">
            <div className="cs-bs__head">
              <h3 className="cs-bs__label">Workspace</h3>
            </div>
            <p className="cs-bs__text" id="cs-bs-workspace">
              {WORKSPACES[workspace].name}
            </p>
          </section>
        </div>
      </div>
      <div className="cs-review__side">
        <div className="cs-approve">
          <span className="cs-approve__rule" aria-hidden="true" />
          <p className="cs-eyebrow">Ready when you are</p>
          <h2 className="cs-approve__title">Approve your brief to start finding collaborators.</h2>
          <p className="cs-approve__text">Nothing is shared until you approve it. You can keep editing any section first.</p>
          <div className="cs-approve__btns">
            <Button fullWidth iconRight={<IcArrowRight />} onClick={() => go('ready')}>
              Approve brief
            </Button>
            <Button fullWidth variant="secondary" onClick={() => go('idea')}>
              Edit my answers
            </Button>
          </div>
          <Button variant="link" className="cs-approve__draft" onClick={onDraft}>
            Save as draft
          </Button>
        </div>
        <div className="cs-sgs">
          <p className="cs-eyebrow">Optional suggestions from Akines</p>
          {SUGGESTIONS.map((s) => (
            <SuggestionCard key={s.id} title={s.title} text={s.text} state={suggestions[s.id] ?? 'default'} set={(st) => setSuggestion(s.id, st)} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ A8 ready */
const TIERS = [
  { icon: <IcEye />, title: 'In your project brief', text: 'Your project name, overview, stage and support needed. People you contact can see this.' },
  { icon: <IcSliders />, title: 'Used for matching', text: 'Your purpose, problem, audience and desired outcome. Akines uses them to recommend people and does not show them.' },
  { icon: <IcLock />, title: 'Stays private', text: 'Your drafts, any answer you haven’t approved and everything outside this brief.' },
];

export function ReadyStep({ answers, brief, onExplore, onSave }: { answers: Answers; brief: Brief; onExplore: () => void; onSave: () => void }) {
  return (
    <section className="cs-ready">
      <div className="cs-ready__summary">
        <StepHeading big eyebrow="Brief approved" title="Your idea is ready for its next step." support="Your project brief is ready. You can now explore people whose skills and experience may complement your idea." />
        <article className="cs-card">
          <p className="cs-eyebrow">Project summary</p>
          <h2 className="cs-card__name">{brief.name}</h2>
          <p className="cs-card__text">{brief.overview}</p>
          <hr className="cs-card__rule" />
          <dl className="cs-card__meta">
            <div>
              <dt className="cs-eyebrow">Project stage</dt>
              <dd>{stageOf(answers.stage)?.title ?? 'Not chosen yet'}</dd>
            </div>
            <div>
              <dt className="cs-eyebrow">Support needed</dt>
              <dd>{needsShort(answers.needs)}</dd>
            </div>
          </dl>
        </article>
        <div className="cs-btnrow">
          <Button iconRight={<IcArrowRight />} onClick={onExplore}>
            Explore collaborators
          </Button>
          <Button variant="secondary" onClick={onSave}>
            Save project
          </Button>
        </div>
        <p className="cs-note">Akines will never send an introduction request on your behalf.</p>
      </div>
      <div className="cs-ready__share">
        <p className="cs-eyebrow">What happens to your information</p>
        <ul className="cs-tiers">
          {TIERS.map((t) => (
            <li key={t.title} className="cs-tier">
              <span className="cs-tier__icon" aria-hidden="true">
                {t.icon}
              </span>
              <div className="cs-tier__body">
                <h3 className="cs-tier__title">{t.title}</h3>
                <p className="cs-tier__text">{t.text}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export { PATHS };
