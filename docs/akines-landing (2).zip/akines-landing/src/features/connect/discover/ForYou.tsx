'use client';

/**
 * 02 For you on Akines: filter chips and a grid of 3 columns (PRD section 02, Figma 17893:108772 and the For You Block set 17899:22544).
 *
 * Wiring (unchanged from the stub):
 *  - useDiscover() gives { filter, isRequested(id), isJoined(id) }. FILTERS (data.ts) lists the seven filters in order; setFilter(key)
 *    changes the filter in place (never a navigation) and tracks for_you_filter_select.
 *  - FOR_YOU[filter] is the card list: 9 cards for All and 6 or 3 for the others, a union on `kind` (see cards.tsx for the markup).
 *  - Connect and Join call connect(id) and join(id); they track for_you_card_action themselves. The other footer actions and the card
 *    body call trackCardAction and trackCardClick (cards.tsx). The header link "Explore all" opens For you, all (lists.tsx).
 *  - CardView (card-view.tsx) draws one card of any kind; the For you page uses the same one.
 *
 * The chips are toggle buttons in a labelled group (aria-pressed, as the kit Chip): Tab moves between them, Space and Enter select.
 */
import './foryou.css';
import { useState } from 'react';
import { FILTERS, FOR_YOU, type ForYouFilter } from './data';
import { DxSection } from './parts';
import { setFilter, useDiscover } from './state';
import { CardView } from './card-view';

const labelOf = (key: ForYouFilter) => FILTERS.find((f) => f.key === key)?.label ?? key;

export function ForYou() {
  const d = useDiscover();
  const cards = FOR_YOU[d.filter];

  // Set while rendering (the supported "adjust state when a value changes" pattern, no extra paint): once the filter changed, the page
  // reveal is over. The new cards then rise in on their own, and a polite status tells screen readers what the grid now shows.
  const [shown, setShown] = useState(d.filter);
  const [swapped, setSwapped] = useState(false);
  const [note, setNote] = useState('');
  if (shown !== d.filter) {
    setShown(d.filter);
    setSwapped(true);
    setNote(`Showing ${labelOf(d.filter)}, ${cards.length} cards.`);
  }

  return (
    <DxSection section="for-you">
      <div className="dxf">
        <div className="dxf-filters" role="group" aria-label="Filter For you on Akines" data-m="up">
          {FILTERS.map((f) => (
            <button key={f.key} type="button" className="dxf-chip" aria-pressed={d.filter === f.key} onClick={() => setFilter(f.key)}>
              {f.label}
            </button>
          ))}
        </div>
        <p className="sr-only" role="status">
          {note}
        </p>
        {/* Keyed by filter: a swap replaces the whole grid at once. data-m="stagger" is the page reveal, used for the first grid only. */}
        <ul key={d.filter} className={swapped ? 'dxf-grid dxf-grid--swap' : 'dxf-grid'} role="list" data-m={swapped ? undefined : 'stagger'}>
          {cards.map((c) => (
            <li key={c.id} className="dxf-cell">
              <CardView card={c} filter={d.filter} reveal={!swapped} />
            </li>
          ))}
        </ul>
      </div>
    </DxSection>
  );
}
