'use client';

/**
 * One Explore card (Figma Explore Card set 17896:20601): photograph, title with an arrow, one line of text. Used by the row of Discover
 * (Explore.tsx, 280 wide) and by the grid of Explore all (ExploreAll.tsx, 312 wide). Styles: explore.css (dxe-).
 * A card with `href` is a link; Circles has none (KinCircle is design only), so it is a plain button. Pressing a card tracks
 * discover_category_click { category, position } (1-based), the same event on both pages.
 */
import { Link } from '@/lib/nav';
import { IArrow } from '@/features/community/ui';
import { track } from './analytics';
import type { ExploreCategory } from './data';
import { src } from './images';

export function ExploreCard({ c, index, eager }: { c: ExploreCategory; index: number; eager?: boolean }) {
  const press = () => track('discover_category_click', { category: c.id, position: index + 1 });
  const body = (
    <>
      <span className="dxe-photo">
        <img className="dxe-img" src={src(c.image)} alt="" loading={eager ? 'eager' : 'lazy'} decoding="async" draggable={false} />
      </span>
      <span className="dxe-text">
        <span className="dxe-line">
          <span className="dxe-title">{c.title}</span>
          <span className="dxe-arrow" aria-hidden="true">
            <IArrow s={20} />
          </span>
        </span>
        <span className="dxe-desc">{c.text}</span>
      </span>
      <span className="dxe-rule" aria-hidden="true" />
    </>
  );
  return c.href ? (
    <Link className="dxe-card" href={c.href} draggable={false} onClick={press}>
      {body}
    </Link>
  ) : (
    <button type="button" className="dxe-card" onClick={press}>
      {body}
    </button>
  );
}
