'use client';

/**
 * The frame and the parts shared by the pages that Discover leads to (Figma 11.66 to 11.73): the Back link, the list page (page head,
 * one section, the rail of Discover), the row of filter chips with its grid of cards, and the "No results" block. Styles: lists.css (dxl-),
 * the chips and the grid are the For you block's (foryou.css, dxf-).
 *
 * A list page is the Discover frame with one section in the column: Page head (Back link, then the section header: Alice 32 over a 16
 * support line, 24 apart), then its filters and cards 32 apart. The rail is the one of Discover, unchanged (DiscoverRail.tsx).
 */
import '../../community/feed/feed.css';
import './discover.css';
import './foryou.css';
import './lists.css';
import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from '@/lib/nav';
import { DiscoverRail } from './DiscoverRail';
import { CardView } from './card-view';
import type { ForYouCard, ForYouFilter } from './data';

/** Figma Back link: arrow and a semibold label, 22 high. Used above every page that Discover opens. */
export function BackLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link href={href} className="dxl-back">
      <ArrowLeft size={16} strokeWidth={1.25} absoluteStrokeWidth aria-hidden="true" focusable="false" />
      <span>{children}</span>
    </Link>
  );
}

/** A page of Discover with its rail: Back link, header, then `children` (filters and cards, or a grid). `wide` is Explore all (40 between the blocks). */
export function ListPage({ title, support, back, backHref, wide, children }: { title: string; support: string; back: string; backHref: string; wide?: boolean; children: ReactNode }) {
  const titleId = useId();
  return (
    <div className="fd-page dx-feed">
      <div className="dx-body">
        <div className="dx-column">
          <section className={wide ? 'dxl-section dxl-section--wide' : 'dxl-section'} aria-labelledby={titleId}>
            <div className="dxl-head" data-m="up">
              <BackLink href={backHref}>{back}</BackLink>
              <header className="dxl-header">
                <div className="fd-head__copy">
                  <h1 className="fd-head__title" id={titleId}>
                    {title}
                  </h1>
                  <p className="fd-head__support">{support}</p>
                </div>
              </header>
            </div>
            {children}
          </section>
        </div>
        <DiscoverRail />
      </div>
    </div>
  );
}

/** Figma Section Empty with an action: one centred line between two hairlines and a link under it. The link goes to `href`, or runs `onClick`. */
export function NoResults({ text, action }: { text: string; action: { label: string; href?: string; onClick?: () => void } }) {
  return (
    <div className="dxn">
      <p className="dxn__text">{text}</p>
      {action.href ? (
        <Link href={action.href} className="fd-link">
          {action.label}
        </Link>
      ) : (
        <button type="button" className="fd-link" onClick={action.onClick}>
          {action.label}
        </button>
      )}
    </div>
  );
}

export type Chip<K extends string> = { key: K; label: string };

/**
 * The row of filter chips and the grid of three columns under it (the For you block: foryou.css). `value` is the chip that is on (none on
 * Events at first), `cards` what it shows. With no cards `none` is shown in place of the grid, under the same chips, so the member can pick
 * another one. A change of chip replaces the whole grid at once (the cards rise in together) and a polite status says what it shows now.
 * `cardFilter` is the For you filter the cards report in their analytics (the cards come from the same data as Discover).
 */
export function FilterBlock<K extends string>({
  name,
  chips,
  value,
  onSelect,
  cards,
  cardFilter,
  none,
}: {
  name: string;
  chips: readonly Chip<K>[];
  value: K | null;
  onSelect: (key: K) => void;
  cards: readonly ForYouCard[];
  cardFilter: ForYouFilter;
  none: ReactNode;
}) {
  // Set while rendering (the "adjust state when a value changes" pattern): after a change of chip the page reveal is over.
  const [shown, setShown] = useState(value);
  const [swapped, setSwapped] = useState(false);
  const [note, setNote] = useState('');
  const group = useRef<HTMLDivElement>(null);
  if (shown !== value) {
    const label = chips.find((c) => c.key === value)?.label ?? 'all';
    setShown(value);
    setSwapped(true);
    setNote(cards.length ? `Showing ${label}, ${cards.length} ${cards.length === 1 ? 'card' : 'cards'}.` : `No results for ${label}.`);
  }
  // The link of "No results" disappears when it is pressed: keep focus in the block, on the chip that is on (or the first one)
  const empty = cards.length === 0;
  const wasEmpty = useRef(empty);
  useEffect(() => {
    const was = wasEmpty.current;
    wasEmpty.current = empty;
    if (!was || empty) return;
    const active = document.activeElement;
    if (active && active !== document.body) return;
    const chips = group.current?.querySelectorAll<HTMLElement>('.dxf-chip');
    (group.current?.querySelector<HTMLElement>('[aria-pressed="true"]') ?? chips?.[0])?.focus({ preventScroll: true });
  }, [empty, value]);
  return (
    <div className="dxf">
      <div className="dxf-filters" role="group" aria-label={name} ref={group} data-m="up">
        {chips.map((c) => (
          <button key={c.key} type="button" className="dxf-chip" aria-pressed={value === c.key} onClick={() => onSelect(c.key)}>
            {c.label}
          </button>
        ))}
      </div>
      <p className="sr-only" role="status">
        {note}
      </p>
      {cards.length ? (
        <ul key={String(value)} className={swapped ? 'dxf-grid dxf-grid--swap' : 'dxf-grid'} role="list" data-m={swapped ? undefined : 'stagger'}>
          {cards.map((c) => (
            <li key={c.id} className="dxf-cell">
              <CardView card={c} filter={cardFilter} reveal={!swapped} />
            </li>
          ))}
        </ul>
      ) : (
        none
      )}
    </div>
  );
}
