'use client';

/** Right rail: Your Circles (the match slideshow below it is MatchSlideshow.tsx). Trending now was removed from the rail. FEED_SPEC.md section 4. */
import { Link } from '@/lib/nav';
import { IChevron } from '../ui';
import { CIRCLES, CIRCLES_COPY } from './content';
import { src } from './images';

export function YourCircles() {
  return (
    <section className="fd-box fd-circles" aria-labelledby="fd-circles-title">
      <div className="fd-box__head">
        <h2 className="fd-box__title" id="fd-circles-title">
          {CIRCLES_COPY.title} <span className="fd-box__count">({CIRCLES.length})</span>
        </h2>
        <Link className="fd-link" href={CIRCLES_COPY.link.href}>
          {CIRCLES_COPY.link.label}
        </Link>
      </div>
      <ul className="fd-circles__list">
        {CIRCLES.map((c) => (
          <li key={c.id}>
            <Link className="fd-circle" href={c.href}>
              <span className="fd-circle__photo">
                <img className="cover" src={src(c.image)} alt="" loading="lazy" decoding="async" draggable={false} />
              </span>
              <span className="fd-circle__text">
                <span className="fd-circle__name">{c.name}</span>
                <span className="fd-circle__meta">{c.meta}</span>
              </span>
              <span className="fd-circle__chev">
                <IChevron />
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
