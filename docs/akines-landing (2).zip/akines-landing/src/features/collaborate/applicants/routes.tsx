import type { RouteDef } from '@/routes.types';
import { ApplicantsScreen, CompareScreen, type ApplicantsVariant } from './Applicants';
import { CallCompareScreen, CallScreen, OpenCallsScreen, type CallVariant } from './OpenCalls';
import { APPLICANT_PATHS, CALL_PATHS } from './data';

/**
 * Host side of reviewing applicants. Every frame of a journey shows the same address in Figma (the tab of 12.45 reads
 * .../my-projects/career-guidance-for-everyone/applicants, the tabs of 12.46 read /collaborate/open-calls and
 * /collaborate/open-calls/mapping-the-market-road), so the frames that show another state of the same page live at <path>/state-<name>.
 *
 *   12.45 REVIEW APPLICANTS  (Career Guidance for Everyone, under the project route family, My Projects tab)
 *     .../applicants                        Applicants (17974:162819), the entry from the Review links of Team and the Interest requests band
 *     .../applicants/compare                Compare (17974:169471); the Compare button of the bar opens it
 *     .../applicants/state-compare-selected Compare selected (17974:168901); ticking two boxes shows it
 *     .../applicants/state-loading          Loading (17974:169891), moves on to Applicants after LOADING_MS
 *     .../applicants/state-empty            Empty (17974:170183); the INTEREST REQUESTS card of Team / Empty opens it
 *     .../applicants/state-error            Could not load (17974:170436); Try again goes to Applicants
 *     .../applicants/state-offer-sent       Offer sent (17974:174218); Send offer ends on it
 *     .../applicants/state-joined           Joined (17974:174749), no trigger in the prototype
 *     .../applicants/state-not-now          Not now (17974:175283); Not now ends on it
 *   12.46 OPEN CALL REVIEW
 *     /collaborate/open-calls               Open calls (17976:149803)
 *     /collaborate/open-calls/state-empty   Open calls / Empty (17976:150048)
 *     .../open-calls/mapping-the-market-road                    Open call / Applicants (17976:169488)
 *     .../mapping-the-market-road/state-ready                   Applicants, ready (17976:170080); shortlisting ends on it
 *     .../mapping-the-market-road/state-compare-selected        Applicants, compare selected (17976:170664)
 *     .../mapping-the-market-road/compare                       Open call / Compare (17976:171287)
 *     .../mapping-the-market-road/state-empty                   Open call / Empty (17976:171684)
 *     .../mapping-the-market-road/state-closed                  Open call / Closed (17976:171908); Close call ends on it
 */

const nav = { page: 'collaborate', tab: 'My Projects' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

const applicants = (variant?: ApplicantsVariant) => {
  const Screen = () => <ApplicantsScreen variant={variant} />;
  return Screen;
};
const call = (variant?: CallVariant) => {
  const Screen = () => <CallScreen variant={variant} />;
  return Screen;
};
const openCalls = (variant?: 'empty') => {
  const Screen = () => <OpenCallsScreen variant={variant} />;
  return Screen;
};

export const routes: RouteDef[] = [
  // 12.45 REVIEW APPLICANTS
  def(APPLICANT_PATHS.list, 'Applicants', applicants()),
  def(APPLICANT_PATHS.compare, 'Applicants', CompareScreen),
  def(APPLICANT_PATHS.compareSelected, 'Applicants', applicants('compare-selected')),
  def(APPLICANT_PATHS.loading, 'Applicants', applicants('loading')),
  def(APPLICANT_PATHS.empty, 'Applicants', applicants('empty')),
  def(APPLICANT_PATHS.error, 'Applicants', applicants('error')),
  def(APPLICANT_PATHS.offerSent, 'Applicants', applicants('offer-sent')),
  def(APPLICANT_PATHS.joined, 'Applicants', applicants('joined')),
  def(APPLICANT_PATHS.notNow, 'Applicants', applicants('not-now')),

  // 12.46 OPEN CALL REVIEW
  def(CALL_PATHS.list, 'Open calls', openCalls()),
  def(CALL_PATHS.listEmpty, 'Open calls', openCalls('empty')),
  def(CALL_PATHS.call, 'Applicants', call()),
  def(CALL_PATHS.ready, 'Applicants', call('ready')),
  def(CALL_PATHS.compareSelected, 'Applicants', call('compare-selected')),
  def(CALL_PATHS.compare, 'Applicants', CallCompareScreen),
  def(CALL_PATHS.empty, 'Applicants', call('empty')),
  def(CALL_PATHS.closed, 'Applicants', call('closed')),
];
