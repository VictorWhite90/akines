/**
 * Shared sample data for 12.3 Explore collaborators and 12.4 Saved and requests.
 * Every screen reads the same people so a card looks the same in Discovery, Saved and Requests.
 * Copy is the Figma copy (V2 Desktop, section 12 COLLABORATE), curly quotes included.
 */

export type PersonId = 'amina' | 'kunle' | 'funmi' | 'chidi';

export type Person = {
  id: PersonId;
  name: string;
  firstName: string;
  role: string;
  availability: string;
  skills: string;
  intro: string;
  compat: string;
  experience: string;
  preference: string;
  /** Path under /public, wrap with asset() where it is rendered. */
  photo: string;
};

/*
 * Photos (Figma V2 Desktop, B3 Discovery 17215:15502 and B5 Profile preview 17216:16505):
 *   amina.jpg  node 17216:16515 "Portrait" (B5), master for every Amina portrait
 *   kunle.jpg, funmi.jpg, chidi.jpg  cropped from the B3 portraits (188 x 228)
 */
export const PEOPLE: Record<PersonId, Person> = {
  amina: {
    id: 'amina',
    name: 'Amina Yusuf',
    firstName: 'Amina',
    role: 'Career Researcher',
    availability: 'Available for new projects',
    skills: 'Research · Education · Career Development',
    intro: 'I study how students choose their paths and turn the findings into guidance they can use.',
    compat: 'Amina’s research experience may complement your product design and technology skills, helping your team understand the needs of students.',
    experience: 'Researched career decisions of secondary school students in Lagos.',
    preference: 'Structured weekly collaboration with written updates.',
    photo: '/images/app/collab-people/amina.jpg',
  },
  kunle: {
    id: 'kunle',
    name: 'Kunle Afolabi',
    firstName: 'Kunle',
    role: 'Software Engineer',
    availability: 'Open to new collaborations',
    skills: 'Engineering · Mobile · Low-bandwidth design',
    intro: 'I build learning and community tools that work on the phones and connections students actually have.',
    compat: 'Kunle’s engineering experience may help turn your product design into a platform that works reliably for students on mobile.',
    experience: 'Built a homework help app used in secondary schools across Lagos and Ibadan.',
    preference: 'Short weekly check-ins and a shared task board.',
    photo: '/images/app/collab-people/kunle.jpg',
  },
  funmi: {
    id: 'funmi',
    name: 'Funmi Okoro',
    firstName: 'Funmi',
    role: 'Learning Experience Designer',
    availability: 'Available from next month',
    skills: 'Learning design · Facilitation · Content',
    intro: 'I design learning journeys that help young people reflect on who they are and what they want to do.',
    compat: 'Funmi’s learning design experience may complement your focus on student decisions, shaping how guidance is presented and understood.',
    experience: 'Designed an after-school career curriculum for community learning centres.',
    preference: 'Workshop-style sessions with asynchronous feedback.',
    photo: '/images/app/collab-people/funmi.jpg',
  },
  chidi: {
    id: 'chidi',
    name: 'Chidi Nwosu',
    firstName: 'Chidi',
    role: 'Community Partnerships Lead',
    availability: 'Available for new projects',
    skills: 'Partnerships · Student outreach · Facilitation',
    intro: 'I connect schools, community groups and young people so good ideas reach the students who need them.',
    compat: 'Chidi’s work with school and student communities in Nigeria may help your team reach, and learn from, the students you want to support.',
    experience: 'Led a student mentorship network across eight schools in Enugu and Abuja.',
    preference: 'Regular conversations with clear shared expectations.',
    photo: '/images/app/collab-people/chidi.jpg',
  },
};

/** Order of the recommendations in Discovery (B3). */
export const RECOMMENDED: PersonId[] = ['amina', 'kunle', 'funmi', 'chidi'];

/** Saved collaborators at the start of a visit (B11 shows Kunle and Funmi). */
export const SEEDED_SAVED: PersonId[] = ['kunle', 'funmi'];

/** The project B3 matches for (Figma B3 data stays Career Guidance for Everyone whichever project B2 shows). */
export const PROJECT = {
  name: 'Career Guidance for Everyone',
  stage: 'Ready to plan',
  brief: 'Ready to plan. Looking for collaborators and research.',
};

/* ------------------------------------------------------------------ B2 Change project (Figma 12.3 Modal:Change project 17972:147081) */

export type ProjectId = 'career' | 'adire' | 'community' | 'mentorship';

export type ProjectOption = {
  id: ProjectId;
  name: string;
  /** The stage line of the modal row ("Current project. " goes in front of it on the project that is in use). */
  stage: string;
  /** The line under the project name on B2 (Matching with your approved brief). */
  brief: string;
};

export const DEFAULT_PROJECT: ProjectId = 'career';

export const PROJECT_OPTIONS: ProjectOption[] = [
  { id: 'career', name: 'Career Guidance for Everyone', stage: 'Ready to plan.', brief: PROJECT.brief },
  { id: 'adire', name: 'Adire Stories', stage: 'Building. Looking for collaborators and distribution.', brief: 'Building. Looking for collaborators and distribution.' },
  { id: 'community', name: 'Community Learning Initiative', stage: 'Planning. Looking for collaborators.', brief: 'Planning. Looking for collaborators.' },
  { id: 'mentorship', name: 'Mentorship Circle', stage: 'Planning. Looking for collaborators.', brief: 'Planning. Looking for collaborators.' },
];

export const projectOption = (id: ProjectId): ProjectOption => PROJECT_OPTIONS.find((p) => p.id === id) ?? PROJECT_OPTIONS[0];

/** Routes of this part and the neighbours it links to. */
export const R = {
  start: '/collaborate/start',
  entry: '/collaborate/collaborators',
  matching: '/collaborate/collaborators/matching',
  discovery: '/collaborate/collaborators/discovery',
  discoveryEmpty: '/collaborate/collaborators/discovery/state-no-recommendations',
  why: '/collaborate/collaborators/why-this-match',
  profile: '/collaborate/collaborators/profile-preview',
  request: '/collaborate/collaborators/request',
  sent: '/collaborate/collaborators/request-sent',
  saved: '/collaborate/saved-collaborators',
  savedEmpty: '/collaborate/saved-collaborators/state-empty',
  requests: '/collaborate/introduction-requests',
  requestsEmpty: '/collaborate/introduction-requests/state-empty',
} as const;

/**
 * Profile, introduction request, Request sent and Why this match routes of one person. Amina keeps the original B5, B9, B10 and B4 paths;
 * Kunle, Funmi and Chidi have their own journeys (12.28 to 12.30), each with the same screens (the confirm modal and the toast are overlays).
 */
export const personRoutes = (id: PersonId) =>
  id === 'amina'
    ? { profile: R.profile, request: R.request, sent: R.sent, why: R.why }
    : {
        profile: `/collaborate/collaborators/${id}`,
        request: `/collaborate/collaborators/${id}/request`,
        sent: `/collaborate/collaborators/${id}/request-sent`,
        why: `/collaborate/collaborators/${id}/why-this-match`,
      };

/* ------------------------------------------------------------------ B2 matching intention */

export type Intention = 'project' | 'skills' | 'interest';

export const INTENTIONS: { id: Intention; label: string; title: string; text: string }[] = [
  { id: 'project', label: 'For a project', title: 'For a project', text: 'Find people whose skills and experience complement a specific project.' },
  { id: 'skills', label: 'For my skills', title: 'For my skills', text: 'Discover projects and people that align with my interests and expertise.' },
  { id: 'interest', label: 'For a shared interest', title: 'For a shared interest', text: 'Find people who share an interest, purpose or creative direction.' },
];

/* ------------------------------------------------------------------ Matching preferences modal */

export type PrefGroup = { key: string; label: string; desc: string; options: string[]; defaults: string[] };

export const PREF_GROUPS: PrefGroup[] = [
  { key: 'skills', label: 'Skills', desc: 'Skills required for the project.', options: ['Research', 'Engineering', 'Product design'], defaults: ['Research', 'Engineering', 'Product design'] },
  { key: 'experience', label: 'Experience', desc: 'Relevant experience or expertise.', options: ['Education', 'Student communities', 'Early-stage products'], defaults: ['Education'] },
  { key: 'availability', label: 'Availability', desc: 'Current availability for new collaborations.', options: ['Open now', 'From next month', 'Flexible'], defaults: ['Open now'] },
  { key: 'communication', label: 'Communication style', desc: 'Preferred communication approach.', options: ['Structured and written', 'Conversational', 'Asynchronous updates'], defaults: ['Structured and written'] },
  { key: 'rhythm', label: 'Working rhythm', desc: 'Preferred collaboration cadence.', options: ['Weekly', 'Fortnightly', 'Intensive sprints'], defaults: ['Weekly'] },
  { key: 'location', label: 'Location', desc: 'Geographic relevance, when applicable.', options: ['Nigeria', 'West Africa', 'Anywhere'], defaults: ['Nigeria'] },
  { key: 'interests', label: 'Shared interests', desc: 'Relevant interests or shared purpose.', options: ['Access to education', 'Youth development', 'Career guidance'], defaults: ['Career guidance'] },
];

export type Prefs = Record<string, string[]>;

export const defaultPrefs = (): Prefs => Object.fromEntries(PREF_GROUPS.map((g) => [g.key, [...g.defaults]]));

/** "Research, engineering, product design": the skills line of the matching context bar. */
export function skillsLine(prefs: Prefs): string {
  const list = (prefs.skills ?? []).map((s) => s.toLowerCase());
  if (!list.length) return 'Not specified';
  const text = list.join(', ');
  return text.charAt(0).toUpperCase() + text.slice(1);
}

/* ------------------------------------------------------------------ B4 why this match */

export type MatchRow = { category: string; text: string; source: string };

/** Pronouns the per person copy of the overlays and the request pages is written with. */
export const PRONOUN: Record<PersonId, { subject: string; object: string; possessive: string }> = {
  amina: { subject: 'she', object: 'her', possessive: 'her' },
  kunle: { subject: 'he', object: 'him', possessive: 'his' },
  funmi: { subject: 'she', object: 'her', possessive: 'her' },
  chidi: { subject: 'he', object: 'him', possessive: 'his' },
};

const CATEGORIES = ['Shared purpose', 'Complementary skills', 'Relevant experience', 'Preferred communication style', 'Availability', 'Working rhythm', 'Geographic or cultural relevance', 'Previous trusted contributions'] as const;

/** The eight rows of Why this match: [text, source] in the order of CATEGORIES. Amina is B4 (17216:16167), the others 12.28 to 12.30 (17972:139787, 17972:141398, 17972:142259). */
const MATCH_TEXT: Record<PersonId, [string, string][]> = {
  amina: [
    ['You both care about making career guidance more accessible to students.', 'From her public profile'],
    ['Your product design experience may complement Amina’s career research expertise.', 'From your project brief and her public skills'],
    ['Amina has experience researching student career decisions.', 'From her public experience'],
    ['You both prefer clear expectations and structured communication.', 'Shared for this match'],
    ['Amina is currently open to new collaborations.', 'Shared for this match'],
    ['You both prefer a weekly working rhythm with asynchronous updates between sessions.', 'Shared for this match'],
    ['Amina has experience working with student communities in Nigeria.', 'From her public profile'],
    ['Amina has previously contributed to education-focused research projects.', 'Shared with her consent'],
  ],
  kunle: [
    ['You both want students to reach career guidance on the phones they already have.', 'From his public profile'],
    ['Your product design experience may complement Kunle’s engineering and low-bandwidth design skills.', 'From your project brief and his public skills'],
    ['Kunle has built a homework help app used in secondary schools across Lagos and Ibadan.', 'From his public experience'],
    ['You both prefer short, regular updates and clear task ownership.', 'Shared for this match'],
    ['Kunle is currently open to new collaborations.', 'Shared for this match'],
    ['You both prefer a weekly check-in with a shared task board between sessions.', 'Shared for this match'],
    ['Kunle has experience building tools for schools across Lagos and Ibadan.', 'From his public profile'],
    ['Kunle has previously reviewed open learning tools for students.', 'Shared with his consent'],
  ],
  funmi: [
    ['You both want students to understand their options before they decide.', 'From her public profile'],
    ['Your product design experience may complement Funmi’s learning design and facilitation skills.', 'From your project brief and her public skills'],
    ['Funmi has designed an after-school career curriculum for community learning centres.', 'From her public experience'],
    ['You both prefer honest, early feedback.', 'Shared for this match'],
    ['Funmi is available from next month.', 'Shared for this match'],
    ['Funmi prefers workshop-style sessions with asynchronous feedback between them.', 'Shared for this match'],
    ['Funmi has experience working with community learning centres.', 'From her public profile'],
    ['Funmi has previously co-authored a facilitator handbook.', 'Shared with her consent'],
  ],
  chidi: [
    ['You both want career guidance to reach the students who need it.', 'From his public profile'],
    ['Your product design experience may complement Chidi’s partnerships and student outreach skills.', 'From your project brief and his public skills'],
    ['Chidi has led a student mentorship network across eight schools in Enugu and Abuja.', 'From his public experience'],
    ['You both prefer regular conversations and clear shared expectations.', 'Shared for this match'],
    ['Chidi is currently available for new projects.', 'Shared for this match'],
    ['Chidi prefers regular conversations with a short written summary after each one.', 'Shared for this match'],
    ['Chidi has experience working with school and student communities in Nigeria.', 'From his public profile'],
    ['Chidi has previously reviewed a school partnerships programme.', 'Shared with his consent'],
  ],
};

export const matchRowsFor = (id: PersonId): MatchRow[] => MATCH_TEXT[id].map(([text, source], i) => ({ category: CATEGORIES[i], text, source }));

/** The B4 rows of Amina (kept under their original name). */
export const MATCH_ROWS: MatchRow[] = matchRowsFor('amina');

/** The privacy line under the summary card of Why this match. */
export const whyNoteFor = (id: PersonId) => `Explanations use only what ${PEOPLE[id].firstName} has chosen to share. This is a reason to explore, not a promise of compatibility.`;

/** The wide photograph of the Why this match summary card (382 x 300). */
export const WIDE_PHOTO: Record<PersonId, string> = {
  amina: '/images/app/collab-people/amina-wide.jpg',
  kunle: '/images/app/collab-people/kunle-wide.jpg',
  funmi: '/images/app/collab-people/funmi-wide.jpg',
  chidi: '/images/app/collab-people/chidi-wide.jpg',
};

/* ------------------------------------------------------------------ B5 profile preview (Amina) and the profiles of 12.28 to 12.30 */

export type Profile = {
  keySkills: string[];
  about: string;
  experience: { title: string; detail: string }[];
  skills: string[];
  interests: string[];
  preferences: { label: string; value: string }[];
  contributions: { title: string; detail: string }[];
  matchContext: string;
};

/**
 * Per person copy that carries a pronoun or the name, written out as in Figma (the profile side note, the request notice, the confirm modal
 * text and the two lines of the Request sent screen) together with the message the request starts with.
 */
export type PersonCopy = {
  seeing: string;
  requestNotice: string;
  requestMessage: string;
  confirm: string;
  sentSupport: string;
  sentNote: string;
};

export const PROFILES: Record<PersonId, Profile> = {
  amina: {
    keySkills: ['Research', 'Education', 'Career Development'],
    about: 'Amina researches how students in Nigeria make decisions about what to study and where to work. She turns interviews and surveys into practical guidance for schools, families and the students themselves, and cares about making that guidance reach students who are usually left out of it.',
    experience: [
      { title: 'Career decisions of secondary school students', detail: 'Lead researcher, Lagos State education research programme' },
      { title: 'Pathways to university', detail: 'Research consultant for an education non-profit' },
      { title: 'Guidance counsellor toolkit', detail: 'Co-author and researcher' },
    ],
    skills: ['Career research', 'Student interviews', 'Survey design', 'Education policy'],
    interests: ['Access to education', 'Youth development', 'Career guidance', 'Inclusive design'],
    preferences: [
      { label: 'Communication style', value: 'Clear expectations and structured communication' },
      { label: 'Preferred working rhythm', value: 'Weekly, with asynchronous updates between sessions' },
      { label: 'Availability', value: 'Currently open to new collaborations' },
      { label: 'Collaboration preferences', value: 'Written briefs, shared documents and one live session each week' },
    ],
    contributions: [
      { title: 'Education-focused research project', detail: 'Acknowledged by the project team. Shared with Amina’s consent.' },
      { title: 'Student guidance toolkit', detail: 'Reviewer. Shared with Amina’s consent.' },
    ],
    matchContext: 'You both care about making career guidance more accessible to students, and Amina’s research experience may complement your product design skills.',
  },
  // Figma 12.28, Collaborator profile: Kunle Afolabi (17706:74545)
  kunle: {
    keySkills: ['Engineering', 'Mobile', 'Low-bandwidth design'],
    about: 'Kunle builds learning and community tools for students who rely on basic phones and unreliable connections. He starts from how people really use their devices, keeps each tool light enough to work anywhere, and enjoys turning a designer’s idea into something students can use every day.',
    experience: [
      { title: 'Homework help app', detail: 'Lead engineer, used in secondary schools across Lagos and Ibadan' },
      { title: 'Low-bandwidth lesson player', detail: 'Engineer at an education non-profit' },
      { title: 'Community noticeboard', detail: 'Volunteer developer' },
    ],
    skills: ['Mobile development', 'Low-bandwidth design', 'APIs', 'Offline-first apps'],
    interests: ['Learning tools', 'Student access', 'Open source', 'Community technology'],
    preferences: [
      { label: 'Communication style', value: 'Short, regular updates and clear task ownership' },
      { label: 'Preferred working rhythm', value: 'Weekly check-ins, with a shared task board between them' },
      { label: 'Availability', value: 'Currently open to new collaborations' },
      { label: 'Collaboration preferences', value: 'A shared task board, short calls and written decisions' },
    ],
    contributions: [
      { title: 'Student homework app', detail: 'Acknowledged by the project team. Shared with Kunle’s consent.' },
      { title: 'Open learning tools', detail: 'Reviewer. Shared with Kunle’s consent.' },
    ],
    matchContext: 'You both want students to reach career guidance on the phones they already have, and Kunle’s engineering experience may help turn your product design into a platform that works reliably on mobile.',
  },
  // Figma 12.29, Collaborator profile: Funmi Okoro (17706:75314)
  funmi: {
    keySkills: ['Learning design', 'Facilitation', 'Content'],
    about: 'Funmi designs learning journeys for young people in community learning centres. She runs workshops, writes the activities and listens closely to what students say, so that guidance helps them reflect on who they are and not only on which job to pick.',
    experience: [
      { title: 'After-school career curriculum', detail: 'Lead designer for community learning centres' },
      { title: 'Reflection workshops for students', detail: 'Facilitator, secondary school programme' },
      { title: 'Facilitator handbook', detail: 'Author and trainer' },
    ],
    skills: ['Learning design', 'Workshop facilitation', 'Content writing', 'Curriculum planning'],
    interests: ['Student reflection', 'Youth development', 'Community learning', 'Inclusive design'],
    preferences: [
      { label: 'Communication style', value: 'Honest, early feedback in workshop-style sessions' },
      { label: 'Preferred working rhythm', value: 'Workshop-style sessions, with asynchronous feedback between them' },
      { label: 'Availability', value: 'Available from next month' },
      { label: 'Collaboration preferences', value: 'Shared documents, live workshops and written feedback' },
    ],
    contributions: [
      { title: 'Career curriculum for community centres', detail: 'Acknowledged by the learning centres. Shared with Funmi’s consent.' },
      { title: 'Facilitator handbook', detail: 'Co-author. Shared with Funmi’s consent.' },
    ],
    matchContext: 'You both want students to understand their options, and Funmi’s learning design experience may complement your focus on student decisions.',
  },
  // Figma 12.30, Collaborator profile: Chidi Nwosu (17706:76083)
  chidi: {
    keySkills: ['Partnerships', 'Student outreach', 'Facilitation'],
    about: 'Chidi builds lasting relationships between schools, community groups and young people. He has led student networks across several states and enjoys introductions that turn into real programmes for students.',
    experience: [
      { title: 'Student mentorship network', detail: 'Lead, eight schools in Enugu and Abuja' },
      { title: 'School partnerships programme', detail: 'Partnerships manager at an education non-profit' },
      { title: 'Community outreach days', detail: 'Organiser and facilitator' },
    ],
    skills: ['Partnership building', 'Student outreach', 'Facilitation', 'Programme coordination'],
    interests: ['Access to education', 'Student mentorship', 'Community networks', 'Youth leadership'],
    preferences: [
      { label: 'Communication style', value: 'Regular conversations with clear shared expectations' },
      { label: 'Preferred working rhythm', value: 'Regular conversations, with a short written summary after each one' },
      { label: 'Availability', value: 'Currently open to new collaborations' },
      { label: 'Collaboration preferences', value: 'Short calls, clear written expectations and an open channel for questions' },
    ],
    contributions: [
      { title: 'Student mentorship network', detail: 'Acknowledged by partner schools. Shared with Chidi’s consent.' },
      { title: 'School partnerships programme', detail: 'Reviewer. Shared with Chidi’s consent.' },
    ],
    matchContext: 'Chidi’s work with school and student communities in Nigeria may help your team reach, and learn from, the students you want to support.',
  },
};

/** The B5 profile preview of Amina (kept under its original name). */
export const AMINA_PROFILE = PROFILES.amina;

/* ------------------------------------------------------------------ B9 introduction request, B10 sent, confirm modal */

export const PERSON_COPY: Record<PersonId, PersonCopy> = {
  amina: {
    seeing: 'Amina’s public profile and the details she chose to share for matching. Private information stays private.',
    requestNotice: 'Amina will see your message and your public profile, then decide whether to connect. Neither of you is added to a project automatically.',
    requestMessage:
      'Hi Amina,\n\nI’m working on a career guidance platform for Nigerian students.\n\nYour experience in career research and your interest in education access seem closely aligned with what we’re building.\n\nI’d love to connect and explore whether we could work together.',
    confirm: 'She will see your message and your public profile, then decide whether to connect. Nothing is sent until you confirm.',
    sentSupport: 'Amina can now review your message and decide whether she’d like to connect.',
    sentNote: 'Amina hasn’t responded yet. You’ll see her decision here when she does.',
  },
  kunle: {
    seeing: 'Kunle’s public profile and the details he chose to share for matching. Private information stays private.',
    requestNotice: 'Kunle will see your message and your public profile, then decide whether to connect. Neither of you is added to a project automatically.',
    requestMessage:
      'Hi Kunle,\n\nI’m working on a career guidance platform for Nigerian students.\n\nYour experience building learning tools that work on basic phones seems closely aligned with what we’re building.\n\nI’d love to connect and explore whether we could work together.',
    confirm: 'He will see your message and your public profile, then decide whether to connect. Nothing is sent until you confirm.',
    sentSupport: 'Kunle can now review your message and decide whether he’d like to connect.',
    sentNote: 'Kunle hasn’t responded yet. You’ll see his decision here when he does.',
  },
  funmi: {
    seeing: 'Funmi’s public profile and the details she chose to share for matching. Private information stays private.',
    requestNotice: 'Funmi will see your message and your public profile, then decide whether to connect. Neither of you is added to a project automatically.',
    requestMessage:
      'Hi Funmi,\n\nI’m working on a career guidance platform for Nigerian students.\n\nYour experience designing learning journeys for young people seems closely aligned with what we’re building.\n\nI’d love to connect and explore whether we could work together.',
    confirm: 'She will see your message and your public profile, then decide whether to connect. Nothing is sent until you confirm.',
    sentSupport: 'Funmi can now review your message and decide whether she’d like to connect.',
    sentNote: 'Funmi hasn’t responded yet. You’ll see her decision here when she does.',
  },
  chidi: {
    seeing: 'Chidi’s public profile and the details he chose to share for matching. Private information stays private.',
    requestNotice: 'Chidi will see your message and your public profile, then decide whether to connect. Neither of you is added to a project automatically.',
    requestMessage:
      'Hi Chidi,\n\nI’m working on a career guidance platform for Nigerian students.\n\nYour experience connecting schools and student communities seems closely aligned with what we’re building.\n\nI’d love to connect and explore whether we could work together.',
    confirm: 'He will see your message and your public profile, then decide whether to connect. Nothing is sent until you confirm.',
    sentSupport: 'Chidi can now review your message and decide whether he’d like to connect.',
    sentNote: 'Chidi hasn’t responded yet. You’ll see his decision here when he does.',
  },
};

/* The message of the Amina request (B9), kept under its original name. */
export const REQUEST_MESSAGE = PERSON_COPY.amina.requestMessage;

/* ------------------------------------------------------------------ Ask Akines why drawer */

/**
 * The three paragraphs of the answer. Amina is Modal:Ask Akines why (17219:17688); Kunle, Funmi and Chidi are the clones of 12.3 and 12.28
 * to 12.30 (17972:139514, 17972:141216, 17972:142077).
 */
export const ASK_ANSWERS: Record<PersonId, string[]> = {
  amina: [
    'Amina is recommended because your project requires career research expertise, and she has relevant experience in that area.',
    'You also share an interest in improving access to career guidance for students.',
    'Her preferred working rhythm may complement the structured weekly collaboration you selected for this project.',
  ],
  kunle: [
    'Kunle is recommended because your project needs engineering skills, and he has built learning tools for students who rely on basic phones.',
    'You also share an interest in helping students reach career guidance on the devices they already have.',
    'His preference for short weekly check-ins and a shared task board may fit the structured weekly collaboration you selected for this project.',
  ],
  funmi: [
    'Funmi is recommended because your project needs help with how guidance is presented, and she has designed learning journeys for young people.',
    'You also share an interest in helping students understand their options before they decide.',
    'Her preference for workshop-style sessions with asynchronous feedback may complement the structured weekly collaboration you selected for this project.',
  ],
  chidi: [
    'Chidi is recommended because your project needs to reach students, and he has led a mentorship network across eight schools.',
    'You also share an interest in making career guidance reach the students who need it most.',
    'His preference for regular conversations with clear shared expectations may complement the structured weekly collaboration you selected for this project.',
  ],
};

export const askFollowUps = (id: PersonId) => [`What does ${PRONOUN[id].possessive} experience include?`, `How does ${PRONOUN[id].possessive} working rhythm fit?`, 'What is shared with me?'];

/** The follow-up chips of Amina (kept under their original name). */
export const ASK_FOLLOW_UPS = askFollowUps('amina');

/* ------------------------------------------------------------------ Not relevant feedback */

export const NOT_RELEVANT_REASONS = ['Skills do not match', 'Project interests differ', 'Working preferences differ', 'Not available', 'Other'];

export const notRelevantNote = (id: PersonId) => `Your answer is optional and ${PEOPLE[id].firstName} won’t be notified.`;

/* ------------------------------------------------------------------ Privacy and information sharing */

export type PrivacyTier = { icon: 'eye' | 'share' | 'lock'; title: string; text: string; tags: string[] };

export const privacyTiersFor = (id: PersonId): PrivacyTier[] => {
  const first = PEOPLE[id].firstName;
  const poss = PRONOUN[id].possessive;
  return [
    { icon: 'eye', title: 'Public profile', text: `Information ${first} intentionally made available on ${poss} public profile.`, tags: ['Name', 'Professional role', 'Public skills', 'Selected experience', 'Public interests'] },
    { icon: 'share', title: 'Shared for this match', text: `Information ${first} agreed to share for collaboration matching.`, tags: ['Availability', 'Working preferences', 'Project interests', 'Collaboration preferences'] },
    { icon: 'lock', title: 'Stays private', text: 'Information that remains private and is never used in explanations.', tags: ['Private conversations', 'Unshared personal details', 'Sensitive profile information'] },
  ];
};

/** The three rows of "Why is this visible?". Figma draws them closed, the open text is the Info Item State=Open copy written for the person. */
export const privacyReasonsFor = (id: PersonId): { label: string; text: string }[] => {
  const first = PEOPLE[id].firstName;
  const { subject, possessive } = PRONOUN[id];
  const Possessive = possessive.charAt(0).toUpperCase() + possessive.slice(1);
  return [
    { label: 'Availability', text: `${first} agreed to share ${possessive} availability for collaboration matching.` },
    { label: 'Skills', text: `${Possessive} skills are part of ${possessive} public profile.` },
    { label: 'Working preferences', text: `${first} shared these for this match so you can see how ${subject} likes to collaborate.` },
  ];
};

export const PRIVACY_TIERS = privacyTiersFor('amina');
export const PRIVACY_REASONS = privacyReasonsFor('amina');

/* ------------------------------------------------------------------ B12 introduction requests */

export type RequestStatus = 'pending' | 'accepted' | 'notnow';

export const STATUS_LABEL: Record<RequestStatus, string> = { pending: 'Pending', accepted: 'Accepted', notnow: 'Not now' };

/**
 * Key of one request: person and stage. A person can have two (Chidi has the 28 October request that is Not now on B12 and the new
 * pending request of 5 November), so withdrawing one never touches the other.
 */
export const requestKey = (id: PersonId, stage: RequestStatus) => `${id}:${stage}`;

/** The 12.47 page of a request. Pending (Amina, Kunle, Funmi, Chidi) and Not now (Chidi) are the paths B10 and B12 link to; Amina's Accepted and Not now are state routes. */
export const requestRoute = (id: PersonId, stage: RequestStatus = 'pending') =>
  stage === 'notnow' ? (id === 'amina' ? `${R.requests}/amina/state-not-now` : `${R.requests}/${id}/not-now`) : stage === 'accepted' ? `${R.requests}/${id}/state-accepted` : `${R.requests}/${id}`;

export type IntroRequest = {
  key: string;
  id: PersonId;
  name: string;
  role: string;
  message: string;
  status: RequestStatus;
  date: string;
};

/** The B12 list (Figma 17218:17542). Withdrawn requests are taken out of it by the store (B12 after withdrawn, 17974:164047). */
export const REQUESTS: IntroRequest[] = [
  {
    key: requestKey('amina', 'pending'),
    id: 'amina',
    name: 'Amina Yusuf',
    role: 'Career Researcher',
    message: 'Hi Amina, I’m working on a career guidance platform for Nigerian students. Your experience in career research seems closely aligned with what we’re building.',
    status: 'pending',
    date: 'Sent 1 November 2026',
  },
  {
    key: requestKey('chidi', 'notnow'),
    id: 'chidi',
    name: 'Chidi Nwosu',
    role: 'Education Technologist',
    message: 'Hi Chidi, I’m building a guidance platform for students and would value your view on the learning side of the product.',
    status: 'notnow',
    date: 'Sent 28 October 2026',
  },
];

/* ------------------------------------------------------------------ 12.47 Introduction request pages */

export type RequestStep = { title: string; note: string; state: 'done' | 'upcoming' | 'ended' };

export type RequestPageData = {
  key: string;
  id: PersonId;
  stage: RequestStatus;
  /** The role line of the card, shown as "<role> · For Career Guidance for Everyone". */
  role: string;
  sent: string;
  note: string;
  headline: string;
  support: string;
  steps: RequestStep[];
  notice: { title: string; text: string };
};

const pendingPage = (id: PersonId, role: string, sentLong: string, sentShort: string): RequestPageData => {
  const first = PEOPLE[id].firstName;
  const { subject, possessive } = PRONOUN[id];
  return {
    key: requestKey(id, 'pending'),
    id,
    stage: 'pending',
    role,
    sent: `Sent ${sentLong}`,
    note: PERSON_COPY[id].requestMessage,
    headline: `Waiting for ${first}.`,
    support: `${first} has not replied yet. You will see ${possessive} decision here when ${subject} does.`,
    steps: [
      { title: 'Sent', note: sentShort, state: 'done' },
      { title: 'Seen', note: `You will see when ${first} has opened it`, state: 'upcoming' },
      { title: 'Reply', note: `${first} decides whether to connect`, state: 'upcoming' },
    ],
    notice: {
      title: `Nothing more is shared until ${first} agrees.`,
      text: `${first} can see your note and your public profile. Neither of you is added to a project automatically. You can withdraw this request before ${subject} replies.`,
    },
  };
};

const notNowPage = (id: PersonId, role: string, sent: string, sentShort: string, replyShort: string, note: string): RequestPageData => {
  const first = PEOPLE[id].firstName;
  return {
    key: requestKey(id, 'notnow'),
    id,
    stage: 'notnow',
    role,
    sent,
    note,
    headline: `${first} is not available to connect right now.`,
    support: 'This is not a reflection on you or your project. You can look for other collaborators, or try again another time.',
    steps: [
      { title: 'Sent', note: sentShort, state: 'done' },
      { title: 'Not now', note: replyShort, state: 'ended' },
    ],
    notice: { title: 'Nothing changes for your project.', text: `Your note stays between you and ${first}. You can send a new request later, or look at other people who may fit.` },
  };
};

/** Figma 12.47: Pending 17974:158093 (Amina), 165381 (Kunle), 165496 (Funmi), 165611 (Chidi); Accepted 17974:158358; Not now 17974:158630 (Amina), 165726 (Chidi). */
export const REQUEST_PAGES: Partial<Record<PersonId, Partial<Record<RequestStatus, RequestPageData>>>> = {
  amina: {
    pending: pendingPage('amina', 'Career Researcher', '1 November 2026', 'Sun 1 Nov'),
    accepted: {
      key: requestKey('amina', 'accepted'),
      id: 'amina',
      stage: 'accepted',
      role: 'Career Researcher',
      sent: 'Sent 1 November 2026. Accepted 4 November 2026.',
      note: PERSON_COPY.amina.requestMessage,
      headline: 'Amina accepted your request.',
      support: 'You can start a conversation whenever you are ready.',
      steps: [
        { title: 'Sent', note: 'Sun 1 Nov', state: 'done' },
        { title: 'Seen', note: 'Mon 2 Nov', state: 'done' },
        { title: 'Reply', note: 'Amina accepted, Wed 4 Nov', state: 'done' },
      ],
      notice: { title: 'You are connected.', text: 'Amina has agreed to talk with you. You are not added to each other’s projects until you both choose to be.' },
    },
    notnow: notNowPage('amina', 'Career Researcher', 'Sent 1 November 2026. Reply 4 November 2026.', 'Sun 1 Nov', 'Wed 4 Nov', PERSON_COPY.amina.requestMessage),
  },
  kunle: { pending: pendingPage('kunle', 'Software Engineer', '5 November 2026', 'Thu 5 Nov') },
  funmi: { pending: pendingPage('funmi', 'Learning Experience Designer', '5 November 2026', 'Thu 5 Nov') },
  chidi: {
    pending: pendingPage('chidi', 'Community Partnerships Lead', '5 November 2026', 'Thu 5 Nov'),
    // the one B12 links to: its role line follows the B12 row (Education Technologist)
    notnow: notNowPage('chidi', 'Education Technologist', 'Sent 28 October 2026. Reply 2 November 2026.', 'Wed 28 Oct', 'Mon 2 Nov', REQUESTS[1].message),
  },
};
