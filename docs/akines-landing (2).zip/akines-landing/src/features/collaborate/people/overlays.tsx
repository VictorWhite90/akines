'use client';

import { useEffect, useState } from 'react';
import { Button, Chip, Drawer, IconButton, Modal, Radio, toast } from '@/ui';
import { useNav, usePath } from '@/lib/nav';
import { BackLink, IconArrowUp, IconChevronDown, IconChevronUp, IconEye, IconLock, IconShare, IconSparkle } from './cc-ui';
import {
  ASK_ANSWERS,
  askFollowUps,
  NOT_RELEVANT_REASONS,
  notRelevantNote,
  PEOPLE,
  PERSON_COPY,
  PREF_GROUPS,
  privacyReasonsFor,
  privacyTiersFor,
  PROJECT_OPTIONS,
  R,
  personRoutes,
  type PersonId,
  type Prefs,
  type ProjectId,
} from './data';
import { ccStore, useCc } from './store';

/**
 * The overlays of 12.3. They are state of the screen that opens them, never routes:
 *   prefs        Modal: Adjust matching preferences     (B3, B3 empty)
 *   project      Modal: Change project                   (B2)
 *   ask          Drawer: Ask Akines why                  (B3, B4, B5)
 *   notrelevant  Modal: Not relevant feedback            (B3, B5)
 *   privacy      Modal: Privacy and information sharing  (B4, B5)
 *   confirm      Modal: Confirm introduction request     (B9, and the requests of Kunle, Funmi and Chidi)
 * `person` is whose overlay it is (Amina by default): the ask, notrelevant, privacy and confirm overlays are written for that person
 * (Amina 17219:17688, 17219:17865, 17219:17602; Kunle, Funmi and Chidi are the clones of 12.3 and 12.28 to 12.30).
 * `from` says where the Ask Akines why drawer was opened: the clones opened from the B3 cards end with "Back to collaborators", the ones
 * opened from a profile or from Why this match with "Back to profile" (Amina's single frame says "Back to profile" everywhere).
 */
export type OverlayId = 'prefs' | 'project' | 'ask' | 'notrelevant' | 'privacy' | 'confirm';

export function CcOverlays({ open, onClose, person = 'amina', from = 'profile' }: { open: OverlayId | null; onClose: () => void; person?: PersonId; from?: 'cards' | 'profile' }) {
  const nav = useNav();
  const path = usePath();
  const toDiscovery = () => {
    if (path !== R.discovery) nav.push(R.discovery);
  };
  return (
    <>
      <PreferencesModal
        open={open === 'prefs'}
        onClose={onClose}
        onApply={(prefs) => {
          ccStore.setPrefs(prefs);
          onClose();
          toDiscovery();
        }}
      />
      <ProjectModal open={open === 'project'} onClose={onClose} />
      <AskDrawer open={open === 'ask'} onClose={onClose} person={person} backLabel={person !== 'amina' && from === 'cards' ? 'Back to collaborators' : 'Back to profile'} />
      <NotRelevantModal
        open={open === 'notrelevant'}
        onClose={onClose}
        person={person}
        onRemove={() => {
          const undo = ccStore.dismiss(person);
          onClose();
          toDiscovery();
          toast.show({ message: 'Removed from your recommendations.', actionLabel: 'Undo', onAction: undo });
        }}
      />
      <PrivacyModal open={open === 'privacy'} onClose={onClose} person={person} />
      <ConfirmModal
        open={open === 'confirm'}
        onClose={onClose}
        person={person}
        onSend={() => {
          ccStore.sendRequest(person);
          onClose();
          nav.push(personRoutes(person).sent);
        }}
      />
    </>
  );
}

/* ------------------------------------------------------------------ Adjust matching preferences (Figma 17219:17731) */

function PreferencesModal({ open, onClose, onApply }: { open: boolean; onClose: () => void; onApply: (p: Prefs) => void }) {
  const { prefs } = useCc();
  const [draft, setDraft] = useState<Prefs>(prefs);
  // every time the modal opens it starts from the saved preferences, so Cancel really discards
  useEffect(() => {
    if (open) setDraft(prefs);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const toggle = (key: string, option: string) =>
    setDraft((d) => {
      const cur = d[key] ?? [];
      return { ...d, [key]: cur.includes(option) ? cur.filter((x) => x !== option) : [...cur, option] };
    });
  return (
    <Modal
      open={open}
      onClose={onClose}
      size="xl"
      width={1040}
      className="cc-pref"
      eyebrow="Your matching preferences"
      title="What matters most in a collaborator?"
      description="Choose what matters to you. Every preference is optional."
      footer={
        <>
          <Button onClick={() => onApply(draft)}>Update recommendations</Button>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
        </>
      }
    >
      <div className="cc-pref__rows">
        {PREF_GROUPS.map((g) => (
          <div className="cc-pref__row" key={g.key}>
            <div className="cc-pref__label">
              <p className="cc-pref__name">
                <span>{g.label}</span>
                <span className="cc-pref__opt">Optional</span>
              </p>
              <p className="cc-pref__desc">{g.desc}</p>
            </div>
            <div className="cc-pref__options" role="group" aria-label={g.label}>
              {g.options.map((o) => (
                <Chip key={o} selected={(draft[g.key] ?? []).includes(o)} onClick={() => toggle(g.key, o)}>
                  {o}
                </Chip>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Change project (Figma 12.3 Modal:Change project 17972:147081) */

/**
 * Four projects as a radio list (Project Options 17972:146802), the one in use ticked. "Use this project" applies the ticked one, closes the
 * modal and shows the toast with Undo (Toast:Project changed 17972:147356); B2 then shows the chosen project (Project changed 17972:147145).
 * The stage line of the project in use starts with "Current project." as in the drawing of Career Guidance for Everyone.
 */
function ProjectModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { project } = useCc();
  const [draft, setDraft] = useState<ProjectId>(project);
  // every time the modal opens it starts from the project in use, so Cancel really discards
  useEffect(() => {
    if (open) setDraft(project);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const use = () => {
    onClose();
    if (draft === project) return;
    const undo = ccStore.setProject(draft);
    const name = PROJECT_OPTIONS.find((p) => p.id === draft)?.name ?? '';
    toast.show({ message: `Looking for collaborators for ${name}.`, actionLabel: 'Undo', onAction: undo });
  };
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="cc-proj"
      eyebrow="Change project"
      title="Which project is this for?"
      description="We will look for people who fit the project you choose."
      footer={
        <>
          <Button onClick={use}>Use this project</Button>
          <Button variant="link" onClick={onClose}>
            Cancel
          </Button>
        </>
      }
    >
      <div className="cc-proj__list" role="radiogroup" aria-label="Project">
        {PROJECT_OPTIONS.map((o) => (
          <Radio
            key={o.id}
            name="cc-project"
            value={o.id}
            label={o.name}
            description={o.id === project ? `Current project. ${o.stage}` : o.stage}
            checked={draft === o.id}
            onChange={() => setDraft(o.id)}
          />
        ))}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Ask Akines why (Figma 17219:17688) */

function AskDrawer({ open, onClose, person, backLabel }: { open: boolean; onClose: () => void; person: PersonId; backLabel: string }) {
  const [picked, setPicked] = useState<string[]>([]);
  useEffect(() => {
    if (open) setPicked([]);
  }, [open]);
  const first = PEOPLE[person].firstName;
  return (
    <Drawer open={open} onClose={onClose} width={560} className="cc-drawer" eyebrow="Ask Akines" title={`Why ${first}?`}>
      <div className="cc-ask">
        <div className="cc-ask__conv">
          <p className="cc-ask__user">{`Why is ${first} recommended for this project?`}</p>
          <div className="cc-ask__reply">
            <span className="cc-ask__avatar" aria-hidden="true">
              <IconSparkle size={16} />
            </span>
            <div className="cc-ask__answer">
              <p className="cc-cap">Akines</p>
              <div className="cc-ask__text">
                {ASK_ANSWERS[person].map((para) => (
                  <p key={para}>{para}</p>
                ))}
              </div>
            </div>
          </div>
          <p className="cc-ask__note">Akines explains matches using only what has been shared. It can’t promise compatibility.</p>
        </div>
        <div className="cc-ask__chips" role="group" aria-label="Follow-up questions">
          {askFollowUps(person).map((q) => (
            <Chip key={q} selected={picked.includes(q)} onClick={() => setPicked((p) => (p.includes(q) ? p.filter((x) => x !== q) : [...p, q]))}>
              {q}
            </Chip>
          ))}
        </div>
        <form className="cc-ask__form" onSubmit={(e) => e.preventDefault()}>
          <input className="cc-ask__input" type="text" aria-label="Ask a follow-up question" placeholder="Ask a follow-up question..." />
          <IconButton type="submit" variant="solid" className="cc-ask__send" label="Send">
            <IconArrowUp size={20} strokeWidth={1.5} />
          </IconButton>
        </form>
        <BackLink onClick={onClose}>{backLabel}</BackLink>
      </div>
    </Drawer>
  );
}

/* ------------------------------------------------------------------ Not relevant feedback (Figma 17219:17865) */

function NotRelevantModal({ open, onClose, onRemove, person }: { open: boolean; onClose: () => void; onRemove: () => void; person: PersonId }) {
  const [reason, setReason] = useState(NOT_RELEVANT_REASONS[0]);
  useEffect(() => {
    if (open) setReason(NOT_RELEVANT_REASONS[0]);
  }, [open]);
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="cc-nr"
      eyebrow="Optional feedback"
      title="Why isn’t this a fit?"
      description={notRelevantNote(person)}
      footer={
        <>
          <Button onClick={onRemove}>Remove from recommendations</Button>
          <Button variant="link" onClick={onRemove}>
            Skip feedback
          </Button>
        </>
      }
    >
      <div role="radiogroup" aria-label="Reason">
        {NOT_RELEVANT_REASONS.map((r) => (
          <Radio key={r} name="cc-reason" value={r} label={r} checked={reason === r} onChange={() => setReason(r)} />
        ))}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Privacy and information sharing (Figma 17219:17602) */

const TIER_ICON = { eye: IconEye, share: IconShare, lock: IconLock } as const;

function PrivacyModal({ open, onClose, person }: { open: boolean; onClose: () => void; person: PersonId }) {
  // Figma Info Item: every row starts collapsed (State=Default) and a click swaps it to State=Open, a second click back
  const [openRows, setOpenRows] = useState<string[]>([]);
  useEffect(() => {
    if (open) setOpenRows([]);
  }, [open]);
  const tiers = privacyTiersFor(person);
  const reasons = privacyReasonsFor(person);
  return (
    <Modal
      open={open}
      onClose={onClose}
      size="xl"
      width={1100}
      className="cc-priv"
      eyebrow="Privacy and information sharing"
      title="What you can see, and why."
      footer={<Button onClick={onClose}>Done</Button>}
    >
      <div className="cc-priv__tiers">
        {tiers.map((t) => {
          const Icon = TIER_ICON[t.icon];
          return (
            <section className="cc-priv__tier" key={t.title}>
              <h3 className="cc-priv__title">
                <Icon size={18} strokeWidth={1.5} />
                {t.title}
              </h3>
              <p className="cc-priv__text">{t.text}</p>
              <ul className="cc-priv__tags">
                {t.tags.map((tag) => (
                  <li key={tag}>{tag}</li>
                ))}
              </ul>
            </section>
          );
        })}
      </div>
      <div className="cc-priv__why">
        <p className="cc-eyebrow">Why is this visible?</p>
        <div className="cc-priv__list">
          {reasons.map((r, i) => {
            const isOpen = openRows.includes(r.label);
            return (
              <div className="cc-priv__item" key={r.label} data-open={isOpen || undefined}>
                <button type="button" className="cc-priv__head" aria-expanded={isOpen} aria-controls={`cc-priv-${i}`} onClick={() => setOpenRows((rows) => (rows.includes(r.label) ? rows.filter((x) => x !== r.label) : [...rows, r.label]))}>
                  <span>{r.label}</span>
                  <span className="cc-priv__chev">{isOpen ? <IconChevronUp size={16} strokeWidth={1.5} /> : <IconChevronDown size={16} strokeWidth={1.5} />}</span>
                </button>
                <div className="cc-priv__panel" id={`cc-priv-${i}`} hidden={!isOpen}>
                  <p>{r.text}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Confirm introduction request (Figma 17219:17914; Kunle 17706:74693, Funmi 17706:75462, Chidi 17706:76231) */

function ConfirmModal({ open, onClose, onSend, person }: { open: boolean; onClose: () => void; onSend: () => void; person: PersonId }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={560}
      className="cc-confirm"
      eyebrow="Confirm your request"
      title={`Send this request to ${PEOPLE[person].firstName}?`}
      description={PERSON_COPY[person].confirm}
      footer={
        <>
          <Button arrow="up-right" onClick={onSend}>
            Send request
          </Button>
          <Button variant="secondary" onClick={onClose}>
            Keep editing
          </Button>
        </>
      }
    />
  );
}
