'use client';

import { CallScreen } from './Call';
import { EndedScreen } from './Ended';
import { LobbyScreen } from './Lobby';

/**
 * The meeting screens (Figma 12.43 Meetings), registered by routes.tsx for both projects with shell "bare" (no app header):
 *  Lobby 17809:111216, Lobby / Camera off 17809:111347, In call 17809:110599, In call / Screen sharing 17809:110707,
 *  In call / People 17809:110810, In call / Chat 17809:110965, Call ended 17809:111469.
 * The state frames (camera off, screen sharing, people, chat) open already in that state and show the designed look with no devices.
 * Devices, simulated people and panels: call-store.ts, parts.tsx, Call.tsx, Panels.tsx. Styles: call.css (mc-).
 */
export const Lobby = () => <LobbyScreen />;
export const LobbyCameraOff = () => <LobbyScreen cameraOff />;
export const Call = () => <CallScreen />;
export const CallSharing = () => <CallScreen simulate initial={{ presenting: true }} />;
export const CallPeople = () => <CallScreen simulate initial={{ panel: 'people' }} />;
export const CallChat = () => <CallScreen simulate initial={{ panel: 'chat' }} />;
export const CallEnded = () => <EndedScreen />;
