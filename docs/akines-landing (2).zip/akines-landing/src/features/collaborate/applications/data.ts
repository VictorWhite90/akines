/**
 * Sample data of 12.44 APPLICATION STATUS: the days and times Ngozi shared (Figma Slot Picker, set 17972:144663) and the steps of the
 * Application Timeline per stage. Dates are the story's dates (Thu 5 Nov 2026 onwards) and stay as drawn.
 * No 'use client'.
 */
import type { TimelineStep } from './shared';

/* ---------------- talk times (Slot Picker variants) ---------------- */

export type DayKey = 'mon' | 'tue' | 'wed';
export type DaySlot = { time: string; /** Greyed out in Figma (Slot Chip State=Disabled): not offered. */ unavailable?: boolean };
export type Day = { key: DayKey; weekday: string; date: string; slots: DaySlot[] };

export const DAYS: Day[] = [
  {
    key: 'mon',
    weekday: 'Mon',
    date: '9 Nov',
    slots: [{ time: '10:00 am' }, { time: '11:30 am' }, { time: '2:00 pm', unavailable: true }, { time: '4:30 pm' }],
  },
  {
    key: 'tue',
    weekday: 'Tue',
    date: '10 Nov',
    slots: [{ time: '9:30 am' }, { time: '12:00 pm' }, { time: '4:00 pm' }, { time: '5:30 pm' }],
  },
  {
    key: 'wed',
    weekday: 'Wed',
    date: '11 Nov',
    slots: [{ time: '10:00 am' }, { time: '1:00 pm', unavailable: true }, { time: '3:00 pm' }, { time: '4:00 pm' }],
  },
];

/** A chosen time: the day and the position of the chip in that day's row. */
export type Pick = { day: DayKey; slot: number };

/** The time drawn on the Talk booked and Offer received frames (Tue 10 Nov, 4:00 pm). */
export const DEFAULT_PICK: Pick = { day: 'tue', slot: 2 };

export const dayOf = (key: DayKey) => DAYS.find((d) => d.key === key)!;
/** "Tue 10 Nov" */
export const pickDate = (p: Pick) => {
  const d = dayOf(p.day);
  return `${d.weekday} ${d.date}`;
};
/** "4:00 pm" */
export const pickTime = (p: Pick) => dayOf(p.day).slots[p.slot].time;
/** "Tue 10 Nov, 4:00 pm WAT" (picker summary and booked line) */
export const pickFull = (p: Pick) => `${pickDate(p)}, ${pickTime(p)} WAT`;
/** "Tue 10 Nov, 4:00 pm" (timeline note) */
export const pickShort = (p: Pick) => `${pickDate(p)}, ${pickTime(p)}`;

/* ---------------- timeline steps per stage (Application Timeline variants) ---------------- */

export const SENT_ON = 'Thu 5 Nov';
export const SHORTLISTED_ON = 'Sat 7 Nov';
export const OFFER_SENT_ON = 'Thu 12 Nov';
export const START_ON = 'Mon 23 Nov';
export const DECLINED_ON = 'Fri 13 Nov';
export const WITHDRAWN_ON = 'Fri 6 Nov';

export const pendingSteps: TimelineStep[] = [
  { title: 'Sent', note: SENT_ON, state: 'done' },
  { title: 'Shortlisted', note: 'When Ngozi shortlists you', state: 'upcoming' },
  { title: 'Talk', note: 'A 20 minute video call', state: 'upcoming' },
  { title: 'Offer', note: 'If you both decide to go ahead', state: 'upcoming' },
  { title: 'Joined', note: 'You join the team', state: 'upcoming' },
];

export const shortlistedSteps: TimelineStep[] = [
  { title: 'Sent', note: SENT_ON, state: 'done' },
  { title: 'Shortlisted', note: SHORTLISTED_ON, state: 'done' },
  { title: 'Talk', note: 'Pick a time', state: 'current' },
  { title: 'Offer', note: 'After you talk', state: 'upcoming' },
  { title: 'Joined', note: 'When you both agree', state: 'upcoming' },
];

export const talkSteps = (pick: Pick): TimelineStep[] => [
  { title: 'Sent', note: SENT_ON, state: 'done' },
  { title: 'Shortlisted', note: SHORTLISTED_ON, state: 'done' },
  { title: 'Talk', note: pickShort(pick), state: 'current' },
  { title: 'Offer', note: 'After the talk', state: 'upcoming' },
  { title: 'Joined', note: 'When you both agree', state: 'upcoming' },
];

export const offerSteps = (pick: Pick): TimelineStep[] => [
  { title: 'Sent', note: SENT_ON, state: 'done' },
  { title: 'Shortlisted', note: SHORTLISTED_ON, state: 'done' },
  { title: 'Talk', note: pickShort(pick), state: 'done' },
  { title: 'Offer', note: `${OFFER_SENT_ON}. Waiting for your reply`, state: 'current' },
  { title: 'Joined', note: 'When you accept', state: 'upcoming' },
];
