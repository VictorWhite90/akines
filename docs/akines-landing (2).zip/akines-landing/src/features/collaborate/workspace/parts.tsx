'use client';

import type { ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { Button } from '@/ui';
import { ProjectHeader } from '../project-header/ProjectHeader';
import { ProjectRail, type ReviewKey } from './rail';
import { cx } from './util';
import { Icon, ArrowRight, ArrowLeft, ArrowUpRight, CheckIcon, ChevronDown, BellIcon, SlidersIcon, Av, AvStack, Dot, CardLink, BackLink, ActionButton, Over } from './atoms';
import { PRESENCE_TEXT, type Member, type Milestone, type Presence, type Step, type WorkItem } from './data';
import { MEMBER_STAND_IN, NAV_PATHS, useProject, VISIBLE_NAV_ITEMS, type NavKey } from './project';

export type { NavKey };

/**
 * Shared pieces of the project workspace screens (12.10 to 12.13): icons, links, the project header, the project
 * navigation, the three column frame, the context panel blocks and the rows and cards that repeat across screens.
 * Every class is prefixed cw- and lives in workspace.css.
 */

export { cx };

export { Icon, ArrowRight, ArrowLeft, ArrowUpRight, CheckIcon, ChevronDown, BellIcon, SlidersIcon, Av, AvStack, Dot, CardLink, BackLink, ActionButton };

/* ------------------------------------------------------------------ small atoms */

export { Over };

/** Section header (Figma Section Header, Medium): label, headline, support line. */
export function SectionHeader({ label, title, support }: { label: string; title: string; support?: string }) {
  return (
    <header className="cw-sh">
      <Over className="cw-sh__label">{label}</Over>
      <h2 className="cw-sh__title">{title}</h2>
      {support ? <p className="cw-sh__text">{support}</p> : null}
    </header>
  );
}

/** One band of the centre column: a section header with its content below. */
export function Band({ label, title, support, children, className }: { label: string; title: string; support?: string; children?: ReactNode; className?: string }) {
  return (
    <section className={cx('cw-band', className)} data-m="up">
      <SectionHeader label={label} title={title} support={support} />
      {children}
    </section>
  );
}

/** Facts row of a page header: small label over a value. */
export function Facts({ items, compact, bare, narrow }: { items: { label: string; value: ReactNode }[]; compact?: boolean; bare?: boolean; narrow?: boolean }) {
  return (
    <dl className={cx('cw-facts', compact && 'cw-facts--compact', bare && 'cw-facts--bare', narrow && 'cw-facts--narrow')}>
      {items.map((f) => (
        <div className="cw-facts__item" key={f.label}>
          <dt>{f.label}</dt>
          <dd>{f.value}</dd>
        </div>
      ))}
    </dl>
  );
}

/** Page header of a workspace screen (Figma Section Header, Large): label, title, description, then children (facts, actions). */
export function PageHead({ back, label, title, lead, children }: { back?: ReactNode; label: string; title: string; lead?: string; children?: ReactNode }) {
  return (
    <header className="cw-pagehead" data-m="up">
      {back}
      <Over>{label}</Over>
      <h1 className="cw-pagehead__title">{title}</h1>
      {lead ? <p className="cw-pagehead__lead">{lead}</p> : null}
      {children}
    </header>
  );
}

/* ------------------------------------------------------------------ project header */

/** The Project header, its dropdowns, modals and Create AI overlay live in project-header/ProjectHeader.tsx (Figma 12.25). */
export { ProjectHeader };

/* ------------------------------------------------------------------ project navigation */

/** Project navigation, eight visible items (Figma "Project Nav", 17352:14054). Reflection and Launch are hidden, see NAV_ITEMS in project.ts. Every item links to its page. */
/** The page behind every item of the project navigation of Career Guidance for Everyone (Adire Stories has its own, see NAV_PATHS in project.ts). */
export const NAV_HREFS = NAV_PATHS.career;

export function ProjectNav({ active, hrefs }: { active: NavKey; hrefs?: Record<NavKey, string> }) {
  const project = useProject();
  const targets = hrefs ?? project.nav;
  return (
    <nav className="cw-nav" aria-label="Project workspace">
      <p className="cw-nav__eyebrow">PROJECT WORKSPACE</p>
      <ul className="cw-nav__list">
        {VISIBLE_NAV_ITEMS.map((item, i) => {
          const num = String(i + 1).padStart(2, '0');
          return (
            <li key={item.label}>
              <Link href={targets[item.key]} className="cw-nav__item" aria-current={item.key === active ? 'page' : undefined}>
                <span className="cw-nav__num">{num}</span>
                <span className="cw-nav__label">{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/* ------------------------------------------------------------------ the three column frame */

/**
 * The three column frame. The right column is the shared project rail (meeting card first, then team availability, needs review and
 * workload) when `rail` is set: `true` for the full rail, `'short'` for the empty pages (meeting card and team availability only).
 * `railHide` leaves out a Needs review row that points at the page itself. A drill-down page that keeps its own panels passes `context`
 * instead. `wide` has no right column at all (the Tasks board). The project nav is pinned under the project header while the page scrolls.
 */
export function WorkspaceFrame({ active, context, rail, railHide, wide, children }: { active: NavKey; context?: ReactNode; rail?: boolean | 'short'; railHide?: ReviewKey[]; wide?: boolean; children: ReactNode }) {
  const { key, header } = useProject();
  const dash = Boolean(rail) || Boolean(wide);
  return (
    <div className="cw-ws">
      {/* Career Guidance for Everyone has the full header; on Adire Stories only the project switcher is wired, as on the sample projects (12.26) */}
      <ProjectHeader project={header} wired={key === 'career'} />
      <div className={cx('cw-ws__grid', wide && 'cw-ws__grid--wide', dash && 'cw-ws__grid--dash')}>
        <div className="cw-navwrap">
          <ProjectNav active={active} />
        </div>
        <div className={cx('cw-main', dash && 'cw-main--dash')}>{children}</div>
        {rail ? (
          <aside className="cw-ctx cw-rail" aria-label="Project rail">
            <ProjectRail variant={rail === 'short' ? 'short' : 'full'} hide={railHide} />
          </aside>
        ) : wide ? null : (
          <aside className="cw-ctx" aria-label="Project context">
            {context}
          </aside>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ context panel blocks */

export function Ctx({ label, children, rule }: { label: string; children: ReactNode; rule?: boolean }) {
  // rule: force the divider on or off; by default every block but the last one has it (a few blocks of the design differ)
  return (
    <section className="cw-ctx__block" data-rule={rule === undefined ? undefined : rule ? 'on' : 'off'}>
      <Over as="h3">{label}</Over>
      {children}
    </section>
  );
}

const PRESENCE_DOT: Record<Presence, 'green' | 'accent' | 'gray'> = { available: 'green', working: 'accent', away: 'gray' };

/** Rows of people with a status line (Figma Availability Row). */
export function PeopleRows({ people }: { people: { initials: string; name: string; text: string; tone: 'green' | 'accent' | 'gray' }[] }) {
  return (
    <ul className="cw-people">
      {people.map((p) => (
        <li className="cw-people__row" key={p.name}>
          <Av initials={p.initials} size={36} />
          <div className="cw-people__text">
            <span className="cw-people__name">{p.name}</span>
            <span className="cw-people__status">
              <Dot tone={p.tone} size={7} />
              {p.text}
            </span>
          </div>
        </li>
      ))}
    </ul>
  );
}

/** Availability rows of the team, or of the members named in `only` (the Studio, Work and Milestone panels show Adaeze and Tobi). */
export function Availability({ label = 'TEAM AVAILABILITY', only }: { label?: string; only?: string[] }) {
  const { key, members } = useProject();
  // `only` names Career Guidance members; on Adire Stories the member in the same position stands in
  const names = only?.map((i) => (key === 'adire' ? (MEMBER_STAND_IN[i] ?? i) : i));
  const rows = members.filter((m): m is Member & { presence: Presence } => !!m.presence && (!names || names.includes(m.initials))).map((m) => ({
    initials: m.initials,
    name: m.name,
    text: PRESENCE_TEXT[m.presence],
    tone: PRESENCE_DOT[m.presence],
  }));
  return (
    <Ctx label={label}>
      <PeopleRows people={rows} />
    </Ctx>
  );
}

export function UpcomingSession({ rule }: { rule?: boolean }) {
  const { session } = useProject().context;
  return (
    <Ctx label="UPCOMING SESSION" rule={rule}>
      <p className="cw-session__title">{session.title}</p>
      <p className="cw-ctx__line">{session.when}</p>
      <p className="cw-ctx__line">{session.people}</p>
    </Ctx>
  );
}

/** A titled item of a context block: title, a status line with an amber dot, and a link (Review decision, Open conversation). */
export function CtxItem({ title, status, children }: { title: string; status: string; children?: ReactNode }) {
  return (
    <>
      <p className="cw-ctx__item">{title}</p>
      <p className="cw-ctx__status">
        <Dot size={7} />
        {status}
      </p>
      {children}
    </>
  );
}

export function Decision({ label = 'UNRESOLVED DECISIONS', href }: { label?: string; /** Where "Review decision" goes. Only the Overview has a destination in the design (the decision discussion). */ href?: string }) {
  const { decision } = useProject().context;
  return (
    <Ctx label={label}>
      <CtxItem title={decision.title} status={decision.status}>
        <CardLink href={href} arrow>
          Review decision
        </CardLink>
      </CtxItem>
    </Ctx>
  );
}

/* ------------------------------------------------------------------ repeated rows and cards */

/** Work item row (Figma Work Item): title, next action, status line and an action button. A row with a destination is one link. */
export function WorkRow({ item, metaPhase }: { item: Pick<WorkItem, 'title' | 'next' | 'status' | 'member' | 'action' | 'href'> & { phase: string }; metaPhase?: string }) {
  const body = (
    <>
      <div className="cw-work__content">
        <h3 className="cw-work__title">{item.title}</h3>
        <p className="cw-work__next">{item.next}</p>
        <p className="cw-work__meta">
          <span className="cw-work__status">
            <Dot size={7} />
            {item.status}
          </span>
          <span>{item.member}</span>
          <span>{metaPhase ?? item.phase}</span>
        </p>
      </div>
      <span className="cw-work__act">
        {item.href ? (
          <span className="k-btn k-btn--md k-btn--secondary">
            <span className="k-btn__label">{item.action}</span>
            <span className="k-btn__icon k-btn__icon--right">
              <ArrowRight />
            </span>
          </span>
        ) : (
          <Button variant="secondary" iconRight={<ArrowRight />}>
            {item.action}
          </Button>
        )}
      </span>
    </>
  );
  return item.href ? (
    <Link href={item.href} className="cw-work cw-work--link">
      {body}
    </Link>
  ) : (
    <div className="cw-work">{body}</div>
  );
}

const STEP_LABEL: Record<Step['status'], string> = { Completed: 'COMPLETED', 'In progress': 'IN PROGRESS', Next: 'NEXT' };

/** Progress step rows (Figma Progress Step). The rows have no destination. */
export function Steps({ steps, arrow = true }: { steps: Step[]; arrow?: boolean }) {
  return (
    <ol className="cw-steps">
      {steps.map((s) => (
        <li className={cx('cw-step', `cw-step--${s.status === 'In progress' ? 'doing' : s.status === 'Next' ? 'next' : 'done'}`)} key={s.title}>
          <span className="cw-step__mark" aria-hidden="true">
            {s.status === 'Completed' ? <CheckIcon size={14} sw={1.5} /> : s.status === 'In progress' ? <i /> : null}
          </span>
          <div className="cw-step__text">
            <p className="cw-step__title">{s.title}</p>
            <p className="cw-step__cap">{s.caption}</p>
          </div>
          <span className="cw-step__right">
            <span>{STEP_LABEL[s.status]}</span>
            {arrow ? <ArrowRight /> : null}
          </span>
        </li>
      ))}
    </ol>
  );
}

/** Milestone card (Figma Milestone Card). With a destination the whole card is a link. */
export function MilestoneCard({ m }: { m: Milestone }) {
  const body = (
    <>
      <div className="cw-mcard__top">
        <span className="cw-mcard__status">
          <Dot tone={m.status === 'In progress' ? 'accent' : 'gray'} />
          {m.status.toUpperCase()}
        </span>
        <span className="cw-mcard__due">{m.due}</span>
      </div>
      <div className="cw-mcard__copy">
        <h3 className="cw-mcard__title">{m.title}</h3>
        <p className="cw-mcard__text">{m.description}</p>
      </div>
      <div className="cw-mcard__foot">
        <div className="cw-mcard__who">
          <AvStack initials={m.people.map((p) => p.initials)} />
          <span>{m.people.map((p) => p.name).join(', ')}</span>
        </div>
        <span className="cw-mcard__go">
          View milestone
          <ArrowRight />
        </span>
      </div>
    </>
  );
  return m.href ? (
    <Link href={m.href} className="cw-mcard">
      {body}
    </Link>
  ) : (
    <div className="cw-mcard">{body}</div>
  );
}

/** Number as a word for the short counts in the copy ("Three pieces of work"). */
const WORDS = ['No', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten'];
export const countWord = (n: number) => WORDS[n] ?? String(n);
