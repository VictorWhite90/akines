import type { RouteDef } from '@/routes.types';
import Entry from './Entry';
import Matching from './Matching';
import Discovery, { DiscoveryEmpty } from './Discovery';
import WhyMatch, { WhyMatchScreen } from './WhyMatch';
import Profile, { ProfileScreen } from './Profile';
import IntroRequest, { IntroRequestScreen, RequestSent, RequestSentScreen } from './IntroRequest';
import Saved, { SavedEmpty, Requests, RequestsEmpty } from './Saved';
import { RequestStateScreen, RequestStatusScreen } from './RequestStatus';
import { PEOPLE, R, personRoutes, requestRoute, type PersonId } from './data';

/** 12.3 Explore collaborators and 12.4 Saved and requests. Every screen highlights the Collaborators tab. */
const nav = { page: 'collaborate', tab: 'Collaborators' } as const;

/** 12.28 to 12.30: the profile, Why this match, the introduction request and the Request sent screen of Kunle, Funmi and Chidi (route files must not be client components, so each screen is wrapped here). */
const journey = (id: Exclude<PersonId, 'amina'>): RouteDef[] => {
  const p = personRoutes(id);
  const name = PEOPLE[id].name;
  const ProfilePage = () => <ProfileScreen id={id} />;
  const WhyPage = () => <WhyMatchScreen id={id} />;
  const RequestPage = () => <IntroRequestScreen id={id} />;
  const SentPage = () => <RequestSentScreen id={id} />;
  return [
    { path: p.profile, title: name, shell: 'app', nav, component: ProfilePage },
    { path: p.why, title: 'Why this match', shell: 'app', nav, component: WhyPage },
    { path: p.request, title: 'Introduction request', shell: 'app', nav, component: RequestPage },
    { path: p.sent, title: 'Request sent', shell: 'app', nav, component: SentPage },
  ];
};

/**
 * 12.47 Introduction request: the page of a request. Pending is the page B10 and B12 link to (/introduction-requests/<id>); Chidi's Not now
 * is the one his B12 row links to. Amina's Accepted and Not now, Loading and Could not load have no trigger in the prototype, so they live
 * at .../state-<name>.
 */
const requestPage = (id: PersonId, stage: 'pending' | 'accepted' | 'notnow') => {
  const Page = () => <RequestStatusScreen id={id} stage={stage} />;
  return Page;
};
const requestState = (initial: 'loading' | 'error') => {
  const Page = () => <RequestStateScreen initial={initial} />;
  return Page;
};
const requestDef = (id: PersonId, stage: 'pending' | 'accepted' | 'notnow'): RouteDef => ({ path: requestRoute(id, stage), title: 'Introduction request', shell: 'app', nav, component: requestPage(id, stage) });

export const routes: RouteDef[] = [
  // 12.3 Explore collaborators
  { path: R.entry, title: 'Explore collaborators', shell: 'app', nav, component: Entry },
  { path: R.matching, title: 'Your collaboration intention', shell: 'app', nav, component: Matching },
  { path: R.discovery, title: 'Collaborators', shell: 'app', nav, component: Discovery },
  { path: R.discoveryEmpty, title: 'Collaborators', shell: 'app', nav, component: DiscoveryEmpty },
  { path: R.why, title: 'Why this match', shell: 'app', nav, component: WhyMatch },
  { path: R.profile, title: 'Amina Yusuf', shell: 'app', nav, component: Profile },
  { path: R.request, title: 'Introduction request', shell: 'app', nav, component: IntroRequest },
  { path: R.sent, title: 'Request sent', shell: 'app', nav, component: RequestSent },
  // 12.28 Kunle Afolabi, 12.29 Funmi Okoro, 12.30 Chidi Nwosu
  ...journey('kunle'),
  ...journey('funmi'),
  ...journey('chidi'),
  // 12.4 Saved and requests
  { path: R.saved, title: 'Saved collaborators', shell: 'app', nav, component: Saved },
  { path: R.savedEmpty, title: 'Saved collaborators', shell: 'app', nav, component: SavedEmpty },
  { path: R.requests, title: 'Introduction requests', shell: 'app', nav, component: Requests },
  { path: R.requestsEmpty, title: 'Introduction requests', shell: 'app', nav, component: RequestsEmpty },
  // 12.47 Introduction request
  requestDef('amina', 'pending'),
  requestDef('amina', 'accepted'),
  requestDef('amina', 'notnow'),
  requestDef('kunle', 'pending'),
  requestDef('funmi', 'pending'),
  requestDef('chidi', 'pending'),
  requestDef('chidi', 'notnow'),
  { path: `${R.requests}/amina/state-loading`, title: 'Introduction request', shell: 'app', nav, component: requestState('loading') },
  { path: `${R.requests}/amina/state-error`, title: 'Introduction request', shell: 'app', nav, component: requestState('error') },
];
