'use client';

/**
 * Shared frame of the four Discover sections: the <section> with its ids, the reused community section header, and the
 * `discover_section_view` tracking. The UI agents keep using DxSection and change what goes inside it.
 */
import { useRef, type MouseEvent, type ReactNode } from 'react';
import { SectionHeader } from '@/features/community/feed/parts';
import { cx } from '@/features/community/ui';
import { useSectionView } from './analytics';
import { HEADS, SECTION_DOM, type SectionId } from './data';

/**
 * `onLinkClick` runs when the member presses the link in the header ("Explore all", "See all"): this is where its analytics event goes.
 * The link goes to the page in data.ts (HEADS href: For you, all; All interests; All suggestions). The header itself is the community
 * SectionHeader, unchanged (title Alice 32, support line, underlined link with an arrow).
 */
export function DxSection({
  section,
  onLinkClick,
  className,
  children,
}: {
  section: SectionId;
  onLinkClick?: () => void;
  className?: string;
  children?: ReactNode;
}) {
  const ref = useRef<HTMLElement>(null);
  useSectionView(ref, section);
  const copy = HEADS[section];
  const dom = SECTION_DOM[section];
  // href '' would make ArrowLink render a <button>: a link with no destination is a plain control, not a dead anchor
  const head = { title: copy.title, support: copy.support, link: copy.link ? { label: copy.link, href: copy.href ?? '' } : undefined };
  const onClickCapture = (e: MouseEvent<HTMLElement>) => {
    if (onLinkClick && (e.target as HTMLElement).closest('.fd-head .fd-link')) onLinkClick();
  };
  return (
    <section ref={ref} className={cx('fd-section', 'dx-section', className)} id={dom.id} aria-labelledby={dom.titleId} data-dx-section={section} onClickCapture={onClickCapture}>
      <SectionHeader id={dom.titleId} head={head} />
      {children}
    </section>
  );
}
