'use client';

import { useEffect } from 'react';
import { openSignIn } from '@/features/auth/panel-store';
import { LandingPage } from './LandingPage';

/** Route "/sign-in": the landing page with the sign-in panel already open (used when a signed-out visitor opens a member page). */
export default function SignInLanding() {
  useEffect(() => {
    openSignIn();
  }, []);
  return <LandingPage />;
}
