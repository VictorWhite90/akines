'use client';

/**
 * The three Home state boards (Figma 10.1 "Home / Loading" 17111:9740, "Section error" 17111:10090, "Empty" 17111:10399).
 * Loading returns to Home after 1.5 s (AFTER_TIMEOUT), Try again goes to Loading.
 */
import { useEffect } from 'react';
import { Button } from '@/ui';
import { useNav } from '@/lib/nav';
import './community.css';
import { HEAD, InvitesBand, IntrosBand, UpcomingBand } from './bands';
import { P } from './data';
import { EmptyPanel, IAlert, IRefresh, SectionHeader } from './ui';

const ROUTE_LOADING = '/community/state-loading';

function SkCards({ n = 2 }: { n?: number }) {
  return (
    <div className="ch-skgrid" aria-hidden="true">
      {Array.from({ length: n }, (_, i) => (
        <div className="ch-sk ch-sk--card" key={i}>
          <span className="ch-sk" style={{ width: 120, height: 10 }} />
          <span className="ch-sk" style={{ width: 360, height: 30, maxWidth: '100%' }} />
          <span className="ch-sk" style={{ width: 480, height: 14, maxWidth: '100%' }} />
          <span className="ch-sk" style={{ width: 380, height: 14, maxWidth: '100%' }} />
          <span className="ch-sk ch-sk--pill" style={{ width: 160, height: 44 }} />
        </div>
      ))}
    </div>
  );
}

export function LoadingBoard() {
  const nav = useNav();
  useEffect(() => {
    const t = setTimeout(() => nav.replace(P.home), 1500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <div className="ch-page ch-state" aria-busy="true">
      <p className="ch-loadnote" role="status">
        <IRefresh />
        <span>Getting things ready</span>
      </p>
      <div className="ch-main">
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="lg" {...HEAD.cont} />
          </div>
          <SkCards />
        </section>
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="lg" {...HEAD.intros} />
          </div>
          <div className="ch-skgrid" aria-hidden="true">
            {[0, 1].map((i) => (
              <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                <span className="ch-sk ch-sk--photo" style={{ height: 520 }} />
                <div className="ch-sk--cap">
                  <span className="ch-sk" style={{ width: 180, height: 12 }} />
                  <span className="ch-sk" style={{ width: 240, height: 30, maxWidth: '100%' }} />
                  <span className="ch-sk" style={{ width: '100%', height: 14 }} />
                  <span className="ch-sk" style={{ width: 440, height: 14, maxWidth: '100%' }} />
                  <span className="ch-sk" style={{ width: 200, height: 14 }} />
                </div>
              </div>
            ))}
          </div>
        </section>
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="md" {...HEAD.ups} />
          </div>
          <div className="ch-skgrid ch-skgrid--ups" aria-hidden="true">
            {[0, 1, 2, 3].map((i) => (
              <div className="ch-skup" key={i}>
                <span className="ch-sk ch-sk--photo" style={{ width: '100%', aspectRatio: '1' }} />
                <div className="ch-sk--cap">
                  <span className="ch-sk" style={{ width: 90, height: 12 }} />
                  <span className="ch-sk" style={{ width: 240, height: 22, maxWidth: '100%' }} />
                  <span className="ch-sk" style={{ width: 160, height: 14 }} />
                </div>
              </div>
            ))}
          </div>
        </section>
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="md" {...HEAD.invs} />
          </div>
          <SkCards />
        </section>
      </div>
    </div>
  );
}

export function ErrorBoard() {
  const nav = useNav();
  return (
    <div className="ch-page ch-state">
      <div className="ch-main">
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="lg" {...HEAD.cont} />
          </div>
          <div className="ch-pad">
            <div className="ch-error" role="alert">
              <div className="ch-error__head">
                <IAlert />
                <h3 className="ch-error__title">We could not load this section.</h3>
              </div>
              <p className="ch-error__text">Your conversations and projects are safe. Check your connection and try again. The rest of your page is still here.</p>
              <div>
                <Button variant="secondary" onClick={() => nav.push(ROUTE_LOADING)}>
                  Try again
                </Button>
              </div>
            </div>
          </div>
        </section>
        <IntrosBand />
        <UpcomingBand />
        <InvitesBand />
      </div>
    </div>
  );
}

export function EmptyBoard() {
  return (
    <div className="ch-page ch-state">
      <div className="ch-main">
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="lg" {...HEAD.cont} />
          </div>
          <EmptyPanel variant="panel" title="Nothing is waiting for you." text="Conversations and projects you start will appear here, so you can pick them up when you are ready.">
            <Button variant="secondary" href={P.messages}>
              Start a conversation
            </Button>
          </EmptyPanel>
        </section>
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="lg" {...HEAD.intros} />
          </div>
          <EmptyPanel variant="panel" title="No introductions right now." text="New people appear here when there is a real reason to meet. You can change what Akines uses to suggest them.">
            <Button variant="secondary" href={P.settings}>
              Review recommendation preferences
            </Button>
          </EmptyPanel>
        </section>
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="md" {...HEAD.ups} />
          </div>
          <EmptyPanel variant="panel" title="No upcoming moments yet." text="When you accept an invitation or plan a call, it appears here.">
            <Button variant="secondary" href={P.connect}>
              Find someone to connect with
            </Button>
          </EmptyPanel>
        </section>
        <section className="ch-band">
          <div className="ch-pad">
            <SectionHeader size="md" {...HEAD.invs} />
          </div>
          <EmptyPanel variant="panel" title="No invitations right now." text="People and communities will invite you here when they are making room for you.">
            <Button variant="secondary" href={P.connect}>
              Find someone to connect with
            </Button>
          </EmptyPanel>
        </section>
      </div>
    </div>
  );
}
