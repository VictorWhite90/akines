// READ-ONLY Figma node dump for use_figma (paste the whole file as `code`, edit the three constants).
// Prints a compact indented tree with everything needed to rebuild a node in CSS:
// size, position (relative to parent), auto layout, padding, gap, alignment, sizing, fills (with the variable
// name when bound), strokes, radius, effects, opacity, text (characters, font, size, line height, letter spacing,
// colour, alignment, case) and component instance info (main component name + variant properties).
// Hidden layers are listed with "HIDDEN" so you know they exist but must not be rendered.
const NODE_ID = '0:0'; // e.g. '17064:5064'
const DEPTH = 6; // how many levels below the node
const MAX_NODES = 400; // stop after this many lines (raise it, or dump a child instead)

figma.skipInvisibleInstanceChildren = false;
const varCache = {};
async function varName(id) {
  if (!id) return null;
  if (varCache[id] !== undefined) return varCache[id];
  const v = await figma.variables.getVariableByIdAsync(id);
  varCache[id] = v ? v.name : id;
  return varCache[id];
}
const hex = (c, a) => {
  const h = (n) => Math.round(n * 255).toString(16).padStart(2, '0');
  return '#' + h(c.r) + h(c.g) + h(c.b) + (a !== undefined && a < 1 ? ' @' + a.toFixed(2) : '');
};
async function paintStr(p) {
  if (p.visible === false) return null;
  if (p.type === 'SOLID') {
    const bv = p.boundVariables && p.boundVariables.color;
    const o = p.opacity === undefined ? 1 : p.opacity;
    return hex(p.color, o) + (bv ? ' (' + (await varName(bv.id)) + ')' : '');
  }
  if (p.type === 'IMAGE') return 'IMG(' + p.scaleMode + (p.filters ? ' filters=' + JSON.stringify(p.filters) : '') + ')';
  if (p.type.startsWith('GRADIENT')) {
    const stops = p.gradientStops.map((s) => hex(s.color, s.color.a) + '@' + s.position.toFixed(2)).join(' ');
    return p.type + '[' + stops + '] ' + JSON.stringify(p.gradientTransform);
  }
  return p.type;
}
const r1 = (n) => (Math.round(n * 10) / 10).toString();
let count = 0;
const lines = [];
async function dump(node, depth, indent) {
  if (count++ >= MAX_NODES) return;
  let s = indent + node.type + ' "' + node.name + '" ' + node.id;
  if ('width' in node) s += ' ' + r1(node.width) + 'x' + r1(node.height);
  if (node.parent && 'x' in node && node.parent.type !== 'PAGE') s += ' @' + r1(node.x) + ',' + r1(node.y);
  if (node.visible === false) s += ' HIDDEN';
  if (node.opacity !== undefined && node.opacity !== 1) s += ' op=' + r1(node.opacity);
  if (node.rotation) s += ' rot=' + r1(node.rotation);
  if (node.layoutPositioning === 'ABSOLUTE') s += ' ABS';
  if ('layoutMode' in node && node.layoutMode !== 'NONE') {
    s += ' | auto:' + (node.layoutMode === 'HORIZONTAL' ? 'ROW' : 'COL');
    s += ' gap=' + node.itemSpacing;
    s += ' pad=' + [node.paddingTop, node.paddingRight, node.paddingBottom, node.paddingLeft].join('/');
    s += ' main=' + node.primaryAxisAlignItems + ' cross=' + node.counterAxisAlignItems;
    if (node.layoutWrap === 'WRAP') s += ' WRAP rowGap=' + node.counterAxisSpacing;
  }
  if ('layoutSizingHorizontal' in node) s += ' | sizeH=' + node.layoutSizingHorizontal + ' sizeV=' + node.layoutSizingVertical;
  if ('layoutGrow' in node && node.layoutGrow) s += ' grow=' + node.layoutGrow;
  if ('constraints' in node && node.layoutPositioning === 'ABSOLUTE') s += ' cons=' + node.constraints.horizontal + '/' + node.constraints.vertical;
  if ('minWidth' in node && (node.minWidth || node.maxWidth)) s += ' minW=' + node.minWidth + ' maxW=' + node.maxWidth;
  if ('clipsContent' in node && node.clipsContent) s += ' clip';
  if ('fills' in node && node.fills !== figma.mixed && node.fills.length) {
    const f = (await Promise.all(node.fills.map(paintStr))).filter(Boolean);
    if (f.length) s += ' | fill=' + f.join(' + ');
  }
  if ('strokes' in node && node.strokes.length) {
    const st = (await Promise.all(node.strokes.map(paintStr))).filter(Boolean);
    if (st.length) {
      const w = node.strokeWeight === figma.mixed ? [node.strokeTopWeight, node.strokeRightWeight, node.strokeBottomWeight, node.strokeLeftWeight].join('/') : node.strokeWeight;
      s += ' | stroke=' + w + ' ' + st.join('+') + ' ' + node.strokeAlign + (node.dashPattern && node.dashPattern.length ? ' dash=' + node.dashPattern : '');
    }
  }
  if ('cornerRadius' in node) {
    if (node.cornerRadius === figma.mixed) s += ' r=' + [node.topLeftRadius, node.topRightRadius, node.bottomRightRadius, node.bottomLeftRadius].join('/');
    else if (node.cornerRadius) s += ' r=' + node.cornerRadius;
  }
  if ('effects' in node && node.effects.length) {
    s += ' | fx=' + node.effects.filter((e) => e.visible !== false).map((e) => {
      if (e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW') return e.type + '(' + e.offset.x + ',' + e.offset.y + ' blur' + e.radius + ' spread' + (e.spread || 0) + ' ' + hex(e.color, e.color.a) + ')';
      return e.type + '(' + e.radius + ')';
    }).join(';');
  }
  if (node.type === 'TEXT') {
    const fn = node.fontName === figma.mixed ? 'mixed' : node.fontName.family + '/' + node.fontName.style;
    const fs = node.fontSize === figma.mixed ? 'mixed' : node.fontSize;
    const lh = node.lineHeight === figma.mixed ? 'mixed' : node.lineHeight.unit === 'AUTO' ? 'auto' : r1(node.lineHeight.value) + (node.lineHeight.unit === 'PERCENT' ? '%' : 'px');
    const ls = node.letterSpacing === figma.mixed ? 'mixed' : node.letterSpacing.value ? r1(node.letterSpacing.value) + (node.letterSpacing.unit === 'PERCENT' ? '%' : 'px') : '0';
    s += ' | TEXT ' + JSON.stringify(node.characters) + ' font=' + fn + ' ' + fs + '/' + lh + ' ls=' + ls + ' align=' + node.textAlignHorizontal + ' case=' + node.textCase + ' deco=' + node.textDecoration + ' autoResize=' + node.textAutoResize + (node.maxLines ? ' maxLines=' + node.maxLines : '');
    const tf = node.fills !== figma.mixed && node.fills.length ? await paintStr(node.fills[0]) : null;
    if (tf) s += ' color=' + tf;
  }
  if (node.type === 'INSTANCE') {
    const mc = await node.getMainComponentAsync();
    s += ' | MAIN=' + (mc ? (mc.parent && mc.parent.type === 'COMPONENT_SET' ? mc.parent.name + ' / ' : '') + mc.name + ' ' + mc.id : '?');
    const props = node.componentProperties;
    const ps = Object.keys(props).map((k) => k.split('#')[0] + '=' + props[k].value).join(', ');
    if (ps) s += ' props{' + ps + '}';
  }
  if (node.type === 'COMPONENT') s += ' | COMPONENT';
  if (node.type === 'COMPONENT_SET') s += ' | COMPONENT_SET variants=' + node.children.length;
  if ('reactions' in node && node.reactions.length) s += ' | reactions=' + node.reactions.length;
  lines.push(s);
  if (depth > 0 && 'children' in node) {
    for (const c of node.children) await dump(c, depth - 1, indent + '  ');
  }
}
const root = await figma.getNodeByIdAsync(NODE_ID);
await dump(root, DEPTH, '');
return lines.join('\n') + (count > MAX_NODES ? '\n... truncated at ' + MAX_NODES + ' nodes' : '');
