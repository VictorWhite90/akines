'use client';

import '../workspace/workspace.css';
import './launch.css';
import { useEffect, useState } from 'react';
import { useNav } from '@/lib/nav';
import { Button, EmptyState, toast } from '@/ui';
import { ActionButton, BackLink, CardLink, Facts, Over, PageHead, WorkspaceFrame } from '../workspace/parts';
import { NOT_READY, type LaunchPage } from './data';
import { ConfirmAttributionModal, ShareProjectModal } from './modals';
import { CreditRow, LaunchContext, MaterialRow, Progress, ReadinessRow, RowList, useLaunch } from './parts';

/**
 * 12.24 Launch: Not ready, Readiness, Materials, Attribution, Ready to share and Outcome, with Modal:Confirm attribution,
 * Toast:Attribution confirmed, Modal:Share project and Toast:Project shared. Each page is its own route (see routes.tsx).
 * The "state-" routes are the Figma frames that no control reaches: Not ready, and the overlay frames that open with the modal or the
 * toast already showing.
 * Controls with no destination in the design are shown and do nothing: the material rows, the credit rows, Copy link and the readiness
 * rows other than Outstanding work and Team acknowledgement. Outstanding work and Review final work go to Tasks.
 * Create AI never publishes: nothing on these pages publishes except the explicit Share project, which the design leaves enabled
 * whether or not the approval box is ticked.
 * Career Guidance for Everyone and Adire Stories render these same pages: `useLaunch()` (parts.tsx) gives each page the copy and the paths
 * of its own project. Adire Stories has Readiness, Materials, Attribution, Ready to share and Outcome (see art-routes.tsx). Not ready
 * and the overlay frames are Career "state-" routes. The modals and toasts read the same copy, so they follow the project too.
 */

const TOAST_MS = 2500;
/** The toast of a "state-" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

type View = 'notReady' | 'readiness' | 'materials' | 'attribution' | 'ready' | 'outcome';
type Overlay = { confirm?: boolean; share?: boolean; toast?: 'confirmed' | 'shared' };

const CONTEXT: Record<View, LaunchPage> = {
  notReady: 'notReady',
  readiness: 'readiness',
  materials: 'materials',
  attribution: 'attribution',
  ready: 'sharing',
  outcome: 'outcome',
};

/* ------------------------------------------------------------------ pages */

/** Not ready: the header, the empty state and the link to Readiness (Career only, it is a "state-" route). */
function NotReadyPage() {
  const { lp } = useLaunch();
  return (
    <div className="ln-page ln-page--notready">
      <PageHead label={NOT_READY.label} title={NOT_READY.title} lead={NOT_READY.lead} />
      <section className="ln-notready" data-m="up" aria-label="Launch is not ready">
        <EmptyState className="cw-empty" title={NOT_READY.emptyTitle} text={NOT_READY.emptyText} />
        <CardLink href={lp.readiness} arrow>
          {NOT_READY.link}
        </CardLink>
      </section>
    </div>
  );
}

/** Readiness: facts, the two actions, the project outcome and the checklist. */
function ReadinessPage() {
  const { readiness, readinessRows, lp, tasksPath } = useLaunch();
  return (
    <div className="ln-page ln-page--readiness">
      <PageHead label={readiness.label} title={readiness.title} lead={readiness.lead}>
        <Facts compact items={readiness.facts} />
        <div className="ln-actions ln-actions--head">
          <ActionButton href={lp.materials}>{readiness.prepare}</ActionButton>
          <ActionButton href={tasksPath} variant="secondary">
            {readiness.review}
          </ActionButton>
        </div>
      </PageHead>

      <section className="ln-sec ln-sec--outcome" data-m="up">
        <Over>{readiness.outcomeLabel}</Over>
        <h2 className="ln-out__title">{readiness.outcomeTitle}</h2>
        <p className="ln-out__note">{readiness.outcomeNote}</p>
      </section>

      <section className="ln-sec" data-m="up">
        <Over>{readiness.checklistLabel}</Over>
        <Progress label={readiness.progressLabel} value={readiness.progressValue} met={readiness.met} total={readiness.total} />
        <RowList label="Readiness checklist">
          {readinessRows.map((r) => (
            <li key={r.id}>
              <ReadinessRow row={r} />
            </li>
          ))}
        </RowList>
      </section>
    </div>
  );
}

/** Materials: the six pieces and the way on to attribution. */
function MaterialsPage() {
  const { materials, materialRows, lp } = useLaunch();
  return (
    <div className="ln-page ln-page--materials">
      <PageHead back={<BackLink href={lp.readiness}>{materials.back}</BackLink>} label={materials.label} title={materials.title} lead={materials.lead} />
      <section className="ln-sec" data-m="up">
        <Over>{materials.listLabel}</Over>
        <RowList label="Materials">
          {materialRows.map((r) => (
            <li key={r.id}>
              <MaterialRow row={r} />
            </li>
          ))}
        </RowList>
      </section>
      <div className="ln-actions" data-m="up">
        <Button href={lp.attribution} arrow="up-right">
          {materials.next}
        </Button>
      </div>
    </div>
  );
}

/** Attribution: the four credits. Confirm attribution opens the modal, Continue to sharing goes to Ready to share. */
function AttributionPage({ onConfirm }: { onConfirm: () => void }) {
  const { attribution, credits, lp } = useLaunch();
  return (
    <div className="ln-page ln-page--attribution">
      <PageHead back={<BackLink href={lp.materials}>{attribution.back}</BackLink>} label={attribution.label} title={attribution.title} lead={attribution.lead} />
      <section className="ln-sec" data-m="up">
        <Over>{attribution.listLabel}</Over>
        <RowList label="Contributors">
          {credits.map((c) => (
            <li key={c.name}>
              <CreditRow credit={c} />
            </li>
          ))}
        </RowList>
        <p className="ln-text">{attribution.note}</p>
      </section>
      <div className="ln-actions" data-m="up">
        <Button onClick={onConfirm}>{attribution.confirm}</Button>
        <CardLink href={lp.ready} arrow>
          {attribution.next}
        </CardLink>
      </div>
    </div>
  );
}

/** Ready to share: what will be shared, who will see it and the Share project button (enabled, as drawn). */
function ReadyPage({ onShare }: { onShare: () => void }) {
  const { ready, sharedRows, lp } = useLaunch();
  return (
    <div className="ln-page">
      <PageHead back={<BackLink href={lp.attribution}>{ready.back}</BackLink>} label={ready.label} title={ready.title} lead={ready.lead} />
      <section className="ln-sec" data-m="up">
        <Over>{ready.sharedLabel}</Over>
        <RowList label="What will be shared">
          {sharedRows.map((r) => (
            <li key={r.id}>
              <MaterialRow row={r} />
            </li>
          ))}
        </RowList>
      </section>
      <section className="ln-sec" data-m="up">
        <Over>{ready.seeLabel}</Over>
        <dl className="ln-see">
          {ready.see.map((s) => (
            <div className="ln-see__item" key={s.label}>
              <dt>{s.label}</dt>
              <dd className="ln-see__value">{s.value}</dd>
              <dd className="ln-see__detail">{s.detail}</dd>
            </div>
          ))}
        </dl>
      </section>
      <p className="ln-text" data-m="up">
        {ready.note}
      </p>
      <div className="ln-actions" data-m="up">
        <Button onClick={onShare}>{ready.share}</Button>
      </div>
    </div>
  );
}

/** Outcome: the shared project, its link and its credits. Copy link has no reaction in the design. */
function OutcomePage() {
  const { outcome, credits, lp } = useLaunch();
  return (
    <div className="ln-page">
      <PageHead back={<BackLink href={lp.readiness}>{outcome.back}</BackLink>} label={outcome.label} title={outcome.title} lead={outcome.lead} />
      <section className="ln-sec" data-m="up">
        <Over>{outcome.aboutLabel}</Over>
        <p className="ln-about">{outcome.about}</p>
      </section>
      <section className="ln-sec" data-m="up">
        <Over>{outcome.linkLabel}</Over>
        <div className="ln-link">
          <span className="ln-link__url">{outcome.link}</span>
          <Button variant="secondary">{outcome.copy}</Button>
        </div>
        <p className="ln-text">{outcome.sharedNote}</p>
      </section>
      <section className="ln-sec" data-m="up">
        <Over>{outcome.creditsLabel}</Over>
        <RowList label="Credits">
          {credits.map((c) => (
            <li key={c.name}>
              <CreditRow credit={c} />
            </li>
          ))}
        </RowList>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ screen */

/**
 * One screen component drives every frame. Confirm attribution in its modal closes it and shows "Attribution confirmed" on the
 * Attribution page. Share project in its modal goes to Outcome and shows "Project shared" there; the toasts have no Undo.
 */
function Screen({ view, overlay = {} }: { view: View; overlay?: Overlay }) {
  const nav = useNav();
  const { toastConfirmed, toastShared, lp } = useLaunch();
  const [confirm, setConfirm] = useState(Boolean(overlay.confirm));
  const [share, setShare] = useState(Boolean(overlay.share));

  // the "state-" frames with a toast: the page with the toast already showing
  useEffect(() => {
    if (overlay.toast === 'confirmed') toast.show({ message: toastConfirmed, duration: STATE_TOAST_MS });
    if (overlay.toast === 'shared') toast.show({ message: toastShared, duration: STATE_TOAST_MS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overlay.toast]);

  const confirmed = () => {
    setConfirm(false);
    toast.show({ message: toastConfirmed, duration: TOAST_MS });
  };
  const shared = () => {
    setShare(false);
    nav.push(lp.outcome);
    toast.show({ message: toastShared, duration: TOAST_MS });
  };

  return (
    <WorkspaceFrame active="launch" context={<LaunchContext page={CONTEXT[view]} />}>
      {view === 'notReady' ? <NotReadyPage /> : null}
      {view === 'readiness' ? <ReadinessPage /> : null}
      {view === 'materials' ? <MaterialsPage /> : null}
      {view === 'attribution' ? <AttributionPage onConfirm={() => setConfirm(true)} /> : null}
      {view === 'ready' ? <ReadyPage onShare={() => setShare(true)} /> : null}
      {view === 'outcome' ? <OutcomePage /> : null}
      {view === 'attribution' ? <ConfirmAttributionModal open={confirm} onClose={() => setConfirm(false)} onConfirm={confirmed} /> : null}
      {view === 'ready' ? <ShareProjectModal open={share} onClose={() => setShare(false)} onShare={shared} /> : null}
    </WorkspaceFrame>
  );
}

export const LaunchNotReady = () => <Screen view="notReady" />;
export const LaunchReadiness = () => <Screen view="readiness" />;
export const LaunchMaterials = () => <Screen view="materials" />;
export const LaunchAttribution = () => <Screen view="attribution" />;
export const LaunchReady = () => <Screen view="ready" />;
export const LaunchOutcome = () => <Screen view="outcome" />;
/** Frame "Modal:Confirm attribution": Attribution with the modal open. */
export const LaunchConfirmModal = () => <Screen view="attribution" overlay={{ confirm: true }} />;
/** Frame "Toast:Attribution confirmed": Attribution with the toast showing. */
export const LaunchConfirmed = () => <Screen view="attribution" overlay={{ toast: 'confirmed' }} />;
/** Frame "Modal:Share project": Ready to share with the modal open. */
export const LaunchShareModal = () => <Screen view="ready" overlay={{ share: true }} />;
/** Frame "Toast:Project shared": Outcome with the toast showing. */
export const LaunchShared = () => <Screen view="outcome" overlay={{ toast: 'shared' }} />;
