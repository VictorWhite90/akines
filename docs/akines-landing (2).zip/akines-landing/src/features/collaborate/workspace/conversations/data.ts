/**
 * Sample data of 12.13 Conversations (Figma frames Conversations 17389:27624, Decision discussion 17390:27542, Empty 17390:27951,
 * Modal:Start conversation 17390:28256, Toast:Conversation started 17390:28304, Dropdown:Meet 17808:109947, Panel:Conversation info
 * 17808:109955, Modal:Schedule meeting 17808:110053, Toast:Meeting scheduled 17808:110125). Copy is taken from the frames.
 */
import { PATHS } from '../data';

/** Paths of the Conversations page and of its state frames (the "state-" routes have no control that reaches them). */
export const CONV_PATHS = {
  list: PATHS.conversations,
  decision: PATHS.conversationsDecision,
  empty: PATHS.conversationsEmpty,
  start: PATHS.conversationsStart,
  started: PATHS.conversationsStarted,
  meetMenu: `${PATHS.conversations}/state-meet-menu`,
  info: `${PATHS.conversations}/state-conversation-info`,
  schedule: `${PATHS.conversations}/state-schedule-meeting`,
  scheduled: `${PATHS.conversations}/state-meeting-scheduled`,
} as const;

export type ConversationId = 'onboarding' | 'team' | 'decision' | 'milestone' | 'questions';

/** A row of the list (Figma Conversation Row): title, time and the unread dot. Nothing else is shown. */
export type ConversationItem = {
  id: ConversationId;
  name: string;
  time: string;
  /** Unread rows have a semibold title, a dark time and the amber dot. The open conversation is always read. */
  unread?: boolean;
  /** Only two conversations have a thread view in the design (the others react to hover and press but go nowhere). */
  href?: string;
};

export const CONVERSATIONS: ConversationItem[] = [
  { id: 'onboarding', name: 'Onboarding flow', time: '10:48', href: PATHS.conversations },
  { id: 'team', name: 'Career Guidance team', time: '09:15' },
  { id: 'decision', name: 'Choose the onboarding approach', time: 'Yesterday', unread: true, href: PATHS.conversationsDecision },
  { id: 'milestone', name: 'First Student Experience', time: 'Yesterday', unread: true },
  { id: 'questions', name: 'Questions students ask about careers', time: 'Mon' },
];

/** Types of the Start conversation modal (the design has Work chosen). */
export const START_TYPES = ['Project', 'Milestone', 'Work', 'Decision'] as const;
export type StartType = (typeof START_TYPES)[number];

export type Message = {
  id: string;
  /** Initials of the sender: the portrait is the one of the team member with them. */
  initials: string;
  name: string;
  time: string;
  text: string;
  /** Your own message: on the right, amber outline, "time You" in the head, no portrait. */
  own?: boolean;
  /** File embed under the message. */
  file?: { name: string; meta: string };
  /** Decision embed under the message. */
  decision?: { title: string; status: string };
};

export type Thread = {
  id: 'onboarding' | 'decision';
  title: string;
  /** "Work discussion": the line under the title in the Conversation info panel. */
  kind: string;
  /** The line under the title in the thread header. */
  line: string;
  /** The date label above the first message. */
  date: string;
  messages: Message[];
  /** The Join card closes the thread (the Decision discussion frame has none). */
  join?: boolean;
};

const DECISION_CARD = { title: 'Choose the onboarding approach', status: 'Awaiting acknowledgement' };

export const THREADS: Record<Thread['id'], Thread> = {
  onboarding: {
    id: 'onboarding',
    title: 'Onboarding flow',
    kind: 'Work discussion',
    line: '4 people, linked to the student onboarding draft',
    date: 'Today',
    join: true,
    messages: [
      { id: 'm1', initials: 'NE', name: 'Ngozi Eze', time: '10:30', text: 'These are the interview notes behind the questions.', file: { name: 'Career interview notes.docx', meta: 'Word, 180 KB' } },
      { id: 'm2', initials: 'AO', name: 'Adaeze Okoye', time: '10:48', text: 'We should settle the approach before building more screens.', decision: DECISION_CARD },
      { id: 'm3', initials: 'KA', name: 'You', time: '11:02', text: 'Agreed. I will review the decision today.', own: true },
      { id: 'm4', initials: 'TA', name: 'Tobi Adeyemi', time: '11:20', text: 'Let us talk it through on Thursday.' },
    ],
  },
  decision: {
    id: 'decision',
    title: 'Choose the onboarding approach',
    kind: 'Decision discussion',
    line: '4 people, decision awaiting acknowledgement',
    date: 'Yesterday',
    messages: [
      { id: 'd1', initials: 'TA', name: 'Tobi Adeyemi', time: '15:10', text: 'The open option may feel overwhelming on a first visit.' },
      { id: 'd2', initials: 'NE', name: 'Ngozi Eze', time: '16:30', text: 'Agreed. Most students we interviewed wanted a clear first step.' },
      { id: 'd3', initials: 'AO', name: 'Adaeze Okoye', time: '17:40', text: 'I prefer the guided option. Can we decide before Friday?', decision: DECISION_CARD },
    ],
  },
};

/** The linked work of the Conversation info panel (the design shows the same panel on both threads). */
export type LinkedWork = { title: string; status: string };

export const LINKED_WORK: LinkedWork = { title: 'Review the student onboarding draft', status: 'Needs your review' };

export const SHARED_FILES = [
  { name: 'Student onboarding draft.pdf', meta: 'PDF, 2.4 MB' },
  { name: 'Career interview notes.docx', meta: 'Word, 180 KB' },
];

/** Empty frame copy. */
export const EMPTY = {
  title: 'Every collaboration starts with a conversation.',
  text: 'Start a discussion with your team.',
};

/** Toast: Conversation started. */
export const STARTED_TOAST = 'Conversation started. Your team has been notified.';

/** Toast: Meeting scheduled (the text of the schedule modal's own toast, shown by the state frame). */
export const SCHEDULED_TOAST = 'Meeting scheduled for Thursday, 4:00 PM.';

/** Placeholder of the Conversation name field of the Start conversation modal. */
export const START_PLACEHOLDER = 'For example, Onboarding flow';

/**
 * Everything on the Conversations page that names the project, the people or the work. Career Guidance for Everyone reads the
 * constants above through CAREER_CONVERSATIONS, Adire Stories reads ART_CONVERSATIONS (art-data.ts), same shape and order.
 */
export type ConversationsData = {
  conversations: ConversationItem[];
  threads: Record<Thread['id'], Thread>;
  linkedWork: LinkedWork;
  sharedFiles: typeof SHARED_FILES;
  empty: typeof EMPTY;
  startedToast: string;
  startPlaceholder: string;
};

export const CAREER_CONVERSATIONS: ConversationsData = {
  conversations: CONVERSATIONS,
  threads: THREADS,
  linkedWork: LINKED_WORK,
  sharedFiles: SHARED_FILES,
  empty: EMPTY,
  startedToast: STARTED_TOAST,
  startPlaceholder: START_PLACEHOLDER,
};
