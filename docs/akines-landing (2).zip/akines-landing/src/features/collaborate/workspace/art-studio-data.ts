// Studio page, removed 5 Nov 2026 (Tasks, Conversations, Files and Workspace cover it). Commented out, not deleted. Figma: parked on the TRASH page.
// To bring it back: remove the leading "// " of every commented line below.
export {};

// import { CANVAS, CANVAS_COLUMNS, MILESTONES, PATHS, STUDIO_WORK, type CanvasItem, type Milestone, type StudioWork } from './data';
// import { ADD_TO_CANVAS } from '../project-header/data';
// import type { ProjectKey } from './project';
//
// /**
//  * Studio data of the two projects with project pages: Career Guidance for Everyone ("career", the data of data.ts) and Adire Stories
//  * ("adire", the Digital Art project). Both have the same shape, the same keys, the same array lengths and the same order, so the
//  * same Studio and Shared canvas components render either. Only the visible text differs; ids stay the same because the code switches on them.
//  *
//  * What is not in the Adire set: the work detail pages, the Milestone detail and the Empty state are not mirrored, so no Adire row or
//  * card has an `href` that leads to them (the Career set links to them).
//  */
//
// /** The copy of the Add to canvas modal and its toast (project-header/data.ts holds the Career copy; it is shared and not edited). */
// export type AddToCanvasCopy = typeof ADD_TO_CANVAS;
//
// export type StudioData = {
//   /** The cards of the shared canvas, in the order of the design. */
//   canvas: CanvasItem[];
//   /** The two columns of the shared canvas, as ids of `canvas`. */
//   columns: string[][];
//   /** "Current work" rows of the Studio. */
//   work: StudioWork[];
//   /** The milestone the Studio work is connected to. */
//   milestone: Milestone;
//   /** The "Needs your review" item of the context panel. */
//   review: { title: string; status: string; href?: string };
//   /** The title the Create new work modal starts with. */
//   createTitle: string;
//   addToCanvas: AddToCanvasCopy;
// };
//
// /** The pages of the Studio under a project root (the Career root gives PATHS.studio and PATHS.canvas). */
// export const studioPaths = (root: string) => ({ studio: `${root}/studio`, canvas: `${root}/studio/canvas` });
//
// /** Career Guidance for Everyone, as it was before Adire Stories existed. */
// export const CAREER_STUDIO: StudioData = {
//   canvas: CANVAS,
//   columns: CANVAS_COLUMNS,
//   work: STUDIO_WORK,
//   milestone: MILESTONES[0],
//   review: { title: 'Review the student onboarding draft', status: 'Adaeze Okoye, 2 hours ago', href: PATHS.work },
//   createTitle: 'Questions for the second school visit',
//   addToCanvas: ADD_TO_CANVAS,
// };
//
// /** Adire Stories. Amara Obi stands in for Adaeze Okoye, Ayo Bello for Tobi Adeyemi and Yusuf Danjuma for Ngozi Eze. */
// export const ART_CANVAS: CanvasItem[] = [
//   { id: 'classroom', type: 'Image', title: 'Workshop visit, Abeokuta', body: 'Photo from the first workshop visit. Cloth dries on the line after the indigo dip.', initials: 'YD', name: 'Yusuf Danjuma', time: '3 days ago', comments: '2 comments' },
//   { id: 'questions', type: 'Note', title: 'Questions to ask the dyers about cloth', body: 'Collected from the first workshop visits. Added for the headwrap portrait.', initials: 'AB', name: 'Ayo Bello', time: 'Yesterday', comments: '3 comments' },
//   { id: 'subjects', type: 'Reference', title: 'How cassava paste resist works', body: 'A short article on the resist method behind adire eleko. Useful for the pattern notes.', initials: 'AO', name: 'Amara Obi', time: '4 days ago', comments: '1 comment', link: true },
//   { id: 'unknown', type: 'Note', title: 'What we still do not know', body: 'Which patterns may we show by name? Ask each dyer before the print proof.', initials: 'KA', name: 'Kemi Adeyemi', time: 'Last week', comments: '4 comments' },
//   { id: 'onboarding', type: 'Draft', title: 'Headwrap portrait draft', body: 'Three layers from linework to highlights. The colour layer is ready for review.', initials: 'AO', name: 'Amara Obi', time: '2 hours ago', comments: '5 comments', needsReview: true },
//   { id: 'interviews', type: 'Reference', title: 'Dye pot notes, Ibadan', body: 'Notes from the second round of visits with pattern makers.', initials: 'YD', name: 'Yusuf Danjuma', time: '5 days ago', comments: 'No comments', link: true },
// ];
//
// export const ART_STUDIO_WORK: StudioWork[] = [
//   { id: 'onboarding', title: 'Review the headwrap colour layer', kind: 'Draft', status: 'Needs your review', member: 'Amara Obi', updated: 'Updated 2 hours ago', action: 'Review work' },
//   { id: 'journey', title: 'Map the pattern repeats', kind: 'Research note', status: 'In progress', member: 'Ayo Bello', updated: 'Updated yesterday', action: 'Open work' },
//   { id: 'questions', title: 'Questions to ask the dyers about cloth', kind: 'Note', status: 'In progress', member: 'Yusuf Danjuma', updated: 'Updated 3 days ago', action: 'Open work' },
// ];
//
// /** Milestone 3 of Adire Stories, the one the Studio work belongs to. It has no `href`: the Milestone detail is not mirrored. */
// export const ART_STUDIO_MILESTONE: Milestone = {
//   status: 'In progress',
//   due: 'Due 26 November',
//   title: 'Headwrap Portrait',
//   description: 'Finish the first full plate, from linework to colour and highlights.',
//   people: [
//     { initials: 'AO', name: 'Amara Obi' },
//     { initials: 'AB', name: 'Ayo Bello' },
//   ],
// };
//
// /** The Add to canvas modal of Adire Stories (the Career copy with the cloth in the description). */
// export const ART_ADD_TO_CANVAS: AddToCanvasCopy = {
//   ...ADD_TO_CANVAS,
//   description: 'Share a note, a reference or an image of cloth with everyone on the team.',
// };
//
// export const ART_STUDIO: StudioData = {
//   canvas: ART_CANVAS,
//   columns: CANVAS_COLUMNS,
//   work: ART_STUDIO_WORK,
//   milestone: ART_STUDIO_MILESTONE,
//   review: { title: 'Review the headwrap colour layer', status: 'Amara Obi, 2 hours ago' },
//   createTitle: 'Questions for the second visit to Abeokuta',
//   addToCanvas: ART_ADD_TO_CANVAS,
// };
//
// export const STUDIO_DATA: Record<ProjectKey, StudioData> = { career: CAREER_STUDIO, adire: ART_STUDIO };
