/** Copy of the Research Workspace frames (Figma 12.15). */
export const PROJECT_NAME = 'Career Guidance for Everyone';
export const DOC_TITLE = 'Career guidance needs of secondary school students';

export const OUTLINE: { label: string; level: 1 | 2 }[] = [
  { label: 'Executive summary', level: 1 },
  { label: 'Background', level: 1 },
  { label: 'Methods', level: 1 },
  { label: 'Findings', level: 1 },
  { label: 'Access to guidance', level: 2 },
  { label: 'Mentors and timing', level: 2 },
  { label: 'Parent voice', level: 2 },
  { label: 'Recommendations', level: 1 },
  { label: 'References', level: 1 },
];

export const STYLE_ITEMS: { id: string; label: string; selected?: boolean }[] = [
  { id: 'normal', label: 'Normal text' },
  { id: 'h1', label: 'Heading 1' },
  { id: 'h2', label: 'Heading 2', selected: true },
  { id: 'h3', label: 'Heading 3' },
  { id: 'quote', label: 'Quote' },
];

export type ThreadState = 'open' | 'replying' | 'resolved';
export type Message = { who: 'ayo' | 'amara' | 'kemi'; name: string; time: string; text: string };
export type Thread = { id: string; quote: string; messages: Message[] };

export const THREADS: Thread[] = [
  {
    id: 'ayo',
    quote: 'Only 41% of students had met a career counsellor.',
    messages: [
      { who: 'ayo', name: 'Ayo Bello', time: '10:42', text: 'Can we cite the survey year here? Readers will ask.' },
      { who: 'kemi', name: 'Kemi Adeyemi', time: '10:51', text: 'Good catch. Adding the 2025 survey now.' },
    ],
  },
  {
    id: 'amara',
    quote: 'three states',
    messages: [{ who: 'amara', name: 'Amara Obi', time: '10:42', text: 'Name the states here so readers do not wait for the methods section.' }],
  },
];
