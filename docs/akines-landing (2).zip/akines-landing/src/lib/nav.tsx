'use client';

/**
 * Navigation abstraction. The same screens run in two places:
 *   1. the Next.js app (this file), and
 *   2. the single-file preview artifact, where src/lib/nav.hash.tsx replaces this module at bundle time
 *      (esbuild alias, see scripts/build-artifact.mjs). Both export the same names.
 *
 * Always use these instead of next/link or next/navigation inside screens:
 *   <Link href="/community">          internal path (starts with "/")
 *   <Link href="#how-it-works">        in-page anchor (plain <a>)
 *   <Link href="https://...">          external (plain <a>)
 *   const { push, replace, back } = useNav();
 *   const path = usePath();            current path, no trailing slash ("/" for the landing page)
 */
import NextLink from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { forwardRef, type AnchorHTMLAttributes } from 'react';

type LinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> & { href: string; replace?: boolean };

export const Link = forwardRef<HTMLAnchorElement, LinkProps>(function Link({ href, replace, children, ...rest }, ref) {
  if (href.startsWith('/')) {
    return (
      <NextLink ref={ref} href={href} replace={replace} {...rest}>
        {children}
      </NextLink>
    );
  }
  const external = /^https?:\/\//.test(href);
  return (
    <a ref={ref} href={href} {...(external ? { rel: 'noopener' } : {})} {...rest}>
      {children}
    </a>
  );
});

export function useNav() {
  const router = useRouter();
  return {
    push: (path: string) => router.push(path),
    replace: (path: string) => router.replace(path),
    back: () => router.back(),
  };
}

export function usePath(): string {
  const p = usePathname() || '/';
  return p.length > 1 && p.endsWith('/') ? p.slice(0, -1) : p;
}

/** True when running inside the single-file preview artifact (hash routing). */
export const IS_PREVIEW = false;

/** Only the preview router needs the list of paths (see nav.hash.tsx); a no-op here so shared code can call it. */
export function registerPaths(_paths: string[]) {}
