'use client';

import '../workspace.css';
import './conversations.css';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { FileText, Info, MessageSquare, Paperclip, Plus } from 'lucide-react';
import { asset } from '@/lib/assets';
import { Link, useNav, usePath } from '@/lib/nav';
import { useMemoState } from '@/lib/hooks';
import { Button, Chip, Field, IconButton, Modal, TextInput, toast } from '@/ui';
import { DP } from '../../decisions/data';
import { JoinCard } from '../../meetings/JoinCard';
import { MeetMenu } from '../../meetings/MeetMenu';
import { ScheduleModal } from '../../meetings/ScheduleModal';
import type { TeamMember } from '../../project-team/data';
import { CardLink, Dot, WorkspaceFrame, cx } from '../parts';
import { useProject } from '../project';
import { SlideOut, useMembers, useStartMeeting } from '../slideout';
import { useConversationsData } from './art-data';
import { CONV_PATHS, SCHEDULED_TOAST, START_TYPES, type ConversationItem, type Message, type StartType, type Thread } from './data';

/**
 * 12.13 Conversations: Conversations (the list and the open thread, two columns, no rail), Decision discussion, Empty,
 * Modal: Start conversation, Toast: Conversation started, Dropdown: Meet, Panel: Conversation info, Modal: Schedule meeting and
 * Toast: Meeting scheduled. One screen component drives every frame.
 *
 * What the prototype does: the + opens the Start conversation modal (Start closes it, shows the toast and returns to Conversations),
 * a row with a thread opens it, Meet opens its menu (Start a meeting now opens the lobby, Schedule for later opens the Schedule
 * meeting modal), the i button opens the Conversation info panel (Start meeting opens the lobby, Close closes it), the decision card
 * opens the decision, Join opens the lobby. The "state-" routes are the frames that have no natural trigger (see CONV_PATHS):
 * the modal, the toast, the menu, the panel and the schedule modal already showing.
 * Controls with no destination in the design (the rows without a thread, Open on the file, Open work, Attach) are shown and do nothing.
 * The page follows the project (useProject): Adire Stories shows its own conversations and people, and its decision discussion and
 * decision detail are not mirrored, so the row and the decision card that lead there on Career have no destination.
 */

const TOAST_MS = 2500;
/** The toasts of the "state-" frames stay longer so they can be looked at. */
const STATE_TOAST_MS = 8000;

type View = 'main' | 'decision' | 'empty';

type ScreenProps = {
  view: View;
  /** Frame Modal:Start conversation. */
  startOpen?: boolean;
  /** Frame Toast:Conversation started. */
  startedToast?: boolean;
  /** Frame Dropdown:Meet: the Meet menu open. */
  menuOpen?: boolean;
  /** Frame Panel:Conversation info. */
  infoOpen?: boolean;
  /** Frame Modal:Schedule meeting. */
  scheduleOpen?: boolean;
  /** Frame Toast:Meeting scheduled. */
  scheduledToast?: boolean;
};

/* ------------------------------------------------------------------ Modal: Start conversation */

export function StartConversationModal({ open, onClose, onStart }: { open: boolean; onClose: () => void; onStart: () => void }) {
  const { startPlaceholder } = useConversationsData();
  const [type, setType] = useState<StartType>('Work');
  const [name, setName] = useState('');
  const [first, setFirst] = useState('');

  // every opening starts again from the frame: Work chosen, both fields empty
  useEffect(() => {
    if (open) {
      setType('Work');
      setName('');
      setFirst('');
    }
  }, [open]);

  const start = (e?: FormEvent) => {
    e?.preventDefault();
    onStart();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow="NEW CONVERSATION"
      title="What do you want to discuss?"
      description="Choose what it is about so the right people see it."
      footer={
        <>
          <Button type="submit" form="cv-start-form">
            Start conversation
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="cv-start-form" className="cw-form" onSubmit={start} noValidate>
        <div className="cw-form__group" role="group" aria-labelledby="cv-type-label">
          <span className="cw-form__label" id="cv-type-label">
            Type
          </span>
          <div className="cw-chips">
            {START_TYPES.map((t) => (
              <Chip key={t} selected={type === t} onClick={() => setType(t)}>
                {t}
              </Chip>
            ))}
          </div>
        </div>
        <Field label="Conversation name" hint="A few words are enough.">
          <TextInput value={name} placeholder={startPlaceholder} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="First message" hint="Your team will be notified.">
          <TextInput value={first} placeholder="Say what this conversation is for." onChange={(e) => setFirst(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ portraits */

/** Round portrait of a team member (the Figma crop shows the top of the photo); a member without a photo shows initials. */
function Face({ m, size, className }: { m: Pick<TeamMember, 'photo' | 'initials'> | undefined; size: number; className?: string }) {
  return (
    <span className={cx('cv-face', className)} style={{ ['--cv-face' as string]: `${size}px` }} aria-hidden="true">
      {m?.photo ? <img src={asset(m.photo)} alt="" width={size} height={size} loading="lazy" decoding="async" /> : <span>{m?.initials}</span>}
    </span>
  );
}

/* ------------------------------------------------------------------ list */

/**
 * Conversation Row (Figma Conversation Row, 17383:14207 and its Unread, Hover and Selected variants): title, time and the unread dot.
 * The dot's place is always kept so the time stays where it is. Hover and Pressed come from CSS, Selected is the open conversation.
 */
function Row({ item, active }: { item: ConversationItem; active: boolean }) {
  const unread = Boolean(item.unread) && !active;
  const body = (
    <>
      <span className="cv-row__name">
        {unread ? <span className="sr-only">Unread. </span> : null}
        {item.name}
      </span>
      <span className="cv-row__meta">
        <span className="cv-row__time">{item.time}</span>
        <i className="cv-row__dot" aria-hidden="true" />
      </span>
    </>
  );
  const cls = cx('cv-row', unread && 'cv-row--unread');
  if (active) {
    return (
      <div className={cls} aria-current="true">
        {body}
      </div>
    );
  }
  if (item.href) {
    return (
      <Link href={item.href} className={cls}>
        {body}
      </Link>
    );
  }
  // no thread view in the design: the row reacts to hover and press but goes nowhere
  return (
    <button type="button" className={cls} aria-disabled="true">
      {body}
    </button>
  );
}

/* ------------------------------------------------------------------ thread */

/** Embed / Decision: one link to the decision (on Career Guidance; Adire Stories has no decision detail, so the card is plain there). */
function DecisionEmbed({ decision, href }: { decision: NonNullable<Message['decision']>; href?: string }) {
  const body = (
    <>
      <span className="cv-dec__label">DECISION</span>
      <span className="cv-dec__title">{decision.title}</span>
      <span className="cv-dec__status">
        <Dot size={8} />
        {decision.status}
      </span>
      <span className="cv-dec__link">Review decision</span>
    </>
  );
  return href ? (
    <Link href={href} className="cv-embed__card cv-dec">
      {body}
    </Link>
  ) : (
    <div className="cv-embed__card cv-dec">{body}</div>
  );
}

/** Message (Figma Thread Message, Side=In and Side=Out): portrait, name and time, a rounded bubble; embeds sit under it, indented. */
function MessageItem({ m, member, decisionHref }: { m: Message; member: TeamMember | undefined; decisionHref?: string }) {
  return (
    <li className="cv-item">
      <div className={cx('cv-msg', m.own && 'cv-msg--own')}>
        {m.own ? null : <Face m={member} size={36} />}
        <div className="cv-msg__col">
          <div className="cv-msg__meta">
            {m.own ? (
              <>
                <span className="cv-msg__time">{m.time}</span>
                <span className="cv-msg__name">{m.name}</span>
              </>
            ) : (
              <>
                <span className="cv-msg__name">{m.name}</span>
                <span className="cv-msg__time">{m.time}</span>
              </>
            )}
          </div>
          <p className="cv-bubble">{m.text}</p>
        </div>
      </div>
      {m.file ? (
        <div className="cv-embed">
          <div className="cv-embed__card cv-file">
            <span className="cv-tile" aria-hidden="true">
              <FileText size={16} strokeWidth={1.5} />
            </span>
            <span className="cv-file__text">
              <span className="cv-file__name">{m.file.name}</span>
              <span className="cv-file__meta">{m.file.meta}</span>
            </span>
            {/* Open has no destination in the design */}
            <button type="button" className="cv-file__open" aria-label={`Open ${m.file.name}`}>
              Open
            </button>
          </div>
        </div>
      ) : null}
      {m.decision ? (
        <div className="cv-embed">
          <DecisionEmbed decision={m.decision} href={decisionHref} />
        </div>
      ) : null}
    </li>
  );
}

/** Composer (Figma Thread composer): the Attach circle (no destination), the pill field and Send. */
function Composer({ draft, onDraft, onSend }: { draft: string; onDraft: (v: string) => void; onSend: () => void }) {
  const field = useRef<HTMLInputElement>(null);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!draft.trim()) return;
    onSend();
    field.current?.focus();
  };

  return (
    <form className="cv-composer" onSubmit={submit} noValidate>
      <IconButton label="Attach file" variant="outline" className="cv-composer__attach">
        <Paperclip strokeWidth={1.5} />
      </IconButton>
      <input ref={field} className="cv-composer__field" type="text" value={draft} placeholder="Write to the team" aria-label="Write to the team" autoComplete="off" onChange={(e) => onDraft(e.target.value)} />
      <Button type="submit" arrow="up-right">
        Send
      </Button>
    </form>
  );
}

/** Keys of the state kept for this visit: one set per project, so what is typed or sent on one project never shows on the other. */
const memoKey = (project: 'career' | 'adire', name: string) => (project === 'career' ? `cv.${name}` : `cv.adire.${name}`);

function ThreadView({ thread, onInfo }: { thread: Thread; onInfo: () => void }) {
  const { key } = useProject();
  const members = useMembers();
  const [draft, setDraft] = useMemoState<string>(memoKey(key, `draft.${thread.id}`), '');
  const [sent, setSent] = useMemoState<Message[]>(memoKey(key, `sent.${thread.id}`), []);
  const feed = useRef<HTMLOListElement>(null);
  const first = useRef(true);
  const decisionHref = key === 'career' ? DP.detail : undefined;
  const renderMessage = (m: Message) => <MessageItem key={m.id} m={m} member={members.find((p) => p.initials === m.initials)} decisionHref={decisionHref} />;
  // the three people who are not you, as the stack of the header
  const others = members.slice(1, 4);

  // Send adds what was typed to the end of the open thread (kept for this visit only)
  const send = () => {
    const text = draft.trim();
    if (!text) return;
    setSent((prev) => [...prev, { id: `sent-${prev.length}`, initials: members[0]?.initials ?? 'KA', name: 'You', time: 'Just now', text, own: true }]);
    setDraft('');
  };

  // a sent message scrolls into view; the first render leaves the page where it is
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    feed.current?.lastElementChild?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [sent.length]);

  return (
    <section className="cv-thread" aria-label={thread.title}>
      <header className="cv-thread__head">
        <div className="cv-thread__who">
          <span className="cv-stack" aria-hidden="true">
            {others.map((m) => (
              <Face key={m.id} m={m} size={32} className="cv-stack__face" />
            ))}
          </span>
          <div className="cv-thread__text">
            <h2 className="cv-thread__title">{thread.title}</h2>
            <p className="cv-thread__line">{thread.line}</p>
          </div>
        </div>
        <div className="cv-thread__actions">
          <MeetMenu />
          <IconButton label="Conversation info" variant="outline" size="sm" className="cv-info-btn" aria-haspopup="dialog" onClick={onInfo}>
            <Info strokeWidth={1.5} />
          </IconButton>
        </div>
      </header>
      <div className="cv-feed">
        <p className="cv-date">{thread.date}</p>
        <ol className="cv-msgs" ref={feed} aria-label="Messages">
          {thread.messages.map(renderMessage)}
          {thread.join ? (
            <li className="cv-item">
              <div className="cv-embed cv-embed--join">
                <JoinCard />
              </div>
            </li>
          ) : null}
          {sent.map(renderMessage)}
        </ol>
      </div>
      <Composer draft={draft} onDraft={setDraft} onSend={send} />
    </section>
  );
}

/* ------------------------------------------------------------------ Panel: Conversation info */

/** Panel:Conversation info (17808:109955): title and kind, the linked work, the members with their status, the shared files. */
function InfoPanel({ thread, open, onClose }: { thread: Thread; open: boolean; onClose: () => void }) {
  const { linkedWork, sharedFiles } = useConversationsData();
  const members = useMembers();
  const start = useStartMeeting();
  return (
    <SlideOut
      open={open}
      onClose={onClose}
      eyebrow="CONVERSATION"
      label={thread.title}
      footer={
        <>
          <Button onClick={start}>Start meeting</Button>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
        </>
      }
    >
      <div className="cv-info" tabIndex={-1} data-autofocus>
        <div className="cv-info__id">
          <h2 className="cv-info__title">{thread.title}</h2>
          <p className="cv-info__kind">{thread.kind}</p>
        </div>
        <section className="cv-info__block" aria-label="Linked work">
          <p className="cv-info__label">LINKED WORK</p>
          <div className="cv-info__card">
            <p className="cv-info__work">{linkedWork.title}</p>
            <p className="cv-info__status">
              <Dot size={8} />
              {linkedWork.status}
            </p>
            {/* Open work has no destination in the design */}
            <button type="button" className="cv-info__link">
              Open work
            </button>
          </div>
        </section>
        <section className="cv-info__block" aria-label="Members">
          <p className="cv-info__label">MEMBERS</p>
          <ul className="cv-info__people">
            {members.map((m) => (
              <li key={m.id} className="cv-person">
                <Face m={m} size={40} />
                <span className="cv-person__text">
                  <span className="cv-person__name">{m.name.replace(/\(you\)/, '(You)')}</span>
                  <span className="cv-person__role">{m.role}</span>
                </span>
                <span className="cv-person__dot">
                  <Dot tone={m.presence === 'available' ? 'green' : m.presence === 'working' ? 'accent' : 'gray'} size={8} />
                  <span className="sr-only">{m.availability}</span>
                </span>
              </li>
            ))}
          </ul>
        </section>
        <section className="cv-info__block" aria-label="Shared files">
          <p className="cv-info__label">SHARED FILES</p>
          <ul className="cv-info__files">
            {sharedFiles.map((f) => (
              <li key={f.name} className="cv-sfile">
                <span className="cv-tile cv-tile--sm" aria-hidden="true">
                  <FileText size={16} strokeWidth={1.5} />
                </span>
                <span className="cv-file__text">
                  <span className="cv-file__name">{f.name}</span>
                  <span className="cv-file__meta">{f.meta}</span>
                </span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </SlideOut>
  );
}

/* ------------------------------------------------------------------ screen */

/**
 * The state frames open a menu or a modal without a pointer, and the first control inside would then show its focus ring, which the
 * frames do not have. The ring stays hidden (body.cv-quiet) until the first key press, so keyboard use is never affected.
 */
function useQuietFocus(active: boolean) {
  useEffect(() => {
    if (!active) return;
    const body = document.body;
    const off = () => body.classList.remove('cv-quiet');
    body.classList.add('cv-quiet');
    document.addEventListener('keydown', off, { once: true });
    return () => {
      document.removeEventListener('keydown', off);
      off();
    };
  }, [active]);
}


function Screen({ view, startOpen, startedToast, menuOpen, infoOpen, scheduleOpen, scheduledToast }: ScreenProps) {
  const nav = useNav();
  const path = usePath();
  const { root } = useProject();
  const data = useConversationsData();
  const listPath = `${root}/conversations`;
  const [modal, setModal] = useState(Boolean(startOpen));
  const [info, setInfo] = useState(Boolean(infoOpen));
  const [schedule, setSchedule] = useState(Boolean(scheduleOpen));
  useQuietFocus(Boolean(startOpen || menuOpen || scheduleOpen));

  const showStarted = (ms: number) => toast.show({ message: data.startedToast, actionLabel: 'Undo', duration: ms, onAction: () => nav.push(listPath) });

  // the "state-conversation-started" frame: Conversations with the toast already showing
  useEffect(() => {
    if (startedToast) showStarted(STATE_TOAST_MS);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startedToast]);

  // the "state-meeting-scheduled" frame: Conversations with the Meeting scheduled toast showing
  useEffect(() => {
    if (scheduledToast) toast.show({ message: SCHEDULED_TOAST, actionLabel: 'Undo', duration: STATE_TOAST_MS });
  }, [scheduledToast]);

  // the "state-meet-menu" frame: the Meet menu opens on its own once the page is there
  useEffect(() => {
    if (!menuOpen) return;
    const t = window.setTimeout(() => document.querySelector<HTMLButtonElement>('.cv-thread__actions button[aria-haspopup="menu"]')?.click(), 400);
    return () => window.clearTimeout(t);
  }, [menuOpen]);

  // Start conversation in the modal returns to Conversations (from any other frame too) and shows the toast; Undo returns there as well
  const start = () => {
    setModal(false);
    if (path !== listPath) nav.push(listPath);
    showStarted(TOAST_MS);
  };

  const modalEl = <StartConversationModal open={modal} onClose={() => setModal(false)} onStart={start} />;
  const thread = data.threads[view === 'decision' ? 'decision' : 'onboarding'];
  const empty = view === 'empty';

  return (
    <WorkspaceFrame active="conversations" wide>
      <div className={cx('cv-chat', empty && 'cv-chat--empty')} data-m="up">
        <section className="cv-list" aria-labelledby="cv-list-title">
          <header className="cv-list__head">
            <h1 className="cv-list__title" id="cv-list-title">
              Conversations
            </h1>
            <IconButton label="New conversation" variant="outline" size="sm" className="cv-new" aria-haspopup="dialog" onClick={() => setModal(true)}>
              <Plus strokeWidth={1.5} />
            </IconButton>
          </header>
          {empty ? null : (
            <ul className="cv-list__rows" aria-label="Conversations">
              {data.conversations.map((c) => (
                <li key={c.id}>
                  <Row item={c} active={c.id === thread.id} />
                </li>
              ))}
            </ul>
          )}
        </section>
        {empty ? (
          <div className="cv-empty">
            <span className="cv-empty__icon" aria-hidden="true">
              <MessageSquare size={24} strokeWidth={1.5} />
            </span>
            <h2 className="cv-empty__title">{data.empty.title}</h2>
            <p className="cv-empty__text">{data.empty.text}</p>
            <Button arrow="up-right" onClick={() => setModal(true)} aria-haspopup="dialog">
              Start conversation
            </Button>
          </div>
        ) : (
          <ThreadView key={thread.id} thread={thread} onInfo={() => setInfo(true)} />
        )}
      </div>
      {modalEl}
      {empty ? null : <InfoPanel thread={thread} open={info} onClose={() => setInfo(false)} />}
      <ScheduleModal open={schedule} onClose={() => setSchedule(false)} />
    </WorkspaceFrame>
  );
}

export const Conversations = () => <Screen view="main" />;
export const ConversationsDecision = () => <Screen view="decision" />;
export const ConversationsEmpty = () => <Screen view="empty" />;
/** Frame "Modal: Start conversation": Conversations with the modal open. */
export const ConversationsStartModal = () => <Screen view="main" startOpen />;
/** Frame "Toast: Conversation started": Conversations with the toast showing. */
export const ConversationsStarted = () => <Screen view="main" startedToast />;
/** Frame "Dropdown: Meet": Conversations with the Meet menu open. */
export const ConversationsMeetMenu = () => <Screen view="main" menuOpen />;
/** Frame "Panel: Conversation info": Conversations with the panel open. */
export const ConversationsInfo = () => <Screen view="main" infoOpen />;
/** Frame "Modal: Schedule meeting": Conversations with the Schedule meeting modal open. */
export const ConversationsScheduleModal = () => <Screen view="main" scheduleOpen />;
/** Frame "Toast: Meeting scheduled": Conversations with the toast showing. */
export const ConversationsScheduled = () => <Screen view="main" scheduledToast />;
