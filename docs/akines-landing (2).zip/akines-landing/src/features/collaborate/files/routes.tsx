import type { RouteDef } from '@/routes.types';
import { Files, FilesCreateModal, FilesCreated, FilesEmpty, FilesUploadModal, FilesUploaded } from './Files';
import { FilePreview } from './FilePreview';
import { FP } from './data';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * 12.19 Files: Files, Empty, File preview, and the four overlay frames.
 * The "state-" routes are the Figma frames that have no natural trigger in the prototype (they are not linked from the UI):
 * Empty, and the Files page with Modal:Upload file, Toast:File uploaded, Modal:Create document or Toast:Document created showing.
 * The modals open from Upload file and Create document (header and Empty State).
 */
export const routes: RouteDef[] = [
  { path: FP.list, title: 'Files', shell: 'app', nav, component: Files },
  { path: FP.empty, title: 'Files', shell: 'app', nav, component: FilesEmpty },
  { path: FP.preview, title: 'File', shell: 'app', nav, component: FilePreview },
  { path: FP.upload, title: 'Files', shell: 'app', nav, component: FilesUploadModal },
  { path: FP.uploaded, title: 'Files', shell: 'app', nav, component: FilesUploaded },
  { path: FP.createDoc, title: 'Files', shell: 'app', nav, component: FilesCreateModal },
  { path: FP.docCreated, title: 'Files', shell: 'app', nav, component: FilesCreated },
];
