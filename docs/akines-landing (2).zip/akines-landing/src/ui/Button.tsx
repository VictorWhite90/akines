'use client';

/**
 * The one button of Akines. It is the landing page pill: on hover (pointer devices) a fill rises from the bottom edge,
 * the label colour swaps, a hairline ring fades in and the arrow nudges; press scales to 0.97. Everything is styled in
 * src/styles/ui.css (BUTTON_SPEC.md has the colour table). The Figma Components page has the matching "Button" and "Icon Button".
 */
import { forwardRef, useLayoutEffect, useRef, type AnchorHTMLAttributes, type ButtonHTMLAttributes, type ReactNode, type Ref } from 'react';
import { ArrowDown, ArrowRight, ArrowUpRight } from 'lucide-react';
import { AppLink } from '@/components/AppLink';
import { cx } from './internal';
import { Tooltip } from './Tooltip';

export type ButtonVariant = 'primary' | 'secondary' | 'accent' | 'ghost' | 'danger' | 'link';
/** dark = for light surfaces, light = for photographs and dark surfaces. */
export type ButtonTone = 'dark' | 'light';
export type ButtonSize = 'sm' | 'md' | 'lg' | 'xl';
/** The direction an arrow icon points, and the direction it nudges on hover. */
export type ButtonArrow = 'up-right' | 'down' | 'right';
/** Design gallery only: forces a state for static display. */
export type ButtonState = 'hover' | 'pressed' | 'focus';

const ARROWS: Record<ButtonArrow, ReactNode> = {
  'up-right': <ArrowUpRight strokeWidth={1.5} aria-hidden="true" focusable="false" />,
  down: <ArrowDown strokeWidth={1.5} aria-hidden="true" focusable="false" />,
  right: <ArrowRight strokeWidth={1.5} aria-hidden="true" focusable="false" />,
};

type Common = {
  variant?: ButtonVariant;
  tone?: ButtonTone;
  /** sm 36, md 48 (default), lg 56, xl 62 (48 below 1280). */
  size?: ButtonSize;
  /** Landing only: md is 48 below 1280 and 50 from 1280, xl is 48 and 62, with the landing paddings. */
  fluid?: boolean;
  icon?: ReactNode;
  /** Sits after the label and nudges on hover. */
  iconRight?: ReactNode;
  /** Shorthand for iconRight with a built-in arrow; also sets which way the icon nudges. */
  arrow?: ButtonArrow;
  /** Spinner left of the label, keeps the resting width, ignores clicks, sets aria-busy. */
  loading?: boolean;
  /** Looks disabled (grey, no sweep) but still receives clicks, for forms where the click explains what is missing. Sets aria-disabled. */
  looksDisabled?: boolean;
  fullWidth?: boolean;
  href?: string;
  /** Design gallery only. */
  state?: ButtonState;
};
export type ButtonProps = Common &
  Omit<ButtonHTMLAttributes<HTMLButtonElement>, keyof Common> &
  Omit<AnchorHTMLAttributes<HTMLAnchorElement>, keyof Common | keyof ButtonHTMLAttributes<HTMLButtonElement>>;

const assign = <T,>(ref: Ref<T> | undefined, node: T | null) => {
  if (typeof ref === 'function') ref(node);
  else if (ref) (ref as { current: T | null }).current = node;
};

/**
 * Pill button. With `href` it renders the app link (external URLs get rel="noopener"), otherwise a `<button type="button">`.
 */
export const Button = forwardRef<HTMLButtonElement | HTMLAnchorElement, ButtonProps>(function Button(
  { variant = 'primary', tone = 'dark', size = 'md', fluid, icon, iconRight, arrow, loading, looksDisabled, fullWidth, href, state, className, children, disabled, onClick, type, ...rest },
  ref,
) {
  const node = useRef<HTMLButtonElement | HTMLAnchorElement | null>(null);
  const restWidth = useRef(0);
  // A loading button never gets narrower than it was at rest: remember the resting width, hold it while loading.
  useLayoutEffect(() => {
    const el = node.current;
    if (!el || loading === undefined) return;
    if (loading) {
      if (restWidth.current) el.style.setProperty('--k-lock', `${restWidth.current}px`);
    } else {
      restWidth.current = el.offsetWidth;
      el.style.removeProperty('--k-lock');
    }
  });
  const setRef = (el: HTMLButtonElement | HTMLAnchorElement | null) => {
    node.current = el;
    assign(ref, el);
  };

  const off = Boolean(disabled);
  const live = !off && !looksDisabled && !loading;
  const cls = cx(
    'k-btn',
    `k-btn--${variant}`,
    `k-btn--${size}`,
    tone === 'light' && 'k-btn--light',
    fluid && 'k-btn--fluid',
    fullWidth && 'k-btn--full',
    loading && 'k-btn--loading',
    (off || looksDisabled) && 'k-btn--disabled',
    live && 'k-btn--live',
    className,
  );
  const right = iconRight ?? (arrow ? ARROWS[arrow] : undefined);
  const inner = (
    <>
      {loading ? <span className="k-btn__spinner" aria-hidden="true" /> : null}
      {icon ? <span className="k-btn__icon" aria-hidden="true">{icon}</span> : null}
      {children != null && children !== false ? <span className="k-btn__label">{children}</span> : null}
      {right ? <span className="k-btn__icon k-btn__icon--right" data-nudge={arrow ?? 'right'} aria-hidden="true">{right}</span> : null}
    </>
  );

  if (href) {
    const blocked = off || loading;
    return (
      <AppLink
        {...(rest as AnchorHTMLAttributes<HTMLAnchorElement>)}
        ref={setRef as Ref<HTMLAnchorElement>}
        href={href}
        className={cls}
        data-force={state}
        aria-disabled={blocked || looksDisabled || undefined}
        aria-busy={loading || undefined}
        tabIndex={blocked ? -1 : (rest as { tabIndex?: number }).tabIndex}
        onClick={(e) => {
          if (blocked) {
            e.preventDefault();
            return;
          }
          (onClick as ((e: React.MouseEvent<HTMLAnchorElement>) => void) | undefined)?.(e as never);
        }}
      >
        {inner}
      </AppLink>
    );
  }
  return (
    <button
      {...(rest as ButtonHTMLAttributes<HTMLButtonElement>)}
      ref={setRef as Ref<HTMLButtonElement>}
      type={type ?? 'button'}
      className={cls}
      data-force={state}
      disabled={disabled}
      aria-disabled={looksDisabled || undefined}
      aria-busy={loading || undefined}
      // a loading button keeps its place in the tab order but ignores clicks
      onClick={loading ? (e) => e.preventDefault() : (onClick as ButtonHTMLAttributes<HTMLButtonElement>['onClick'])}
    >
      {inner}
    </button>
  );
});

export type IconButtonProps = {
  /** The accessible name and the tooltip. */
  label: string;
  /** solid = primary colours, outline = secondary, ghost = ghost. */
  variant?: 'solid' | 'outline' | 'ghost';
  tone?: ButtonTone;
  /** sm 36, md 44 (default), lg 52. */
  size?: 'sm' | 'md' | 'lg';
  /** Renders a link instead of a button (Messages in the app header). */
  href?: string;
  /** The label also shows as a dark tooltip on hover and keyboard focus. Default true; the landing page turns it off (it has none today). */
  tooltip?: boolean;
  /** Design gallery only. */
  state?: ButtonState;
  children: ReactNode;
} & Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'aria-label'>;

const ICON_VARIANT = { solid: 'primary', outline: 'secondary', ghost: 'ghost' } as const;

/** Round icon-only button with the same hover as Button. `label` is the accessible name and the tooltip. */
export const IconButton = forwardRef<HTMLButtonElement | HTMLAnchorElement, IconButtonProps>(function IconButton(
  { label, size = 'md', variant = 'ghost', tone = 'dark', href, tooltip = true, state, className, children, type, disabled, ...rest },
  ref,
) {
  const cls = cx(
    'k-iconbtn',
    `k-iconbtn--${size}`,
    `k-btn--${ICON_VARIANT[variant]}`,
    tone === 'light' && 'k-btn--light',
    disabled ? 'k-btn--disabled' : 'k-btn--live',
    className,
  );
  const body = (
    <>
      <span className="k-iconbtn__fx" aria-hidden="true" />
      <span className="k-iconbtn__glyph" aria-hidden="true">{children}</span>
    </>
  );
  const el = href ? (
    <AppLink
      {...(rest as unknown as AnchorHTMLAttributes<HTMLAnchorElement>)}
      ref={ref as Ref<HTMLAnchorElement>}
      href={href}
      aria-label={label}
      className={cls}
      data-force={state}
    >
      {body}
    </AppLink>
  ) : (
    <button {...rest} ref={ref as Ref<HTMLButtonElement>} type={type ?? 'button'} aria-label={label} className={cls} data-force={state} disabled={disabled}>
      {body}
    </button>
  );
  return tooltip ? (
    <Tooltip label={label} describe={false}>
      {el}
    </Tooltip>
  ) : (
    el
  );
});
