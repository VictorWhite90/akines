'use client';

import '../workspace/workspace.css';
import './decisions.css';
import './detail.css';
import { Fragment, useEffect, useState } from 'react';
import { Link, useNav, usePath } from '@/lib/nav';
import { toast } from '@/ui';
import { DashCard, MetricCard, MetricRow, SegmentBar, StageTracker } from '../workspace/dash';
import { PATHS } from '../workspace/data';
import { ActionButton, BackLink, CardLink, Icon, PageHead, WorkspaceFrame, cx } from '../workspace/parts';
import { FP } from '../files/data';
import { DP, FILES, OPTIONS, ACKNOWLEDGE, type DecisionOption } from './data';
import { DD, DD_IDS } from './detail-data';
import { AcknowledgeModal } from './modals';

/**
 * 12.20 Decision detail (17729:117836) with Modal:Acknowledge decision (17729:120932) and Toast:Decision acknowledged (17729:120851).
 * The dashboard look: the shared rail on the right (without its Needs review row for this decision), the header with its two buttons,
 * four metric cards that scroll to their card, the decision progress, acknowledgements beside the details, the two options, context,
 * problem and direction in three columns, the supporting files, the discussion and the outcome.
 * Acknowledge decision opens the modal; its button shows the toast over the detail ("3 of 4 have acknowledged"). The design shows only
 * the toast, the detail itself does not change, so nothing is stored. Open discussion goes to the decision discussion. The "state-"
 * routes are the overlay frames. Career Guidance for Everyone only.
 * Links from the prototype: the milestone row opens the milestone, the first file opens the File preview, Open discussion (card link)
 * opens the discussion. Without a destination in the design (shown, they do nothing): the second file, the two option cards and the
 * timeline steps.
 */

const TOAST_MS = 2500;
/** The toast of the "state-" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

/** Up-right arrow of an Open action (Figma icon/arrow-up-right, 16 px, 1.5 stroke) and the 24 px one of a value (10 px arrow, 1.5 stroke). */
const ArrowUpRight = ({ size = 16 }: { size?: 16 | 24 }) => (
  <Icon size={size} sw={size === 24 ? 1 : 1.5}>
    <path d="M4.5 11.5 11.5 4.5M5.5 4.5h6v6" />
  </Icon>
);

/* ------------------------------------------------------------------ Decision Option (17729:92994) */

/** Option card: stage and type, the name, then what it is good for and what to watch for. The proposed option has the dark border. */
function Option({ option }: { option: DecisionOption }) {
  const proposed = option.type === 'PROPOSED';
  return (
    <article className={cx('dd-opt', proposed && 'dd-opt--proposed')} data-m="up">
      <div className="dd-opt__top">
        <span className="dd-label">{option.stage}</span>
        {proposed ? <i className="dd-opt__dot" aria-hidden="true" /> : null}
        <span className="dd-label">{option.type}</span>
      </div>
      <h3 className="dd-opt__title">{option.title}</h3>
      <div className="dd-rule" aria-hidden="true" />
      <div className="dd-opt__field">
        <span className="dd-label">GOOD FOR</span>
        <p>{option.goodFor}</p>
      </div>
      <div className="dd-opt__field">
        <span className="dd-label">WATCH FOR</span>
        <p>{option.watchFor}</p>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ rows */

/** Supporting file row (Figma Work Row, 704 by 92). With a destination the row is one link with Open at the right. */
function FileRow({ name, meta, href }: { name: string; meta: string; href?: string }) {
  const body = (
    <>
      <span className="dd-row__text">
        <span className="dd-row__title">{name}</span>
        <span className="dd-row__status">{meta}</span>
      </span>
      {href ? (
        <span className="dd-row__act">
          <span className="dd-row__open">Open</span>
          <ArrowUpRight />
        </span>
      ) : null}
    </>
  );
  return href ? (
    <Link href={href} className="dd-row dd-row--link">
      {body}
    </Link>
  ) : (
    <div className="dd-row">{body}</div>
  );
}

/* ------------------------------------------------------------------ screen */

function Screen({ modalOpen, acknowledgedToast }: { modalOpen?: boolean; acknowledgedToast?: boolean }) {
  const nav = useNav();
  const path = usePath();
  const [modal, setModal] = useState(Boolean(modalOpen));

  // the "state-decision-acknowledged" frame: the detail with the toast already showing
  useEffect(() => {
    if (acknowledgedToast) toast.show({ message: ACKNOWLEDGE.toast, duration: STATE_TOAST_MS });
  }, [acknowledgedToast]);

  // the modal's button closes it and shows the toast over the detail (the state frame goes back to the detail first)
  const acknowledge = () => {
    setModal(false);
    if (path === DP.acknowledge) nav.push(DP.detail);
    toast.show({ message: ACKNOWLEDGE.toast, duration: TOAST_MS });
  };

  const m = DD.metrics;
  const ack = DD.acknowledgements;
  const out = DD.outcome;

  return (
    <WorkspaceFrame active="decisions" rail railHide={['decision']}>
      <div className="dd-page">
        <PageHead back={<BackLink href={DP.list}>{DD.back}</BackLink>} label={DD.label} title={DD.title} lead={DD.lead}>
          <div className="cw-actions cw-actions--btns">
            <ActionButton onClick={() => setModal(true)}>{DD.acknowledge}</ActionButton>
            <ActionButton variant="secondary" href={PATHS.conversationsDecision}>
              {DD.discuss}
            </ActionButton>
          </div>
        </PageHead>

        <MetricRow>
          <MetricCard label={m.acknowledged.label} value={m.acknowledged.value} caption={m.acknowledged.caption} dot scrollTo={DD_IDS.acknowledgements} />
          <MetricCard label={m.decideBy.label} value={m.decideBy.value} caption={m.decideBy.caption} scrollTo={DD_IDS.acknowledgements} />
          <MetricCard label={m.options.label} value={m.options.value} caption={m.options.caption} scrollTo={DD_IDS.options} />
          <MetricCard label={m.files.label} value={m.files.value} caption={m.files.caption} scrollTo={DD_IDS.files} />
        </MetricRow>

        <DashCard title={DD.progress.title} className="dd-progress">
          <StageTracker stages={DD.progress.steps} />
        </DashCard>

        <div className="dd-pair" id={DD_IDS.acknowledgements}>
          <DashCard title={ack.title} className="dd-ack">
            <p className="dd-total">
              <span>{ack.count}</span>
              {ack.caption}
            </p>
            <SegmentBar done={ack.done} total={ack.total} />
            <ul className="dd-legend">
              {ack.people.map((p) => (
                <li key={p.name}>
                  <span className="dd-legend__name">
                    <i className={cx('dd-dot', p.acknowledged && 'dd-dot--done')} aria-hidden="true" />
                    {p.name}
                  </span>
                  <span className={cx('dd-legend__state', !p.acknowledged && 'is-waiting')}>{p.acknowledged ? 'Acknowledged' : 'Waiting'}</span>
                </li>
              ))}
            </ul>
          </DashCard>

          <DashCard title={DD.details.title} className="dd-details">
            <ul className="dd-lines">
              {DD.details.rows.map((r) => (
                <li className="dd-line" key={r.label}>
                  <div className="dd-line__in">
                    <span className="dd-line__k">{r.label}</span>
                    <span className="dd-line__v">{r.value}</span>
                  </div>
                </li>
              ))}
              <li className="dd-line">
                <Link href={PATHS.milestone} className="dd-line__in dd-line__in--link">
                  <span className="dd-line__k">{DD.details.milestone.label}</span>
                  <span className="dd-line__v">
                    {DD.details.milestone.value}
                    <ArrowUpRight size={24} />
                  </span>
                </Link>
              </li>
            </ul>
          </DashCard>
        </div>

        <div className="dd-options" id={DD_IDS.options}>
          {OPTIONS.map((o) => (
            <Option key={o.id} option={o} />
          ))}
        </div>
        <p className="dd-note" data-m="up">
          {DD.optionsNote}
        </p>

        <DashCard className="dd-cols">
          <div className="dd-columns">
            {DD.columns.map((c, i) => (
              <Fragment key={c.label}>
                {i > 0 ? <i className="dd-columns__rule" aria-hidden="true" /> : null}
                <div className="dd-col">
                  <h3 className="dd-label">{c.label}</h3>
                  <p>{c.text}</p>
                </div>
              </Fragment>
            ))}
          </div>
        </DashCard>

        <section className="dd-files" id={DD_IDS.files} data-m="up">
          <h2 className="dd-label">{DD.files.title}</h2>
          <ul className="dd-rows">
            {FILES.map((f, i) => (
              <li key={f.name}>
                {/* the first file opens the File preview; the second has no destination in the design */}
                <FileRow name={f.name} meta={f.meta} href={i === 0 ? FP.preview : undefined} />
              </li>
            ))}
          </ul>
        </section>

        <DashCard title={DD.discussion.title} className="dd-discussion">
          <ul className="dd-comments">
            {DD.discussion.comments.map((c) => (
              <li className="dd-comment" key={c.name}>
                <span className="dd-av" aria-hidden="true">
                  {c.initials}
                </span>
                <div className="dd-comment__text">
                  <p className="dd-comment__name">{c.name}</p>
                  <p className="dd-comment__line">{c.text}</p>
                </div>
              </li>
            ))}
          </ul>
          <CardLink href={PATHS.conversationsDecision} className="dd-link">
            {DD.discussion.link}
          </CardLink>
        </DashCard>

        <DashCard title={out.title} className="dd-outcome">
          <p className="dd-outcome__status">
            <i className="dd-dot dd-dot--amber" aria-hidden="true" />
            <span>{out.status}</span>
          </p>
          <p className="dd-outcome__text">{out.text}</p>
        </DashCard>
      </div>
      <AcknowledgeModal open={modal} onClose={() => setModal(false)} onAcknowledge={acknowledge} />
    </WorkspaceFrame>
  );
}

export const DecisionDetail = () => <Screen />;
/** Frame "Modal:Acknowledge decision": the detail with the modal open. */
export const DecisionAcknowledgeModal = () => <Screen modalOpen />;
/** Frame "Toast:Decision acknowledged": the detail with the toast showing. */
export const DecisionAcknowledged = () => <Screen acknowledgedToast />;
