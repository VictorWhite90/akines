import { useSyncExternalStore } from 'react';
import { DEFAULT_PROJECT, defaultPrefs, requestKey, SEEDED_SAVED, type Intention, type PersonId, type Prefs, type ProjectId } from './data';

/**
 * Prototype state of 12.3 and 12.4 (the Figma prototype variables), shared by every screen of this part.
 *   saved           the saved collaborators list (B11); starts with Kunle and Funmi as in the design
 *   discoverySaved  cards that show the Saved variant in Discovery (B3), set by Save for later during this visit
 *   dismissed       recommendations removed with Not relevant (B3 then shows the three card layout)
 *   prefs           matching preferences chosen in the modal
 *   intention       choice made in B2
 *   project         the project B2 shows (Change project), Career Guidance for Everyone until another one is chosen
 *   withdrawn       keys of the requests withdrawn on a 12.47 page; B12 leaves them out (see requestKey in data.ts)
 * Every action returns an undo function, used by the toast "Undo".
 */
type State = {
  saved: PersonId[];
  discoverySaved: PersonId[];
  dismissed: PersonId[];
  prefs: Prefs;
  intention: Intention;
  project: ProjectId;
  withdrawn: string[];
};

let state: State = {
  saved: [...SEEDED_SAVED],
  discoverySaved: [],
  dismissed: [],
  prefs: defaultPrefs(),
  intention: 'project',
  project: DEFAULT_PROJECT,
  withdrawn: [],
};

const listeners = new Set<() => void>();
const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
};
function set(patch: Partial<State>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

type Undo = () => void;

export const ccStore = {
  get: () => state,
  save(id: PersonId): Undo {
    const prev = { saved: state.saved, discoverySaved: state.discoverySaved };
    set({
      saved: state.saved.includes(id) ? state.saved : [...state.saved, id],
      discoverySaved: state.discoverySaved.includes(id) ? state.discoverySaved : [...state.discoverySaved, id],
    });
    return () => set(prev);
  },
  unsave(id: PersonId): Undo {
    const prev = { saved: state.saved, discoverySaved: state.discoverySaved };
    set({ saved: state.saved.filter((x) => x !== id), discoverySaved: state.discoverySaved.filter((x) => x !== id) });
    return () => set(prev);
  },
  dismiss(id: PersonId): Undo {
    const prev = state.dismissed;
    set({ dismissed: state.dismissed.includes(id) ? state.dismissed : [...state.dismissed, id] });
    return () => set({ dismissed: prev });
  },
  setPrefs(prefs: Prefs) {
    set({ prefs });
  },
  setIntention(intention: Intention) {
    set({ intention });
  },
  setProject(project: ProjectId): Undo {
    const prev = state.project;
    set({ project });
    return () => set({ project: prev });
  },
  /** Withdraw request (12.47): the request leaves B12. Undo puts it back. */
  withdraw(key: string): Undo {
    set({ withdrawn: state.withdrawn.includes(key) ? state.withdrawn : [...state.withdrawn, key] });
    return () => set({ withdrawn: state.withdrawn.filter((k) => k !== key) });
  },
  /** A new introduction request to this person (Send request on the confirm modal): an earlier withdrawn one no longer counts. */
  sendRequest(id: PersonId) {
    const key = requestKey(id, 'pending');
    if (state.withdrawn.includes(key)) set({ withdrawn: state.withdrawn.filter((k) => k !== key) });
  },
};

/** The whole state; it only changes identity when something changes, so selecting from it in render is safe. */
export function useCc(): State {
  return useSyncExternalStore(subscribe, () => state, () => state);
}
