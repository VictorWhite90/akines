#!/usr/bin/env node
// Visits every registered route of the preview bundle at three widths and reports console errors, page errors,
// horizontal overflow, broken images and empty screens. On the desktop pass it also checks the routing itself:
// duplicate routes (two paths with the same hash) and every internal link on the page (a[data-route]) that has no registered route.
//   node scripts/build-preview.mjs /tmp/akines-prev && python3 -m http.server -d /tmp/akines-prev 8123 &
//   node scripts/check-routes.mjs http://localhost:8123 [outDir for screenshots]
import { createRequire } from 'node:module';
import { mkdirSync } from 'node:fs';

// Playwright is installed globally in the workspace (NODE_PATH), so it is loaded with require rather than import.
const { chromium } = createRequire(import.meta.url)('playwright');

const base = process.argv[2] || 'http://localhost:8123';
const shots = process.argv[3];
if (shots) mkdirSync(shots, { recursive: true });
const sizes = [
  ['desktop', 1512, 982],
  ['tablet', 1194, 834],
  ['mobile', 402, 874],
];
const browser = await chromium.launch();
const problems = [];
let visited = 0;
let paths = [];
const hashOf = (p) => (p === '/' ? '#' : '#' + p.split('?')[0].replace(/^\/+|\/+$/g, '').replace(/\//g, '-'));
let known = new Set();
let linkCount = 0;
for (const [label, width, height] of sizes) {
  const ctx = await browser.newContext({ viewport: { width, height } });
  await ctx.addInitScript(() => {
    try {
      localStorage.setItem('akines.session.v1', '1');
    } catch {}
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push('console: ' + m.text());
  });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('requestfailed', (r) => errors.push('request failed: ' + r.url()));
  await page.goto(base + '/', { waitUntil: 'load' });
  if (!paths.length) {
    paths = await page.evaluate(() => window.__AKINES_ROUTES__);
    known = new Set(paths.map(hashOf));
    const seen = new Map();
    for (const p of paths) {
      const h = hashOf(p);
      if (seen.has(h)) problems.push(`routing: ${p} and ${seen.get(h)} share the hash ${h}`);
      seen.set(h, p);
    }
  }
  for (const p of paths) {
    errors.length = 0;
    const hash = p === '/' ? '' : p.slice(1).replace(/\//g, '-');
    await page.goto(base + '/#' + hash, { waitUntil: 'load' });
    await page.reload({ waitUntil: 'load' });
    await page.waitForTimeout(p === '/' ? 600 : 450);
    const info = await page.evaluate(() => {
      const de = document.documentElement;
      const imgs = [...document.images].filter((i) => i.complete && i.naturalWidth === 0 && i.src).map((i) => i.src.slice(-60));
      return { sw: de.scrollWidth, cw: de.clientWidth, h: de.scrollHeight, text: (document.body.innerText || '').trim().length, imgs, title: document.title };
    });
    visited++;
    const tag = `${label} ${p}`;
    if (label === 'desktop') {
      const links = await page.evaluate(() => [...document.querySelectorAll('a[data-route]')].map((a) => ({ h: a.getAttribute('href'), t: (a.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 40) })));
      linkCount += links.length;
      for (const l of links) if (!known.has(l.h)) problems.push(`${tag}: link to a route that is not registered ${l.h} ("${l.t}")`);
    }
    if (info.sw > info.cw + 1) problems.push(`${tag}: horizontal overflow ${info.sw} > ${info.cw}`);
    if (info.text < 20) problems.push(`${tag}: almost no text`);
    if (info.imgs.length) problems.push(`${tag}: broken images ${info.imgs.join(', ')}`);
    for (const e of errors) problems.push(`${tag}: ${e}`);
    if (shots) await page.screenshot({ path: `${shots}/${label}-${hash || 'home'}.png`, fullPage: false });
  }
  await ctx.close();
}
await browser.close();
console.log(`${visited} visits over ${paths.length} routes, ${linkCount} internal links checked on the desktop pass`);
console.log(problems.length ? problems.join('\n') : 'no problems');
process.exit(problems.length ? 1 : 0);
