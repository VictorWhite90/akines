'use client';

import { useState, type ReactNode } from 'react';
import { toast } from '@/ui/toast';
import { useNav, usePath } from '@/lib/nav';
import { APPLICANTS, APPLICANT_PATHS, CALL_PATH, NOT_NOW, OFFER, TIMES, type ApplicantId, type Group } from './data';
import { NotNowModal, ProposeTimesModal, SendOfferModal } from './modals';
import { ApplicantSlideOut } from './slideout';
import { applicants } from './store';

/**
 * What a host can do with a person who applied, shared by the list, the compare page and the slide-out: open the slide-out, Shortlist,
 * Propose times, Send offer and Not now (with Undo in its toast). The overlays are rendered in `layer`; put it anywhere in the page.
 *
 * The modals of the design end on the Applicants frame (Send times and Send offer go to Applicants, Send on Not now goes to
 * Applicants / Not now, Undo goes to Applicants), so an action taken on another page of the journey (Compare) returns to the list.
 * On the list itself nothing navigates: the page already shows the new status.
 */

type Modal = { kind: 'times' | 'offer' | 'notnow'; id: ApplicantId };

export function useReviewer(group: Group) {
  const nav = useNav();
  const path = usePath();
  const home = group === 'project' ? APPLICANT_PATHS.list : CALL_PATH;
  const [slide, setSlide] = useState<ApplicantId | null>(null);
  const [modal, setModal] = useState<Modal | null>(null);

  // the page the journey ends on: the list. A state route (".../state-offer-sent") is not the list, so an action there goes to it as well.
  const toList = () => {
    if (path !== home) nav.push(home);
  };
  const finish = () => {
    setModal(null);
    setSlide(null);
    toList();
  };

  const open = (id: ApplicantId) => setSlide(id);
  const shortlist = (id: ApplicantId) => {
    applicants.shortlist(id);
    // a shortlisted person of a call has no slide-out; on a project the slide-out becomes the Shortlisted one
    if (APPLICANTS[id].group === 'call') setSlide(null);
  };
  const propose = (id: ApplicantId) => setModal({ kind: 'times', id });
  const offer = (id: ApplicantId) => setModal({ kind: 'offer', id });
  const notNow = (id: ApplicantId) => setModal({ kind: 'notnow', id });
  const undo = (id: ApplicantId) => {
    applicants.undoNotNow(id);
    toList();
  };

  const person = modal ? APPLICANTS[modal.id] : null;
  const sendTimes = () => {
    if (!person) return;
    toast.show({ message: TIMES.toast(person.name) });
    finish();
  };
  const sendOffer = () => {
    if (!person) return;
    applicants.sendOffer(person.id);
    toast.show({ message: OFFER.toast(person.name) });
    finish();
  };
  const sendNotNow = () => {
    if (!person) return;
    const id = person.id;
    applicants.markNotNow(id);
    toast.show({ message: NOT_NOW.toast(person.name), actionLabel: 'Undo', onAction: () => undo(id) });
    finish();
  };

  const closeModal = () => setModal(null);
  const layer: ReactNode = (
    <>
      <ApplicantSlideOut id={slide} onClose={() => setSlide(null)} h={{ shortlist, propose, offer, notNow }} />
      <ProposeTimesModal open={modal?.kind === 'times'} person={modal?.kind === 'times' ? person : null} onClose={closeModal} onSend={sendTimes} />
      <SendOfferModal open={modal?.kind === 'offer'} person={modal?.kind === 'offer' ? person : null} onClose={closeModal} onSend={sendOffer} />
      <NotNowModal open={modal?.kind === 'notnow'} person={modal?.kind === 'notnow' ? person : null} onClose={closeModal} onSend={sendNotNow} />
    </>
  );

  return { open, shortlist, propose, offer, notNow, undo, layer };
}
