'use client';

/**
 * Figma "Modal:Notifications" (17104:7225): a 400 px popover under the header bell (right 64, top 88) over a click-to-close scrim.
 * Phones: Figma "Sheet:Notifications (Mobile)" (18080:177287), a bottom sheet opened from the Profile sheet.
 * The shell renders this component on every signed-in screen, so it also hosts the Community overlays (Overlays.tsx).
 */
import { Modal } from '@/ui';
import { useNav } from '@/lib/nav';
import { useLayout } from '@/lib/hooks';
import { P } from './data';
import { openModal } from './store';
import { CommunityOverlays, Sheet } from './Overlays';
import { ListRow, TextLink } from './ui';
import './community.css';
import './sheets-mobile.css';

export function NotificationsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const nav = useNav();
  const phone = useLayout() === 'mobile';
  const go = (path: string) => {
    onClose();
    nav.push(path);
  };
  /* Figma SWAP_OVERLAY: the popover is replaced by the panel */
  const swap = (id: Parameters<typeof openModal>[0]) => {
    onClose();
    openModal(id);
  };
  const rows = (
    <div className="ch-notif__list">
      <ListRow title="Amara replied in Community Health Initiative" text="A few minutes ago" avatar="amara" onClick={() => go(P.thread('amara'))} />
      <ListRow title="Two places left: Starting a purpose-driven business" text="Today" avatar="kincircle" onClick={() => swap('inv-kin')} />
      <ListRow title="Reminder: Project Call with the Food Systems Cliq at 2:00 PM" text="Today" onClick={() => swap('up-project')} />
    </div>
  );
  return (
    <>
      {phone ? (
        <Sheet open={open} onClose={onClose} title="Notifications" variant="list">
          {rows}
          <div className="chs__linkarea">
            <TextLink onClick={() => go(P.settings)}>Notification preferences</TextLink>
          </div>
        </Sheet>
      ) : (
        <Modal open={open} onClose={onClose} title="Notifications" hideClose flush width={400} className="ch-notif">
          {rows}
          <TextLink onClick={() => go(P.settings)} className="ch-notif__pref">
            Notification preferences
          </TextLink>
        </Modal>
      )}
      <CommunityOverlays />
    </>
  );
}
