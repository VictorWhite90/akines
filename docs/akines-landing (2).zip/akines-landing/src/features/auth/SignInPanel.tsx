'use client';

/**
 * Slide-out sign-in panel (Figma section 07: Sign-in Overlay Desktop, Tablet, Mobile).
 * Look and motion follow the landing menu (Menu.tsx, menu.css, motion.css): a dimmed and blurred page, an ivory glass
 * panel sliding in from the left (a full-screen sheet on mobile), Escape, backdrop click and Close dismiss it,
 * Tab stays inside, focus returns to the button that opened it. Open state lives in panel-store.ts.
 *
 * Every field starts prefilled with the dummy account (src/lib/auth.ts) so Log in completes the flow:
 * Loading (1.8 s) then Success, which signs in and goes to the page the visitor asked for (or /community).
 * Clearing a field shows Missing, a wrong password shows Invalid. Google and Apple have no destination in the design
 * (their Loading state only returns to Default after 2.4 s), so here they sign in with the dummy account after that wait.
 */
import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { takeNext } from '@/app-shell/AppShell';
import { Logo } from '@/components/Logo';
import { DUMMY, checkCredentials, signIn } from '@/lib/auth';
import { useScrollLock } from '@/lib/hooks';
import { Link, useNav } from '@/lib/nav';
import { closeSignIn, useSignInOpen } from './panel-store';
import { AuField, CloseGlyph, OrDivider, PrimaryButton, ShowToggle, SocialButton, type Provider } from './au-bits';
import '../../styles/auth.css';

/* ---------- static frames (routes /sign-in/state-*) ---------- */
export type SignInPreset = 'focus' | 'missing' | 'invalid' | 'loading' | 'success';
let preset: SignInPreset | null = null;
const presetListeners = new Set<() => void>();
/** Used by the static state routes: set before opening the panel, clear (null) when the route unmounts. */
export const setSignInPreset = (p: SignInPreset | null) => {
  preset = p;
  presetListeners.forEach((l) => l());
};
const usePreset = () =>
  useSyncExternalStore(
    (cb) => {
      presetListeners.add(cb);
      return () => {
        presetListeners.delete(cb);
      };
    },
    () => preset,
    () => null,
  );

/* ---------- timings ---------- */
/** Closing animation length in motion rules (menu-fade-out, menu-panel-out). */
const EXIT_MS = 280;
/** Figma: the Log in button stays in Loading about this long before Success. */
const LOADING_MS = 1800;
/** Figma Social Button Loading variant: AFTER_TIMEOUT 2.4 s. */
const PROVIDER_MS = 2400;
/** How long the Success frame stays before the panel closes and the page changes. */
const SUCCESS_MS = 700;

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])';

type Phase = 'idle' | 'loading' | 'success';
type Errors = { id: 'missing' | null; pw: 'missing' | 'wrong' | null };
const NO_ERRORS: Errors = { id: null, pw: null };

/** Values used by the static frames (same samples as the Figma frames). */
const SAMPLE_ID = 'ndegoyit';
const SAMPLE_PW = 'password123';

function initial(p: SignInPreset | null) {
  switch (p) {
    case 'focus':
      return { id: '', pw: '', phase: 'idle' as Phase, err: NO_ERRORS };
    case 'missing':
      return { id: '', pw: '', phase: 'idle' as Phase, err: { id: 'missing', pw: 'missing' } as Errors };
    case 'invalid':
      return { id: SAMPLE_ID, pw: SAMPLE_PW, phase: 'idle' as Phase, err: { id: null, pw: 'wrong' } as Errors };
    case 'loading':
      return { id: SAMPLE_ID, pw: SAMPLE_PW, phase: 'loading' as Phase, err: NO_ERRORS };
    case 'success':
      return { id: SAMPLE_ID, pw: SAMPLE_PW, phase: 'success' as Phase, err: NO_ERRORS };
    default:
      return { id: DUMMY.email, pw: DUMMY.password, phase: 'idle' as Phase, err: NO_ERRORS };
  }
}

export function SignInPanelHost() {
  const open = useSignInOpen();
  return open ? <SignInPanel /> : null;
}

function SignInPanel() {
  const forced = usePreset();
  // The static Loading and Success frames start in their state and no timer is armed, so they stay put.
  const start = useRef(initial(forced)).current;

  const nav = useNav();
  const root = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const closeBtn = useRef<HTMLButtonElement>(null);
  const idRef = useRef<HTMLInputElement>(null);
  const pwRef = useRef<HTMLInputElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  const closingRef = useRef(false);
  const timers = useRef<number[]>([]);

  const [id, setId] = useState(start.id);
  const [pw, setPw] = useState(start.pw);
  const [showPw, setShowPw] = useState(false);
  const [err, setErr] = useState<Errors>(start.err);
  const [phase, setPhase] = useState<Phase>(start.phase);
  const [provider, setProvider] = useState<Provider | null>(null);
  const [closing, setClosing] = useState(false);

  const later = useCallback((fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  }, []);
  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  };
  useEffect(() => () => clearTimers(), []);

  /** Plays the closing animation, then removes the panel. `after` runs once it is gone. */
  const requestClose = useCallback((restoreFocus = true, after?: () => void) => {
    if (closingRef.current) return;
    closingRef.current = true;
    const finish = () => {
      closeSignIn();
      if (restoreFocus) {
        const el = opener.current;
        if (el && document.contains(el)) el.focus();
      }
      if (after) window.requestAnimationFrame(after);
    };
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      finish();
      return;
    }
    setClosing(true);
    window.setTimeout(finish, EXIT_MS);
  }, []);

  /** Success: sign in with the account that was checked and go where the visitor was headed. */
  const complete = useCallback(() => {
    requestClose(false, () => {
      signIn();
      nav.push(takeNext('/community'));
    });
  }, [nav, requestClose]);

  // Lock page scroll, remember what opened the panel, move focus in, Escape and a Tab trap.
  useScrollLock(true);
  useEffect(() => {
    opener.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    // Static frames keep their look (no focus ring on Close); the live panel puts focus on Close like the menu does.
    (forced === 'focus' ? idRef.current : forced ? panelRef.current : closeBtn.current)?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        requestClose();
        return;
      }
      if (event.key !== 'Tab' || !root.current) return;
      const items = Array.from(root.current.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((el) => el.offsetParent !== null);
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || !root.current.contains(active))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (active === last || !root.current.contains(active))) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [requestClose, forced]);

  const busy = phase !== 'idle' || provider !== null;

  const submit = () => {
    if (busy) return;
    const idMissing = !id.trim();
    const pwMissing = !pw;
    if (idMissing || pwMissing) {
      setErr({ id: idMissing ? 'missing' : null, pw: pwMissing ? 'missing' : null });
      (idMissing ? idRef : pwRef).current?.focus();
      return;
    }
    setErr(NO_ERRORS);
    setPhase('loading');
    later(() => {
      if (checkCredentials(id, pw) === 'ok') {
        setPhase('success');
        later(complete, SUCCESS_MS);
      } else {
        setPhase('idle');
        setErr({ id: null, pw: 'wrong' });
        pwRef.current?.focus();
      }
    }, LOADING_MS);
  };

  const startProvider = (p: Provider) => {
    if (busy) return;
    setErr(NO_ERRORS);
    setProvider(p);
    later(complete, PROVIDER_MS);
  };

  const differentAccount = () => {
    clearTimers();
    setId('');
    setPw('');
    setErr(NO_ERRORS);
    setPhase('idle');
    window.requestAnimationFrame(() => idRef.current?.focus());
  };

  const toJoin = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    e.preventDefault();
    requestClose(false, () => nav.push('/join'));
  };

  const success = phase === 'success';
  const idField = (
    <AuField
      key="id"
      label="Mobile number, username or email"
      value={id}
      inputRef={idRef}
      placeholder="e.g. @ndegoyit or 0803 123 4567"
      autoComplete="username"
      verified={success}
      readOnly={success}
      message={err.id === 'missing' ? 'Enter your mobile number, username or email.' : undefined}
      onChange={(v) => {
        setId(v);
        if (err.id) setErr((e) => ({ ...e, id: null }));
      }}
    />
  );

  return (
    <div
      ref={root}
      className="au-root"
      role="dialog"
      aria-modal="true"
      aria-labelledby="au-panel-title"
      data-closing={closing ? '' : undefined}
    >
      <div className="au-backdrop" onClick={() => requestClose()} aria-hidden="true" />
      <div ref={panelRef} className="au-panel" tabIndex={-1}>
        <h2 id="au-panel-title" className="sr-only">
          Sign in to Akines
        </h2>
        <div className="au-head">
          <button ref={closeBtn} type="button" className="au-close" onClick={() => requestClose()} aria-label="Close">
            <CloseGlyph size={20} />
            <span className="au-close__label" aria-hidden="true">
              Close
            </span>
          </button>
          <Logo className="au-head__logo" />
          <span className="au-head__spacer" aria-hidden="true" />
        </div>
        <div className="au-rule" />
        <div className="au-gap au-gap--a" />

        <form
          className="au-form"
          noValidate
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <div className="au-form__main">
            {idField}
            <AuField
              key="pw"
              label="Password"
              value={pw}
              inputRef={pwRef}
              type={showPw ? 'text' : 'password'}
              placeholder="Enter your password"
              autoComplete="current-password"
              message={
                err.pw === 'missing' ? 'Enter your password.' : err.pw === 'wrong' ? "That password doesn't match this account." : undefined
              }
              action={<ShowToggle shown={showPw} onToggle={() => setShowPw((s) => !s)} />}
              onChange={(v) => {
                setPw(v);
                if (err.pw) setErr((e) => ({ ...e, pw: null }));
              }}
            />
            {success ? (
              <>
                <div className="au-slot">
                  <p className="au-slot__label">Next step</p>
                  <p className="au-slot__body">Reserved for the next authentication step, once it is confirmed.</p>
                </div>
                <button type="button" className="au-link au-link--start" onClick={differentAccount}>
                  Use a different account
                </button>
              </>
            ) : (
              <>
                <PrimaryButton label="Log in" type="submit" loading={phase === 'loading'} />
                {/* No destination in the design yet */}
                <button type="button" className="au-link au-forgot">
                  Forgot password?
                </button>
              </>
            )}
          </div>

          {success ? null : (
            <>
              <div className="au-social-block" data-dim={phase === 'loading' ? '' : undefined}>
                <OrDivider />
                <div className="au-providers">
                  <SocialButton provider="google" loading={provider === 'google'} onClick={() => startProvider('google')} />
                  <SocialButton provider="apple" loading={provider === 'apple'} onClick={() => startProvider('apple')} />
                </div>
              </div>
              <p className="au-prompt">
                <span>Don&apos;t have an account?</span>
                <Link href="/join" className="au-link au-link--inline" onClick={toJoin}>
                  Create an account
                </Link>
              </p>
            </>
          )}
        </form>

        <div className="au-gap au-gap--b" />
        <p className="au-tagline">Less scrolling. More belonging.</p>
      </div>
    </div>
  );
}
