'use client';

/**
 * Building blocks of the application stage pages (Figma 12.44): the two column layout with its heading, Next Steps Panel,
 * Request Summary, Talk Card, Offer Card, Slot Picker (with Day Tab and Slot Chip) and the end state layout.
 * Classes are prefixed apl-; the end states reuse the dsc- classes of "Interest sent" (projects.css), which they match in Figma.
 */
import './applications.css';
import type { ReactNode } from 'react';
import { Button } from '@/ui';
import { asset } from '@/lib/assets';
import { BackLink } from '../projects/ui';
import type { Interest } from '../projects/store';
import { OTHER_ROLE, interestDefaults, DESIGNED_SLUG } from '../projects/data';
import { DAYS, dayOf, pickFull, type DayKey, type Pick } from './data';
import { StatusPill, type ApplicationStatus } from './shared';

/** Ngozi's round photo of the Request Summary and Offer Card (Figma "Photo / ngozi") and the large photograph of the end states (hash cb6ee846). */
const AVATAR = '/images/app/community/av-ngozi.jpg';
export const END_PHOTO = '/images/app/collab-projects/ngozi-eze.jpg';

/** The role the request is for ("Product Designer" unless the person picked another one in Express interest). */
export const roleOf = (interest: Interest | undefined) => {
  const role = interest?.role;
  return role && role !== OTHER_ROLE ? role : interestDefaults(DESIGNED_SLUG).role;
};

/* ------------------------------------------------------------------ page layout */

/** Page with the main column (880) and the side column (440), 64 apart. */
export function RequestLayout({ back, head, side, children }: { back: { href: string; label: string }; head: ReactNode; side: ReactNode; children?: ReactNode }) {
  return (
    <div className="apl-page">
      <div className="apl-layout">
        <div className="apl-main">
          <BackLink href={back.href}>{back.label}</BackLink>
          {head}
          {children}
        </div>
        <aside className="apl-side">{side}</aside>
      </div>
    </div>
  );
}

/** Heading block: the headline (48) and the support line under it, 36 px below the back link. */
export function RequestHead({ title, lead }: { title: string; lead: string }) {
  return (
    <header className="apl-head">
      <h1 className="apl-h1" data-m="words">
        {title}
      </h1>
      <p className="apl-lead" data-m="up">
        {lead}
      </p>
    </header>
  );
}

/** Next Steps Panel (Figma 17972:147480): serif title and three numbered lines. */
export function NextSteps({ title, lines }: { title: string; lines: [string, string, string] }) {
  return (
    <section className="apl-panel" aria-label={title} data-m="up">
      <h2 className="apl-panel__title">{title}</h2>
      <ol className="apl-panel__lines">
        {lines.map((line, i) => (
          <li key={i} className="apl-panel__line">
            <span className="apl-panel__num" aria-hidden="true">
              {i + 1}
            </span>
            <span className="apl-panel__text">{line}</span>
          </li>
        ))}
      </ol>
    </section>
  );
}

/* ------------------------------------------------------------------ cards */

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="apl-fact">
      <dt className="apl-label">{label}</dt>
      <dd className="apl-fact__value">{value}</dd>
    </div>
  );
}

/** Request Summary (Figma 17972:147394): who, role, availability, when it was sent and the note. */
export function RequestSummary({ interest, status }: { interest: Interest; status: ApplicationStatus }) {
  return (
    <section className="apl-card" aria-label="Your request" data-m="up">
      <div className="apl-card__head">
        <img className="apl-card__avatar apl-card__avatar--lg" src={asset(AVATAR)} alt="" width={72} height={72} decoding="async" />
        <div className="apl-card__info">
          <p className="apl-label">Your request to join</p>
          <p className="apl-card__title">A Better Way to Learn</p>
          <p className="apl-card__sub">Led by Ngozi Eze, Lagos</p>
        </div>
        <StatusPill status={status} />
      </div>
      <hr className="apl-rule" />
      <dl className="apl-facts">
        <Fact label="Role" value={roleOf(interest)} />
        <Fact label="Availability" value={interest.time} />
        <Fact label="Sent" value="Thu 5 Nov" />
      </dl>
      {interest.message ? (
        <>
          <hr className="apl-rule" />
          <div className="apl-noteblock">
            <p className="apl-label">Your note</p>
            <p className="apl-noteblock__text">{interest.message}</p>
          </div>
        </>
      ) : null}
    </section>
  );
}

/** Talk Card (Figma 17972:147455): the booked date and time, length, where, with whom. */
export function TalkCard({ pick }: { pick: Pick }) {
  const day = dayOf(pick.day);
  return (
    <section className="apl-card" aria-label="Your talk" data-m="up">
      <div className="apl-card__head apl-card__head--top">
        <div className="apl-when">
          <p className="apl-label">Your talk with Ngozi</p>
          <p className="apl-when__date">
            {day.weekday} {day.date}
          </p>
          <p className="apl-when__time">{day.slots[pick.slot].time} WAT</p>
        </div>
        <StatusPill status="Talk booked" />
      </div>
      <hr className="apl-rule" />
      <dl className="apl-facts">
        <Fact label="Length" value="20 minutes" />
        <Fact label="Where" value="Video call" />
        <Fact label="With" value="Ngozi Eze" />
      </dl>
      <p className="apl-card__note">The call link is ready when it is time. You will find it here and in your messages.</p>
    </section>
  );
}

/** Offer Card (Figma 17972:147422): the offer with role, hours, start date and Ngozi's note. */
export function OfferCard({ role }: { role: string }) {
  return (
    <section className="apl-card" aria-label="Your offer" data-m="up">
      <div className="apl-card__head">
        <img className="apl-card__avatar" src={asset(AVATAR)} alt="" width={56} height={56} decoding="async" />
        <div className="apl-card__info">
          <p className="apl-label">Offer from Ngozi Eze</p>
          <p className="apl-card__title">A Better Way to Learn</p>
        </div>
        <StatusPill status="Offer received" />
      </div>
      <hr className="apl-rule" />
      <dl className="apl-facts">
        <Fact label="Role" value={role} />
        <Fact label="Hours" value="6 hours a week, agreed together" />
        <Fact label="Start date" value="Mon 23 Nov" />
        <Fact label="Sent" value="Thu 12 Nov" />
      </dl>
      <hr className="apl-rule" />
      <div className="apl-noteblock apl-noteblock--offer">
        <p className="apl-label">A note from Ngozi</p>
        <p className="apl-noteblock__quote">We loved your onboarding sketches. We would be glad to have you on the team.</p>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ slot picker */

const IconCheck = () => (
  <svg width={14} height={14} viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth={0.875} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path transform="translate(2.3333 3.5)" d="M9.3333 0L2.9167 6.4167L0 3.5" />
  </svg>
);

/**
 * Slot Picker (Figma 17972:144663): Ngozi's three days (Day Tab), the times of the chosen day (Slot Chip), the summary and Confirm time.
 * Changing the day clears the time, as the Figma variants do. Times Ngozi has taken are shown greyed out and cannot be chosen.
 */
export function SlotPicker({ day, slot, onDay, onSlot, onConfirm }: { day: DayKey; slot: number | null; onDay: (d: DayKey) => void; onSlot: (i: number) => void; onConfirm: () => void }) {
  const current = dayOf(day);
  const picked: Pick | null = slot === null ? null : { day, slot };
  return (
    <section className="apl-card apl-picker" aria-label="Available times" data-m="up">
      <header className="apl-picker__head">
        <h2 className="apl-picker__heading">Ngozi&apos;s available times</h2>
        <p className="apl-picker__support">Choose one time. You can change it later.</p>
      </header>
      <div className="apl-days" role="group" aria-label="Day">
        {DAYS.map((d) => (
          <button key={d.key} type="button" className="apl-day" aria-pressed={d.key === day} data-selected={d.key === day || undefined} onClick={() => d.key !== day && onDay(d.key)}>
            <span className="apl-day__weekday">{d.weekday}</span>
            <span className="apl-day__date">{d.date}</span>
            {d.key === day ? <i className="apl-day__bar" aria-hidden="true" /> : null}
          </button>
        ))}
      </div>
      <div className="apl-slots" role="group" aria-label={`Times on ${current.weekday} ${current.date}`}>
        {current.slots.map((s, i) => (
          <button
            key={s.time}
            type="button"
            className="apl-slot"
            aria-pressed={slot === i}
            data-selected={slot === i || undefined}
            disabled={s.unavailable}
            onClick={() => onSlot(i)}
          >
            {slot === i ? <IconCheck /> : null}
            <span>{s.time}</span>
          </button>
        ))}
      </div>
      <hr className="apl-rule" />
      <div className="apl-picker__foot">
        <p className="apl-picker__summary" data-chosen={picked ? 'true' : undefined} aria-live="polite">
          {picked ? pickFull(picked) : 'Choose a time to continue.'}
        </p>
        <Button disabled={!picked} onClick={onConfirm}>
          Confirm time
        </Button>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ end states */

/**
 * End state (Figma Joined, Offer declined, Not selected, Withdrawn): the "Interest sent" layout, text and request card on the left,
 * Ngozi's photograph flush to the right edge.
 */
export function EndState({
  eyebrow,
  title,
  lead,
  meta,
  status,
  note,
  children,
}: {
  eyebrow: string;
  title: string;
  lead: string;
  meta: string;
  status: ApplicationStatus;
  note: string;
  children: ReactNode;
}) {
  return (
    <div className="dsc-sent">
      <div className="dsc-sent__content">
        <p className="dsc-eyebrow" data-m="up">
          {eyebrow}
        </p>
        <h1 className="dsc-h1 dsc-h1--sent" data-m="words">
          {title}
        </h1>
        <p className="dsc-lead" data-m="up">
          {lead}
        </p>
        <section className="dsc-request" aria-label="Your request" data-m="up">
          <div className="dsc-request__row">
            <img className="dsc-portrait" src={asset(END_PHOTO)} alt="" width={64} height={64} loading="lazy" decoding="async" />
            <div className="dsc-request__info">
              <p className="dsc-request__name">A Better Way to Learn</p>
              <p className="dsc-request__meta">{meta}</p>
            </div>
            <StatusPill status={status} />
          </div>
          <hr className="dsc-request__rule" />
          <p className="dsc-request__note">{note}</p>
        </section>
        <div className="dsc-actions">{children}</div>
      </div>
      <div className="dsc-sent__photo" data-m="frame">
        <img className="cover" src={asset(END_PHOTO)} alt="" decoding="async" />
      </div>
    </div>
  );
}
