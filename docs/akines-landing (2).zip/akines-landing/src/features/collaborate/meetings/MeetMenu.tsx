'use client';

import './meetings.css';
import { useState } from 'react';
import { useNav } from '@/lib/nav';
import { Button, Menu } from '@/ui';
import { ChevronDown } from '../workspace/atoms';
import { useProject } from '../workspace/project';
import { ScheduleModal } from './ScheduleModal';
import { meetings, meetPaths } from './store';

/**
 * The Meet button of the conversation header with its menu (Figma Dropdown:Meet 17808:109947): Start a meeting now starts one for everyone and opens
 * its lobby; Schedule for later opens the Schedule meeting modal. `forceOpen` is for the state frame (not used by the page itself).
 */
export function MeetMenu() {
  const nav = useNav();
  const { key, root } = useProject();
  const [schedule, setSchedule] = useState(false);
  return (
    <>
      <Menu
        align="end"
        trigger={(p) => (
          <Button {...p} variant="secondary" size="sm" iconRight={<ChevronDown />}>
            Meet
          </Button>
        )}
        items={[
          {
            label: 'Start a meeting now',
            description: 'Meet with the team right away.',
            onSelect: () => {
              meetings.startNow(key);
              nav.push(meetPaths(root).lobby);
            },
          },
          { label: 'Schedule for later', description: 'Pick a time and invite the team.', onSelect: () => setSchedule(true) },
        ]}
      />
      <ScheduleModal open={schedule} onClose={() => setSchedule(false)} />
    </>
  );
}
