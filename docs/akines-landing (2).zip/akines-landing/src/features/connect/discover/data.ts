/**
 * Connect / Discover: all copy, images, ids and link targets (PRD "Connect / Discover" and Figma section 11).
 * Plain module on purpose (no 'use client'): the route table, the state store and the analytics module all read it.
 * Images are named here (folder under public/images/app and file name without extension) and resolved with src() in images.ts.
 * Ids are stable and unique across the page. They are what the state store and the analytics events carry, never names or text.
 */
import { DESIGNED_SLUG } from '@/features/collaborate/projects/data';

export { ERROR_COPY, LOADING_MS, LOADING_NOTE } from '@/features/community/feed/content';

/** Image reference: folder under public/images/app and file name without extension (same convention as the community feed, plus `discover`). */
export type DiscoverImg = `${'feed' | 'community' | 'discover' | 'workspace'}/${string}`;

/** How long "Try again" shows the skeleton before the recommendations section comes back, in ms (same as the community feed). */
export const RETRY_MS = 900;

/* ---------------------------------------------------------------- destinations (the Figma links; everything else is plain) */
export const DEST = {
  /** Explore, People */
  people: '/collaborate/collaborators',
  /** Explore, Projects */
  projects: '/collaborate/discover',
  /** Explore, Artworks & Stores, and the Buy button of the artwork card */
  makeSell: '/make-sell',
  /** The project detail that Collaborate "Discover projects" uses for A Better Way to Learn */
  betterWay: `/collaborate/projects/${DESIGNED_SLUG}`,
} as const;

/**
 * The pages the Discover cards and links lead to (Figma 11.66 to 11.73, tab URL tails). KinCircle (11.11 to 11.65) is design only, so
 * every circle card, "Your circles" row and the Circles category card stay plain controls: there is no path for them here.
 */
export const PATHS = {
  discover: '/connect',
  explore: '/connect/explore',
  forYou: '/connect/for-you',
  interests: '/connect/interests',
  /** The one interest page: every interest card opens it */
  interest: '/connect/interests/visual-arts',
  events: '/connect/events',
  /** The one event page: every event card opens it */
  event: '/connect/events/memory-and-cloth',
  suggestions: '/connect/discover/suggestions',
  startProject: '/collaborate/start',
} as const;
/** "Anaya Smith" becomes "anaya-smith", the tail of the profile URL. */
export const slugOf = (name: string) => name.toLowerCase().replace(/[^a-z]+/g, '-').replace(/^-|-$/g, '');
export const profilePath = (slug: string) => `/connect/people/${slug}`;

/* ---------------------------------------------------------------- sections */
/** The four sections in page order. */
export type SectionId = 'explore' | 'for-you' | 'interests' | 'recommendations';
export const SECTION_ORDER: readonly SectionId[] = ['explore', 'for-you', 'interests', 'recommendations'];
/** DOM ids: `id` is the <section> id (also the scroll target), `titleId` the heading id for aria-labelledby. */
export const SECTION_DOM: Record<SectionId, { id: string; titleId: string }> = {
  explore: { id: 'dx-explore', titleId: 'dx-title-explore' },
  'for-you': { id: 'dx-for-you', titleId: 'dx-title-for-you' },
  interests: { id: 'dx-interests', titleId: 'dx-title-interests' },
  recommendations: { id: 'dx-recommendations', titleId: 'dx-title-recommendations' },
};

/**
 * Section header copy. `link` is the label of the underlined right-aligned link and `href` where it goes (Figma 11.1 wiring).
 * Explore has no link in the design: its whole header row is the link to Explore all (`href` alone).
 */
export type SectionCopy = { title: string; support: string; link?: string; href?: string };
export const HEADS: Record<SectionId, SectionCopy> = {
  // Explore has a heading only (no support line); the header row leads to Explore all
  explore: { title: 'Explore', support: '', href: PATHS.explore },
  'for-you': {
    title: 'For you on Akines',
    support: 'A mix of people, circles, projects and stories based on your interests and activity.',
    link: 'Explore all',
    href: PATHS.forYou,
  },
  interests: {
    title: 'Explore by interest',
    support: 'Dive into what moves you. Find people, circles and content around the things you love.',
    link: 'Explore all',
    href: PATHS.interests,
  },
  recommendations: { title: 'People whose journeys complement yours', support: 'Meet people for a reason, not by chance.', link: 'See all', href: PATHS.suggestions },
};

/* ---------------------------------------------------------------- 01 Explore */
export type ExploreId = 'people' | 'circles' | 'stores' | 'projects' | 'events';
/** `href` is missing where the category has no destination (Circles: KinCircle is design only, so the card is a plain control). */
export type ExploreCategory = { id: ExploreId; title: string; text: string; image: DiscoverImg; href?: string };
export const EXPLORE: ExploreCategory[] = [
  { id: 'people', title: 'People', text: 'Artists, creators and kindred spirits.', image: 'community/av-ngozi', href: DEST.people },
  { id: 'circles', title: 'Circles', text: 'Communities and shared interests.', image: 'community/av-kincircle' },
  { id: 'stores', title: 'Artworks & Stores', text: "Original work that's made-to-order.", image: 'discover/explore-stores', href: DEST.makeSell },
  { id: 'projects', title: 'Projects', text: 'Collaborations and creative builds.', image: 'community/zine', href: DEST.projects },
  { id: 'events', title: 'Events', text: 'Talks, workshops and gatherings.', image: 'discover/event-workshop', href: PATHS.events },
];

/** Explore all (Figma 11.66): the header, the search field (plain: no results are designed) and the same five cards in a grid. */
export const EXPLORE_PAGE = {
  title: 'Explore',
  support: 'Find people, circles, work, projects and events.',
  back: 'Back to Discover',
  search: 'Search people, circles, work and events',
};

/* ---------------------------------------------------------------- 02 For you on Akines */
export type ForYouFilter = 'all' | 'people' | 'circles' | 'projects' | 'studio-visits' | 'stories' | 'events';
export const FILTERS: { key: ForYouFilter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'people', label: 'People' },
  { key: 'circles', label: 'Circles' },
  { key: 'projects', label: 'Projects' },
  { key: 'studio-visits', label: 'Studio Visits' },
  { key: 'stories', label: 'Stories' },
  { key: 'events', label: 'Events' },
];
export const isForYouFilter = (v: string): v is ForYouFilter => FILTERS.some((f) => f.key === v);

/** Person card. Button "Connect", after pressing "Requested". */
export type PersonCard = {
  kind: 'person';
  id: string;
  name: string;
  image: DiscoverImg;
  /** "Textile artist · Ibadan" */
  identity: string;
  text: string;
  /** "126 Kin connections" */
  connections: string;
  /** The profile page of this person (Figma 11.73) */
  href: string;
};
export type CircleAccess = 'open' | 'approval';
/** Circle card. Open circles: "Join" then "Joined". Approval circles: "Request to join" with the note "Approval needed" then "Requested". */
export type CircleCard = {
  kind: 'circle';
  id: string;
  name: string;
  image: DiscoverImg;
  /** "416 members · 6 active" */
  meta: string;
  text: string;
  access: CircleAccess;
};
/** Artwork card. Button "Buy" goes to the Make & Sell page. */
export type ArtworkCard = {
  kind: 'artwork';
  id: string;
  /** "CERAMICS" */
  tag: string;
  title: string;
  maker: string;
  makerImage: DiscoverImg;
  /** The maker row leads to the maker's profile */
  makerHref: string;
  price: string;
  /** "1 of 1" */
  edition: string;
  image: DiscoverImg;
  action: string;
  href: string;
};
/** Project, studio visit, story and event cards share one shape. `tag` is PROJECT, STUDIO VISIT, STORY or the event date; `meta` is the line under the text. */
export type ContentCard = {
  kind: 'project' | 'studio' | 'story' | 'event';
  id: string;
  tag: string;
  title: string;
  text: string;
  meta: string;
  image: DiscoverImg;
  action: string;
  /** Only A Better Way to Learn has a destination; the others are plain. */
  href?: string;
};
export type ForYouCard = PersonCard | CircleCard | ArtworkCard | ContentCard;
export type CardType = ForYouCard['kind'];

/** Button copy of the cards that change local state. */
export const CARD_COPY = {
  person: { action: 'Connect', done: 'Requested' },
  circle: {
    open: { action: 'Join', done: 'Joined' },
    approval: { action: 'Request to join', done: 'Requested', note: 'Approval needed' },
  },
} as const;
/** Label of the circle button before and after pressing, and the note under it where the circle needs approval. */
export const circleCopy = (c: CircleCard): { action: string; done: string; note?: string } => CARD_COPY.circle[c.access];

const person = (id: string, name: string, image: DiscoverImg, identity: string, text: string, connections: string): PersonCard => ({
  kind: 'person', id: `person-${id}`, name, image, identity, text, connections, href: profilePath(slugOf(name)),
});
const circle = (id: string, name: string, image: DiscoverImg, meta: string, text: string, access: CircleAccess): CircleCard => ({
  kind: 'circle', id: `circle-${id}`, name, image, meta, text, access,
});

export const PEOPLE_CARDS: PersonCard[] = [
  person('anaya', 'Anaya Smith', 'discover/person-anaya', 'Textile artist · Ibadan', 'Exploring memory, fabric and the everyday.', '126 Kin connections'),
  person('tunde', 'Tunde Bakare', 'community/av-tunde', 'Community health designer · Abuja', 'Designing care that begins with listening.', '84 Kin connections'),
  person('ngozi', 'Ngozi Eze', 'community/av-ngozi', 'Writer and zine maker · Lagos', 'Writing small books about the places we pass through.', '212 Kin connections'),
  person('amara', 'Amara Okafor', 'community/av-amara', 'Visual artist · Abuja', 'Painting rooms where conversations happen.', '97 Kin connections'),
  person('folake', 'Folake Adeniran', 'community/av-folake', 'Storyteller · Lagos', 'Collecting the stories families tell at the table.', '143 Kin connections'),
  person('chuka', 'Chuka Nwosu', 'community/av-chuka', 'Founder and maker · Port Harcourt', 'Building tools for small workshops.', '61 Kin connections'),
];

export const CIRCLE_CARDS: CircleCard[] = [
  circle('textiles', 'Textiles & Adire', 'feed/circle-textiles', '416 members · 6 active', 'A community for lovers of indigo, dyeing and fabric culture.', 'open'),
  circle('poetry', 'Poetry and Wine talk', 'feed/circle-poetry', '20 members · 4 active', 'Slow evenings of verse, wine and good company.', 'approval'),
  circle('makers', 'Lagos Makers', 'community/zine', '310 members · 12 active', 'Makers sharing process, tools and Saturday studio notes.', 'open'),
  circle('health', 'Community Health Circle', 'community/health', '128 members · 9 active', 'Practical conversations about care in our neighbourhoods.', 'approval'),
  circle('university', 'University friends', 'community/kincircle', '54 members · 7 active', 'A circle for staying close after graduation.', 'open'),
  circle('food', 'Food Systems Cliq', 'feed/journal-2', '72 members · 5 active', 'Talking about food, farming and fair prices.', 'open'),
];

export const ARTWORK: ArtworkCard = {
  kind: 'artwork',
  id: 'artwork-vase',
  tag: 'CERAMICS',
  title: 'Firing day vase',
  maker: 'Thandi Dlamini',
  makerImage: 'workspace/ayo',
  makerHref: profilePath('thandi-dlamini'),
  price: '$10,000',
  edition: '1 of 1',
  image: 'feed/product-3',
  action: 'Buy',
  href: DEST.makeSell,
};

export const PROJECT_CARDS: ContentCard[] = [
  {
    kind: 'project', id: 'project-better-way', tag: 'PROJECT', title: 'A Better Way to Learn',
    text: 'A digital learning initiative exploring more accessible ways for students to learn.',
    meta: 'Ngozi Eze · 2 people', image: 'feed/journal-1', action: 'View project', href: DEST.betterWay,
  },
  {
    kind: 'project', id: 'project-zine', tag: 'PROJECT', title: 'Lagos Makers Zine',
    text: 'A shared zine collecting maker stories from across the city.',
    meta: 'Obinna Adeyemi · 3 people', image: 'community/zine', action: 'View project',
  },
  {
    kind: 'project', id: 'project-health', tag: 'PROJECT', title: 'Community Health Initiative',
    text: 'Mapping simple, trusted health information for neighbourhoods.',
    meta: 'Amara Okafor · 4 people', image: 'community/health', action: 'View project',
  },
];

export const STUDIO_CARDS: ContentCard[] = [
  { kind: 'studio', id: 'studio-tunde', tag: 'STUDIO VISIT', title: "Tunde's studio", text: 'Ceramics, clay and slow making in Ibadan.', meta: 'Ibadan · Saturdays', image: 'feed/studio-1', action: 'Request a visit' },
  { kind: 'studio', id: 'studio-chidi', tag: 'STUDIO VISIT', title: "Chidi's studio", text: 'Weaving and natural dyes in Abuja.', meta: 'Abuja · By appointment', image: 'feed/studio-2', action: 'Request a visit' },
  { kind: 'studio', id: 'studio-amina', tag: 'STUDIO VISIT', title: "Amina's studio", text: 'Printmaking and paper in Lagos.', meta: 'Lagos · Fridays', image: 'feed/studio-3', action: 'Request a visit' },
];

export const STORY_CARDS: ContentCard[] = [
  { kind: 'story', id: 'story-dye-yard', tag: 'STORY', title: 'The dye yard in Ibadan', text: 'Anaya Smith follows the cloth from the vat to the line.', meta: 'By Anaya Smith', image: 'feed/story-1', action: 'Read story' },
  { kind: 'story', id: 'story-saturday', tag: 'STORY', title: 'A year of Saturday studios', text: 'What changed when one studio opened its doors every week.', meta: 'By Tunde Bakare', image: 'feed/story-2', action: 'Read story' },
  { kind: 'story', id: 'story-loom', tag: 'STORY', title: 'What the loom remembers', text: 'A weaver on patterns passed down and patterns broken.', meta: 'By Ngozi Eze', image: 'feed/story-3', action: 'Read story' },
];

export const EVENT_CARDS: ContentCard[] = [
  { kind: 'event', id: 'event-talk', tag: 'SAT 22 NOV · 4:00 PM', title: 'Memory and Cloth: an artist talk', text: 'Anaya Smith in conversation about textiles and memory.', meta: 'Lagos · In person', image: 'discover/event-talk', action: 'View event', href: PATHS.event },
  { kind: 'event', id: 'event-indigo', tag: 'SUN 23 NOV · 10:00 AM', title: 'Indigo dye day', text: 'A hands-on morning with natural indigo.', meta: 'Ibadan · In person', image: 'discover/event-workshop', action: 'View event', href: PATHS.event },
  { kind: 'event', id: 'event-open-studio', tag: 'SAT 29 NOV · 2:00 PM', title: 'Open studio afternoon', text: 'Meet the makers and see work in progress.', meta: 'Abuja · In person', image: 'discover/event-open-studio', action: 'View event', href: PATHS.event },
];

/** The cards of each filter, in display order (grids of 3 columns). "All" mixes the kinds and is the only list with the artwork. */
export const FOR_YOU: Record<ForYouFilter, ForYouCard[]> = {
  all: [PEOPLE_CARDS[0], CIRCLE_CARDS[0], ARTWORK, PROJECT_CARDS[0], STUDIO_CARDS[0], STORY_CARDS[0], EVENT_CARDS[0], PEOPLE_CARDS[1], CIRCLE_CARDS[1]],
  people: PEOPLE_CARDS,
  circles: CIRCLE_CARDS,
  projects: PROJECT_CARDS,
  'studio-visits': STUDIO_CARDS,
  stories: STORY_CARDS,
  events: EVENT_CARDS,
};

/* ---------------------------------------------------------------- For you, all (Figma 11.67) */
/** The 18 cards of the For you page, as drawn: three columns, six rows. */
export const FOR_YOU_ALL: ForYouCard[] = [
  PEOPLE_CARDS[0], CIRCLE_CARDS[0], ARTWORK,
  PROJECT_CARDS[0], STUDIO_CARDS[0], STORY_CARDS[0],
  EVENT_CARDS[0], PEOPLE_CARDS[1], CIRCLE_CARDS[1],
  PROJECT_CARDS[1], PEOPLE_CARDS[2], STORY_CARDS[1],
  STUDIO_CARDS[1], EVENT_CARDS[1], CIRCLE_CARDS[2],
  PEOPLE_CARDS[3], EVENT_CARDS[2], CIRCLE_CARDS[3],
];
const KIND_OF_FILTER: Record<Exclude<ForYouFilter, 'all'>, ForYouCard['kind']> = {
  people: 'person', circles: 'circle', projects: 'project', 'studio-visits': 'studio', stories: 'story', events: 'event',
};
/**
 * The cards a chip of the For you page shows. Figma draws one result frame for Studio Visits: No results (11.67 / No results). The other
 * chips have no frame, so they filter the 18 cards by kind.
 */
export const forYouAllCards = (filter: ForYouFilter): ForYouCard[] =>
  filter === 'all' ? FOR_YOU_ALL : filter === 'studio-visits' ? [] : FOR_YOU_ALL.filter((c) => c.kind === KIND_OF_FILTER[filter]);
/** "No studio visits to show right now. Try another filter, or come back soon." */
export const forYouEmptyText = (filter: ForYouFilter) => {
  const label = FILTERS.find((f) => f.key === filter)?.label ?? filter;
  return `No ${label.toLowerCase()} to show right now. Try another filter, or come back soon.`;
};
export const FOR_YOU_PAGE = {
  back: 'Back to Discover',
  empty: { link: 'Show all of For you' },
};

/* ---------------------------------------------------------------- Interest page (Figma 11.69, Visual Arts) */
export const YUSUF_CARD: PersonCard = person('yusuf', 'Yusuf Umar', 'workspace/yusuf', 'Multidisciplinary artist · Kwara', 'Making work across sound, craft and collaboration.', '73 Kin connections');
/** The eight cards of Visual Arts, as drawn: three columns, three rows. */
export const INTEREST_CARDS: ForYouCard[] = [
  PEOPLE_CARDS[3], CIRCLE_CARDS[0], EVENT_CARDS[0],
  PEOPLE_CARDS[0], CIRCLE_CARDS[2], EVENT_CARDS[1],
  YUSUF_CARD, EVENT_CARDS[2],
];
export type InterestFilter = 'all' | 'people' | 'circles' | 'projects' | 'events';
export const INTEREST_FILTERS: { key: InterestFilter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'people', label: 'People' },
  { key: 'circles', label: 'Circles' },
  { key: 'projects', label: 'Projects' },
  { key: 'events', label: 'Events' },
];
const KIND_OF_INTEREST: Record<Exclude<InterestFilter, 'all'>, ForYouCard['kind']> = { people: 'person', circles: 'circle', projects: 'project', events: 'event' };
/** Figma draws one result frame: Projects gives No results. People, Circles and Events filter the eight cards by kind. */
export const interestCards = (filter: InterestFilter): ForYouCard[] =>
  filter === 'all' ? INTEREST_CARDS : filter === 'projects' ? [] : INTEREST_CARDS.filter((c) => c.kind === KIND_OF_INTEREST[filter]);
export const INTEREST_PAGE = {
  back: 'Back to Discover',
  /** Shown when Projects is selected */
  empty: { text: 'No projects in Visual Arts yet. Start one and invite collaborators.', link: 'Start a project', href: PATHS.startProject },
};

/* ---------------------------------------------------------------- Events (Figma 11.70) */
export type EventFilter = 'week' | 'month' | 'online' | 'in-person';
/** An event of the list: the card plus what the chips look at. */
export type EventListing = ContentCard & { kind: 'event'; month: boolean; week: boolean; online: boolean };
const more = (c: Omit<EventListing, 'kind' | 'action' | 'href'>): EventListing => ({ ...c, kind: 'event', action: 'View event', href: PATHS.event });
/** The six events, as drawn. The first three are the cards of For you; "Online" is the meta line of the two online events. */
export const EVENTS: EventListing[] = [
  { ...EVENT_CARDS[0], kind: 'event', month: true, week: false, online: false },
  { ...EVENT_CARDS[1], kind: 'event', month: true, week: false, online: false },
  more({ id: 'event-reading', tag: 'THU 27 NOV · 6:30 PM', title: 'Writing the everyday: a reading', text: 'Four writers read short pieces about ordinary days.', meta: 'Online', image: 'feed/hero-card-6', month: true, week: false, online: true }),
  { ...EVENT_CARDS[2], kind: 'event', month: true, week: false, online: false },
  more({ id: 'event-zine', tag: 'SAT 6 DEC · 11:00 AM', title: 'Zine making for beginners', text: 'Fold, cut and print a first zine in one morning.', meta: 'Lagos · In person', image: 'community/zine-tall', month: false, week: false, online: false }),
  more({ id: 'event-poetry-evening', tag: 'FRI 12 DEC · 7:00 PM', title: 'Poetry and wine evening', text: 'Slow readings, an open mic and good company.', meta: 'Online', image: 'feed/circle-poetry', month: false, week: false, online: true }),
];
export const EVENT_FILTERS: { key: EventFilter; label: string }[] = [
  { key: 'week', label: 'This week' },
  { key: 'month', label: 'This month' },
  { key: 'online', label: 'Online' },
  { key: 'in-person', label: 'In person' },
];
/** No chip selected shows all six. Figma draws one result frame: This week gives No results. The other chips filter by the facts above. */
export const eventsFor = (filter: EventFilter | null): EventListing[] => {
  switch (filter) {
    case null: return EVENTS;
    case 'week': return EVENTS.filter((e) => e.week);
    case 'month': return EVENTS.filter((e) => e.month);
    case 'online': return EVENTS.filter((e) => e.online);
    case 'in-person': return EVENTS.filter((e) => !e.online);
  }
};
export const EVENTS_PAGE = {
  title: 'Events',
  support: 'Talks, workshops and gatherings.',
  back: 'Back to Discover',
  empty: (filter: EventFilter) => (filter === 'week' ? 'No events this week. Try This month, or look at all events.' : `No events ${EVENT_FILTERS.find((f) => f.key === filter)?.label.toLowerCase()}. Try another filter, or look at all events.`),
  showAll: 'Show all events',
};

/* ---------------------------------------------------------------- Event page (Figma 11.71, Memory and Cloth) */
export const EVENT_PAGE = {
  slug: 'memory-and-cloth',
  back: 'Back to Events',
  tag: 'SAT 22 NOV · 4:00 PM',
  title: 'Memory and Cloth: an artist talk',
  image: 'discover/event-talk' as DiscoverImg,
  hostLabel: 'Hosted by',
  host: 'Anaya Smith',
  hostImage: 'discover/person-anaya' as DiscoverImg,
  hostHref: profilePath('anaya-smith'),
  facts: [
    { label: 'Date', value: 'Saturday 22 November, 4:00 pm to 6:00 pm WAT' },
    { label: 'Place', value: 'Lagos. The address is sent when you register.' },
    { label: 'Format', value: 'In person' },
    { label: 'Host', value: 'Anaya Smith' },
  ],
  aboutLabel: 'ABOUT',
  about: 'Anaya Smith shares the work behind her indigo cloths and how memory finds its way into pattern. The talk is followed by a conversation and time to look closely at the cloth.',
  register: { label: 'REGISTER FOR THIS EVENT', action: 'Register' },
  registered: { label: 'REGISTRATION', done: 'Registered', note: (email: string) => `We emailed your confirmation to ${email}.`, cancel: 'Cancel registration' },
  save: 'Save event',
  share: 'Share this event',
  bring: { label: 'WHAT TO BRING', lines: ['A notebook and something to write with.', 'A small piece of cloth that holds a memory.', 'Questions for Anaya, if you have them.'] },
  modal: {
    title: 'Register for Memory and Cloth: an artist talk',
    text: 'We will email your confirmation to the address below. You can cancel your place at any time.',
    name: { label: 'Name', value: 'Kemi Adeyemi', hint: 'From your Akines profile.' },
    email: { label: 'Email', value: 'kemi.adeyemi@example.com', hint: 'We will send your confirmation here.' },
    submit: 'Register',
    cancel: 'Cancel',
  },
  toast: { message: 'You are registered for this event.', undo: 'Undo' },
};

/** Every card by id (a card that appears in "All" and in its own filter is one entry). */
export const CARD_BY_ID: ReadonlyMap<string, ForYouCard> = new Map([...Object.values(FOR_YOU).flat(), ...FOR_YOU_ALL, ...INTEREST_CARDS, ...EVENTS].map((c) => [c.id, c]));
/** 1-based position of a card in a filter's list, or undefined when the card is not in that list. */
export const cardPosition = (id: string, filter: ForYouFilter): number | undefined => {
  const i = FOR_YOU[filter].findIndex((c) => c.id === id);
  return i < 0 ? undefined : i + 1;
};

/** What pressing a card's button does, as an analytics id. */
export type CardActionId = 'connect' | 'join' | 'request_to_join' | 'buy' | 'view_project' | 'request_visit' | 'read_story' | 'view_event';
export const cardActionId = (c: ForYouCard): CardActionId => {
  switch (c.kind) {
    case 'person':
      return 'connect';
    case 'circle':
      return c.access === 'approval' ? 'request_to_join' : 'join';
    case 'artwork':
      return 'buy';
    case 'project':
      return 'view_project';
    case 'studio':
      return 'request_visit';
    case 'story':
      return 'read_story';
    case 'event':
      return 'view_event';
  }
};

/* ---------------------------------------------------------------- 03 Explore by interest */
export type InterestId = 'visual-arts' | 'music' | 'film-media' | 'design' | 'writing' | 'textiles' | 'craft' | 'food' | 'photography' | 'architecture' | 'dance' | 'poetry';
export type Interest = { id: InterestId; title: string; text: string; image: DiscoverImg };
/** The twelve interests of Explore by interest, all (Figma 11.68). The page of Discover shows the first four. */
export const ALL_INTERESTS: Interest[] = [
  { id: 'visual-arts', title: 'Visual Arts', text: 'Painters, illustrators, photographers and other visual creatives.', image: 'discover/interest-visual-arts' },
  { id: 'music', title: 'Music', text: 'Musicians, producers, sound artists and music enthusiasts.', image: 'discover/interest-music' },
  { id: 'film-media', title: 'Film & Media', text: 'Filmmakers, editors, storytellers and media creatives.', image: 'discover/interest-film' },
  { id: 'design', title: 'Design', text: 'Designers, product thinkers and UX creatives.', image: 'discover/interest-design' },
  { id: 'writing', title: 'Writing', text: 'Writers, essayists, editors and zine makers.', image: 'feed/hero-card-6' },
  { id: 'textiles', title: 'Textiles', text: 'Weavers, dyers, adire makers and textile artists.', image: 'feed/hero-card-4' },
  { id: 'craft', title: 'Craft', text: 'Potters, leatherworkers, woodworkers and makers by hand.', image: 'feed/studio-1' },
  { id: 'food', title: 'Food', text: 'Cooks, growers and people who turn meals into stories.', image: 'discover/interest-food' },
  { id: 'photography', title: 'Photography', text: 'Photographers, image makers and visual documentarians.', image: 'feed/story-2' },
  { id: 'architecture', title: 'Architecture', text: 'Architects, builders and people who shape spaces.', image: 'discover/interest-architecture' },
  { id: 'dance', title: 'Dance', text: 'Dancers, choreographers and movement artists.', image: 'feed/journal-2' },
  { id: 'poetry', title: 'Poetry', text: 'Poets, spoken word artists and lovers of verse.', image: 'feed/circle-poetry' },
];
export const INTERESTS: Interest[] = ALL_INTERESTS.slice(0, 4);
export const INTERESTS_PAGE = {
  title: 'Explore by interest',
  support: 'Dive into what moves you. Find people, circles and content around the things you love.',
  back: 'Back to Discover',
};

/* ---------------------------------------------------------------- 04 People whose journeys complement yours */
/**
 * `id` is the recommendation id, `userId` the recommended user. `match` is the percentage (the card reads "95% match", see matchLabel).
 * `prompt` is the conversation prompt without quotation marks: the PRD example shows it in curly quotes, so the card adds them.
 */
export type Recommendation = {
  id: string;
  userId: string;
  name: string;
  image: DiscoverImg;
  /** "Textile artist · Ibadan" */
  identity: string;
  /** With the hash, as shown: "#Textiles" */
  tags: string[];
  match: number;
  prompt: string;
};
export const RECOMMENDATIONS: Recommendation[] = [
  {
    id: 'rec-ayo', userId: 'ayo', name: 'Ayo Balogun', image: 'workspace/ayo', identity: 'Textile artist · Ibadan',
    tags: ['#Textiles', '#CulturalHeritage', '#VisualStorytelling'], match: 95,
    prompt: 'Ask about the dye yard in Ibadan: what does it smell like, and who taught her?',
  },
  {
    id: 'rec-amara', userId: 'amara', name: 'Amara Okafor', image: 'workspace/amara', identity: 'Visual artist · Abuja',
    tags: ['#Painting', '#Conversation', '#Place'], match: 91,
    prompt: 'Ask how a room changes what people say to each other.',
  },
  {
    id: 'rec-yusuf', userId: 'yusuf', name: 'Yusuf Umar', image: 'workspace/yusuf', identity: 'Multidisciplinary artist · Kwara',
    tags: ['#Collaboration', '#Sound', '#Craft'], match: 88,
    prompt: 'Ask what he would build first if the idea could be tested in a day.',
  },
  {
    id: 'rec-ngozi', userId: 'ngozi', name: 'Ngozi Eze', image: 'community/av-ngozi', identity: 'Writer and zine maker · Lagos',
    tags: ['#Zines', '#Memory', '#Cities'], match: 86,
    prompt: 'Ask which neighbourhood she has not written about yet, and why.',
  },
];
/** The eight people of "All suggestions" (Figma 11.72): the four of the section, then four more. */
export const SUGGESTIONS: Recommendation[] = [
  ...RECOMMENDATIONS,
  {
    id: 'rec-tunde', userId: 'tunde', name: 'Tunde Bakare', image: 'community/av-tunde', identity: 'Community health designer · Abuja',
    tags: ['#Health', '#Listening', '#Design'], match: 84,
    prompt: 'Ask how he decides which small group to start with.',
  },
  {
    id: 'rec-chuka', userId: 'chuka', name: 'Chuka Nwosu', image: 'community/av-chuka', identity: 'Founder and maker · Port Harcourt',
    tags: ['#Making', '#Founders', '#Ideas'], match: 82,
    prompt: 'Ask what he would make first if no one were watching.',
  },
  {
    id: 'rec-folake', userId: 'folake', name: 'Folake Adeniran', image: 'community/av-folake', identity: 'Storyteller · Lagos',
    tags: ['#Stories', '#Walking', '#Lagos'], match: 80,
    prompt: 'Ask where her slow Sunday walks usually end up.',
  },
  {
    id: 'rec-anaya', userId: 'anaya', name: 'Anaya Smith', image: 'discover/person-anaya', identity: 'Textile artist · Ibadan',
    tags: ['#Textiles', '#Memory', '#Everyday'], match: 78,
    prompt: 'Ask what she has learned from keeping old cloth in use.',
  },
];
export const REC_BY_ID: ReadonlyMap<string, Recommendation> = new Map(SUGGESTIONS.map((r) => [r.id, r]));
/** 1-based position of a recommendation in its list (the section shows the first four of the same list), or undefined for an unknown id. */
export const recPosition = (id: string): number | undefined => {
  const i = SUGGESTIONS.findIndex((r) => r.id === id);
  return i < 0 ? undefined : i + 1;
};
export const SUGGESTIONS_PAGE = {
  title: 'People whose journeys complement yours',
  support: 'Eight people, chosen for what you are working on.',
  back: 'Back to Discover',
  empty: 'No suggestions right now. We will add people as your journey grows.',
};

export const RECS_COPY = {
  /** Heading of every card */
  heading: 'Someone to meet',
  /** Section label next to the heading */
  label: 'AI Suggestion',
  notNow: 'Not now',
  sayHello: 'Say hello',
  undo: 'Undo',
};
export const matchLabel = (r: Recommendation) => `${r.match}% match`;
export const firstName = (name: string) => name.split(' ')[0];
/** Note that replaces the buttons after "Say hello". */
export const sentNote = (r: Recommendation) => `Hello sent to ${firstName(r.name)}. We will let you know when they reply.`;
/** Note that replaces the card after "Not now"; the "Undo" button sits next to it. */
export const dismissedNote = (r: Recommendation) => `Not now noted. We will not show ${firstName(r.name)} for a while.`;

/* ---------------------------------------------------------------- states */
export const STATE_COPY = {
  /** Rail, Your circles, when the member has joined none. `link` is the "Find circles" link. */
  circlesEmpty: { title: 'Your circles', text: 'Your circles will appear here when you join one.', link: 'Find circles' },
  /** Rail, You two would get along, when there is nothing to suggest */
  matchEmpty: "We're finding people who may be relevant to you.",
  /** Explore by interest, when there is nothing to show */
  interestsEmpty: "There isn't anything to show here yet.",
  /** People whose journeys complement yours, when there are no recommendations */
  recommendationsEmpty: "We're finding people who may be relevant to you.",
  /** Section error panel (Figma Discover "Section error"): the Community Home panel with its own message, which does not mention conversations and projects */
  sectionError: {
    title: 'We could not load this section.',
    text: 'Check your connection and try again. The rest of this page is still here.',
    retry: 'Try again',
  },
};

/* ---------------------------------------------------------------- People profiles (Figma 11.73) */
/**
 * One page per person: the six people of the cards, Ayo Balogun and Yusuf Umar (the recommendations) and Thandi Dlamini (the maker of
 * the artwork). `connections` is what the profile says; the person cards and the Interest card keep their own numbers as drawn.
 */
export type Profile = {
  slug: string;
  name: string;
  image: DiscoverImg;
  /** "Textile artist · Ibadan" */
  identity: string;
  connections: string;
  /** The line under the role, in the primary colour */
  intro: string;
  /** The three pills under the intro */
  tags: [string, string, string];
  about: string;
  interests: string[];
};
const profile = (name: string, image: DiscoverImg, identity: string, connections: string, intro: string, tags: [string, string, string], about: string, interests: string[]): Profile => ({
  slug: slugOf(name), name, image, identity, connections, intro, tags, about, interests,
});
/** In the order of the Figma frames. */
export const PROFILES: Profile[] = [
  profile('Anaya Smith', 'discover/person-anaya', 'Textile artist · Ibadan', '126 Kin connections',
    'Exploring memory, fabric and the everyday. I work with worn cloth and the stories people keep in it.', ['Textiles', 'Memory', 'Everyday'],
    'Anaya is a textile artist in Ibadan. She makes hanging pieces from worn garments and hosts the artist talk Memory and Cloth. She likes meeting people who keep objects for the stories they hold.',
    ['Textiles', 'Memory', 'Adire', 'Natural dyes', 'Slow making']),
  profile('Tunde Bakare', 'community/av-tunde', 'Community health designer · Abuja', '84 Kin connections',
    'Designing care that begins with listening. I work with small teams on health services that fit how people live.', ['Health', 'Listening', 'Design'],
    'Tunde designs community health services in Abuja. He begins with long conversations and small trials, and he prefers practical work in small groups.',
    ['Community health', 'Listening', 'Service design', 'Small groups']),
  profile('Ngozi Eze', 'community/av-ngozi', 'Writer and zine maker · Lagos', '212 Kin connections',
    'Writing small books about the places we pass through. I make zines about neighbourhoods and the people in them.', ['Zines', 'Memory', 'Cities'],
    'Ngozi writes and prints zines in Lagos. Her recent issues follow bus routes and market streets. She writes to remember the people in her life.',
    ['Zines', 'Memory', 'Cities', 'Print', 'Short writing']),
  profile('Amara Okafor', 'community/amara', 'Visual artist · Abuja', '97 Kin connections',
    'Painting rooms where conversations happen. I am interested in how a place changes what people say.', ['Painting', 'Conversation', 'Place'],
    'Amara is a visual artist in Abuja. She paints interiors and the talk that fills them. She believes a poem can host a whole evening.',
    ['Painting', 'Conversation', 'Place', 'Poetry']),
  profile('Folake Adeniran', 'community/folake', 'Storyteller · Lagos', '109 Kin connections',
    'I tell stories out loud and on paper, usually after a slow walk.', ['Stories', 'Walking', 'Lagos'],
    'Folake is a storyteller in Lagos. She collects stories on long walks and shares them at small gatherings. Sunday is for slow walks and long talks.',
    ['Storytelling', 'Walking', 'Oral history', 'Lagos']),
  profile('Chuka Nwosu', 'community/chuka', 'Founder and maker · Port Harcourt', '64 Kin connections',
    'Starting something of my own, one conversation at a time.', ['Making', 'Founders', 'Ideas'],
    'Chuka is a founder and maker in Port Harcourt. He is building a small studio and likes to think an idea through with one person at a time.',
    ['Making', 'Founders', 'Ideas', 'Craft']),
  profile('Ayo Balogun', 'workspace/ayo', 'Textile artist · Ibadan', '143 Kin connections',
    'Textiles are living archives. I follow dye, cloth and the people who keep them.', ['Textiles', 'Cultural heritage', 'Visual storytelling'],
    'Ayo is a textile artist in Ibadan. She spends time at a dye yard and records how the craft is passed from one person to the next.',
    ['Textiles', 'Cultural heritage', 'Visual storytelling', 'Natural dyes']),
  profile('Yusuf Umar', 'workspace/yusuf', 'Multidisciplinary artist · Kwara', '71 Kin connections',
    'I want collaboration that challenges an idea without flattening it.', ['Collaboration', 'Sound', 'Craft'],
    'Yusuf is a multidisciplinary artist in Kwara. He works across sound and craft, and likes to test an idea in a day before he builds it.',
    ['Collaboration', 'Sound', 'Craft', 'Prototyping']),
  profile('Thandi Dlamini', 'workspace/ayo', 'Ceramicist · Johannesburg', '88 Kin connections',
    'Making vessels you can hear. I fire in small batches and share every step.', ['Ceramics', 'Studio visits', 'Craft'],
    'Thandi is a ceramicist in Maboneng, Johannesburg. She fires vessels in small batches and walks visitors through her workshop. Firing day vase is one of hers.',
    ['Ceramics', 'Studio visits', 'Craft', 'Firing']),
];
export const PROFILE_BY_SLUG: ReadonlyMap<string, Profile> = new Map(PROFILES.map((p) => [p.slug, p]));
export const firstOfName = (name: string) => name.split(' ')[0];
/** The store id of a person on this page ("person-anaya"): the id of the person card, where there is one. */
export const personId = (p: Profile) => `person-${firstOfName(p.name).toLowerCase()}`;
/** The recommendation of that person ("rec-anaya"), when they are one of the eight suggestions. */
export const recIdOf = (p: Profile): string | undefined => {
  const id = `rec-${firstOfName(p.name).toLowerCase()}`;
  return REC_BY_ID.has(id) ? id : undefined;
};

export const PROFILE_COPY = {
  back: 'Back to Discover',
  connect: { action: 'Connect', done: 'Requested' },
  hello: { action: 'Say hello', done: 'Hello sent' },
  aboutLabel: 'ABOUT',
  interestsLabel: 'INTERESTS',
  actionsLabel: (first: string) => `CONNECT WITH ${first.toUpperCase()}`,
  seeingLabel: 'WHAT YOU’RE SEEING',
  seeing: (first: string) => `${first}’s public profile on Akines. Private information stays private.`,
  error: {
    title: 'We could not load this profile.',
    text: 'Check your connection and try again. Your Kin connections are safe.',
    retry: 'Try again',
    back: 'Back to Discover',
  },
  /** Where the Loading frame leads after 2.5 s, and where Try again ends (Figma: Anaya Smith) */
  fallback: 'anaya-smith',
};
