import type { RouteDef } from '@/routes.types';
import { DiscoverPage } from './DiscoverPage';

/**
 * Connect / Discover (Figma section 11, frames "11.1 - Connect / Discover ..."). /connect is the Discover tab itself.
 * The state routes and the filter routes are for review: they open the same page in one state or with one For you filter selected.
 * Route files must not be client components, so each screen is wrapped here.
 */
const nav = { page: 'connect', tab: 'Discover' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

const Discover = () => <DiscoverPage />;
const Loading = () => <DiscoverPage state="loading" />;
const Failed = () => <DiscoverPage state="error" />;
const Empty = () => <DiscoverPage state="empty" />;
const People = () => <DiscoverPage force="people" />;
const Circles = () => <DiscoverPage force="circles" />;
const Projects = () => <DiscoverPage force="projects" />;
const StudioVisits = () => <DiscoverPage force="studio-visits" />;
const Stories = () => <DiscoverPage force="stories" />;
const Events = () => <DiscoverPage force="events" />;

export const routes: RouteDef[] = [
  def('/connect', 'Connect: Discover', Discover),
  def('/connect/state-loading', 'Connect: Discover, loading', Loading),
  def('/connect/state-error', 'Connect: Discover, error', Failed),
  def('/connect/state-empty', 'Connect: Discover, empty', Empty),
  def('/connect/filter-people', 'Connect: Discover, People', People),
  def('/connect/filter-circles', 'Connect: Discover, Circles', Circles),
  def('/connect/filter-projects', 'Connect: Discover, Projects', Projects),
  def('/connect/filter-studio-visits', 'Connect: Discover, Studio Visits', StudioVisits),
  def('/connect/filter-stories', 'Connect: Discover, Stories', Stories),
  def('/connect/filter-events', 'Connect: Discover, Events', Events),
];
