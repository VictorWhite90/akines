'use client';

import { cloneElement, useEffect, useId, useState, type ReactElement, type SyntheticEvent } from 'react';

/** Dark pill tooltip (like the header tooltips). Shows on hover (pointer devices) and keyboard focus; Escape hides it. */
export function Tooltip({ label, children, describe = true, side = 'bottom' }: { label: string; children: ReactElement<Record<string, unknown>>; describe?: boolean; side?: 'top' | 'bottom' }) {
  const id = useId();
  const [off, setOff] = useState(false);
  useEffect(() => {
    if (!off) return;
    const reset = () => setOff(false);
    const wrap = document.getElementById(id)?.parentElement;
    wrap?.addEventListener('pointerleave', reset);
    wrap?.addEventListener('focusout', reset);
    return () => {
      wrap?.removeEventListener('pointerleave', reset);
      wrap?.removeEventListener('focusout', reset);
    };
  }, [off, id]);
  // Keep the pill inside the viewport (8 px margin): arrows at the right edge of a phone would push it out.
  const keepInView = (e: SyntheticEvent<HTMLElement>) => {
    const wrap = e.currentTarget;
    const pill = wrap.querySelector<HTMLElement>('.k-tip__pill');
    if (!pill) return;
    const r = wrap.getBoundingClientRect();
    const left = r.left + r.width / 2 - pill.offsetWidth / 2;
    const vw = document.documentElement.clientWidth;
    const clamped = Math.max(8, Math.min(left, vw - 8 - pill.offsetWidth));
    wrap.style.setProperty('--k-tip-shift', `${Math.round(clamped - left)}px`);
  };
  return (
    <span
      className="k-tip"
      data-side={side}
      data-off={off || undefined}
      onPointerEnter={keepInView}
      onFocus={keepInView}
      onKeyDown={(e) => {
        if (e.key === 'Escape') setOff(true);
      }}
    >
      {describe ? cloneElement(children, { 'aria-describedby': [children.props['aria-describedby'], id].filter(Boolean).join(' ') }) : children}
      <span className="k-tip__pill" role="tooltip" id={id}>
        {label}
      </span>
    </span>
  );
}
