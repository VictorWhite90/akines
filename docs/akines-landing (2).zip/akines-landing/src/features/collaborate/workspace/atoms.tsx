'use client';

import type { ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { Button } from '@/ui';
import { cx } from './util';

/** The smallest pieces of the project screens (icons, avatar, dot, links, button). Kept apart from parts.tsx so dash.tsx and rail.tsx can use them without a cycle; parts.tsx re-exports all of them. */

/* ------------------------------------------------------------------ icons (Figma strokes, currentColor) */

type IconProps = { size?: number };
export function Icon({ size = 16, box = 16, sw = 1.25, children }: { size?: number; box?: number; sw?: number; children: ReactNode }) {
  return (
    <svg width={size} height={size} viewBox={`0 0 ${box} ${box}`} fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      {children}
    </svg>
  );
}
export const ArrowRight = ({ size = 16 }: IconProps) => (
  <Icon size={size}>
    <path d="M3 8h9.5M8.5 3.5 13 8l-4.5 4.5" />
  </Icon>
);
export const ArrowLeft = ({ size = 16 }: IconProps) => (
  <Icon size={size}>
    <path d="M13 8H3.5M7.5 3.5 3 8l4.5 4.5" />
  </Icon>
);
export const ArrowUpRight = ({ size = 16 }: IconProps) => (
  <Icon size={size}>
    <path d="M4.5 11.5 11.5 4.5M5.5 4.5h6v6" />
  </Icon>
);
export const CheckIcon = ({ size = 14, sw = 1.25 }: IconProps & { sw?: number }) => (
  <Icon size={size} sw={sw}>
    <path d="m3 8.5 3.2 3.2L13 4.8" />
  </Icon>
);
export const ChevronDown = () => (
  <Icon size={20} box={20} sw={1.4}>
    <path d="m5 7.5 5 5 5-5" />
  </Icon>
);
export const BellIcon = () => (
  <Icon size={20} box={20} sw={1.4}>
    <path d="M5.5 8.5a4.5 4.5 0 0 1 9 0c0 4.2 1.8 5.5 1.8 5.5H3.7s1.8-1.3 1.8-5.5ZM8.4 16.5a1.8 1.8 0 0 0 3.2 0" />
  </Icon>
);
export const SlidersIcon = () => (
  <Icon size={20} box={20} sw={1.4}>
    <path d="M3 6h7M14 6h3M3 14h3M10 14h7" />
    <circle cx="12" cy="6" r="2" />
    <circle cx="8" cy="14" r="2" />
  </Icon>
);

/* ------------------------------------------------------------------ small atoms */

/** Avatar with initials (Figma: ivory fill and default border on cards, muted fill and subtle border on activity rows). */
export function Av({ initials, size = 32, tone = 'brand', className }: { initials: string; size?: number; tone?: 'brand' | 'muted'; className?: string }) {
  return (
    <span className={cx('cw-av', `cw-av--${tone}`, className)} style={{ ['--cw-av' as string]: `${size}px`, ['--cw-fs' as string]: `${size >= 48 ? 13 : size >= 36 ? 12 : 11}px` }} aria-hidden="true">
      {initials}
    </span>
  );
}

export function AvStack({ initials, size = 32 }: { initials: string[]; size?: number }) {
  return (
    <span className="cw-avs" aria-hidden="true">
      {initials.map((i, n) => (
        <Av key={`${i}-${n}`} initials={i} size={size} />
      ))}
    </span>
  );
}

export const Dot = ({ tone = 'accent', size = 8 }: { tone?: 'accent' | 'green' | 'gray'; size?: number }) => (
  <i className={cx('cw-dot', `cw-dot--${tone}`)} style={{ ['--cw-dot' as string]: `${size}px` }} aria-hidden="true" />
);

/** The underlined text link of the design (Card Link). Without `href` and `onClick` it has no destination and does nothing. */
export function CardLink({ href, onClick, arrow = false, children, className }: { href?: string; onClick?: () => void; arrow?: boolean; children: ReactNode; className?: string }) {
  const inner = (
    <>
      <span className="cw-link__label">{children}</span>
      {arrow ? <ArrowRight /> : null}
    </>
  );
  if (href) {
    return (
      <Link href={href} className={cx('cw-link', className)}>
        {inner}
      </Link>
    );
  }
  return (
    <button type="button" className={cx('cw-link', className)} onClick={onClick}>
      {inner}
    </button>
  );
}

export function BackLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link href={href} className="cw-back">
      <ArrowLeft />
      <span>{children}</span>
    </Link>
  );
}

/** Primary or secondary pill button with the design's arrow. */
export function ActionButton({ href, onClick, variant = 'primary', arrow = false, children, type }: { href?: string; onClick?: () => void; variant?: 'primary' | 'secondary'; arrow?: boolean; children: ReactNode; type?: 'button' | 'submit' }) {
  return (
    <Button variant={variant} href={href} onClick={onClick} iconRight={arrow ? <ArrowRight /> : undefined} type={href ? undefined : type}>
      {children}
    </Button>
  );
}


export const Over = ({ children, className, as: As = 'p' }: { children: ReactNode; className?: string; as?: 'p' | 'span' | 'h3' }) => <As className={cx('cw-over', className)}>{children}</As>;
