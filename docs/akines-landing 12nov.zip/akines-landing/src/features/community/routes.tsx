import type { RouteDef } from '@/routes.types';
import { FeedPage } from './feed/FeedPage';
import { Messages } from './Messages';
import { Banter, Collaboration, ZineCollaboration } from './Collab';
import { ProfessionalSupport, QuietCompany, ReflectPrivately } from './Care';
import { SettingsConnection, SettingsExplanations, SettingsIndex, SettingsPrivacy, SettingsRecommendation } from './Settings';

const nav = { page: 'community' } as const;
const def = (path: string, title: string, component: RouteDef['component'], mobile?: RouteDef['mobile']): RouteDef => ({ path, title, shell: 'app', nav, component, mobile });
/** Phone layout: sub-pages get the top bar with a back button (Figma "Top Bar Mobile"); chat threads also hide the bottom tab bar. */
const top = (title: string, back: string, bottomBar = true): RouteDef['mobile'] => ({ bar: 'top', title, back, bottomBar });

// Community Home feed: /community picks an arrangement at random on every visit, /community/feed/a to d force one (review and tests)
const Feed = () => <FeedPage />;
const FeedA = () => <FeedPage force="a" />;
const FeedB = () => <FeedPage force="b" />;
const FeedC = () => <FeedPage force="c" />;
const FeedD = () => <FeedPage force="d" />;
const FeedLoading = () => <FeedPage state="loading" />;
const FeedError = () => <FeedPage state="error" />;
const FeedEmpty = () => <FeedPage state="empty" />;

const Inbox = () => <Messages />;
const Amara = () => <Messages slug="amara" />;
const Folake = () => <Messages slug="folake" />;
const FoodSystems = () => <Messages slug="food-systems-cliq" />;
const KinCircle = () => <Messages slug="kincircle-reflection" />;
const University = () => <Messages slug="university-friends" />;

export const routes: RouteDef[] = [
  def('/community', 'Community Home', Feed),
  def('/community/feed/a', 'Community Home: Discover', FeedA),
  def('/community/feed/b', 'Community Home: Belong', FeedB),
  def('/community/feed/c', 'Community Home: Make together', FeedC),
  def('/community/feed/d', 'Community Home: Heritage and craft', FeedD),
  def('/community/feed/state-loading', 'Community Home feed: loading', FeedLoading),
  def('/community/feed/state-error', 'Community Home feed: section error', FeedError),
  def('/community/feed/state-empty', 'Community Home feed: no match to suggest', FeedEmpty),
  def('/community/messages', 'Messages', Inbox, top('Messages', '/community')),
  def('/community/messages/amara', 'Messages: Amara', Amara, top('Amara', '/community/messages', false)),
  def('/community/messages/folake', 'Messages: Folake', Folake, top('Folake', '/community/messages', false)),
  def('/community/messages/food-systems-cliq', 'Messages: Food Systems Cliq', FoodSystems, top('Food Systems Cliq', '/community/messages', false)),
  def('/community/messages/kincircle-reflection', 'Messages: KinCircle Reflection', KinCircle, top('KinCircle Reflection', '/community/messages', false)),
  def('/community/messages/university-friends', 'Messages: University friends', University, top('University friends', '/community/messages', false)),
  def('/community/collaborations', 'Community Health Initiative', Collaboration, top('Community Health Initiative', '/community')),
  def('/community/collaborations/lagos-makers-zine', 'Lagos Makers Zine', ZineCollaboration, top('Lagos Makers Zine', '/community')),
  def('/community/care', 'Quiet company', QuietCompany, top('Quiet company', '/community')),
  def('/community/care/reflect', 'Reflect privately', ReflectPrivately, top('Reflect privately', '/community')),
  def('/community/care/professional-support', 'Find professional support', ProfessionalSupport, top('Find professional support', '/community')),
  // /community/settings: the Recommendation preferences page on tablet and desktop, the Settings list (mobile form of the settings nav) on phones.
  def('/community/settings', 'Recommendation preferences', SettingsIndex, top('Settings', '/community')),
  def('/community/settings/preferences', 'Recommendation preferences', SettingsRecommendation, top('Recommendation preferences', '/community/settings')),
  def('/community/settings/recommendations', 'Recommendation explanations', SettingsExplanations, top('Recommendation explanations', '/community/settings')),
  def('/community/settings/privacy', 'Privacy settings', SettingsPrivacy, top('Privacy settings', '/community/settings')),
  def('/community/settings/connection', 'Connection preferences', SettingsConnection, top('Connection preferences', '/community/settings')),
  def('/community/banter', 'Banter', Banter, top('Banter', '/community')),
];
