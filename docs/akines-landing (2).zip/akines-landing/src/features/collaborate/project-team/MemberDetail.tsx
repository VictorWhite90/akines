'use client';

import '../workspace/workspace.css';
import './team.css';
import './member.css';
import { Link } from '@/lib/nav';
import { meetPaths } from '../meetings/store';
import { DashCard, MetricCard, MetricRow } from '../workspace/dash';
import { BackLink, Icon, PageHead, WorkspaceFrame, cx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { DETAIL } from './data';
import { HISTORY_ROWS, MEMBER as M, type HistoryRow } from './member-data';
import { SkillTags } from './parts';

/**
 * 12.21 Team / Member detail (17729:111084): one member in the dashboard look. The shared rail on the right, then the header (back link,
 * large initials, eyebrow, name, one line), four metric cards, contributions by week beside availability, role in this project, skills
 * and the contribution history as six rows.
 * Links come from the prototype: Open tasks goes to Tasks and Next session to the meeting lobby; Contributions and Acknowledged scroll to
 * the history. Four of the six history rows open the place the work lives (decision discussion, project brief, milestone, agreements); the
 * other two rows and the skill tags have no destination in the design and do nothing. Career Guidance for Everyone only.
 */

/** The small up-right arrow of an Open action (Figma icon/arrow-up-right, 16 px, 1.5 stroke). */
const ArrowUpRight16 = () => (
  <Icon size={16} sw={1.5}>
    <path d="M4.5 11.5 11.5 4.5M5.5 4.5h6v6" />
  </Icon>
);

/** Contribution row (Figma Work Row, 704 by 92): the work, what it was and when, and Open at the right when the row has a destination. */
function HistoryItem({ row }: { row: HistoryRow }) {
  const body = (
    <>
      <span className="mb-row__text">
        <span className="mb-row__title">{row.title}</span>
        <span className="mb-row__status">{row.status}</span>
      </span>
      {row.href ? (
        <span className="mb-row__act">
          <span className="mb-row__open">Open</span>
          <ArrowUpRight16 />
        </span>
      ) : null}
    </>
  );
  return row.href ? (
    <Link href={row.href} className="mb-row mb-row--link">
      {body}
    </Link>
  ) : (
    <div className="mb-row">{body}</div>
  );
}

export function MemberDetail() {
  const { root, nav } = useProject();
  const m = M.metrics;
  const week = M.week;
  const avail = M.availability;
  return (
    <WorkspaceFrame active="team" rail>
      <div className="mb-page">
        <PageHead
          back={
            <>
              <BackLink href={nav.team}>{M.back}</BackLink>
              <span className="mb-avatar" aria-hidden="true">
                {M.initials}
              </span>
            </>
          }
          label={M.label}
          title={M.name}
          lead={M.lead}
        />

        <MetricRow>
          <MetricCard label={m.tasks.label} value={m.tasks.value} caption={m.tasks.caption} href={nav.tasks} />
          <MetricCard label={m.contributions.label} value={m.contributions.value} caption={m.contributions.caption} scrollTo={M.history.id} />
          <MetricCard label={m.acknowledged.label} value={m.acknowledged.value} caption={m.acknowledged.caption} scrollTo={M.history.id} />
          <MetricCard label={m.session.label} value={m.session.value} caption={m.session.caption} dot href={meetPaths(root).lobby} />
        </MetricRow>

        <div className="mb-pair">
          <DashCard title={week.title} className="mb-week">
            <p className="mb-total">
              <span>{week.total}</span>
              {week.caption}
            </p>
            <div className="mb-chart" role="img" aria-label={`${week.total} ${week.caption}, by week from 12 Oct to 2 Nov`}>
              {week.bars.map((b) => (
                <span className="mb-day" key={b.label}>
                  <i className={cx('mb-bar', b.now && 'mb-bar--now')} style={{ height: `${b.h}px` }} />
                  <span className={cx('mb-day__label', b.now && 'is-now')}>{b.label}</span>
                </span>
              ))}
            </div>
          </DashCard>

          <DashCard title={avail.title} className="mb-avail">
            <p className="mb-status">
              <i className="mb-status__dot" aria-hidden="true" />
              <span>{avail.status}</span>
            </p>
            <div className="mb-rule" aria-hidden="true" />
            <p className="mb-label">{avail.nextLabel}</p>
            <p className="mb-session">{avail.session}</p>
            <p className="mb-meta">{avail.when}</p>
            <p className="mb-meta">{avail.note}</p>
          </DashCard>
        </div>

        <DashCard title={M.role.title} className="mb-role">
          <dl className="mb-fields">
            {M.role.fields.map((f) => (
              <div className="mb-field" key={f.label}>
                <dt className="mb-label">{f.label}</dt>
                <dd>{f.value}</dd>
              </div>
            ))}
          </dl>
        </DashCard>

        <DashCard title={M.skills.title} className="mb-skills">
          <SkillTags labels={DETAIL.skills.map((s) => ({ label: s.label, used: s.used }))} wrap />
          <p className="mb-meta">{M.skills.note}</p>
        </DashCard>

        <section id={M.history.id} className="mb-history" data-m="up">
          <h2 className="mb-label">{M.history.title}</h2>
          <p className="mb-meta">{M.history.support}</p>
          <ul className="mb-rows">
            {HISTORY_ROWS.map((r) => (
              <li key={r.id}>
                <HistoryItem row={r} />
              </li>
            ))}
          </ul>
        </section>
      </div>
    </WorkspaceFrame>
  );
}
