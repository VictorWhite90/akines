'use client';

/**
 * Small shared pieces of the sign-in panel and the join flow (prefix au-): icons, spinner, text field, primary button,
 * provider buttons, "or continue with" divider. Looks come from the Figma Components page (Email Input, Primary Button,
 * Social Button, Form Error, Divider / Or, Spinner). Styles: src/styles/auth.css.
 */
import { useId, type ReactNode, type Ref } from 'react';
import { Button } from '@/ui/Button';
import './../../styles/auth.css';

/* ---------- icons (Figma icon/circle-alert, circle-check, arrow-right, google, apple, x) ---------- */
type IconProps = { size?: number; className?: string };

export const AlertIcon = ({ size = 20, className }: IconProps) => (
  <svg className={className} width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.667" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <circle cx="10" cy="10" r="8.333" />
    <path d="M10 6.667V10" />
    <path d="M10 13.333h.008" />
  </svg>
);
export const CheckCircleIcon = ({ size = 20, className }: IconProps) => (
  <svg className={className} width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.667" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <circle cx="10" cy="10" r="8.333" />
    <path d="m7.5 10 1.667 1.667L12.5 8.333" />
  </svg>
);
export const ArrowRightIcon = ({ size = 16, className }: IconProps) => (
  <svg className={className} width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.333" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="M3.333 8h9.334" />
    <path d="m8 3.333 4.667 4.667L8 12.667" />
  </svg>
);
export const CloseGlyph = ({ size = 20 }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="M5 5l10 10M15 5 5 15" />
  </svg>
);
export const CheckGlyph = ({ size = 14 }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    <path d="m2.5 7.2 3 3 6-6.2" />
  </svg>
);
/** Official four colour Google "G". */
export const GoogleMark = () => (
  <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true" focusable="false">
    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
  </svg>
);
export const AppleMark = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <path
      fill="currentColor"
      d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701z"
    />
  </svg>
);

/* ---------- text field (Figma Email Input: Default, Hover, Focus, Filled, Error, Verified) ---------- */
export type AuFieldProps = {
  id?: string;
  label: string;
  value: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  type?: 'text' | 'password' | 'email' | 'tel';
  inputMode?: 'text' | 'email' | 'numeric' | 'tel';
  autoComplete?: string;
  maxLength?: number;
  /** red border, alert icon and the message below (replaces the helper) */
  message?: ReactNode;
  /** green border and check icon */
  verified?: boolean;
  /** text under the field (12 px) */
  helper?: ReactNode;
  /** success is the lighter green (#279d45), strong the darker one (#1b7531) used by the Figma availability line */
  helperTone?: 'default' | 'success' | 'strong' | 'error';
  /** content at the right inside the field, e.g. the Show / Hide button */
  action?: ReactNode;
  /** extra content under the message and helper (username suggestions, password meter) */
  below?: ReactNode;
  inputRef?: Ref<HTMLInputElement>;
  autoFocus?: boolean;
  onFocus?: () => void;
  onBlur?: () => void;
  onEnter?: () => void;
  readOnly?: boolean;
  spellCheck?: boolean;
  name?: string;
};

export function AuField(p: AuFieldProps) {
  const auto = useId();
  const id = p.id ?? auto;
  const msgId = `${id}-msg`;
  const helpId = `${id}-help`;
  const state = p.message ? 'error' : p.verified ? 'verified' : 'default';
  return (
    <div className="au-field" data-state={state}>
      <label className="au-field__label" htmlFor={id}>
        {p.label}
      </label>
      <div className="au-input" data-state={state}>
        <input
          ref={p.inputRef}
          id={id}
          name={p.name}
          className="au-input__el"
          type={p.type ?? 'text'}
          inputMode={p.inputMode}
          autoComplete={p.autoComplete}
          maxLength={p.maxLength}
          placeholder={p.placeholder}
          value={p.value}
          readOnly={p.readOnly}
          spellCheck={p.spellCheck ?? false}
          autoCapitalize="none"
          autoCorrect="off"
          autoFocus={p.autoFocus}
          aria-invalid={p.message ? true : undefined}
          aria-describedby={p.message ? msgId : p.helper ? helpId : undefined}
          onChange={(e) => p.onChange?.(e.target.value)}
          onFocus={p.onFocus}
          onBlur={p.onBlur}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && p.onEnter) {
              e.preventDefault();
              p.onEnter();
            }
          }}
        />
        {p.message ? <AlertIcon className="au-input__icon au-input__icon--error" /> : null}
        {!p.message && p.verified ? <CheckCircleIcon className="au-input__icon au-input__icon--ok" /> : null}
        {p.action}
      </div>
      {p.message ? (
        <p className="au-msg" id={msgId} role="alert">
          <AlertIcon size={16} />
          <span>{p.message}</span>
        </p>
      ) : p.helper ? (
        <p className="au-helper" id={helpId} data-tone={p.helperTone ?? 'default'}>
          {p.helper}
        </p>
      ) : null}
      {p.below}
    </div>
  );
}

/** The "Show" / "Hide" word at the right of a password field. */
export function ShowToggle({ shown, onToggle }: { shown: boolean; onToggle: () => void }) {
  return (
    <button type="button" className="au-show" aria-pressed={shown} onClick={onToggle}>
      {shown ? 'Hide' : 'Show'}
    </button>
  );
}

/* ---------- buttons (the kit Button: full width, md) ---------- */
export function PrimaryButton({
  label,
  onClick,
  loading,
  looksDisabled,
  type = 'button',
  className,
}: {
  label: string;
  onClick?: () => void;
  loading?: boolean;
  /** Figma Disabled variant: grey, still clickable (the click shows the error) */
  looksDisabled?: boolean;
  type?: 'button' | 'submit';
  className?: string;
}) {
  return (
    <Button
      type={type}
      fullWidth
      className={className}
      loading={loading}
      looksDisabled={looksDisabled}
      iconRight={<ArrowRightIcon />}
      onClick={onClick ? () => onClick() : undefined}
    >
      {label}
    </Button>
  );
}

export type Provider = 'google' | 'apple';
export function SocialButton({ provider, loading, onClick }: { provider: Provider; loading?: boolean; onClick?: () => void }) {
  return (
    <Button
      variant="secondary"
      fullWidth
      className="au-social"
      loading={loading}
      icon={provider === 'google' ? <GoogleMark /> : <AppleMark />}
      onClick={() => onClick?.()}
    >
      {provider === 'google' ? 'Continue with Google' : 'Continue with Apple'}
    </Button>
  );
}

/** "or continue with" between two hairlines (Figma Divider / Or). */
export const OrDivider = () => (
  <div className="au-or" role="separator">
    <span className="au-or__line" />
    <span className="au-or__label">or continue with</span>
    <span className="au-or__line" />
  </div>
);
