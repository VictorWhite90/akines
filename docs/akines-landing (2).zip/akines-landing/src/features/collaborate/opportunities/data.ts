/**
 * Sample data of 12.31 Opportunities (list 17711:90709, empty 17711:91587) and 12.32 My Contributions (list 17711:91796, empty 17711:92242).
 * Copy is the Figma copy. Types, stages and dates are stored in sentence case and drawn in capitals by the stylesheet, as in the Figma
 * stage line (OPEN ROLE, FILM, 2 NOVEMBER 2026).
 */
import { PATHS } from '../workspace/data';

const project = (slug: string) => `/collaborate/projects/${slug}`;

/* ---------------------------------------------------------------- 12.31 Opportunities */

export type Opportunity = {
  id: string;
  /** Title of the card, the role. */
  role: string;
  summary: string;
  type: 'Application' | 'Film' | 'Book';
  project: string;
  commitment: string;
  owner: string;
  /** The card opens the project detail (A Better Way to Learn opens its own existing detail, 17321:20075). */
  href: string;
};

/** Eight open roles, three cards to a row, in the order of the Figma list. */
export const OPPORTUNITIES: Opportunity[] = [
  {
    id: 'product-designer',
    role: 'Product Designer',
    summary: 'Shapes how students move through each lesson.',
    type: 'Application',
    project: 'A Better Way to Learn',
    commitment: 'A few hours a week.',
    owner: 'Ngozi Eze',
    href: project('a-better-way-to-learn'),
  },
  {
    id: 'ux-researcher',
    role: 'UX Researcher',
    summary: 'Runs short interviews with traders and turns them into clear findings.',
    type: 'Application',
    project: 'Market Women Ledger',
    commitment: 'Weekends.',
    owner: 'Amaka Okafor',
    href: project('market-women-ledger'),
  },
  {
    id: 'ux-writer',
    role: 'UX Writer',
    summary: 'Writes short, clear messages for patients and nurses.',
    type: 'Application',
    project: 'Clinic Queue',
    commitment: 'A few hours a week.',
    owner: 'Dayo Adebayo',
    href: project('clinic-queue'),
  },
  {
    id: 'cinematographer',
    role: 'Cinematographer',
    summary: 'Films the street and home scenes for each episode.',
    type: 'Film',
    project: 'Voices of Lagos',
    commitment: 'Weekends.',
    owner: 'Tunde Bakare',
    href: project('voices-of-lagos'),
  },
  {
    id: 'sound-designer',
    role: 'Sound Designer',
    summary: 'Records and cleans the audio so every voice is easy to hear.',
    type: 'Film',
    project: 'Voices of Lagos',
    commitment: 'Weekends.',
    owner: 'Tunde Bakare',
    href: project('voices-of-lagos'),
  },
  {
    id: 'illustrator',
    role: 'Illustrator',
    summary: 'Draws the pictures for each page in a warm, simple style.',
    type: 'Book',
    project: 'Stories for Small Hands',
    commitment: 'Flexible hours.',
    owner: 'Ifeoma Obi',
    href: project('stories-for-small-hands'),
  },
  {
    id: 'education-researcher',
    role: 'Education Researcher',
    summary: 'Runs short student interviews and turns them into clear findings.',
    type: 'Application',
    project: 'A Better Way to Learn',
    commitment: 'Weekends.',
    owner: 'Ngozi Eze',
    href: project('a-better-way-to-learn'),
  },
  {
    id: 'mobile-developer',
    role: 'Mobile Developer',
    summary: 'Builds the first version of the ledger so it works on a basic phone.',
    type: 'Application',
    project: 'Market Women Ledger',
    commitment: 'Flexible hours.',
    owner: 'Amaka Okafor',
    href: project('market-women-ledger'),
  },
];

/* ---------------------------------------------------------------- 12.32 My Contributions */

/**
 * Records 2 and 4 used to open Work detail 2 "Map the student journey" in the Studio. The Studio was removed 5 Nov 2026, so those two
 * records have no destination (as in the Figma frame 12.32).
 */

export type Contribution = {
  id: string;
  type: string;
  date: string;
  title: string;
  context: string;
  relatedWork: string;
  project: string;
  /** Third meta column; the Figma record hides it when there is no acknowledgement. */
  acknowledgement?: string;
  /** Where the record opens. Missing: the Figma record has no reaction (Final Credit "View related work"). */
  href?: string;
};

export const CONTRIBUTIONS: Contribution[] = [
  {
    id: 'brief-acknowledged',
    type: 'Peer acknowledgement',
    date: '2 November 2026',
    title: 'Acknowledgement of the project brief',
    context: 'Tobi Adeyemi acknowledged the shared project brief.',
    relatedWork: 'Shared project brief',
    project: 'Career Guidance for Everyone',
    href: PATHS.brief,
  },
  {
    id: 'journey-map',
    type: 'Work submitted',
    date: '29 October 2026',
    title: 'Student journey map',
    context: 'Submitted to the shared workspace and reviewed by two team members.',
    relatedWork: 'Map the student journey',
    project: 'Career Guidance for Everyone',
    acknowledgement: 'Acknowledged by Adaeze Okoye.',
  },
  {
    id: 'onboarding-decision',
    type: 'Decision influenced',
    date: '27 October 2026',
    title: 'Choose the onboarding approach',
    context: 'Your comments on the two onboarding options were part of the discussion before the decision.',
    relatedWork: 'Decision discussion',
    project: 'Career Guidance for Everyone',
    href: PATHS.conversationsDecision,
  },
  {
    id: 'product-design',
    type: 'Skill demonstrated',
    date: '24 October 2026',
    title: 'Product design',
    context: 'Shown in the student journey map and the onboarding sketches.',
    relatedWork: 'Map the student journey',
    project: 'Career Guidance for Everyone',
  },
  {
    id: 'brief-approved',
    type: 'Milestone completed',
    date: '12 October 2026',
    title: 'Project brief approved',
    context: 'Completed with Tobi Adeyemi and Adaeze Okoye.',
    relatedWork: 'Shared project brief',
    project: 'Career Guidance for Everyone',
    acknowledgement: 'Acknowledged by Ngozi Eze.',
    href: PATHS.brief,
  },
  {
    id: 'wayfinding',
    type: 'Final credit',
    date: '14 August 2026',
    title: 'Campus wayfinding study',
    context: 'Credited as Product Designer when the project closed.',
    relatedWork: 'Final project record',
    project: 'Campus Wayfinding Study',
  },
];

export const CONTRIBUTIONS_NOTE = 'Acknowledgements show that your work was seen. They are not ratings, and nothing here measures how often you are online.';
