/**
 * Sample data and copy of Launch (Figma 12.24): Not ready 17729:93424, Readiness 17729:94066, Materials 17729:94745,
 * Attribution 17729:95391, Ready to share 17729:96037, Outcome 17729:96683, Modal:Confirm attribution 17729:101584,
 * Toast:Attribution confirmed 17729:101733, Modal:Share project 17729:101663, Toast:Project shared 17729:101740.
 * Every text is copied word for word from the frames.
 */
import { PATHS } from '../workspace/data';
import { ART_PATH, type ProjectKey } from '../workspace/project';

/** The paths of the Launch pages under a project's Launch page (the Project navigation goes to `readiness`). */
const launchPaths = (base: string) => ({
  readiness: base,
  notReady: `${base}/state-not-ready`,
  materials: `${base}/materials`,
  attribution: `${base}/attribution`,
  ready: `${base}/ready-to-share`,
  outcome: `${base}/outcome`,
  /** Overlay frames: the parent page with the modal or the toast already showing. */
  confirmModal: `${base}/state-confirm-attribution`,
  confirmed: `${base}/state-attribution-confirmed`,
  shareModal: `${base}/state-share-project`,
  shared: `${base}/state-project-shared`,
});

/** Paths of the Launch pages of Career Guidance for Everyone. PATHS.launch is the Readiness page (the Project navigation goes there). */
export const LP = launchPaths(PATHS.launch);
/** The same pages under Adire Stories (Readiness, Materials, Attribution, Ready to share and Outcome are registered there). */
export const ART_LP = launchPaths(`${ART_PATH}/launch`);

export const PLANNING_NOTE = 'This view shows how Launch will look when the work is ready.';
export const OWNER = 'Kemi Adeyemi (you)';

/* ---------------------------------------------------------------- headers */

const TITLE = "Bring what you've created into the world.";
const LEAD = 'Prepare your work, recognise the people behind it and share the outcome with the people it was made for.';

export const NOT_READY = {
  label: 'LAUNCH',
  title: TITLE,
  lead: LEAD,
  emptyTitle: 'The work is still taking shape.',
  emptyText: 'Your launch space will help you prepare when the project is ready to be shared.',
  link: 'See what readiness needs',
};

export const READINESS = {
  label: 'LAUNCH',
  title: TITLE,
  lead: LEAD,
  facts: [
    { label: 'CRITERIA MET', value: '2 of 5' },
    { label: 'OUTSTANDING WORK', value: '3 tasks' },
    { label: 'APPROVALS', value: '1 pending' },
  ],
  prepare: 'Prepare launch',
  review: 'Review final work',
  outcomeLabel: 'PROJECT OUTCOME',
  outcomeTitle: 'A first guided onboarding for students',
  outcomeNote: 'The outcome your team agreed to bring into the world. This is a preview, because the project is still in Planning.',
  checklistLabel: 'READINESS CHECKLIST',
  progressLabel: 'Completion criteria',
  progressValue: '2 of 5 met',
  /** Criteria met out of the five on the checklist: the filled part of the bar is 2/5. */
  met: 2,
  total: 5,
};

export type ReadinessStatus = 'Done' | 'In progress' | 'Not started';
export type ReadinessRowData = { id: string; title: string; detail: string; status: ReadinessStatus; href?: string };

/** Outstanding work and Review final work go to Tasks, Team acknowledgement goes to Attribution. The other rows have no destination. */
export const READINESS_ROWS: ReadinessRowData[] = [
  { id: 'outcome', title: 'Project outcome', detail: 'A first guided onboarding for students', status: 'Done' },
  { id: 'criteria', title: 'Completion criteria', detail: '2 of 5 criteria met', status: 'In progress' },
  { id: 'work', title: 'Outstanding work', detail: '3 tasks are still open', status: 'In progress', href: PATHS.tasks },
  { id: 'approvals', title: 'Required approvals', detail: 'Approval pending from Kemi Adeyemi', status: 'Not started' },
  { id: 'review', title: 'Final review', detail: 'The team reviews the final outcome together', status: 'Not started' },
  { id: 'ack', title: 'Team acknowledgement', detail: 'Each member confirms how they are credited', status: 'Not started', href: LP.attribution },
];

export const MATERIALS = {
  back: 'Back to readiness',
  label: 'LAUNCH MATERIALS',
  title: 'Prepare what you will share.',
  lead: 'Six pieces help people understand the work. Create AI can draft them when you ask. Your team decides what goes out.',
  listLabel: 'MATERIALS (6)',
  next: 'Next: attribution',
};

export type MaterialStatus = 'Ready' | 'Draft' | 'Not started';
export type MaterialRowData = { id: string; title: string; detail: string; status: MaterialStatus; action: string };

export const MATERIAL_ROWS: MaterialRowData[] = [
  { id: 'description', title: 'Project description', detail: 'A short description people see first.', status: 'Ready', action: 'Review' },
  { id: 'summary', title: 'Project summary', detail: 'What the project set out to do and what it became.', status: 'Ready', action: 'Review' },
  { id: 'presentation', title: 'Presentation', detail: 'Slides to walk people through the outcome.', status: 'Draft', action: 'Continue' },
  { id: 'portfolio', title: 'Portfolio materials', detail: 'Images and pieces that show your work.', status: 'Draft', action: 'Continue' },
  { id: 'documentation', title: 'Final documentation', detail: 'Notes and files that explain how it works.', status: 'Not started', action: 'Prepare' },
  { id: 'announcement', title: 'Public announcement', detail: 'A short note to share the outcome. Nothing goes out until your team approves.', status: 'Not started', action: 'Prepare' },
];

export type Credit = { initials: string; name: string; role: string; contribution: string; attribution: string };

export const CREDITS: Credit[] = [
  { initials: 'KA', name: 'Kemi Adeyemi', role: 'Project owner, product designer', contribution: 'Shaped the project brief and led the guided onboarding design.', attribution: 'Project owner, product design' },
  { initials: 'AO', name: 'Adaeze Okoye', role: 'Product designer, supporting', contribution: 'Mapped the student journey and reviewed the onboarding draft.', attribution: 'Product design' },
  { initials: 'TA', name: 'Tobi Adeyemi', role: 'Software engineer', contribution: 'Built the first onboarding prototype and shared the student onboarding draft.', attribution: 'Software engineering' },
  { initials: 'NE', name: 'Ngozi Eze', role: 'Career researcher', contribution: 'Ran the career interviews and shared the interview notes.', attribution: 'Career research' },
];

export const ATTRIBUTION = {
  back: 'Back to materials',
  label: 'TEAM RECOGNITION',
  title: 'Recognise the people behind it.',
  lead: 'Credits follow what your team agreed about roles and contributions.',
  listLabel: 'CONTRIBUTORS (4)',
  note: 'Credits are drawn from your approved contribution and ownership agreements.',
  confirm: 'Confirm attribution',
  next: 'Continue to sharing',
};

export const READY = {
  back: 'Back to attribution',
  label: 'READY TO SHARE',
  title: 'Share what you have made.',
  lead: 'Check what will be shared and who will see it.',
  sharedLabel: 'WHAT WILL BE SHARED',
  seeLabel: 'WHO WILL SEE IT',
  see: [
    { label: 'VISIBILITY', value: 'Public', detail: 'Anyone with the link can view the project outcome.' },
    { label: 'APPROVAL NEEDED FROM', value: OWNER, detail: 'Every project owner approves before anything is shared.' },
  ],
  note: 'Public sharing needs explicit approval. Create AI can help prepare materials, but it cannot publish.',
  share: 'Share project',
};

/** What will be shared: the six materials, all ready (with the shorter announcement line), and the credits. */
const sharedRows = (materials: MaterialRowData[], announcement: string, credits: string): MaterialRowData[] => [
  ...materials.map((m) => ({ ...m, status: 'Ready' as const, action: 'View', detail: m.id === 'announcement' ? announcement : m.detail })),
  { id: 'credits', title: 'Credits', detail: credits, status: 'Ready', action: 'View' },
];
export const SHARED_ROWS: MaterialRowData[] = sharedRows(MATERIAL_ROWS, 'A short note to share the outcome.', 'Kemi Adeyemi, Adaeze Okoye, Tobi Adeyemi and Ngozi Eze, as your team agreed.');

export const OUTCOME = {
  back: 'Back to launch',
  label: 'PROJECT OUTCOME',
  title: 'Career Guidance for Everyone',
  lead: 'A first guided onboarding for students.',
  aboutLabel: 'ABOUT THE PROJECT',
  about:
    'Help Nigerian students make informed career decisions by connecting what they care about with the paths open to them. The first outcome is a guided onboarding that asks a few simple questions and points students toward what to explore next.',
  linkLabel: 'SHARE LINK',
  link: 'akines.vercel.app/outcome/career-guidance-for-everyone',
  copy: 'Copy link',
  sharedNote: 'Shared on 4 November 2026. Every project owner approved sharing.',
  creditsLabel: 'CREDITS (4)',
};

/* ---------------------------------------------------------------- overlays */

export const CONFIRM_MODAL = {
  eyebrow: 'CONFIRM ATTRIBUTION',
  title: 'Confirm the credits.',
  description: 'Your team agreed how each person is credited. Check them before you confirm.',
  confirm: 'Confirm attribution',
  cancel: 'Cancel',
};

export const SHARE_MODAL = {
  eyebrow: 'SHARE PROJECT',
  title: 'Ready to share it?',
  description: 'Anyone with the link will be able to view the outcome and the credits. Create AI cannot publish. Only your team can share the project.',
  approval: 'I approve sharing this project publicly',
  share: 'Share project',
  cancel: 'Cancel',
};

export const TOAST_CONFIRMED = 'Attribution confirmed. The credits are set.';
export const TOAST_SHARED = 'Project shared. Anyone with the link can view it.';

/* ---------------------------------------------------------------- context panel (Context Panel / Launch, one variant per page) */

export type LaunchPage = 'notReady' | 'readiness' | 'materials' | 'attribution' | 'sharing' | 'outcome';

export const NEEDS = ['An outcome your team has agreed.', 'Completion criteria that are met.', 'Approval from every project owner.'];

/* ---------------------------------------------------------------- per project copy */

/** The copy of the Context Panel / Launch that differs by project. The labels ("READINESS", "WAITING FOR APPROVAL") are the same on both. */
export type LaunchContextCopy = {
  phase: string;
  phaseNote: string;
  readiness: { headline: string; detail: string; waiting: string; ai: string };
  materials: { headline: string; detail: string; ai: string };
  attribution: { headline: string; detail: string; ai: string };
  sharing: { headline: string; detail: string; owner: string; ai: string };
  outcome: { headline: string; detail: string; approved: string; credits: string };
};

/**
 * Everything the Launch pages read, per project. Career Guidance for Everyone is made of the constants above (the Figma frames, word for word).
 * Adire Stories has the same shape, the same counts and the same order, with the Digital Art copy: the series is shared as a printed zine and
 * a small exhibition, and attribution means crediting the illustrators and the dyers. Text that is the same on both projects is shared.
 */
export type LaunchCopy = {
  readiness: typeof READINESS;
  readinessRows: ReadinessRowData[];
  materials: typeof MATERIALS;
  materialRows: MaterialRowData[];
  credits: Credit[];
  attribution: typeof ATTRIBUTION;
  ready: typeof READY;
  sharedRows: MaterialRowData[];
  outcome: typeof OUTCOME;
  confirmModal: typeof CONFIRM_MODAL;
  shareModal: typeof SHARE_MODAL;
  toastConfirmed: string;
  toastShared: string;
  context: LaunchContextCopy;
};

export const CAREER_LAUNCH: LaunchCopy = {
  readiness: READINESS,
  readinessRows: READINESS_ROWS,
  materials: MATERIALS,
  materialRows: MATERIAL_ROWS,
  credits: CREDITS,
  attribution: ATTRIBUTION,
  ready: READY,
  sharedRows: SHARED_ROWS,
  outcome: OUTCOME,
  confirmModal: CONFIRM_MODAL,
  shareModal: SHARE_MODAL,
  toastConfirmed: TOAST_CONFIRMED,
  toastShared: TOAST_SHARED,
  context: {
    phase: 'Planning',
    phaseNote: PLANNING_NOTE,
    readiness: {
      headline: '2 of 5 criteria met',
      detail: '3 tasks are still open.',
      waiting: 'Required before the project can be shared.',
      ai: 'Create AI can prepare launch materials when you ask. It suggests, and your team decides.',
    },
    materials: {
      headline: '2 ready, 2 in draft',
      detail: '2 not started.',
      ai: 'Create AI can draft any of these when you ask. Your team edits and approves every one. It never publishes.',
    },
    attribution: {
      headline: '4 people credited',
      detail: 'Credits follow the contribution and ownership agreements your team approved.',
      ai: 'Create AI is not credited as a contributor. It never changes a credit.',
    },
    sharing: {
      headline: 'Sharing is public.',
      detail: 'Every project owner approves first.',
      owner: 'Approval needed.',
      ai: 'Create AI cannot publish. Only your team can share the project.',
    },
    outcome: {
      headline: 'Shared on 4 November 2026',
      detail: 'Anyone with the link can view the outcome.',
      approved: 'Every project owner approved sharing.',
      credits: '4 people are credited as your team agreed.',
    },
  },
};

const ART_OUTCOME = 'Twelve plates, a zine and a small exhibition';

const ART_READINESS_ROWS: ReadinessRowData[] = [
  { id: 'outcome', title: 'Project outcome', detail: ART_OUTCOME, status: 'Done' },
  READINESS_ROWS[1],
  { ...READINESS_ROWS[2], href: `${ART_PATH}/tasks` },
  READINESS_ROWS[3],
  { id: 'review', title: 'Final review', detail: 'The team reviews the final plates together', status: 'Not started' },
  { ...READINESS_ROWS[5], href: ART_LP.attribution },
];

const ART_MATERIAL_ROWS: MaterialRowData[] = [
  { id: 'description', title: 'Series description', detail: 'A short description people see first.', status: 'Ready', action: 'Review' },
  { id: 'summary', title: 'Series summary', detail: 'What the series set out to do and what it became.', status: 'Ready', action: 'Review' },
  { id: 'presentation', title: 'Exhibition text', detail: 'Short texts for the exhibition wall and the zine.', status: 'Draft', action: 'Continue' },
  { id: 'portfolio', title: 'Plate images', detail: 'The twelve plates, ready for print proofs.', status: 'Draft', action: 'Continue' },
  { id: 'documentation', title: 'Pattern and dye notes', detail: 'Notes on the dyers, the cloth and the patterns.', status: 'Not started', action: 'Prepare' },
  { id: 'announcement', title: 'Public announcement', detail: 'A short note to share the series. Nothing goes out until your team approves.', status: 'Not started', action: 'Prepare' },
];

const ART_CREDITS: Credit[] = [
  { initials: 'KA', name: 'Kemi Adeyemi', role: 'Project owner, art director', contribution: 'Shaped the series brief and led the choice of patterns.', attribution: 'Project owner, art direction' },
  { initials: 'AO', name: 'Amara Obi', role: 'Lead illustrator, linework', contribution: 'Sketched the first three plates and drew the headwrap linework.', attribution: 'Illustration' },
  { initials: 'AB', name: 'Ayo Bello', role: 'Colour artist', contribution: 'Built the first colour palettes and commented on the headwrap highlights.', attribution: 'Colour and palettes' },
  { initials: 'YD', name: 'Yusuf Danjuma', role: 'Textile historian', contribution: 'Spoke with the dyers and shared the reference notes on each pattern.', attribution: 'Textile research' },
];

export const ART_LAUNCH: LaunchCopy = {
  readiness: {
    ...READINESS,
    lead: 'Prepare your plates, recognise the people behind them and share the series with the people it was made for.',
    outcomeTitle: ART_OUTCOME,
    outcomeNote: 'The outcome your team agreed to bring into the world. This is a preview, because the project is still in the Building phase.',
  },
  readinessRows: ART_READINESS_ROWS,
  materials: { ...MATERIALS, lead: 'Six pieces help people understand the series. Create AI can draft them when you ask. Your team decides what goes out.' },
  materialRows: ART_MATERIAL_ROWS,
  credits: ART_CREDITS,
  attribution: {
    ...ATTRIBUTION,
    lead: 'Credits follow what your team agreed, for the illustrators and the dyers.',
    note: 'Credits are drawn from your approved agreements. Dyers are named with their permission.',
  },
  ready: {
    ...READY,
    see: [{ ...READY.see[0], detail: 'Anyone with the link can view the plates and the credits.' }, READY.see[1]],
  },
  sharedRows: sharedRows(ART_MATERIAL_ROWS, 'A short note to share the series.', 'Kemi Adeyemi, Amara Obi, Ayo Bello and Yusuf Danjuma, as your team agreed.'),
  outcome: {
    ...OUTCOME,
    title: 'Adire Stories',
    lead: `${ART_OUTCOME}.`,
    about:
      'A shared illustration series that celebrates adire textile patterns and the people who make them. Each of the twelve plates pairs a dyer or pattern maker in Abeokuta, Ibadan or Osogbo with one pattern. The series ends as a printed zine and a small exhibition.',
    link: 'akines.vercel.app/outcome/adire-stories',
    sharedNote: 'Shared on 3 November 2026. Every project owner approved sharing.',
  },
  confirmModal: { ...CONFIRM_MODAL, description: 'Your team agreed how illustrators and dyers are credited. Check them before you confirm.' },
  shareModal: {
    ...SHARE_MODAL,
    description: 'Anyone with the link will be able to view the plates and the credits. Create AI cannot publish. Only your team can share the project.',
  },
  toastConfirmed: TOAST_CONFIRMED,
  toastShared: TOAST_SHARED,
  context: {
    ...CAREER_LAUNCH.context,
    phase: 'Building',
    attribution: {
      ...CAREER_LAUNCH.context.attribution,
      detail: 'Credits follow the agreements your team approved, including credit for the dyers.',
    },
    outcome: {
      ...CAREER_LAUNCH.context.outcome,
      headline: 'Shared on 3 November 2026',
      detail: 'Anyone with the link can view the series.',
    },
  },
};

export const LAUNCH: Record<ProjectKey, LaunchCopy> = { career: CAREER_LAUNCH, adire: ART_LAUNCH };
export const LAUNCH_PATHS: Record<ProjectKey, typeof LP> = { career: LP, adire: ART_LP };
