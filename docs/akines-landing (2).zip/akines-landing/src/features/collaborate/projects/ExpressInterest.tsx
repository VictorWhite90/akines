'use client';

/**
 * 12.8 Express interest: the form (Figma 17327:21307 empty, 17328:21731 Ready), Sending (17328:21811), Could not send (17328:21891)
 * and Interest sent (17328:22440). The form starts prefilled (role chosen), so Send interest works at once; clicking the chosen role
 * again clears it and reaches the empty frame, where Send interest is disabled.
 * Photo: the owner portrait and the large photo are Ngozi Eze, Figma image hash cb6ee846 (nodes 17328:21744, 17328:22448, 17328:22458).
 * The detail page with the sent request and the withdraw modal live in ProjectDetail.tsx.
 */
import { useEffect, useId, useState } from 'react';
import { Button, Chip, Field, Radio, TextArea } from '@/ui';
import { useNav } from '@/lib/nav';
import { asset } from '@/lib/assets';
import { LOADING_MS, setInterest, useInterestState } from './store';
import { OTHER_ROLE, TIME_OPTIONS, interestDefaults, ownerFirst, personBySlug, projectBySlug, type Project } from './data';
import { BackLink, CardLink, IconArrowRight, Notice, StatusPill } from './ui';
import { REQUEST_BASE } from '../applications/paths';
import { resetApplication } from '../applications/store';

export type InterestVariant = 'empty' | 'sending' | 'error' | 'sent';
type Phase = 'form' | 'sending' | 'error' | 'sent';

const SENT_PHOTO = '/images/app/collab-projects/ngozi-eze.jpg';

/** Round owner photo (the designed project) or initials. */
function OwnerPortrait({ project, size }: { project: Project; size: number }) {
  const lead = project.team[0];
  const person = lead?.slug ? personBySlug(lead.slug) : undefined;
  return person ? (
    <img className="dsc-portrait" src={asset(person.portrait)} alt="" width={size} height={size} loading="lazy" decoding="async" />
  ) : (
    <span className="dsc-portrait dsc-portrait--initials" style={{ width: size, height: size }} aria-hidden="true">
      {lead?.initials ?? project.owner[0]}
    </span>
  );
}

export function ExpressInterestScreen({ slug, variant }: { slug: string; variant?: InterestVariant }) {
  const project = projectBySlug(slug)!;
  const nav = useNav();
  const interests = useInterestState();
  const defaults = interestDefaults(slug);
  const blank = variant === 'empty';
  const [role, setRole] = useState(blank ? '' : defaults.role);
  const [time, setTime] = useState(blank ? '' : defaults.time);
  const [message, setMessage] = useState(blank ? '' : defaults.message);
  const [phase, setPhase] = useState<Phase>(() => (variant === 'sending' ? 'sending' : variant === 'error' ? 'error' : variant === 'sent' ? 'sent' : 'form'));
  const uid = useId();
  const first = ownerFirst(project);
  const roles = [...project.needs.map((n) => n.title), OTHER_ROLE];
  const detailHref = `/collaborate/projects/${slug}`;

  // Figma Sending frame: after 2.5 s the request is sent (or, offline, it could not be sent)
  useEffect(() => {
    if (phase !== 'sending') return;
    const t = window.setTimeout(() => {
      if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        setPhase('error');
        return;
      }
      setInterest(slug, { role: role || defaults.role, time: time || defaults.time, message });
      // a new request starts at Pending (12.44 APPLICATION STATUS)
      resetApplication();
      setPhase('sent');
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  // the static "Interest sent" route has no form behind it: store the dummy request so the detail page shows it
  useEffect(() => {
    if (variant === 'sent' && !interests[slug]) setInterest(slug, defaults);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------------- Interest sent (17328:22440) ---------------- */
  if (phase === 'sent') {
    const sent = interests[slug] ?? defaults;
    return (
      <div className="dsc-sent">
        <div className="dsc-sent__content">
          <p className="dsc-eyebrow" data-m="up">
            Interest sent
          </p>
          <h1 className="dsc-h1 dsc-h1--sent" data-m="words">
            Your interest is on its way.
          </h1>
          <p className="dsc-lead" data-m="up">
            {first} can now read your message and decide whether to invite you onto the team. You will see the reply here.
          </p>
          <section className="dsc-request dsc-request--link" aria-label="Your request" data-m="up">
            <div className="dsc-request__row">
              <OwnerPortrait project={project} size={64} />
              <div className="dsc-request__info">
                <p className="dsc-request__name">{project.title}</p>
                <p className="dsc-request__meta">
                  {sent.role}, {sent.time.charAt(0).toLowerCase() + sent.time.slice(1)}
                </p>
              </div>
              <StatusPill status="pending" />
            </div>
            <hr className="dsc-request__rule" />
            <p className="dsc-request__note">{first} has not replied yet. You will see the decision here when it arrives.</p>
            {/* 12.44: the card and this link open the request (Figma 17328:22446, 17974:166502) */}
            <CardLink href={REQUEST_BASE} arrow>
              View request
            </CardLink>
          </section>
          <div className="dsc-actions">
            <Button href={detailHref} iconRight={<IconArrowRight />}>
              Back to project
            </Button>
            <Button variant="secondary" href="/collaborate/discover">
              Find more projects
            </Button>
          </div>
        </div>
        <div className="dsc-sent__photo" data-m="frame">
          <img className="cover" src={asset(SENT_PHOTO)} alt="" decoding="async" />
        </div>
      </div>
    );
  }

  const busy = phase === 'sending';
  const send = () => {
    if (!role || busy) return;
    setPhase('sending');
  };

  return (
    <div className="dsc-page">
      <form
        className="dsc-interest"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <BackLink href={detailHref}>Back to project</BackLink>

        <header className="dsc-interest__heading">
          <p className="dsc-eyebrow" data-m="up">
            Express interest
          </p>
          <h1 className="dsc-h1 dsc-h1--interest" data-m="words">
            Tell the team how you can help.
          </h1>
          <p className="dsc-lead" data-m="up">
            Choose a role, say how much time you can give and add a note if you like. {first} reviews every request personally.
          </p>
        </header>

        <section className="dsc-summary-card" aria-label="Project and owner">
          <div className="dsc-summary-card__project">
            <p className="dsc-eyebrow">Project</p>
            <p className="dsc-summary-card__name">{project.title}</p>
          </div>
          <span className="dsc-summary-card__divider" aria-hidden="true" />
          <div className="dsc-summary-card__owner">
            <OwnerPortrait project={project} size={56} />
            <div className="dsc-summary-card__info">
              <p className="dsc-eyebrow">Project owner</p>
              <p className="dsc-summary-card__name">{project.owner}</p>
              <p className="dsc-summary-card__role">{personBySlug(project.team[0]?.slug ?? '')?.role ?? project.team[0]?.role ?? 'Project owner'}</p>
            </div>
          </div>
        </section>

        <div className="dsc-interest__fields" inert={busy || undefined}>
          <div className="dsc-group" role="group" aria-labelledby={`${uid}-role`}>
            <p className="dsc-eyebrow" id={`${uid}-role`}>
              Which role would you like to take?
            </p>
            <div className="dsc-roles">
              {roles.map((r) => (
                <Radio
                  key={r}
                  name="role"
                  value={r}
                  label={r}
                  checked={role === r}
                  onChange={() => setRole(r)}
                  // Figma: the chosen role is a toggle, clicking it again clears the choice
                  onClick={() => {
                    if (role === r) setRole('');
                  }}
                />
              ))}
            </div>
          </div>

          <div className="dsc-group" role="group" aria-labelledby={`${uid}-time`}>
            <p className="dsc-eyebrow" id={`${uid}-time`}>
              How much time can you give?
            </p>
            <div className="dsc-times">
              {TIME_OPTIONS.map((t) => (
                <Chip key={t} variant="choice" selected={time === t} onClick={() => setTime(t)}>
                  {t}
                </Chip>
              ))}
            </div>
          </div>

          <Field label="Your message" hint="Optional. A few sentences are enough." className="dsc-message">
            <TextArea
              rows={3}
              value={message}
              data-filled={message ? 'true' : undefined}
              placeholder={`Tell ${first} why this project matters to you and what you could bring.`}
              onChange={(e) => setMessage(e.target.value)}
            />
          </Field>
        </div>

        <Notice title="Only the project owner sees this." text={`${first} will see your message and your public profile. Your contact details stay private until you both agree to talk.`} />
        {phase === 'error' ? <Notice tone="error" title="We could not send your interest." text="Check your connection and try again. Your answers are saved." /> : null}

        <div className="dsc-actions">
          {phase === 'error' ? (
            <Button type="submit" iconRight={<IconArrowRight />}>
              Try again
            </Button>
          ) : (
            <Button type="submit" disabled={!role || busy} iconRight={busy ? undefined : <IconArrowRight />} aria-busy={busy || undefined}>
              {busy ? 'Sending...' : 'Send interest'}
            </Button>
          )}
          <Button variant="secondary" disabled={busy} onClick={() => nav.push(detailHref)}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}

export const ExpressInterest = ({ slug }: { slug: string }) => <ExpressInterestScreen slug={slug} />;
