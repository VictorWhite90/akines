'use client';

import './dash.css';
import { useRef, type ReactNode } from 'react';
import { useNav } from '@/lib/nav';
import { asset } from '@/lib/assets';
import { Button, Drawer } from '@/ui';
import { teamFor, type TeamMember } from '../project-team/data';
import { meetings, meetPaths } from '../meetings/store';
import { CardLink, Dot, Over } from './atoms';
import { useProject } from './project';

/**
 * The right slide-out of the project pages (Figma "Slide-out:Member" 17813:95785 and "Panel:Conversation info" 17808:109955): a 480 wide
 * panel from the right edge over a blurred, darkened page. Header with a small uppercase label and the close button, a scrolling body that
 * brings its own padding, and a footer with the actions. Built on the Drawer, which supplies the backdrop, focus trap, Escape and the exit.
 */
export function SlideOut({ open, onClose, eyebrow, label, footer, children, width = 480 }: { open: boolean; onClose: () => void; eyebrow: string; label?: string; footer?: ReactNode; children: ReactNode; width?: number }) {
  return (
    <Drawer open={open} onClose={onClose} eyebrow={eyebrow} label={label ?? eyebrow} width={width} flush footer={footer} className="cd-slide">
      {children}
    </Drawer>
  );
}

const TONE: Record<TeamMember['presence'], 'green' | 'accent' | 'gray'> = { available: 'green', working: 'accent', away: 'gray', unshared: 'gray' };

/** Start meeting from a slide-out: starts a meeting for everyone and opens its lobby. */
export function useStartMeeting() {
  const nav = useNav();
  const { key, root } = useProject();
  return () => {
    meetings.startNow(key);
    nav.push(meetPaths(root).lobby);
  };
}

/** The member slide-out: portrait, name, role, availability, ABOUT, SKILLS, RECENT CONTRIBUTION; Message (no destination), Start meeting, Open full profile (when the member has a detail page). */
export function MemberSlideOut({ member, open, onClose }: { member: TeamMember | null; open: boolean; onClose: () => void }) {
  const last = useRef<TeamMember | null>(null);
  if (member) last.current = member;
  const m = member ?? last.current;
  const start = useStartMeeting();
  if (!m) return null;
  return (
    <SlideOut
      open={open}
      onClose={onClose}
      eyebrow="MEMBER"
      label={m.name}
      footer={
        <>
          {/* Message has no destination in the design (messages are not built) */}
          <Button size="sm">Message</Button>
          <Button size="sm" variant="secondary" onClick={start}>
            Start meeting
          </Button>
          {m.href ? <CardLink href={m.href}>Open full profile</CardLink> : null}
        </>
      }
    >
      <div className="cd-member">
        {m.photo ? (
          <div className="cd-member__photo">
            <img src={asset(m.photo)} alt="" decoding="async" />
          </div>
        ) : null}
        <div className="cd-member__body">
          <div className="cd-member__id">
            <h2 className="cd-member__name">{m.name.replace(/\s*\(you\)/i, '')}</h2>
            <p className="cd-member__role">{m.role}</p>
            <p className="cd-member__status">
              <Dot tone={TONE[m.presence]} size={7} />
              {m.availability}
            </p>
          </div>
          <section className="cd-member__block">
            <Over>ABOUT</Over>
            <p>{m.about}</p>
          </section>
          <section className="cd-member__block">
            <Over>SKILLS</Over>
            <ul className="cd-chips" aria-label="Skills">
              {m.skills.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </section>
          <section className="cd-member__block">
            <Over>RECENT CONTRIBUTION</Over>
            <p>{m.recent}</p>
          </section>
        </div>
      </div>
    </SlideOut>
  );
}

/** The team members of the project of the page being shown (the four of the rail and the Team page). */
export const useMembers = () => teamFor(useProject().key).members;
