/**
 * Every destination used by a button or link on the landing page lives here,
 * so product can change them without touching components.
 *
 * Sign in and Join now go to the designed flows. Links with no destination in the Figma prototype (intention
 * panels, experience cards, philosophy) still point at the 404 page (src/app/not-found.tsx) until one exists.
 * To go live, replace NOT_FOUND with the real URL for that entry. Items marked TODO still need a confirmed destination.
 */
export const NOT_FOUND = '/404';

export const LINKS = {
  /**
   * Sign in. Opens the slide-out sign-in panel over the landing page (see AppLink), like the Figma prototype.
   * "/sign-in" is also a real route (landing page with the panel open) used when a signed-out visitor opens a member page.
   * Hero and closing "Find my kind of connection" and the footer links open the panel too, as in Figma.
   */
  signIn: '/sign-in',
  /** Create account flow: header Join Akines and "Join the Akines community" (Figma: CTA / Join Akines). */
  join: '/join',
  /** Intention panels and experience links: the Figma landing has no destination for them yet, so they go to the 404 page. */
  notBuilt: NOT_FOUND,
  /** Long-form philosophy page ("Explore the Akines philosophy", "Understand our approach"): not designed yet. */
  philosophy: NOT_FOUND,
  /** Contact. TODO: replace with a mailto: or contact page. Scrolls to the footer for now. */
  contact: '#contact',
  /** Legal and trust pages. TODO: none of these routes exist yet. */
  privacy: '#',
  terms: '#',
  accessibility: '#',
  guidelines: '#',
  safety: '#trust',
} as const;

/** In-page anchors. Section ids are set in the section components. */
export const ANCHORS = {
  top: '#top',
  intention: '#intention',
  philosophy: '#philosophy',
  howItWorks: '#how-it-works',
  experiences: '#experiences',
  trust: '#trust',
  community: '#community',
  contact: '#contact',
} as const;
