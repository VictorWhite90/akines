'use client';

/**
 * The list pages that Discover leads to (Figma 11.66 to 11.72). Each is a component with its own props for the state routes:
 *
 *  - ExploreAll (11.66, /connect/explore): header, search field, the five Explore cards in a grid of three. The search field takes
 *    text and does nothing: no results are designed for it. The Circles card has no destination (KinCircle is design only).
 *  - ForYouAll (11.67, /connect/for-you): the seven chips and the 18 cards. Studio Visits gives No results (its frame), the other chips
 *    filter the cards by kind. `initial` opens the page with a chip on (the No results route).
 *  - AllInterests (11.68, /connect/interests): the twelve interest cards. Every card opens the one Interest page, as drawn.
 *  - InterestPage (11.69, /connect/interests/visual-arts): Visual Arts with the chips All, People, Circles, Projects and Events.
 *    Projects gives No results (its frame) with "Start a project".
 *  - EventsPage (11.70, /connect/events): the six events; no chip is on at first. This week gives No results (its frame) with "Show all
 *    events"; the other chips filter the events. Pressing the chip that is on turns it off.
 *  - Suggestions (11.72, /connect/discover/suggestions): the eight Someone to meet cards (the card of Discover, RecCard); `empty` is the Empty frame.
 *
 * Every page has the page chrome of Discover: the Back link, the section header and the rail (list-parts.tsx).
 */
import { useState } from 'react';
import { Search } from 'lucide-react';
import { TextInput } from '@/ui';
import {
  ALL_INTERESTS,
  EVENTS_PAGE,
  EVENT_FILTERS,
  EXPLORE,
  EXPLORE_PAGE,
  FILTERS,
  FOR_YOU_PAGE,
  HEADS,
  INTERESTS_PAGE,
  INTEREST_FILTERS,
  INTEREST_PAGE,
  PATHS,
  SUGGESTIONS,
  SUGGESTIONS_PAGE,
  eventsFor,
  forYouAllCards,
  forYouEmptyText,
  interestCards,
  type EventFilter,
  type ForYouFilter,
  type InterestFilter,
} from './data';
import { ExploreCard } from './ExploreCard';
import { InterestCard } from './InterestCard';
import { FilterBlock, ListPage, NoResults } from './list-parts';
import { RecCard } from './Recommendations';
import { EmptyText } from './states';
import './explore.css';
import './interests.css';
import './recs.css';

/* ---------------------------------------------------------------- Explore all */
export function ExploreAll() {
  return (
    <ListPage wide title={EXPLORE_PAGE.title} support={EXPLORE_PAGE.support} back={EXPLORE_PAGE.back} backHref={PATHS.discover}>
      <TextInput
        type="search"
        className="dxl-search"
        iconLeft={<Search size={20} strokeWidth={1.25} absoluteStrokeWidth aria-hidden="true" focusable="false" />}
        placeholder={EXPLORE_PAGE.search}
        aria-label={EXPLORE_PAGE.search}
        autoComplete="off"
        enterKeyHint="search"
      />
      <ul className="dxe-grid" data-m="stagger">
        {EXPLORE.map((c, i) => (
          <li key={c.id} style={{ ['--i' as string]: i }}>
            <ExploreCard c={c} index={i} eager={i < 3} />
          </li>
        ))}
      </ul>
    </ListPage>
  );
}

/* ---------------------------------------------------------------- For you, all */
export function ForYouAll({ initial = 'all' }: { initial?: ForYouFilter }) {
  const [filter, setFilter] = useState<ForYouFilter>(initial);
  return (
    <ListPage title={HEADS['for-you'].title} support={HEADS['for-you'].support} back={FOR_YOU_PAGE.back} backHref={PATHS.discover}>
      <FilterBlock
        name="Filter For you on Akines"
        chips={FILTERS}
        value={filter}
        onSelect={setFilter}
        cards={forYouAllCards(filter)}
        cardFilter={filter}
        none={<NoResults text={forYouEmptyText(filter)} action={{ label: FOR_YOU_PAGE.empty.link, onClick: () => setFilter('all') }} />}
      />
    </ListPage>
  );
}

/* ---------------------------------------------------------------- All interests */
export function AllInterests() {
  return (
    <ListPage title={INTERESTS_PAGE.title} support={INTERESTS_PAGE.support} back={INTERESTS_PAGE.back} backHref={PATHS.discover}>
      <ul className="dxi-grid" data-m="stagger">
        {ALL_INTERESTS.map((it, i) => (
          <li key={it.id}>
            <InterestCard interest={it} index={i} />
          </li>
        ))}
      </ul>
    </ListPage>
  );
}

/* ---------------------------------------------------------------- Interest page (Visual Arts) */
const VISUAL_ARTS = ALL_INTERESTS[0];
export function InterestPage({ initial = 'all' }: { initial?: InterestFilter }) {
  const [filter, setFilter] = useState<InterestFilter>(initial);
  return (
    <ListPage title={VISUAL_ARTS.title} support={VISUAL_ARTS.text} back={INTEREST_PAGE.back} backHref={PATHS.discover}>
      <FilterBlock
        name={`Filter ${VISUAL_ARTS.title}`}
        chips={INTEREST_FILTERS}
        value={filter}
        onSelect={setFilter}
        cards={interestCards(filter)}
        cardFilter={filter}
        none={<NoResults text={INTEREST_PAGE.empty.text} action={{ label: INTEREST_PAGE.empty.link, href: INTEREST_PAGE.empty.href }} />}
      />
    </ListPage>
  );
}

/* ---------------------------------------------------------------- Events */
export function EventsPage({ initial = null }: { initial?: EventFilter | null }) {
  const [filter, setFilter] = useState<EventFilter | null>(initial);
  const cards = eventsFor(filter);
  return (
    <ListPage title={EVENTS_PAGE.title} support={EVENTS_PAGE.support} back={EVENTS_PAGE.back} backHref={PATHS.discover}>
      <FilterBlock
        name="Filter events"
        chips={EVENT_FILTERS}
        value={filter}
        onSelect={(key) => setFilter((f) => (f === key ? null : key))}
        cards={cards}
        cardFilter="events"
        none={<NoResults text={filter ? EVENTS_PAGE.empty(filter) : ''} action={{ label: EVENTS_PAGE.showAll, onClick: () => setFilter(null) }} />}
      />
    </ListPage>
  );
}

/* ---------------------------------------------------------------- All suggestions */
export function Suggestions({ empty }: { empty?: boolean }) {
  return (
    <ListPage title={SUGGESTIONS_PAGE.title} support={SUGGESTIONS_PAGE.support} back={SUGGESTIONS_PAGE.back} backHref={PATHS.discover}>
      {empty ? (
        <EmptyText>{SUGGESTIONS_PAGE.empty}</EmptyText>
      ) : (
        <div className="dxr-cards">
          <ul className="dxr-grid">
            {SUGGESTIONS.map((rec, i) => (
              <RecCard key={rec.id} rec={rec} index={i} />
            ))}
          </ul>
        </div>
      )}
    </ListPage>
  );
}
