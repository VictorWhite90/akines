# Akines Button, one component everywhere (4 Nov 2026)

Goal: the landing page button, with its hover effect, is the only button. Today there are two implementations
(`src/components/Button.tsx` with `.btn`, and `src/ui/Button.tsx` with `.k-btn`) and about ten ad hoc button styles.
Figma has the matching set on the Components page ("Button" and "Icon Button", built the same day). Keep the two in step.

## The effect (from the landing, `src/styles/base.css` `.btn`)
Pill (radius 999). On hover (pointer devices only) a fill rises from the bottom edge in 0.55 s ease-out
(`translateY(101%)` to `none`), the label colour changes in 0.4 s, a 1 px ring fades in, and the arrow icon nudges
(up-right 2 px, down 2 px for arrow-down). Press scales to 0.97. Reduced motion: no transitions.
Colours swap on hover, they do not just darken.

## API (`src/ui/Button.tsx`, one export `Button`, plus `IconButton`)
| Prop | Values | Notes |
| --- | --- | --- |
| `variant` | `primary` `secondary` `accent` `ghost` `danger` `link` | `link` is text with an underline, no sweep |
| `tone` | `dark` (default) `light` | `dark` = for light surfaces, `light` = for photos and dark surfaces. Replaces `tone="default"` |
| `size` | `sm` 36, `md` 48 (default), `lg` 56, `xl` 62 | `xl` is the landing "large": 48 below 1280, 62 from 1280 |
| `fluid` | boolean | landing only: `md` is 48 below 1280 and 50 from 1280 (padding 12/20, 14/24), exactly as the old `.btn` |
| `icon`, `iconRight` | ReactNode | `iconRight` nudges on hover. Helpers `arrow="up-right"`, `"down"` or `"right"` give the built-in arrows and the nudge direction |
| `loading` | boolean | spinner, keeps width, ignores clicks, `aria-busy` |
| `disabled` | boolean | native disabled, or `aria-disabled` for links |
| `looksDisabled` | boolean | grey like disabled but still receives clicks (forms where the click explains what is missing); sets `aria-disabled` |
| `fullWidth`, `href`, `onClick`, `className`, `type` | | `href` renders the app `Link` (external URLs get `rel="noopener"`) |
| `state` | `hover` `pressed` `focus` | design gallery only: forces a state for static display (`data-force` attribute) |

`IconButton`: round, `label` required (aria-label and tooltip), `variant` `solid` `outline` `ghost`, `tone`, `size` sm 36, md 44, lg 52, optional `href` (renders a link) and `tooltip` (default true; the landing turns it off because it has none today). The tooltip pill stays inside the viewport.

## Colours per variant (all tokens exist in `src/styles/app-tokens.css` or the landing `tokens.css`)
Hex shown for reference. Rest, then hover (the sweep colour, the label colour, the ring), then pressed.

| Variant, tone | Fill | Label | Border | Hover sweep | Hover label | Hover ring | Pressed sweep |
| --- | --- | --- | --- | --- | --- | --- | --- |
| primary, dark | ink #181818 | inverse #FEFEFE | none | ivory #F4F1EB | ink | ink 1 px | surface-muted #F3F3F3 |
| primary, light | ivory #F4F1EB | ink | none | ink | inverse | none | #494949 |
| secondary, dark | transparent | ink | ink 1 px | ink | ivory | none | #494949 |
| secondary, light | transparent | inverse | inverse 1 px | inverse #FEFEFE | ink | none | ivory |
| accent, dark | amber #F4A63A | ink | none | ink | amber | none | #494949 |
| accent, light | amber #F4A63A | ink | none | inverse | ink | none | ivory |
| ghost, dark | transparent | ink | none | surface-muted #F3F3F3 | ink | none | #E5E5E5 |
| ghost, light | transparent | inverse | none | rgba(254,254,254,.16) | inverse | none | rgba(254,254,254,.26) |
| danger | #D31900 text on transparent, 1 px #FF3B30 border | | | #FF3B30 sweep | inverse | none | #D31900 |
| link | no fill | ink, underline | none | underline thickens | | | |

Disabled: fill `--action-primary-disabled` #DADADA with label `--text-secondary`; outline variants border #DADADA and
label #CCCCCC; ghost and link label #CCCCCC; no sweep, no scale, cursor not-allowed.
Focus visible: 2 px ivory ring plus a 2 px ink ring outside it (the existing app focus style; keep it).
Loading: 16 px spinner left of the label (existing `k-btn__spinner`), label stays, `aria-busy`.

Sizes (font sizes follow the Figma text styles): sm 36 high, padding 0 16, font 14/600, gap 8, icon 14.
md 48, padding 0 24, font 14/600, gap 10, icon 14. lg 56, padding 0 32, font 16/600, icon 16.
xl 62 (from 1280, 48 below), padding 0 32, font 16/600, icon 16.
Font Manrope 600, letter-spacing 0.018em for sm and md, 0 for lg and xl.

## Migration rules
1. `src/components/Button.tsx` and `.btn` styles in `base.css` go away. The landing (`Hero`, `Community`, `FinalCta`,
   `Rhythm`, `NotFoundView`, header CTA `btn--header`) uses the unified Button. The landing must be pixel identical at
   1512, 1194 and 402 (take before screenshots first, compare after).
   Mapping: `light-filled` = primary, tone light. `light-outline` = secondary, tone light. `dark-filled` = primary.
   `dark-outline` = secondary. `size="large"` = xl with `fluid`. Default size = md with `fluid`.
2. Replace the ad hoc action buttons with `Button` or `IconButton`: `.au-btn` (auth), `.fd-pick__btn`, `.cd-card__cta`,
   `.cs-pill` and `.cs-pill--outline`, `.cw-pill`, `.cs-oc__cta`, `.round-btn` and `--outline`, `.icon-btn`, `.cw-ibtn`,
   `.cs-car__btn`, `.cd-savebtn`, `.hdr-iconbtn` and any raw `<button>` that is visually a pill or a round icon button
   performing an action. Keep as they are (not buttons in this sense): tabs, chips, toggles, menu rows, the avatar
   menu trigger, cards that are clickable, form controls, the bottom bar items.
3. Behaviour must not change: same handlers, same hrefs, same labels, same prefilled forms.
4. Where a raw button had a different size (for example 44 high), choose the nearest size; if a layout has a fixed
   height slot (the feed's 62 px slot, the match card) keep the slot and centre the button.
5. Delete dead CSS after migration. Prefix `k-btn` stays the component class (`.k-btn`), the landing prefix goes.

## Living gallery
Add route `/design/buttons` (registered in the route registry, not linked from any nav): every variant by tone by size
by state (default, hover, pressed, focus, disabled, loading) with the forced `state` prop, with and without icons, plus
`IconButton`. Dark tone on ivory, light tone on a dark photo band. This is the page we check in the artifact.

## Verification (do all)
`npx tsc --noEmit`; `node scripts/build-preview.mjs <dir>`; `node scripts/check-routes.mjs` (preview) and a Next
production build; Playwright: hover really changes colours and the rising fill covers the button (measure computed
styles after hover on landing and on an app screen), press scales, disabled ignores clicks, loading ignores clicks,
keyboard focus ring shows, reduced motion has no transitions; before/after screenshots of the landing and of at least
ten app screens that contain buttons (community, feed, collaborate, auth, join). No console errors, no horizontal
overflow at 360, 402, 768, 1194, 1280, 1512, 1920. No em dashes in any copy or comments you write.
