import { asset } from '@/lib/assets';
import type { ModalId } from './store';

/** Paths of the Community screens (canonical, see BUILD_GUIDE) */
export const P = {
  home: '/community',
  messages: '/community/messages',
  thread: (slug: string) => `/community/messages/${slug}`,
  collabs: '/community/collaborations',
  zine: '/community/collaborations/lagos-makers-zine',
  care: '/community/care',
  reflect: '/community/care/reflect',
  pro: '/community/care/professional-support',
  settings: '/community/settings',
  recs: '/community/settings/recommendations',
  privacy: '/community/settings/privacy',
  connection: '/community/settings/connection',
  banter: '/community/banter',
  connect: '/connect',
} as const;

/** Photos copied from Figma (public/images/app/community). Node ids in the comments of each screen. */
export const IMG = (name: string) => asset(`/images/app/community/${name}.jpg`);
export const AV = (name: string) => asset(`/images/app/community/av-${name}.jpg`);

export type AvKey = 'amara' | 'tunde' | 'ngozi' | 'folake' | 'chuka' | 'kincircle' | 'health' | 'friends' | 'zine';

/** Header photo and avatar of each place or person */
export const FACE: Record<AvKey, { name: string }> = {
  amara: { name: 'Amara' },
  tunde: { name: 'Tunde' },
  ngozi: { name: 'Ngozi' },
  folake: { name: 'Folake' },
  chuka: { name: 'Chuka' },
  kincircle: { name: 'KinCircle' },
  health: { name: 'Community Health Initiative' },
  friends: { name: 'Friends' },
  zine: { name: 'Lagos Makers Zine' },
};

export type Action = { modal: ModalId } | { to: string };

/* ---------- 01 intentions ---------- */
export type Suggestion = { title: string; text: string; meta: string; avatar?: AvKey; act: Action };
export type Intention = { label: string; headline: string; items: Suggestion[] };

export const INTENTIONS: Intention[] = [
  {
    label: 'I want some company.',
    headline: 'Some company, whenever you are ready.',
    items: [
      { title: 'Quick Catch-up', text: 'A short, easy conversation with someone from your circle.', meta: 'About 15 min', avatar: 'folake', act: { modal: 'quick' } },
      { title: 'Banter: Can ambition and rest coexist?', text: 'Starts at 6:00 PM. Come to listen or to join in.', meta: 'Today', act: { modal: 'up-banter' } },
      { title: 'Quiet company', text: 'Be in a calm room with others. No talking needed.', meta: 'Anytime', act: { to: P.care } },
    ],
  },
  {
    label: 'I want to collaborate.',
    headline: 'People and projects to build with.',
    items: [
      { title: 'Tunde', text: 'Community-health collaborator who likes practical, small-group work.', meta: 'Collaborator', avatar: 'tunde', act: { modal: 'why-tunde' } },
      { title: 'Lagos Makers Zine', text: 'An open project that could use one more maker.', meta: 'Open project', avatar: 'zine', act: { to: P.zine } },
      { title: 'Arrange a Create Call with Amara', text: 'Pick up the Community Health Initiative together.', meta: 'Create Call', avatar: 'amara', act: { modal: 'cc-amara' } },
      { title: 'Starting a purpose-driven business', text: 'A KinCircle gathering on Thursday. Two places available.', meta: 'KinCircle', avatar: 'kincircle', act: { modal: 'inv-kin' } },
    ],
  },
  {
    label: 'I want to meet someone new.',
    headline: 'Someone new, for a good reason.',
    items: [
      { title: 'Tunde', text: 'Community-health initiatives and small-group collaboration.', meta: 'Introduction', avatar: 'tunde', act: { modal: 'why-tunde' } },
      { title: 'Ngozi', text: 'Writing to remember, and quiet one-to-one conversation.', meta: 'Introduction', avatar: 'ngozi', act: { modal: 'why-ngozi' } },
      { title: 'Starting a purpose-driven business', text: 'Meet five members at a KinCircle on Thursday.', meta: 'KinCircle', avatar: 'kincircle', act: { modal: 'inv-kin' } },
    ],
  },
  {
    label: 'I want to talk to a friend.',
    headline: 'Time with someone you know.',
    items: [
      { title: 'Amara', text: 'Your project has been quiet for six days.', meta: 'Conversation', avatar: 'amara', act: { to: P.thread('amara') } },
      { title: 'Folake', text: 'You were planning a Sunday walk.', meta: 'Conversation', avatar: 'folake', act: { to: P.thread('folake') } },
      { title: 'Game night with university friends', text: 'Friday. Easy company and a few good games.', meta: 'Friday', act: { modal: 'up-game' } },
    ],
  },
  {
    label: 'I want to play.',
    headline: 'Time to play.',
    items: [
      { title: 'Game night with university friends', text: 'Friday, with people you already know.', meta: 'Friday', act: { modal: 'up-game' } },
      { title: 'Play Call', text: 'Games and play with people who like to laugh.', meta: 'About 30 min', act: { modal: 'play' } },
    ],
  },
  {
    label: 'I need encouragement.',
    headline: 'A little encouragement.',
    items: [
      { title: 'Message someone I trust', text: 'Send a note to someone who knows you well.', meta: 'Private', act: { modal: 'trust' } },
      { title: 'Support Call', text: 'A listening ear when something is weighing on you.', meta: 'About 20 min', act: { modal: 'support' } },
      { title: 'Reflect privately', text: 'Write down how things are, just for you.', meta: 'Only you', act: { to: P.reflect } },
    ],
  },
  {
    label: 'I want to offer help.',
    headline: 'A way to be useful.',
    items: [
      { title: 'Encourage someone', text: 'Send a short, kind note to a person in your circle.', meta: 'Takes a minute', act: { modal: 'encourage' } },
      { title: 'Community Health Initiative', text: 'Your project with Amara has been quiet for six days.', meta: 'Collaboration', avatar: 'health', act: { to: P.collabs } },
      { title: 'Circle Call', text: 'A small conversation with the Food Systems Cliq.', meta: 'About 45 min', act: { modal: 'circle' } },
    ],
  },
  {
    label: 'I want quiet company.',
    headline: 'Quiet company, close by.',
    items: [
      { title: 'Quiet company', text: 'Be in a calm room with others. No talking needed.', meta: 'Anytime', act: { to: P.care } },
      { title: 'KinCircle Reflection', text: 'Tomorrow. A gentle reflection circle.', meta: 'Tomorrow', act: { modal: 'up-kin' } },
      { title: 'Reflect privately', text: 'Write down how things are, just for you.', meta: 'Only you', act: { to: P.reflect } },
    ],
  },
];

/* ---------- 02 continue ---------- */
export const CONTINUE = [
  {
    key: 'amara',
    who: 'Amara · Community Health Initiative',
    text: 'Your project with Amara has been quiet for six days.',
    last: 'Last message was yours, six days ago',
    image: 'amara',
    thread: 'amara',
    call: 'cc-amara' as ModalId,
  },
  {
    key: 'folake',
    who: 'Folake · Friend',
    text: 'You and Folake were planning a Sunday walk. It has been nine days since you last spoke.',
    last: 'Last message was Folake\'s, nine days ago',
    image: 'folake',
    thread: 'folake',
    call: 'cc-folake' as ModalId,
  },
];

/* ---------- 03 introductions ---------- */
export const INTROS = [
  {
    key: 'tunde',
    name: 'Tunde',
    tags: ['Community health', 'Small-group work'],
    reason: 'You and Tunde are both developing community-health initiatives and prefer practical, small-group collaboration.',
    activity: 'A Create Call to compare how you each plan outreach.',
    image: 'tunde',
    why: 'why-tunde' as ModalId,
    intro: 'intro-tunde' as ModalId,
  },
  {
    key: 'ngozi',
    name: 'Ngozi',
    tags: ['Storytelling', 'Zine-making', 'Slow conversation'],
    reason: 'You and Ngozi both write to remember the people in your lives, and you both prefer a quiet, one-to-one conversation.',
    activity: 'A Quick Catch-up to see whether you would like to write together.',
    image: 'ngozi',
    why: 'why-ngozi' as ModalId,
    intro: 'intro-ngozi' as ModalId,
  },
  {
    key: 'chuka',
    name: 'Chuka',
    tags: ['Small business', 'Thinking out loud'],
    reason: 'You and Chuka are both starting something of your own and like talking ideas through with one person at a time.',
    activity: 'Talk Something Through, for about 20 minutes.',
    image: 'chuka',
    why: 'why-chuka' as ModalId,
    intro: 'intro-chuka' as ModalId,
  },
];

/* ---------- 04 upcoming ---------- */
export type UpcomingItem = { key: string; time: string; title: string; meta: string; image: string; modal: ModalId; extra?: 'inv0' | 'inv1' };
export const UPCOMING: UpcomingItem[] = [
  { key: 'project', time: '2:00 PM', title: 'Project Call with the Food Systems Cliq', meta: 'Create Call · Food Systems Cliq', image: 'health', modal: 'up-project' },
  { key: 'banter', time: '6:00 PM', title: 'Banter: Can ambition and rest coexist?', meta: 'Banter · Open conversation', image: 'friends', modal: 'up-banter' },
  { key: 'kin', time: 'Tomorrow', title: 'KinCircle Reflection', meta: 'KinCircle · Reflection circle', image: 'kincircle-wide', modal: 'up-kin' },
  { key: 'kinbiz', time: 'Thursday', title: 'Starting a purpose-driven business', meta: 'KinCircle · You are going', image: 'kincircle-wide', modal: 'inv-kin', extra: 'inv0' },
  { key: 'game', time: 'Friday', title: 'Game night with university friends', meta: 'Play · University friends', image: 'zine', modal: 'up-game' },
  { key: 'walk', time: 'Next Sunday', title: 'A Sunday walk by the lagoon', meta: 'Friend · You are going', image: 'folake', modal: 'inv-walk', extra: 'inv1' },
];

/* ---------- 05 invitations ---------- */
export const INVITES = [
  {
    key: 'kin',
    inviter: 'KinCircle invitation',
    inviterImg: 'kincircle' as AvKey,
    title: 'Starting a purpose-driven business',
    text: 'Five members are gathering to discuss building businesses around meaningful problems.',
    meta: 'KinCircle · Thursday · Two places available',
    people: ['tunde', 'ngozi', 'chuka'] as AvKey[],
    peopleText: 'Tunde, Ngozi and 3 others',
    image: 'kincircle',
    modal: 'inv-kin' as ModalId,
  },
  {
    key: 'walk',
    inviter: 'Folake invited you',
    inviterImg: 'folake' as AvKey,
    title: 'A Sunday walk by the lagoon',
    text: 'Folake is walking with two friends and would love you to join for an easy, unhurried morning.',
    meta: 'Friend · Next Sunday · 8:00 AM',
    people: ['folake', 'chuka'] as AvKey[],
    peopleText: 'Folake and Chuka',
    image: 'folake',
    modal: 'inv-walk' as ModalId,
  },
];

/* ---------- 06 ways to connect ---------- */
export const WAYS: { key: string; title: string; action: string; image: string; act: Action }[] = [
  { key: 'quick', title: 'Quick Catch-up', action: 'Start a Quick Catch-up', image: 'friends', act: { modal: 'quick' } },
  { key: 'talk', title: 'Talk Something Through', action: 'Talk it through', image: 'ngozi', act: { modal: 'talk' } },
  { key: 'create', title: 'Create Together', action: 'Explore collaboration', image: 'zine-tall', act: { modal: 'create' } },
  { key: 'quiet', title: 'Quiet Company', action: 'Join quiet company', image: 'folake', act: { to: P.care } },
  { key: 'circle', title: 'Circle Call', action: 'Join a Circle Call', image: 'kincircle', act: { modal: 'circle' } },
  { key: 'play', title: 'Play Call', action: 'Start a Play Call', image: 'chuka', act: { modal: 'play' } },
  { key: 'support', title: 'Support Call', action: 'Ask for a Support Call', image: 'amara', act: { modal: 'support' } },
];

/* ---------- 07 active collaborations ---------- */
export const COLLABS = [
  {
    key: 'health',
    image: 'health',
    people: ['amara'] as AvKey[],
    who: 'With Amara',
    title: 'Community Health Initiative',
    text: 'You and Amara are developing a community-health project.',
    status: 'Drafting the outreach plan',
    last: 'Last activity six days ago',
    go: { to: P.collabs } as Action,
    call: { modal: 'cc-amara' } as Action,
    callLabel: 'Arrange a Create Call',
  },
  {
    key: 'zine',
    image: 'zine',
    people: ['folake', 'chuka'] as AvKey[],
    who: 'With Folake and Chuka',
    title: 'Lagos Makers Zine',
    text: 'You, Folake and Chuka are putting together the second issue.',
    status: 'Collecting contributions',
    last: 'Last activity two days ago',
    go: { to: P.zine } as Action,
    call: { modal: 'cc-zine' } as Action,
    callLabel: 'Arrange a Create Call',
  },
  {
    key: 'cliq',
    image: 'kincircle-wide',
    people: ['tunde', 'ngozi'] as AvKey[],
    who: 'With Tunde and Ngozi',
    title: 'Food Systems Cliq Plan',
    text: 'You and the Cliq are shaping a shared project plan together.',
    status: 'Agreeing the next three tasks',
    last: 'Last activity yesterday',
    go: { to: P.thread('food-systems-cliq') } as Action,
    call: { modal: 'create' } as Action,
    callLabel: 'Arrange a Create Call',
  },
  {
    key: 'game',
    image: 'friends',
    people: ['folake', 'chuka'] as AvKey[],
    who: 'With university friends',
    title: 'Game Night Planning',
    text: 'You and your university friends are planning the next game night.',
    status: 'Choosing the games',
    last: 'Last activity three days ago',
    go: { to: P.thread('university-friends') } as Action,
    call: { modal: 'play' } as Action,
    callLabel: 'Start a Play Call',
  },
];

/* ---------- 10 controls ---------- */
export const CONTROLS = [
  { title: 'Recommendation preferences', text: 'Choose which interests and moments Akines may use to suggest people and activities.', to: P.settings },
  { title: 'Recommendation explanations', text: 'See why a person or activity was suggested to you, and what information was used.', to: P.recs },
  { title: 'Privacy settings', text: 'Control who can see you and what stays private to you.', to: P.privacy },
  { title: 'Connection preferences', text: 'Tell Akines how you like to spend time with others.', to: P.connection },
];
