'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { Button, Chip, Field, Modal, TextInput } from '@/ui';
import { CardLink } from '../workspace/parts';
import { CREATE_STAGES, type CreateStage } from './data';
import { useAgreements } from './parts';

/**
 * Modal:Create agreement (17729:120702), Modal:Suggest a change (17729:121142) and Modal:Acknowledge agreement (17729:121194).
 * All three are 640 wide with the eyebrow, headline and support line of the design and the primary button with a Cancel link.
 * The scrim, the close button and Cancel close the modal; every opening starts again from the frame.
 */

/* ------------------------------------------------------------------ Modal:Create agreement */

/** The frame shows Ownership chosen. */
const DEFAULT_STAGE: CreateStage = 'Ownership';

export function CreateAgreementModal({ open, onClose, onCreate }: { open: boolean; onClose: () => void; onCreate: () => void }) {
  const [stage, setStage] = useState<CreateStage>(DEFAULT_STAGE);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const { modal } = useAgreements();
  const m = modal.create;

  useEffect(() => {
    if (open) {
      setStage(DEFAULT_STAGE);
      setTitle('');
      setDescription('');
    }
  }, [open]);

  const create = (e?: FormEvent) => {
    e?.preventDefault();
    onCreate();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={m.eyebrow}
      title={m.title}
      description={m.description}
      footer={
        <>
          <Button type="submit" form="ag-create-form">
            {m.submit}
          </Button>
          <CardLink onClick={onClose}>{modal.cancel}</CardLink>
        </>
      }
    >
      <form id="ag-create-form" className="cw-form" onSubmit={create} noValidate>
        <div className="cw-form__group" role="group" aria-labelledby="ag-stage-label">
          <span className="ag-flabel" id="ag-stage-label">
            {m.stageLabel}
          </span>
          <div className="ag-chips">
            {CREATE_STAGES.map((s) => (
              <Chip key={s} selected={stage === s} onClick={() => setStage(s)}>
                {s}
              </Chip>
            ))}
          </div>
          <p className="ag-hint">{m.stageHint}</p>
        </div>
        <Field label={m.titleLabel} hint={m.titleHint}>
          <TextInput value={title} placeholder={m.titlePlaceholder} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label={m.descLabel} hint={m.descHint}>
          <TextInput value={description} placeholder={m.descPlaceholder} onChange={(e) => setDescription(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal:Suggest a change */

export function SuggestChangeModal({ open, onClose, onSuggest }: { open: boolean; onClose: () => void; onSuggest: () => void }) {
  const [change, setChange] = useState('');
  const [why, setWhy] = useState('');
  const { modal } = useAgreements();
  const m = modal.suggest;

  useEffect(() => {
    if (open) {
      setChange('');
      setWhy('');
    }
  }, [open]);

  const suggest = (e?: FormEvent) => {
    e?.preventDefault();
    onSuggest();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={m.eyebrow}
      title={m.title}
      description={m.description}
      footer={
        <>
          <Button type="submit" form="ag-suggest-form">
            {m.submit}
          </Button>
          <CardLink onClick={onClose}>{modal.cancel}</CardLink>
        </>
      }
    >
      <form id="ag-suggest-form" className="cw-form" onSubmit={suggest} noValidate>
        <Field label={m.changeLabel} hint={m.changeHint}>
          <TextInput value={change} placeholder={m.changePlaceholder} onChange={(e) => setChange(e.target.value)} />
        </Field>
        <Field label={m.whyLabel} hint={m.whyHint}>
          <TextInput value={why} placeholder={m.whyPlaceholder} onChange={(e) => setWhy(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal:Acknowledge agreement */

export function AcknowledgeModal({ open, onClose, onConfirm }: { open: boolean; onClose: () => void; onConfirm: () => void }) {
  const { modal } = useAgreements();
  const m = modal.acknowledge;
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={m.eyebrow}
      title={m.title}
      description={m.description}
      footer={
        <>
          <Button onClick={onConfirm}>{m.submit}</Button>
          <CardLink onClick={onClose}>{modal.cancel}</CardLink>
        </>
      }
    >
      <div className="ag-summary">
        <p className="ag-summary__label">{m.summaryLabel}</p>
        {m.summary.map((line) => (
          <p className="ag-summary__line" key={line}>
            {line}
          </p>
        ))}
        <p className="ag-summary__note">{m.note}</p>
      </div>
    </Modal>
  );
}
