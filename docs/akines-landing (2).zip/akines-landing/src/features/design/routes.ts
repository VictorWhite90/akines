import type { RouteDef } from '@/routes.types';
import { ButtonsGallery } from './ButtonsGallery';

/**
 * Design review pages. They are in the registry (so the preview artifact and the Next build both serve them) but are not linked
 * from any navigation. "/design/buttons" shows every Button and IconButton variant, tone, size and state.
 */
export const routes: RouteDef[] = [{ path: '/design/buttons', title: 'Button gallery', shell: 'site', component: ButtonsGallery }];
