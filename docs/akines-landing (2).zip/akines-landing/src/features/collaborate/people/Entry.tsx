'use client';

import { Button } from '@/ui';
import { asset } from '@/lib/assets';
import { IconCheck } from './cc-ui';
import { R } from './data';

const PRINCIPLES = ['Every recommendation comes with a reason.', 'You decide what to share and who sees it.', 'Nothing is sent without your approval.'];

/** B1 Explore collaborators entry (Figma 17215:14978). Route /collaborate/collaborators. */
export default function Entry() {
  return (
    <div className="cc-split">
      <div className="cc-split__content">
        <div className="cc-heading cc-heading--hero">
          <p className="cc-eyebrow" data-m="up">
            Discover your people
          </p>
          <h1 className="cc-h cc-h--hero" data-m="words">
            Find the people who can help your idea grow.
          </h1>
          <p className="cc-support" data-m="up">
            Discover people whose skills, experience and working preferences may complement yours.
          </p>
        </div>
        <div className="cc-actions" data-m="up">
          <Button href={R.matching} arrow="up-right">
            Explore collaborators
          </Button>
          <Button variant="secondary" href={R.start}>
            Start a project
          </Button>
        </div>
        <ul className="cc-principles" data-m="up">
          {PRINCIPLES.map((p) => (
            <li key={p}>
              <IconCheck size={16} />
              <span>{p}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="cc-split__photo" data-m="frame">
        {/* Figma node 17215:15008 "Collaborators photo" (605 x 762) */}
        <img className="cover" src={asset('/images/app/collab-people/hero-collaborators.jpg')} alt="" decoding="async" width={605} height={762} />
      </div>
    </div>
  );
}
