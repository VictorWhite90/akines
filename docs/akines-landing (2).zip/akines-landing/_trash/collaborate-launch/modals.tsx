'use client';

import { useEffect, useState } from 'react';
import { Button, Modal } from '@/ui';
import { CardLink } from '../workspace/parts';
import { ApprovalItem, useLaunch } from './parts';

/**
 * Modal:Confirm attribution (17729:101584) and Modal:Share project (17729:101663). Both are 640 wide with the eyebrow, headline and support
 * line of the design, the primary button and a Cancel link. The scrim, the close button and Cancel close the modal.
 */

/* ------------------------------------------------------------------ Modal: Confirm attribution */

export function ConfirmAttributionModal({ open, onClose, onConfirm }: { open: boolean; onClose: () => void; onConfirm: () => void }) {
  const { confirmModal: m, credits } = useLaunch();
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={m.eyebrow}
      title={m.title}
      description={m.description}
      footer={
        <>
          <Button onClick={onConfirm}>{m.confirm}</Button>
          <CardLink onClick={onClose}>{m.cancel}</CardLink>
        </>
      }
    >
      <ul className="ln-sum" aria-label="Credits">
        {credits.map((c) => (
          <li className="ln-sum__row" key={c.name}>
            <span className="ln-sum__name">{c.name}</span>
            <span className="ln-sum__attr">{c.attribution}</span>
          </li>
        ))}
      </ul>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal: Share project */

/**
 * The approval box starts empty every time the modal opens and toggles on a press. As drawn in the design, Share project is enabled
 * whether or not the box is ticked, so the box does not gate the button.
 */
export function ShareProjectModal({ open, onClose, onShare }: { open: boolean; onClose: () => void; onShare: () => void }) {
  const { shareModal: m } = useLaunch();
  const [approved, setApproved] = useState(false);

  useEffect(() => {
    if (open) setApproved(false);
  }, [open]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={m.eyebrow}
      title={m.title}
      description={m.description}
      footer={
        <>
          <Button onClick={onShare}>{m.share}</Button>
          <CardLink onClick={onClose}>{m.cancel}</CardLink>
        </>
      }
    >
      <ApprovalItem checked={approved} onChange={setApproved}>
        {m.approval}
      </ApprovalItem>
    </Modal>
  );
}
