import { PREVIEW } from './data';

/**
 * Copy of Files / File preview (Figma 12.19, frame 17729:120125), word for word. The preview is a Career Guidance for Everyone page only
 * (Adire Stories mirrors the Files list, not this page). The header, the preview panel, the related work and milestone, and the comments
 * are those of data.ts (PREVIEW, COMMENTS); the metrics and the information rows below are the dashboard version of the old fields.
 */

export const FP_IDS = { info: 'fp-info', comments: 'fp-comments' } as const;

export const FPD = {
  back: 'Back to files',
  label: PREVIEW.label,
  name: PREVIEW.name,
  lead: PREVIEW.lead,
  download: 'Download',

  metrics: {
    size: { label: 'SIZE', value: '2.4', caption: 'MB, PDF document' },
    pages: { label: 'PAGES', value: '5', caption: 'pages' },
    version: { label: 'VERSION', value: '1', caption: 'current version' },
    comments: { label: 'COMMENTS', caption: 'from the team' },
  },

  previewLabel: 'PREVIEW',

  info: {
    title: 'FILE INFORMATION',
    rows: [
      { label: 'Type', value: 'PDF document' },
      { label: 'Added', value: 'Wednesday 4 November' },
      { label: 'Shared by', value: PREVIEW.contributor.name },
      { label: 'Visible to', value: 'Project team only' },
    ],
  },

  /** Connected work: the related work has no destination in the design, the related milestone opens the milestone (Prototype Review). */
  connected: {
    title: 'CONNECTED WORK',
    work: { label: 'Related work', value: PREVIEW.related[0].text },
    milestone: { label: 'Related milestone', value: PREVIEW.related[1].text, href: PREVIEW.related[1].href },
  },
};
