'use client';

import { useEffect } from 'react';
import { Button } from '@/ui';
import { callStore } from './call-store';
import { TopBar, useCast, useLeaveGuard } from './parts';

/**
 * Call ended (Figma 12.43 Call ended 17809:111469). Reaching it always turns the camera, the microphone and the shared screen off, as the text says.
 * Rejoin goes back to the Lobby, Back to conversation to the project's Conversations.
 */
export function EndedScreen() {
  const cast = useCast();
  useLeaveGuard();
  useEffect(() => {
    callStore.stopAll();
  }, []);

  return (
    <div className="mc-page">
      <TopBar project={cast.project} />
      <main className="mc-ended">
        <p className="mc-eyebrow">{cast.meeting.name.toUpperCase()}</p>
        <h1 className="mc-ended__title">You left the meeting.</h1>
        <p className="mc-ended__text">The meeting lasted 38 minutes. Your camera and microphone are now off.</p>
        <div className="mc-ended__actions">
          <Button size="lg" href={cast.paths.lobby}>
            Rejoin
          </Button>
          <Button size="lg" variant="secondary" href={`${cast.root}/conversations`}>
            Back to conversation
          </Button>
        </div>
      </main>
    </div>
  );
}
