'use client';

/**
 * Messages (Figma 10.2): inbox 17105:6750 and five threads (Amara 17105:6928, Folake 17105:7139, Food Systems Cliq 17105:7345,
 * KinCircle Reflection 17105:7548, University friends 17105:7746). The composer starts with the dummy message of the design;
 * sending appends it to the thread and shows the Sent label.
 */
import { useEffect, useRef } from 'react';
import { Button } from '@/ui';
import './community.css';
import { P, type AvKey } from './data';
import { appendMessage, openModal, setDraft, useCommunity, type ModalId } from './store';
import { Avatar, IArrow, ICheck, IMessage, ListRow, TextLink } from './ui';

type Msg = { from: 'in' | 'out'; sender?: string; text: string };
type Thread = {
  slug: string;
  name: string;
  sub: string;
  av: AvKey;
  preview: string;
  meta: string;
  call?: ModalId;
  groups: { date: string; msgs: Msg[] }[];
  draft: string;
};

export const THREADS: Thread[] = [
  {
    slug: 'amara', name: 'Amara', sub: 'Community Health Initiative', av: 'amara', preview: 'No rush. Tell me when you would like to talk it through.', meta: '6d', call: 'cc-amara',
    groups: [
      { date: 'Thursday', msgs: [{ from: 'in', text: 'I mapped out the three clinics we could visit first. Want to look at it together?' }, { from: 'out', text: 'Yes please. I will send my draft of the outreach plan this week.' }] },
      { date: 'Six days ago', msgs: [{ from: 'in', text: 'No rush. Tell me when you would like to talk it through.' }] },
    ],
    draft: 'I am ready to look at the plan. Could we talk tomorrow?',
  },
  {
    slug: 'folake', name: 'Folake', sub: 'Friend', av: 'folake', preview: 'Yes, I would love that. Let me check my week.', meta: '9d', call: 'cc-folake',
    groups: [
      { date: 'Nine days ago', msgs: [{ from: 'in', text: 'Are we still on for the Sunday walk? No pressure if this week has been busy.' }, { from: 'out', text: 'Yes, I would love that. Let me check my week and come back to you.' }] },
    ],
    draft: 'Yes, Sunday works. Shall we say 8:00 AM?',
  },
  {
    slug: 'food-systems-cliq', name: 'Food Systems Cliq', sub: 'Cliq · 9 members', av: 'health', preview: 'I will bring the budget questions to the 2:00 PM call.', meta: 'Today',
    groups: [{ date: 'Today', msgs: [{ from: 'in', sender: 'Tunde', text: 'Notes from the last call are in the shared folder.' }, { from: 'in', sender: 'Ngozi', text: 'I will bring the budget questions to the 2:00 PM call.' }] }],
    draft: 'Thanks both. See you at 2:00 PM.',
  },
  {
    slug: 'kincircle-reflection', name: 'KinCircle Reflection', sub: 'KinCircle · Tomorrow, 12:30 PM', av: 'kincircle', preview: 'Tomorrow we will begin with one thing that went well.', meta: '1d',
    groups: [{ date: 'Yesterday', msgs: [{ from: 'in', sender: 'Facilitator', text: 'Tomorrow we will begin with one thing that went well this week. No preparation needed.' }] }],
    draft: 'Looking forward to it.',
  },
  {
    slug: 'university-friends', name: 'University friends', sub: 'Group · 7 members', av: 'friends', preview: 'I am bringing the Ludo board.', meta: 'Today',
    groups: [{ date: 'Today', msgs: [{ from: 'in', sender: 'Chuka', text: 'Game night on Friday. Bring snacks, not strategy.' }, { from: 'in', sender: 'Folake', text: 'I am bringing the Ludo board.' }] }],
    draft: 'Count me in for Friday.',
  },
];

function Bubble({ m }: { m: Msg }) {
  return (
    <div className={`ch-bub ch-bub--${m.from}`}>
      <div className="ch-bub__col">
        {m.sender ? <span className="ch-bub__sender">{m.sender}</span> : null}
        <p className="ch-bub__text">{m.text}</p>
      </div>
    </div>
  );
}

function Conversation({ t }: { t: Thread }) {
  const s = useCommunity();
  const sent = s.sent[t.slug] ?? [];
  const key = `msg-${t.slug}`;
  const value = s.draft[key] ?? t.draft;
  const feed = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = feed.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [sent.length, t.slug]);
  const send = () => {
    const text = value.trim();
    if (!text) return;
    appendMessage(t.slug, text);
    setDraft(key, '');
  };
  return (
    <div className="ch-msg__main">
      <TextLink href={P.messages} className="ch-msg__back">
        Back to Messages
      </TextLink>
      <header className="ch-conv__head">
        <div className="ch-conv__who">
          <Avatar k={t.av} size={48} />
          <div className="ch-conv__details">
            <h1 className="ch-conv__name">{t.name}</h1>
            <p className="ch-conv__sub">{t.sub}</p>
          </div>
        </div>
        {t.call ? (
          <Button variant="secondary" onClick={() => openModal(t.call as ModalId)}>
            Arrange a Create Call
          </Button>
        ) : null}
      </header>
      <div className="ch-conv__feed" ref={feed} role="log" aria-label={`Conversation with ${t.name}`}>
        {t.groups.map((g) => (
          <div key={g.date} style={{ display: 'contents' }}>
            <p className="ch-date">{g.date}</p>
            {g.msgs.map((m, i) => (
              <Bubble key={i} m={m} />
            ))}
          </div>
        ))}
        {sent.map((m) => (
          <Bubble key={m.id} m={{ from: 'out', text: m.text }} />
        ))}
        {sent.length ? (
          <p className="ch-sent">
            <ICheck s={14} />
            <span>Sent</span>
          </p>
        ) : null}
      </div>
      <form
        className="ch-composer"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input className="ch-composer__field" aria-label={`Message ${t.name}`} placeholder="Write a message" value={value} onChange={(e) => setDraft(key, e.target.value)} />
        <Button type="submit" iconRight={<IArrow />} disabled={!value.trim()}>
          Send
        </Button>
      </form>
    </div>
  );
}

export function Messages({ slug }: { slug?: string }) {
  const t = THREADS.find((x) => x.slug === slug);
  return (
    <div className="ch-msg" data-view={t ? 'thread' : 'list'}>
      <nav className="ch-msg__side" aria-label="Conversations">
        <h2 className="ch-msg__title">Messages</h2>
        <div className="ch-msg__list">
          {THREADS.map((x) => (
            <ListRow key={x.slug} title={x.name} text={x.preview} meta={x.meta} avatar={x.av} href={P.thread(x.slug)} className={x.slug === slug ? 'ch-row--on' : undefined} />
          ))}
        </div>
      </nav>
      {t ? (
        <Conversation t={t} key={t.slug} />
      ) : (
        <div className="ch-msg__main">
          <div className="ch-msg__empty">
            <IMessage />
            <h1 className="ch-msg__empty-title">Choose a conversation</h1>
            <p className="ch-msg__empty-text">Pick someone from the list to continue, or start something new.</p>
            <Button variant="secondary" onClick={() => openModal('quick')}>Start a Quick Catch-up</Button>
          </div>
        </div>
      )}
    </div>
  );
}
