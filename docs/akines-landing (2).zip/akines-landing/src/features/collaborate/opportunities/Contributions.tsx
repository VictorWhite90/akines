'use client';

/**
 * 12.32 My Contributions: list (Figma 17711:91796, six records) and Empty (17711:92242).
 * Records open their related work (the shared brief, the Decision discussion); the two records about the student journey (the Studio was
 * removed 5 Nov 2026) and the Final credit have no destination. The empty state action goes to My projects (17361:23186). The empty frame has no trigger in the prototype, so it lives
 * at /collaborate/contributions/state-empty.
 */
import { Button } from '@/ui';
import { PATHS } from '../workspace/data';
import { CONTRIBUTIONS, CONTRIBUTIONS_NOTE } from './data';
import { ContributionRecord } from './ContributionRecord';
import { PageHead, StatePanel } from '../projects/ui';

const head = (
  <PageHead
    eyebrow="My contributions"
    title="What you have contributed."
    lead="A record of your work with others, shown with the context it came from. Only you can see this list."
  />
);

export function Contributions() {
  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        {head}
        <section className="dsc-results" aria-label="Contributions">
          <div className="dsc-summary">
            <p className="dsc-summary__count" aria-live="polite">
              {CONTRIBUTIONS.length} contributions
            </p>
            <span className="dsc-summary__note">Most recent first</span>
          </div>
          <div className="co-list" data-m="stagger">
            {CONTRIBUTIONS.map((item) => (
              <ContributionRecord key={item.id} item={item} />
            ))}
          </div>
          <p className="dsc-summary__note co-note">{CONTRIBUTIONS_NOTE}</p>
        </section>
      </div>
    </div>
  );
}

export function ContributionsEmpty() {
  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        {head}
        <StatePanel
          headline="Your contributions will appear here."
          support="When you submit work, join a decision or complete a milestone with others, it is recorded here with the context it came from."
        >
          <Button href={PATHS.list}>Go to My projects</Button>
        </StatePanel>
      </div>
    </div>
  );
}
