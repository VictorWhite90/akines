'use client';

import '../workspace/workspace.css';
import './files.css';
import type { ReactNode } from 'react';
import { FileText, Image as ImageIcon, Layers, NotebookPen, Shapes } from 'lucide-react';
import { Ctx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { FILES_DATA, PREVIEW, type FileIcon } from './data';

/**
 * Pieces of the Files screens. Figma components: Category Chip 17729:92491, File Row 17729:93059, File Preview Panel 17729:98948,
 * File Drop Area 17729:99260, Context Panel / Files 17729:100073. Every class is prefixed fl- and lives in files.css.
 */

/** The Files data of the project of the page (Career Guidance for Everyone or Adire Stories, see FILES_DATA in data.ts). */
export const useFilesData = () => FILES_DATA[useProject().key];

/* ------------------------------------------------------------------ file type icons (Figma icon/file-text, profile/image, notebook-pen, shapes, layers) */

const ICONS = { text: FileText, image: ImageIcon, notes: NotebookPen, shapes: Shapes, layers: Layers } as const;

/** The 40 px tile of a file: ivory square, subtle border, the type icon inside. Also used by the File Drop Area (Chosen). */
export function TypeTile({ icon, className }: { icon: FileIcon; className?: string }) {
  const Icon = ICONS[icon];
  return (
    <span className={className ? `fl-tile ${className}` : 'fl-tile'} aria-hidden="true">
      <Icon size={22} strokeWidth={1.5} focusable="false" />
    </span>
  );
}

/* ------------------------------------------------------------------ page structure */

/** A section of the centre column: the small label over its content (gap 16 in the design). */
export function Section({ label, children }: { label: string; children: ReactNode }) {
  return (
    <section className="fl-sec" data-m="up">
      <h2 className="cw-over">{label}</h2>
      {children}
    </section>
  );
}

/* ------------------------------------------------------------------ Context Panel / Files */

/**
 * The right panel of every Files frame (Context=Files). The Empty frame (Context=Files empty) has the same panel without
 * the "Recently added" block, so there is nothing yet to list.
 */
export function FilesContext({ empty }: { empty?: boolean }) {
  const { sharedWith, sharedNote, recent, keeps } = useFilesData();
  return (
    <>
      <Ctx label="SHARED WITH">
        <ul className="fl-clist">
          {sharedWith.map((m) => (
            <li className="fl-cm" key={m.name}>
              <span className="fl-cm__name">{m.name}</span>
              <span className="fl-cm__meta">{m.role}</span>
            </li>
          ))}
        </ul>
        <p className="fl-cnote">{sharedNote}</p>
      </Ctx>
      {empty ? null : (
        <Ctx label="RECENTLY ADDED">
          <ul className="fl-clist">
            {recent.map((f) => (
              <li className="fl-cm" key={f.name}>
                <span className="fl-cm__name">{f.name}</span>
                <span className="fl-cm__meta">{f.meta}</span>
              </li>
            ))}
          </ul>
        </Ctx>
      )}
      <Ctx label="WHAT THE TEAM KEEPS HERE">
        <p className="cw-ctx__item fl-cline">{keeps.title}</p>
        <p className="fl-cline fl-cline--small">{keeps.when}</p>
        <p className="fl-cline fl-cline--small">{keeps.who}</p>
      </Ctx>
    </>
  );
}

/* ------------------------------------------------------------------ File Preview Panel (Kind=Document) */

/** The ivory panel with a drawn page: eyebrow, title, amber rule, grey text lines, the question and more lines. Decorative. */
export function FilePreviewPanel() {
  const p = PREVIEW.page;
  const lines = (widths: number[]) => (
    <div className="fl-page__lines" aria-hidden="true">
      {widths.map((w, i) => (
        <i key={i} style={{ width: `${(w / 276) * 100}%` }} />
      ))}
    </div>
  );
  return (
    <div className="fl-panel" role="img" aria-label={`Preview of ${PREVIEW.name}. ${p.label}.`}>
      <div className="fl-sheet" aria-hidden="true">
        <p className="fl-sheet__eyebrow">{p.eyebrow}</p>
        <p className="fl-sheet__title">{p.title}</p>
        <i className="fl-sheet__rule" />
        {lines(p.linesA)}
        <p className="fl-sheet__question">{p.question}</p>
        {lines(p.linesB)}
      </div>
      <p className="fl-panel__label" aria-hidden="true">
        {p.label}
      </p>
    </div>
  );
}
