'use client';

/**
 * Figma "Modal:Notifications" (17104:7225): a 400 px popover under the header bell (right 64, top 88) over a click-to-close scrim.
 * The shell renders this component on every signed-in screen, so it also hosts the Community overlays (Overlays.tsx).
 */
import { Modal } from '@/ui';
import { useNav } from '@/lib/nav';
import { P } from './data';
import { openModal } from './store';
import { CommunityOverlays } from './Overlays';
import { ListRow, TextLink } from './ui';
import './community.css';

export function NotificationsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const nav = useNav();
  const go = (path: string) => {
    onClose();
    nav.push(path);
  };
  /* Figma SWAP_OVERLAY: the popover is replaced by the panel */
  const swap = (id: Parameters<typeof openModal>[0]) => {
    onClose();
    openModal(id);
  };
  return (
    <>
      <Modal open={open} onClose={onClose} title="Notifications" hideClose flush width={400} className="ch-notif">
        <div className="ch-notif__list">
          <ListRow title="Amara replied in Community Health Initiative" text="A few minutes ago" avatar="amara" onClick={() => go(P.thread('amara'))} />
          <ListRow title="Two places left: Starting a purpose-driven business" text="Today" avatar="kincircle" onClick={() => swap('inv-kin')} />
          <ListRow title="Reminder: Project Call with the Food Systems Cliq at 2:00 PM" text="Today" onClick={() => swap('up-project')} />
        </div>
        <TextLink onClick={() => go(P.settings)} className="ch-notif__pref">
          Notification preferences
        </TextLink>
      </Modal>
      <CommunityOverlays />
    </>
  );
}
