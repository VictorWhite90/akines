/**
 * Create AI knowledge: the pages it may point to, the standing instructions for the live model and the built-in guide
 * that answers when no live model is available (the Next.js build has no backend). Plain data and functions, no React.
 */

export type Go = { path: string; label: string };

/** Pages Create AI may suggest, with the label shown on the link button. Every path is a registered route. */
export const GO: Go[] = [
  { path: '/community', label: 'Community home' },
  { path: '/community/messages', label: 'Messages' },
  { path: '/community/banter', label: 'Banter' },
  { path: '/connect', label: 'Connect' },
  { path: '/connect/kincircle', label: 'KinCircle' },
  { path: '/connect/rooms', label: 'Rooms' },
  { path: '/connect/activities', label: 'Activities' },
  { path: '/collaborate', label: 'Collaborate' },
  { path: '/collaborate/start', label: 'Start a project' },
  // These two open the chat journeys 16.4 and 16.5 inside the panel (CreateAI.tsx), like "Start a project" opens 16.3.
  { path: '/collaborate/collaborators', label: 'Explore collaborators' },
  { path: '/collaborate/discover', label: 'Discover projects' },
  { path: '/collaborate/my-projects', label: 'Open a project' },
  { path: '/make-sell', label: 'Make and Sell' },
  { path: '/explore', label: 'Explore' },
  { path: '/explore/stories', label: 'Stories' },
  { path: '/explore/studio-visits', label: 'Studio visits' },
  { path: '/care', label: 'Care' },
  { path: '/community/care/reflect', label: 'Reflect privately' },
  { path: '/help', label: 'Help' },
  { path: '/join', label: 'Join Akines' },
];

export const labelFor = (path: string) => GO.find((g) => g.path === path)?.label;

/** Standing instructions for the live model. It has no system prompt, so these go first, as a user turn. */
export const persona = (who: { name: string | null; signedIn: boolean }) =>
  [
    'You are Create AI, the friendly guide inside Akines, a members community for people who want to know, trust and create with others. Its line is "Less scrolling. More belonging."',
    'You can chat about anything the person brings: everyday questions, ideas, writing, creative projects, feeling stuck, planning their day. Answer helpfully and honestly.',
    'About Akines itself, use only the facts below. Never invent features, prices, events, rules or member details. If you do not know, say so and point to Help.',
    'Voice: warm, calm and plain. Usually one to four short sentences, longer only when the person asks for more. No markdown, no headings, no emojis, no em dashes. Use a short list only when the person asks for one.',
    'You cannot take actions in the app, see the account, or message anyone for the person. Never ask for passwords, codes or payment details.',
    'If someone sounds unsafe or in crisis, answer with care and encourage them to contact local emergency services or someone they trust.',
    who.signedIn
      ? `The person is a signed-in member${who.name ? ` called ${who.name}` : ''}.`
      : 'The person is a visitor who is not signed in. Akines is for members: when it is relevant, invite them to join or sign in.',
    'Akines areas: Community (home feed, messages, collaborations, banter), Connect (KinCircle gatherings, rooms, activities), Collaborate (start a project, find collaborators, discover open projects, my projects), Make and Sell (store, journal), Explore (stories, studio visits), Care (quiet company, reflect privately, professional support, Creative DNA), Help.',
    `When one or two pages would help, end the reply with a last line in exactly this form and nothing after it: GO: /path, /path. Choose only from: ${GO.map((g) => g.path).join(', ')}. Otherwise add no such line.`,
  ].join('\n');

/** Split the model reply into the visible text and the suggested pages. Unknown paths are dropped. */
export function parseReply(raw: string): { text: string; go: Go[] } {
  const m = raw.match(/(?:^|\n)\s*GO:\s*([^\n]*)\s*$/i);
  const visible = (m ? raw.slice(0, m.index) : raw).replace(/\n?\s*GO:[^\n]*$/i, '').trim();
  const go: Go[] = [];
  if (m) {
    for (const p of m[1].split(/[,\s]+/)) {
      const g = GO.find((x) => x.path === p.trim());
      if (g && !go.some((x) => x.path === g.path)) go.push(g);
    }
  }
  return { text: visible, go: go.slice(0, 2) };
}

type Rule = { test: RegExp; text: string; go?: string[] };

const RULES: Rule[] = [
  { test: /\b(hi|hello|hey|good (morning|afternoon|evening))\b/i, text: 'Hello. I am Create AI. I can help you find the right place in Akines, or just talk something through. What is on your mind?' },
  { test: /\b(join|sign ?up|create (an )?account|register)\b/i, text: 'Joining is a short, step by step flow, and you can go back at any step. When you are ready, it starts here.', go: ['/join'] },
  { test: /\b(sign ?in|log ?in|password)\b/i, text: 'You can sign in from the top of any page. If you are stuck, Help is the quickest way to get unstuck.', go: ['/help'] },
  { test: /\b(start|begin|launch|new)\b.*\bproject\b|\bproject\b.*\b(start|begin|idea)\b/i, text: 'Starting a project takes a few short questions about what you want to make and who you would like beside you. You can save it and come back.', go: ['/collaborate/start', '/collaborate/collaborators', '/collaborate/my-projects'] },
  { test: /\b(collaborat|co-?found|partner|teammate|find (a )?(maker|person|people))\b/i, text: 'Collaborate is where projects and people meet. You can start your own, look for collaborators, or see open projects that could use another pair of hands.', go: ['/collaborate/collaborators', '/collaborate/discover'] },
  { test: /\b(open projects?|discover)\b/i, text: 'Discover projects lists open projects you could join. Each one shows what is needed and who is already in.', go: ['/collaborate/discover'] },
  { test: /\bbanter\b/i, text: 'Banter is a live conversation on one question, with a start time. You can listen quietly or join in.', go: ['/community/banter'] },
  { test: /\b(kin ?circle|circle|gathering)\b/i, text: 'A KinCircle is a small gathering around something you both care about. Places are limited, so they stay personal.', go: ['/connect/kincircle'] },
  { test: /\b(room|quiet|calm)\b/i, text: 'Rooms are open spaces to be with others. Some are for talking, and some are calm rooms where no talking is needed.', go: ['/connect/rooms'] },
  { test: /\b(activit|game|play|workshop)\b/i, text: 'Activities are shared things to do together, from games to making sessions.', go: ['/connect/activities'] },
  { test: /\b(sell|shop|store|buy|art|journal)\b/i, text: 'Make and Sell is where members share and sell their work, with a journal for the stories behind it.', go: ['/make-sell'] },
  { test: /\b(stor(y|ies)|studio|visit|heritage|legacy)\b/i, text: 'Explore has stories from members and studio visits, a good place to wander when you are not looking for anything in particular.', go: ['/explore/stories', '/explore/studio-visits'] },
  { test: /\b(care|support|anxious|stress|sad|low|overwhelm|lonely|tired|burn(t|ed)? ?out)\b/i, text: 'I am sorry it feels heavy. Care has quiet company and a private place to write things down, just for you. If you feel unsafe, please contact your local emergency services or someone you trust.', go: ['/care', '/community/care/reflect'] },
  { test: /\b(message|chat with|dm|inbox)\b/i, text: 'Messages holds your conversations. You can pick one up where you left off.', go: ['/community/messages'] },
  { test: /\b(help|contact|problem|issue|bug|not working)\b/i, text: 'Help is the best place for questions about your account or something that is not working.', go: ['/help'] },
  { test: /\b(what is|what\'s|about|who are|tell me about)\b.*\b(akines|this)\b|\bakines\b.*\b(what|about)\b/i, text: 'Akines helps you find people you can genuinely know, trust and create with. Less scrolling, more belonging. You choose how you want to connect, and it shows you a few good places to start.', go: ['/community'] },
  { test: /\b(thank|thanks)\b/i, text: 'Any time. I am here whenever you want to talk something through.' },
];

/** The built-in guide: keyword rules for the places in Akines, a kind general fallback for anything else. */
export function guide(question: string): { text: string; go: Go[] } {
  const q = question.trim();
  for (const r of RULES) {
    if (r.test.test(q)) return { text: r.text, go: (r.go ?? []).map((p) => GO.find((g) => g.path === p)!).filter(Boolean) };
  }
  return {
    text: 'I can point you to the right place in Akines. Tell me what you would like to do, for example start a project, meet someone, or find a quiet room.',
    go: [GO.find((g) => g.path === '/community')!],
  };
}
