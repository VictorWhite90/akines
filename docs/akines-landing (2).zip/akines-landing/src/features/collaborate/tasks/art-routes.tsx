import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { TP } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Mirrored: Tasks (17674:851), Board view (17675:149) and Milestone view (17675:873), the three views the view tabs switch between.
 * Not mirrored: Empty, the three stages of the task detail and every "state-" frame (modal, dropdown and toast frames). The Create task
 * modal, the Filter menu and the toasts still work on these pages; their results are kept in the Adire Stories store only.
 * The task rows and board cards have no destination on Adire Stories.
 */
const MIRRORED: string[] = [TP.list, TP.board, TP.milestones];

export const artRoutes: RouteDef[] = routes
  .filter((r) => MIRRORED.includes(r.path))
  .map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
