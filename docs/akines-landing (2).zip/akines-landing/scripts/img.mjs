#!/usr/bin/env node
// Convert a Figma screenshot (PNG saved by the get_screenshot tool) into a web JPEG.
// usage: node scripts/img.mjs <source.png> <public/images/app/feature/name.jpg> [maxWidth=1200] [quality=74]
import sharp from 'sharp';
import { mkdirSync, statSync } from 'node:fs';
import { dirname } from 'node:path';

const [src, dest, maxW = '1200', q = '74'] = process.argv.slice(2);
if (!src || !dest) {
  console.error('usage: node scripts/img.mjs <source.png> <dest.jpg> [maxWidth] [quality]');
  process.exit(1);
}
mkdirSync(dirname(dest), { recursive: true });
const info = await sharp(src)
  .resize({ width: Number(maxW), withoutEnlargement: true })
  .jpeg({ quality: Number(q), mozjpeg: true })
  .toFile(dest);
console.log(`${dest}: ${info.width}x${info.height}, ${(statSync(dest).size / 1024).toFixed(0)} KB`);
