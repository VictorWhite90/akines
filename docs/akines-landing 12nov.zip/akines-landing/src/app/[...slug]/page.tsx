import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { RouteFrame } from '@/app-shell/RouteFrame';
import { findRoute, routes } from '@/routes';

// Every screen is a static path from the registry (src/routes.ts). Unknown paths fall through to the 404 page.
export const dynamicParams = false;

export function generateStaticParams() {
  return routes.filter((r) => r.path !== '/' && r.path !== '/404').map((r) => ({ slug: r.path.split('/').filter(Boolean) }));
}

type Props = { params: Promise<{ slug: string[] }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const route = findRoute('/' + slug.join('/'));
  return route ? { title: route.title ? `${route.title} | Akines` : 'Akines' } : {};
}

export default async function Page({ params }: Props) {
  const { slug } = await params;
  const route = findRoute('/' + slug.join('/'));
  if (!route) notFound();
  const Screen = route.component;
  return (
    <RouteFrame meta={{ path: route.path, title: route.title, shell: route.shell, nav: route.nav, mobile: route.mobile }}>
      <Screen />
    </RouteFrame>
  );
}
