'use client';

/**
 * Right rail of Discover: Your Circles, then You two would get along. Both are the community feed's components, unchanged
 * (features/community/feed/Rail.tsx and MatchSlideshow.tsx). Two differences, both handled here without touching them:
 *
 *  1. In Discover the circle rows and "See all" are plain. The community rail links them to /connect, which is this page, so a
 *     click on them is stopped before it navigates (capture phase) and only reported (your_circle_click, your_circles_see_all_click).
 *     "Why this match?" and the rest of the match card behave exactly as in Community Home.
 *  2. The photo and name of the match card link to that person's profile (MatchSlideshow `profileHref`); the click is reported as
 *     recommendation_profile_click (source "rail"). The match card has no analytics of its own. Its Next, Previous, Not now and Say hello buttons are reported here by listening
 *     to clicks (recommendation_next, recommendation_previous, recommendation_dismiss, recommendation_say_hello, source "rail").
 *     Swipe, drag, arrow keys and the dots are not reported.
 *
 * `empty` is the empty state route: Your circles shows its empty card and the match card its Discover wording.
 * `onFindCircles` runs on "Find circles" in the empty Your circles card; without it the link is a plain button.
 * The sticky geometry (360 wide, pinned under the app header) is .dx-rail in discover.css.
 */
import type { MouseEvent } from 'react';
import { CIRCLES, MATCHES, MATCH_COPY, type Match } from '@/features/community/feed/content';
import { MatchSlideshow } from '@/features/community/feed/MatchSlideshow';
import { YourCircles } from '@/features/community/feed/Rail';
import { track } from './analytics';
import { PROFILE_BY_SLUG, profilePath, slugOf } from './data';
import { EmptyCircles, EmptyMatch } from './states';

/** The slideshow clamps at 10 profiles. */
const MATCH_MAX = 10;

/** The match card links the photo and name to the person's profile (Figma 11.1), where that person has one. All seven matches do. */
const matchProfile = (m: Match) => {
  const slug = slugOf(m.name);
  return PROFILE_BY_SLUG.has(slug) ? profilePath(slug) : undefined;
};

function reportMatchClick(button: HTMLElement) {
  const card = button.closest<HTMLElement>('.fd-match');
  if (!card) return;
  const n = Math.min(MATCHES.length, MATCH_MAX);
  const index = Number(card.dataset.index ?? 0);
  const current = MATCHES[index];
  if (!current || n === 0) return;
  const label = button.getAttribute('aria-label');
  const text = button.textContent?.trim();
  const here = { recommendation_id: current.id, position: index + 1, source: 'rail' as const };
  if (label === 'Next profile') track('recommendation_next', { position: ((index + 1) % n) + 1, source: 'rail' });
  else if (label === 'Previous profile') track('recommendation_previous', { position: ((index - 1 + n) % n) + 1, source: 'rail' });
  else if (text === MATCH_COPY.skip) track('recommendation_dismiss', here);
  else if (text === MATCH_COPY.hello) track('recommendation_say_hello', here);
}

export function DiscoverRail({ empty, onFindCircles }: { empty?: boolean; onFindCircles?: () => void }) {
  const onClickCapture = (e: MouseEvent<HTMLElement>) => {
    const target = e.target as HTMLElement;

    const link = target.closest('a');
    if (link) {
      const who = link.closest<HTMLElement>('.fd-slide__who');
      if (who) {
        const index = Number(who.closest<HTMLElement>('.fd-match')?.dataset.index ?? 0);
        const current = MATCHES[index];
        if (current) track('recommendation_profile_click', { recommendation_id: current.id, position: index + 1, source: 'rail' });
        return;
      }
      const row = link.closest('.fd-circle');
      if (row) {
        e.preventDefault();
        const item = row.closest('li');
        const position = item?.parentElement ? Array.from(item.parentElement.children).indexOf(item) + 1 : 0;
        track('your_circle_click', { circle_id: CIRCLES[position - 1]?.id ?? 'unknown', position });
      } else if (link.closest('.fd-circles .fd-box__head')) {
        e.preventDefault();
        track('your_circles_see_all_click');
      }
      return;
    }

    const button = target.closest('button');
    if (button) reportMatchClick(button);
  };

  return (
    <aside className="dx-rail" aria-label="Your circles and a match" onClickCapture={onClickCapture}>
      {empty ? <EmptyCircles onFind={onFindCircles} /> : <YourCircles />}
      {empty ? <EmptyMatch /> : <MatchSlideshow profileHref={matchProfile} />}
    </aside>
  );
}
