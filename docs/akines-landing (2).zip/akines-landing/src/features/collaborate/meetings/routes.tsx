import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { Call, CallChat, CallEnded, CallPeople, CallSharing, Lobby, LobbyCameraOff } from './Meeting';
import { meetPaths } from './paths';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * 12.43 Meetings: Lobby (17809:111216), Lobby / Camera off (17809:111347), In call (17809:110599), In call / Screen sharing (17809:110707),
 * In call / People (17809:110810), In call / Chat (17809:110965) and Call ended (17809:111469). The screens have no app header (shell "bare").
 * The Lobby, the call and the end screen are reached from the meeting card, the Meet menu, the Join card and the slide-outs; the "state-"
 * routes are the frames that open the call already in that state. Both projects use the same screens and the same meeting store.
 */
const P = meetPaths(PROJECT_PATH);
const screens: { path: (p: ReturnType<typeof meetPaths>) => string; component: RouteDef['component'] }[] = [
  { path: (p) => p.lobby, component: Lobby },
  { path: (p) => p.lobbyOff, component: LobbyCameraOff },
  { path: (p) => p.call, component: Call },
  { path: (p) => p.sharing, component: CallSharing },
  { path: (p) => p.people, component: CallPeople },
  { path: (p) => p.chat, component: CallChat },
  { path: (p) => p.ended, component: CallEnded },
];

const build = (root: string, title: string): RouteDef[] => screens.map((s) => ({ path: s.path(meetPaths(root)), title, shell: 'bare', nav, component: s.component }));

export const routes: RouteDef[] = build(PROJECT_PATH, 'Prototype review');
export const artRoutes: RouteDef[] = build(ART_PATH, 'Colour review');
export const MEET_PATHS = P;
