import type { RouteDef } from '@/routes.types';
import {
  LaunchAttribution,
  LaunchConfirmed,
  LaunchConfirmModal,
  LaunchMaterials,
  LaunchNotReady,
  LaunchOutcome,
  LaunchReadiness,
  LaunchReady,
  LaunchShareModal,
  LaunchShared,
} from './Launch';
import { LP } from './data';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * Launch 12.24: Readiness (17729:94066, the page the Project navigation opens), Not ready (17729:93424), Materials (17729:94745),
 * Attribution (17729:95391), Ready to share (17729:96037), Outcome (17729:96683) and the overlay frames Modal:Confirm attribution
 * (17729:101584), Toast:Attribution confirmed (17729:101733), Modal:Share project (17729:101663) and Toast:Project shared (17729:101740).
 * Readiness, Materials, Attribution, Ready to share and Outcome are reached from the UI (Prepare launch, Next: attribution, Continue to
 * sharing, Share project, the Team acknowledgement row, the Back links). The "state-" routes are the Figma frames no control reaches: Not
 * ready, and the overlay frames that open with the modal or the toast already showing.
 */
export const routes: RouteDef[] = [
  { path: LP.readiness, title: 'Launch', shell: 'app', nav, component: LaunchReadiness },
  { path: LP.notReady, title: 'Launch', shell: 'app', nav, component: LaunchNotReady },
  { path: LP.materials, title: 'Launch materials', shell: 'app', nav, component: LaunchMaterials },
  { path: LP.attribution, title: 'Launch attribution', shell: 'app', nav, component: LaunchAttribution },
  { path: LP.ready, title: 'Ready to share', shell: 'app', nav, component: LaunchReady },
  { path: LP.outcome, title: 'Project outcome', shell: 'app', nav, component: LaunchOutcome },

  { path: LP.confirmModal, title: 'Launch attribution', shell: 'app', nav, component: LaunchConfirmModal },
  { path: LP.confirmed, title: 'Launch attribution', shell: 'app', nav, component: LaunchConfirmed },
  { path: LP.shareModal, title: 'Ready to share', shell: 'app', nav, component: LaunchShareModal },
  { path: LP.shared, title: 'Project outcome', shell: 'app', nav, component: LaunchShared },
];
