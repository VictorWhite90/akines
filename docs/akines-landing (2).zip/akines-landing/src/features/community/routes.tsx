import type { RouteDef } from '@/routes.types';
import { FeedPage } from './feed/FeedPage';
import { Messages } from './Messages';
import { Banter, Collaboration, ZineCollaboration } from './Collab';
import { ProfessionalSupport, QuietCompany, ReflectPrivately } from './Care';
import { SettingsConnection, SettingsExplanations, SettingsPrivacy, SettingsRecommendation } from './Settings';

const nav = { page: 'community' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

// Community Home feed: /community picks an arrangement at random on every visit, /community/feed/a to d force one (review and tests)
const Feed = () => <FeedPage />;
const FeedA = () => <FeedPage force="a" />;
const FeedB = () => <FeedPage force="b" />;
const FeedC = () => <FeedPage force="c" />;
const FeedD = () => <FeedPage force="d" />;
const FeedLoading = () => <FeedPage state="loading" />;
const FeedError = () => <FeedPage state="error" />;
const FeedEmpty = () => <FeedPage state="empty" />;

const Inbox = () => <Messages />;
const Amara = () => <Messages slug="amara" />;
const Folake = () => <Messages slug="folake" />;
const FoodSystems = () => <Messages slug="food-systems-cliq" />;
const KinCircle = () => <Messages slug="kincircle-reflection" />;
const University = () => <Messages slug="university-friends" />;

export const routes: RouteDef[] = [
  def('/community', 'Community Home', Feed),
  def('/community/feed/a', 'Community Home: Discover', FeedA),
  def('/community/feed/b', 'Community Home: Belong', FeedB),
  def('/community/feed/c', 'Community Home: Make together', FeedC),
  def('/community/feed/d', 'Community Home: Heritage and craft', FeedD),
  def('/community/feed/state-loading', 'Community Home feed: loading', FeedLoading),
  def('/community/feed/state-error', 'Community Home feed: section error', FeedError),
  def('/community/feed/state-empty', 'Community Home feed: no match to suggest', FeedEmpty),
  def('/community/messages', 'Messages', Inbox),
  def('/community/messages/amara', 'Messages: Amara', Amara),
  def('/community/messages/folake', 'Messages: Folake', Folake),
  def('/community/messages/food-systems-cliq', 'Messages: Food Systems Cliq', FoodSystems),
  def('/community/messages/kincircle-reflection', 'Messages: KinCircle Reflection', KinCircle),
  def('/community/messages/university-friends', 'Messages: University friends', University),
  def('/community/collaborations', 'Community Health Initiative', Collaboration),
  def('/community/collaborations/lagos-makers-zine', 'Lagos Makers Zine', ZineCollaboration),
  def('/community/care', 'Quiet company', QuietCompany),
  def('/community/care/reflect', 'Reflect privately', ReflectPrivately),
  def('/community/care/professional-support', 'Find professional support', ProfessionalSupport),
  def('/community/settings', 'Recommendation preferences', SettingsRecommendation),
  def('/community/settings/recommendations', 'Recommendation explanations', SettingsExplanations),
  def('/community/settings/privacy', 'Privacy settings', SettingsPrivacy),
  def('/community/settings/connection', 'Connection preferences', SettingsConnection),
  def('/community/banter', 'Banter', Banter),
];
