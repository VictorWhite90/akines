'use client';

/** KinCircle posts (FEED_SPEC.md section 6.2): full width posts with reaction chips that toggle and a "+ React" menu. */
import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Chip, IconButton, Tag } from '@/ui';
import { useDismiss, useMemoState } from '@/lib/hooks';
import { cx } from '../ui';
import { PICKER, POSTS, REACT_LABEL, type PostData } from './content';
import { Face, FeedPhoto } from './parts';

type ReactChip = { emoji: string; label: string; count: number; on: boolean };
type Reacts = Record<string, ReactChip[]>;

const INITIAL: Reacts = Object.fromEntries(POSTS.map((p) => [p.id, p.reactions.map((r) => ({ ...r, on: false }))]));
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

function ReactMenu({ onPick }: { onPick: (emoji: string, label: string) => void }) {
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  const focusTrigger = () => wrap.current?.querySelector<HTMLButtonElement>('.fd-react__btn')?.focus();
  useDismiss(open, wrap, () => setOpen(false));
  useEffect(() => {
    if (open) wrap.current?.querySelector<HTMLButtonElement>('.fd-pick__btn')?.focus();
  }, [open]);

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const items = Array.from(wrap.current?.querySelectorAll<HTMLButtonElement>('.fd-pick__btn') ?? []);
    const at = items.indexOf(document.activeElement as HTMLButtonElement);
    if (e.key === 'Escape') {
      e.stopPropagation();
      setOpen(false);
      focusTrigger();
    } else if (e.key === 'ArrowRight' && items.length) {
      e.preventDefault();
      items[(at + 1) % items.length].focus();
    } else if (e.key === 'ArrowLeft' && items.length) {
      e.preventDefault();
      items[(at - 1 + items.length) % items.length].focus();
    }
  };

  return (
    <div className="fd-react" ref={wrap}>
      <Chip className="fd-react__btn" aria-haspopup="true" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {REACT_LABEL}
      </Chip>
      {open ? (
        <div className="fd-pick" role="group" aria-label="Choose a reaction" onKeyDown={onKey}>
          {PICKER.map((p) => (
            <IconButton
              className="fd-pick__btn"
              key={p.emoji}
              label={`React with ${p.label}`}
              tooltip={false}
              onClick={() => {
                onPick(p.emoji, p.label);
                setOpen(false);
                focusTrigger();
              }}
            >
              <span className="fd-emoji" aria-hidden="true">{p.emoji}</span>
            </IconButton>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function Post({ post, chips, onToggle, onPick }: { post: PostData; chips: ReactChip[]; onToggle: (emoji: string) => void; onPick: (emoji: string, label: string) => void }) {
  const n = post.media.length;
  return (
    <article className="fd-post" aria-label={`Post by ${post.name}`}>
      <header className="fd-post__head">
        <Face image={post.face} size={48} />
        <div className="fd-post__who">
          <p className="fd-post__name">{post.name}</p>
          <p className="fd-post__meta">{post.meta}</p>
        </div>
        {post.circle ? <Tag className="fd-post__circle">{post.circle}</Tag> : null}
      </header>
      <div className="fd-post__body">
        {post.body.map((par) => (
          <p key={par.slice(0, 24)}>{par}</p>
        ))}
      </div>
      {n > 0 ? (
        <div className={cx('fd-post__media', `fd-post__media--${n}`)}>
          {post.media.map((m) => (
            <FeedPhoto key={m} image={m} className="fd-post__img" />
          ))}
        </div>
      ) : null}
      <footer className="fd-post__foot">
        <div className="fd-post__reacts">
          {chips.map((c) => (
            <Chip key={c.emoji} selected={c.on} count={c.count} aria-label={`${cap(c.label)}, ${c.count}`} onClick={() => onToggle(c.emoji)}>
              <span className="fd-emoji" aria-hidden="true">
                {c.emoji}
              </span>
            </Chip>
          ))}
          <ReactMenu onPick={onPick} />
        </div>
        {/* Styled as the underlined text link of the design; it has no destination there, so it stays plain text */}
        <span className="fd-post__replies">{post.replies}</span>
      </footer>
    </article>
  );
}

export function KinCirclePosts() {
  const [reacts, setReacts] = useMemoState<Reacts>('feed.reactions', INITIAL);

  const toggle = (id: string, emoji: string) =>
    setReacts((prev) => ({
      ...prev,
      [id]: (prev[id] ?? []).map((c) => (c.emoji === emoji ? { ...c, on: !c.on, count: c.count + (c.on ? -1 : 1) } : c)),
    }));

  const pick = (id: string, emoji: string, label: string) =>
    setReacts((prev) => {
      const list = prev[id] ?? [];
      return list.some((c) => c.emoji === emoji)
        ? { ...prev, [id]: list.map((c) => (c.emoji === emoji ? { ...c, on: !c.on, count: c.count + (c.on ? -1 : 1) } : c)) }
        : { ...prev, [id]: [...list, { emoji, label, count: 1, on: true }] };
    });

  return (
    <div className="fd-posts" data-m="stagger">
      {POSTS.map((p) => (
        <Post key={p.id} post={p} chips={reacts[p.id] ?? []} onToggle={(e) => toggle(p.id, e)} onPick={(e, l) => pick(p.id, e, l)} />
      ))}
    </div>
  );
}
