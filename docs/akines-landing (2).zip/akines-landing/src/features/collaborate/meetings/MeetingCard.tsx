'use client';

import './meetings.css';
import { useState } from 'react';
import { Video } from 'lucide-react';
import { useNav } from '@/lib/nav';
import { Button } from '@/ui';
import { ArrowUpRight, Dot } from '../workspace/atoms';
import { Portrait } from '../workspace/dash';
import { useProject } from '../workspace/project';
import { teamFor } from '../project-team/data';
import { ScheduleModal } from './ScheduleModal';
import { meetings, meetPaths, useMeeting } from './store';

/**
 * Meeting Card (Figma 17798, three states), always the first block of the project rail:
 *  - Upcoming: date tile, NEXT SESSION, the meeting, "View meeting" (opens the lobby);
 *  - Ongoing:  dark camera tile, HAPPENING NOW, who is there, "Join meeting" (opens the lobby);
 *  - None:     grey camera tile, NO MEETING YET, "Start meeting" (starts one for everyone and opens the lobby) and "Schedule" (opens the modal).
 */
export function MeetingCard({ empty }: { empty?: boolean }) {
  const nav = useNav();
  const { key, root } = useProject();
  const stored = useMeeting(key);
  // the empty pages show the untouched sample meeting as "No meeting yet" (Figma 12.11, 12.14, 12.19 to 12.22 Empty)
  const m = empty && stored.status === 'upcoming' && stored.fresh ? { ...stored, status: 'none' as const } : stored;
  const [schedule, setSchedule] = useState(false);
  const paths = meetPaths(root);
  const others = teamFor(key).members.slice(1, 4);

  if (m.status === 'ongoing') {
    return (
      <section className="mt-card mt-card--ongoing" aria-label="Meeting happening now">
        <div className="mt-card__top">
          <span className="mt-tile mt-tile--dark" aria-hidden="true">
            <Video size={20} strokeWidth={1.5} />
          </span>
          <div className="mt-card__text">
            <p className="mt-eyebrow">
              <Dot tone="green" size={6} />
              HAPPENING NOW
            </p>
            <h3 className="mt-title">{m.name}</h3>
            <p className="mt-sub">Started {m.startedAt}, {others.length} people here</p>
          </div>
        </div>
        <div className="mt-card__foot">
          <span className="mt-faces" aria-hidden="true">
            {others.map((p) => (
              <Portrait key={p.id} src={p.photo} size={32} />
            ))}
          </span>
          <Button size="sm" href={paths.lobby}>
            Join meeting
          </Button>
        </div>
      </section>
    );
  }

  if (m.status === 'upcoming') {
    return (
      <section className="mt-card" aria-label="Next session">
        <div className="mt-card__top">
          <span className="mt-tile mt-tile--date" aria-hidden="true">
            <span className="mt-tile__day">{m.day}</span>
            <span className="mt-tile__time">{m.time}</span>
          </span>
          <div className="mt-card__text">
            <p className="mt-eyebrow">
              <Dot size={6} />
              NEXT SESSION
            </p>
            <h3 className="mt-title">{m.name}</h3>
            <p className="mt-sub">
              {m.minutes} min, {m.people} people
            </p>
          </div>
        </div>
        <Button size="sm" variant="secondary" fullWidth iconRight={<ArrowUpRight />} href={paths.lobby}>
          View meeting
        </Button>
      </section>
    );
  }

  return (
    <section className="mt-card" aria-label="No meeting yet">
      <div className="mt-card__top">
        <span className="mt-tile mt-tile--grey" aria-hidden="true">
          <Video size={20} strokeWidth={1.5} />
        </span>
        <div className="mt-card__text">
          <p className="mt-eyebrow">
            <Dot tone="gray" size={6} />
            NO MEETING YET
          </p>
          <h3 className="mt-title">Meet with the team</h3>
          <p className="mt-sub">Start now or pick a time.</p>
        </div>
      </div>
      <div className="mt-card__buttons">
        <Button
          size="sm"
          onClick={() => {
            meetings.startNow(key);
            nav.push(paths.lobby);
          }}
        >
          Start meeting
        </Button>
        <Button size="sm" variant="secondary" onClick={() => setSchedule(true)} aria-haspopup="dialog">
          Schedule
        </Button>
      </div>
      <ScheduleModal open={schedule} onClose={() => setSchedule(false)} />
    </section>
  );
}
