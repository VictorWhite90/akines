/**
 * Copy of 12.1 Collaborate Home (Figma frame 17182:10780), exactly as designed, and of its Empty state (17111:9037, the real page with the
 * zero tiles; it replaces the old "designed in a later phase" placeholder). Home Loading is 17974:166533.
 */
import { PATHS } from './flow-data';
import { OL } from '../overview-lists/data';
import { DP } from '../decisions/data';
import { PATHS as WORKSPACE_PATHS } from '../workspace/data';
import type { PersonId } from '../people/data';

export const WELCOME = {
  eyebrow: 'Your collaboration space',
  title: 'Welcome back, Kemi.',
  support: 'Your ideas are moving. Here’s what needs your attention today.',
};

export type Tile = { n: string; label: string; count: string; unit: string; text: string; link: string; href?: string };
export const TILES: Tile[] = [
  { n: '01', label: 'Active projects', count: '4', unit: 'active projects', text: 'Where your ideas are moving.', link: 'My Projects', href: PATHS.myProjects },
  { n: '02', label: 'Decisions awaiting you', count: '2', unit: 'decisions', text: 'Your team needs your approval.', link: 'Pending decisions', href: OL.decisions },
  { n: '03', label: 'Collaborator introductions', count: '1', unit: 'introduction', text: 'Someone would like to connect.', link: 'Introduction requests', href: OL.introductions },
  { n: '04', label: 'Tasks due this week', count: '4', unit: 'tasks', text: 'Plan your week around them.', link: 'Upcoming tasks', href: OL.tasks },
];

export const WORKSPACE = {
  label: 'Your workspace',
  title: 'Pick up where you left off.',
  support: 'Your projects, ready when you are.',
  link: 'View All Projects',
};

export type ProjectCard = {
  stage: string;
  active: string;
  title: string;
  text: string;
  milestone: string;
  next: string;
  done: number;
  people: string[];
  team: string;
  cta: string;
};
export const PROJECTS: ProjectCard[] = [
  {
    stage: 'Building',
    active: 'Active 2 hours ago',
    title: 'Career Guidance for Everyone',
    text: 'A digital career guidance platform helping Nigerian students make informed career decisions.',
    milestone: 'Define the first student experience.',
    next: 'Review the onboarding flow.',
    done: 2,
    people: ['KA', 'AY', 'TO'],
    team: '3 collaborators',
    cta: 'Continue working',
  },
  {
    stage: 'Planning',
    active: 'Active yesterday',
    title: 'Community Learning Initiative',
    text: 'A collaborative initiative creating accessible learning opportunities.',
    milestone: 'Finalise the project brief.',
    next: 'Invite your first collaborator.',
    done: 1,
    people: ['KA', 'DO'],
    team: '2 collaborators',
    cta: 'Continue planning',
  },
  {
    stage: 'Exploring',
    active: 'Active 4 days ago',
    title: 'Mentorship Circle',
    text: 'A small mentoring programme connecting Nigerian students with working creatives.',
    milestone: 'Shape the first mentoring session.',
    next: 'Agree the session format.',
    done: 1,
    people: ['KA', 'CO'],
    team: '2 collaborators',
    cta: 'Continue exploring',
  },
  {
    stage: 'Building',
    active: 'Active 1 hour ago',
    title: 'Adire Stories',
    text: 'A shared illustration series that celebrates adire textile patterns and the people who make them.',
    milestone: 'Finish the headwrap portrait.',
    next: 'Review the colour layer.',
    done: 2,
    people: ['KA', 'AO', 'AB'],
    team: '3 collaborators',
    cta: 'Continue working',
  },
];
export const NEW_PROJECT = {
  label: 'New project',
  title: 'Start something new.',
  text: 'Bring your intention to Akines. We’ll help you clarify it, find the right people and prepare to create together.',
  cta: 'Start a project',
};

export type AttentionItem = { type: string; time: string; title: string; text: string; cta: string; /** Where the action goes (none in the design for Review invitation). */ href?: string };
export const ATTENTION: { label: string; title: string; items: AttentionItem[] } = {
  label: 'Your next action',
  title: 'A few things need you.',
  items: [
    { type: 'Decision awaiting you', time: 'Requested 2 days ago', title: 'Career Guidance for Everyone', text: 'The team needs your approval on the first student onboarding direction.', cta: 'Review decision', href: DP.detail },
    { type: 'Project invitation', time: 'Invited 3 days ago', title: 'Community Learning Initiative', text: 'You have been invited to contribute to a new project.', cta: 'Review invitation' },
    { type: 'Collaborator introduction', time: 'Received yesterday', title: 'Amina Yusuf', text: 'A potential collaborator would like to connect around your project.', cta: 'Review introduction', href: OL.introductions },
  ],
};

export type Collaborator = {
  /** Person of the people/ journeys; the card opens that person's profile (12.28 to 12.30, B5) and introduction request. */
  id: PersonId;
  name: string;
  role: string;
  availability: string;
  skills: string;
  purpose: string;
  skill: string;
  preference: string;
  match: string;
  photo: string;
  /** Figma node of the portrait */
  node: string;
};
export const COLLABORATORS_HEAD = {
  label: 'People to create with',
  title: 'The right people can change an idea.',
  support: 'Meet people whose experience, perspective and way of working may complement yours.',
};
export const COLLABORATORS: Collaborator[] = [
  {
    id: 'amina',
    name: 'Amina Yusuf',
    role: 'Career Researcher',
    availability: 'Available for new projects.',
    skills: 'Research · Education · Career Development',
    purpose: 'Making career guidance more accessible to students.',
    skill: 'Experience researching student career decisions.',
    preference: 'Structured weekly collaboration.',
    match: 'Amina’s research experience may complement your product design and technology skills, helping your team better understand the needs of students.',
    photo: '/images/app/collab-start/collab-amina.jpg',
    node: '17204:11680 Collaborator Card / Portrait (carousel Page=1)',
  },
  {
    id: 'kunle',
    name: 'Kunle Afolabi',
    role: 'Software Engineer',
    availability: 'Open to one new project.',
    skills: 'Web Development · Accessibility · Product Engineering',
    purpose: 'Building simple, accessible tools for learners.',
    skill: 'Experience turning early prototypes into reliable products.',
    preference: 'Asynchronous updates with a weekly call.',
    match: 'Kunle’s engineering background may complement your design experience, helping your team move from an agreed idea to a working first version.',
    photo: '/images/app/collab-start/collab-kunle.jpg',
    node: '17204:11849 Collaborator Card / Portrait (carousel Page=2)',
  },
  {
    id: 'funmi',
    name: 'Funmi Okoro',
    role: 'Learning Experience Designer',
    availability: 'Available for new projects.',
    skills: 'Learning Design · Facilitation · Storytelling',
    purpose: 'Helping young people see more possibilities for their future.',
    skill: 'Experience designing workshops and guided learning journeys.',
    preference: 'Hands-on working sessions twice a week.',
    match: 'Funmi’s learning design experience may complement your product skills, helping your team shape how students move through the experience, step by step.',
    photo: '/images/app/collab-start/collab-funmi.jpg',
    node: '17204:12008 Collaborator Card / Portrait (carousel Page=3)',
  },
];

export const INVITES_HEAD = { label: 'Your next collaboration', title: 'You’ve been invited.' };
export type Invitation = {
  date: string;
  title: string;
  text: string;
  by: { name: string; initials: string };
  role: string;
  commitment: string;
  team: string[];
  members: string;
  contribution: string;
};
export const INVITATIONS: Invitation[] = [
  {
    date: 'Invited 28 October',
    title: 'Community Learning Initiative',
    text: 'A project creating accessible learning opportunities for underserved communities.',
    by: { name: 'Daniel Okafor', initials: 'DO' },
    role: 'Product Designer',
    commitment: 'Flexible, based on agreed contribution.',
    team: ['DO', 'TA', 'NY'],
    members: '3 members',
    contribution: 'Help define the learning experience and design the initial product structure.',
  },
  {
    date: 'Invited 30 October',
    title: 'Craft Memory Archive',
    text: 'A shared archive documenting traditional craft techniques with the artisans who practise them.',
    by: { name: 'Tunde Bello', initials: 'TB' },
    role: 'Web Developer',
    commitment: 'Two hours a week, agreed together.',
    team: ['TB', 'FO'],
    members: '2 members',
    contribution: 'Build a simple, accessible home for the archive where artisans can share their techniques.',
  },
];

export const OPEN_HEAD = {
  label: 'Open collaborations',
  title: 'Ideas looking for people.',
  support: 'Explore projects seeking the skills, experience and perspective you can bring.',
  /** The links at the right of the header row (Figma "Open calls links"): Your open calls (12.46) and View All Open Calls (12.5 Discover projects). */
  yourCalls: { label: 'Your open calls', href: OL.openCalls },
  link: 'View All Open Calls',
  linkHref: WORKSPACE_PATHS.discover,
};
export type OpenCall = { stage: string; title: string; text: string; looking: string; team: string[]; teamText: string; commitment: string; owner: string };
export const OPEN_CALLS: OpenCall[] = [
  { stage: 'Exploring', title: 'A Better Way to Learn', text: 'A digital learning initiative exploring more accessible ways for students to learn.', looking: 'Product Designer · Software Engineer · Education Researcher', team: ['NE', 'OA'], teamText: '2 people', commitment: 'Flexible, based on agreed contribution.', owner: 'Ngozi Eze' },
  { stage: 'Planning', title: 'Craft Memory Archive', text: 'A shared archive documenting traditional craft techniques with the artisans who practise them.', looking: 'Photographer · Researcher · Web Developer', team: ['TB', 'FO'], teamText: '2 people', commitment: 'Two hours a week, agreed together.', owner: 'Tunde Bello' },
  { stage: 'Exploring', title: 'Neighbourhood Story Map', text: 'A shared map of the stories, places and voices that shape Lagos neighbourhoods.', looking: 'Illustrator · Writer · Front-end Developer', team: ['CO'], teamText: '1 person', commitment: 'Flexible, based on agreed contribution.', owner: 'Chioma Obi' },
  { stage: 'Exploring', title: 'Voices of the Market', text: 'A shared audio archive of the stories traders tell about their markets and their work.', looking: 'Sound Recordist · Writer · Researcher', team: ['EA', 'BN'], teamText: '2 people', commitment: 'Flexible, based on agreed contribution.', owner: 'Emeka Anozie' },
  { stage: 'Planning', title: 'Learning in Two Languages', text: 'A bilingual learning toolkit for primary school teachers working in two languages.', looking: 'Learning Designer · Illustrator · Teacher', team: ['HS'], teamText: '1 person', commitment: 'Three hours a week, agreed together.', owner: 'Halima Sani' },
  { stage: 'Exploring', title: 'The Weaving Lab', text: 'An open lab exploring how traditional weaving can shape modern product design.', looking: 'Product Designer · Weaver · Photographer', team: ['AD', 'KO'], teamText: '2 people', commitment: 'Flexible, based on agreed contribution.', owner: 'Adaora Duru' },
];

export const MESSAGES_HEAD = { label: 'Team conversations', title: 'Stay connected.' };
export const MESSAGES = [
  { project: 'Career Guidance for Everyone', sender: 'Amina Yusuf', text: '“I’ve added the research findings to the shared brief. We should review the student needs before moving forward.”', time: '2 hours ago', unread: true },
  { project: 'Community Learning Initiative', sender: 'Daniel Okafor', text: '“I’ve shared the first draft of the project brief. Could you take a look this week?”', time: 'Yesterday', unread: true },
  { project: 'Career Guidance for Everyone', sender: 'Tobi Adeyemi', text: '“The onboarding prototype is ready for review whenever you are.”', time: '3 days ago', unread: false },
];

export const START_PANEL = {
  label: 'Your next idea',
  title: 'Something meaningful starts with an idea.',
  support: 'Bring your intention to Akines. We’ll help you clarify it, find the right people and prepare to create together.',
};

/* ------------------------------------------------------------------ Home Empty (17111:9037) */

export const EMPTY_WELCOME = {
  eyebrow: WELCOME.eyebrow,
  title: 'Welcome, Kemi.',
  support: 'You have no projects yet. Start one, find someone to make it with, or join an open call.',
};

export const EMPTY_BEGIN = {
  label: 'Start here',
  title: 'Three ways to begin.',
  support: 'Pick one. You can do the others whenever you like.',
  cards: [
    { n: '01', title: 'Start a project', text: 'Bring an idea and let Akines help you shape it into a brief.', action: 'Start a project', href: PATHS.start },
    { n: '02', title: 'Find collaborators', text: 'See people whose skills and interests fit what you are making.', action: 'Find collaborators', href: PATHS.collaborators },
    { n: '03', title: 'Browse open calls', text: 'Offer your skills to a project that is looking for people.', action: 'Browse open calls', href: WORKSPACE_PATHS.discover },
  ],
};

export const EMPTY_GLANCE = {
  label: 'At a glance',
  title: 'Nothing here yet, and that is fine.',
  support: 'These fill in as you start working with others.',
};
/** The four zero tiles. Each one opens the Empty frame of the page it leads to. */
export const EMPTY_TILES: Tile[] = [
  { n: '01', label: 'Active projects', count: '0', unit: 'projects', text: 'No projects yet.', link: 'My Projects', href: OL.myProjectsEmpty },
  { n: '02', label: 'Decisions awaiting you', count: '0', unit: 'decisions', text: 'Nothing waiting for you.', link: 'Pending decisions', href: OL.decisionsEmpty },
  { n: '03', label: 'Collaborator introductions', count: '0', unit: 'introductions', text: 'No introductions yet.', link: 'Introduction requests', href: OL.introductionsEmpty },
  { n: '04', label: 'Tasks due this week', count: '0', unit: 'tasks', text: 'No tasks yet.', link: 'Upcoming tasks', href: OL.tasksEmpty },
];

export const EMPTY_CAN = {
  label: 'What you can do here',
  title: 'A shared space for creative work.',
  lines: [
    { title: 'Start a project', support: 'Describe an idea and Akines helps you shape it into a brief.' },
    { title: 'Find collaborators', support: 'See people whose skills and interests fit what you are making.' },
    { title: 'Join an open call', support: 'Offer your skills to a project that is looking for people.' },
  ],
};
