'use client';

import './call.css';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Logo } from '@/components/Logo';
import { asset } from '@/lib/assets';
import { teamFor, type TeamMember } from '../project-team/data';
import { useProject } from '../workspace/project';
import { callStore, useCall } from './call-store';
import { MicOffIcon } from './CallIcons';
import { useMeetingView, meetPaths } from './store';

/**
 * Parts shared by the meeting screens (Figma 12.43): the people of the call, the top bar of the Lobby and Call ended, the video tiles, the round
 * call buttons and the hook that decides what your own tile and buttons show.
 */

const clean = (name: string) => name.replace(/\s*\(you\)\s*$/i, '');
const first = (name: string) => clean(name).split(' ')[0];

export type Cast = {
  key: ReturnType<typeof useProject>['key'];
  root: string;
  project: string;
  meeting: ReturnType<typeof useMeetingView>;
  paths: ReturnType<typeof meetPaths>;
  you: TeamMember;
  youName: string;
  /** The three other people in the order of the call grid: the two who can speak, then the one who is muted. */
  others: TeamMember[];
  /** The order of the People panel: you, then the others (the muted one before the last). */
  roster: TeamMember[];
  /** "Adaeze, Tobi and Ngozi" */
  firstNames: string;
};

/** The people of the call come from the project team: the owner is you, the next three are in the call. Ngozi (the third) is muted. */
export function useCast(): Cast {
  const { key, root, header } = useProject();
  const meeting = useMeetingView();
  const members = teamFor(key).members;
  return useMemo(() => {
    const [you, a, b, c] = members;
    const others = [a, b, c];
    return {
      key,
      root,
      project: header.name,
      meeting,
      paths: meetPaths(root),
      you,
      youName: `${clean(you.name)} (You)`,
      others,
      roster: [you, a, c, b],
      firstNames: `${first(a.name)}, ${first(b.name)} and ${first(c.name)}`,
    };
  }, [key, root, header.name, meeting, members]);
}

/** Tells the store a meeting screen is here; when the last one goes and no other appears, every track is stopped. */
export function useLeaveGuard() {
  useEffect(() => {
    callStore.screenShown();
    return () => callStore.screenGone();
  }, []);
}

/* ------------------------------------------------------------------ top bar */

export function TopBar({ project }: { project: string }) {
  return (
    <header className="mc-top">
      <Logo />
      <span className="mc-top__project">{project}</span>
    </header>
  );
}

/* ------------------------------------------------------------------ video */

/** A live stream in a video element. Your own view is mirrored and silent. */
export function LiveVideo({ stream, mirror, contain, className }: { stream: MediaStream; mirror?: boolean; contain?: boolean; className?: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (el.srcObject !== stream) el.srcObject = stream;
    el.play?.().catch(() => {});
    return () => {
      if (el.srcObject === stream) el.srcObject = null;
    };
  }, [stream]);
  return <video ref={ref} className={['mc-tile__video', mirror ? 'mc-tile__video--mirror' : '', contain ? 'mc-tile__video--contain' : '', className ?? ''].filter(Boolean).join(' ')} autoPlay playsInline muted aria-hidden="true" />;
}

const Photo = ({ src, className = 'mc-tile__feed' }: { src?: string; className?: string }) =>
  src ? <img className={className} src={asset(src)} alt="" draggable={false} decoding="async" /> : null;

/** A person of the call: the portrait feed, the shade and the name; the speaker has the amber border. */
export function PhotoTile({ person, name, speaking }: { person: TeamMember; name?: string; speaking?: boolean }) {
  return (
    <div className={`mc-tile${speaking ? ' mc-tile--speaking' : ''}`} data-speaking={speaking ? 'true' : undefined}>
      <Photo src={person.photo} />
      <span className="mc-tile__shade" aria-hidden="true" />
      <span className="mc-tile__name">{name ?? clean(person.name)}</span>
    </div>
  );
}

/** A person with the microphone off and no camera: the dark tile, the portrait circle, the muted badge. */
export function MutedTile({ person }: { person: TeamMember }) {
  return (
    <div className="mc-tile mc-tile--avatar">
      <span className="mc-tile__avatar" aria-hidden="true">
        <Photo src={person.photo} className="mc-tile__avatar-img" />
      </span>
      <span className="mc-tile__badge" role="img" aria-label="Microphone off">
        <MicOffIcon size={16} />
      </span>
      <span className="mc-tile__name">{clean(person.name)}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ your own tile and buttons */

export type SelfView = ReturnType<typeof useSelf>;

/**
 * What your own tile and the mic and camera buttons show.
 *  - Real devices (the Lobby asked for them): your live camera, the microphone state, each button toggles its track.
 *  - Refused or not available: the designed camera-off tile (your portrait in a circle), the buttons are red, and a quiet note says what to allow.
 *  - `simulate` (the frames that open already in a state, with no devices asked for): your portrait as the feed, the buttons toggle a look only.
 */
export function useSelf(simulate: boolean, initialCamOn = true) {
  const call = useCall();
  const [simMic, setSimMic] = useState(true);
  const [simCam, setSimCam] = useState(initialCamOn);
  const sim = simulate && call.phase !== 'ready';

  const view: 'live' | 'photo' | 'off' = call.hasCam && call.camOn && call.stream ? 'live' : sim && simCam ? 'photo' : 'off';
  const micMuted = sim ? !simMic : !call.hasMic || !call.micOn;

  const needCam = call.camOn && !call.hasCam;
  const needMic = !call.hasMic;
  let note: string | null = null;
  if (!sim && call.phase !== 'idle' && call.phase !== 'requesting') {
    if (needCam && needMic) note = 'Allow camera and microphone to use them here.';
    else if (needCam) note = 'Allow the camera to use it here.';
    else if (needMic) note = 'Allow the microphone to use it here.';
  }

  return {
    view,
    stream: call.stream,
    micMuted,
    camOff: view === 'off',
    note,
    toggleMic: () => (sim ? setSimMic((v) => !v) : callStore.toggleMic()),
    toggleCam: () => (sim ? setSimCam((v) => !v) : callStore.toggleCam()),
  };
}

/** Your own tile: live camera, your portrait as the feed, or the camera-off tile; `badge` adds the muted badge when your microphone is off. */
export function SelfTile({ self, person, name, badge, children }: { self: SelfView; person: TeamMember; name: string; badge?: boolean; children?: ReactNode }) {
  return (
    <div className={`mc-tile${self.view === 'off' ? ' mc-tile--avatar' : ''}`}>
      {self.view === 'live' && self.stream ? <LiveVideo stream={self.stream} mirror /> : null}
      {self.view === 'photo' ? <Photo src={person.photo} /> : null}
      {self.view === 'off' ? (
        <span className="mc-tile__avatar" aria-hidden="true">
          <Photo src={person.photo} className="mc-tile__avatar-img" />
        </span>
      ) : (
        <span className="mc-tile__shade" aria-hidden="true" />
      )}
      {badge && self.micMuted ? (
        <span className="mc-tile__badge" role="img" aria-label="Your microphone is off">
          <MicOffIcon size={16} />
        </span>
      ) : null}
      {self.note ? (
        <p className="mc-tile__note" role="status">
          {self.note}
        </p>
      ) : null}
      <span className="mc-tile__name">{name}</span>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ round call button */

export type RoundTone = 'default' | 'selected' | 'alert';

/** Call Button (Figma Call Button): round, 56 high, 72 wide for Leave. Default is white at 14 %, selected is white, alert is red. */
export function RoundButton({
  label,
  tone = 'default',
  wide,
  pressed,
  onClick,
  children,
  buttonRef,
}: {
  label: string;
  tone?: RoundTone;
  wide?: boolean;
  /** For buttons that stay on or off (Present, People, Chat). */
  pressed?: boolean;
  onClick?: () => void;
  children: ReactNode;
  buttonRef?: React.Ref<HTMLButtonElement>;
}) {
  return (
    <button
      ref={buttonRef}
      type="button"
      className={`mc-round mc-round--${tone}${wide ? ' mc-round--wide' : ''}`}
      aria-label={label}
      aria-pressed={pressed}
      title={label}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
