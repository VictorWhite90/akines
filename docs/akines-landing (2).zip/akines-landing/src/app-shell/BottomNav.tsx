'use client';

import { useEffect, useRef, useState } from 'react';
import { Link, useNav } from '@/lib/nav';
import { signOut, useSession } from '@/lib/auth';
import { useScrollLock } from '@/lib/hooks';
import { AppIcon } from './icons';
import type { ActiveNav } from './AppHeader';
import { COUNTERS, DEST, NAV, counterText, pageOf, type AppIconName } from './nav-model';
import type { MainPage } from '@/routes.types';

/** Bottom bar (tablet and mobile): six icons, the active one has an orange 24 x 2 indicator. Tapping a page with nested pages opens its sheet. */
export function BottomBar({ active, onOpenPage }: { active: ActiveNav; onOpenPage: (page: MainPage) => void }) {
  const nav = useNav();
  return (
    <nav className="bbar" aria-label="Main">
      <div className="bbar__items">
        {NAV.map((p) => {
          const isActive = active?.page === p.key;
          return (
            <button
              key={p.key}
              type="button"
              className="bbar__item"
              aria-label={p.label}
              aria-current={isActive ? 'page' : undefined}
              data-active={isActive ? 'true' : 'false'}
              onClick={() => (p.tabs.length === 0 ? nav.push(p.path) : onOpenPage(p.key))}
            >
              <span className="bbar__press" aria-hidden="true" />
              <span className="bbar__ind" aria-hidden="true" />
              <AppIcon name={p.icon} />
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function Backdrop({ onClick }: { onClick: () => void }) {
  return <div className="sheet-backdrop" onClick={onClick} aria-hidden="true" />;
}

function useSheetKeys(open: boolean, onClose: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useScrollLock(open);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.focus();
    const key = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('keydown', key);
      prev?.focus?.();
    };
  }, [open, onClose]);
  return ref;
}

/** Bottom sheet listing the nested pages of one main page. Mobile: full width. Tablet: 560 wide, centred, stuck to the bottom. */
export function PageSheet({ page, active, onClose }: { page: MainPage | null; active: ActiveNav; onClose: () => void }) {
  const nav = useNav();
  const ref = useSheetKeys(page !== null, onClose);
  const [shown, setShown] = useState<MainPage | null>(null);
  useEffect(() => {
    if (page) setShown(page);
  }, [page]);
  const p = shown ? pageOf(shown) : null;
  const activeTab = active && p && active.page === p.key ? active.tab ?? p.tabs[0]?.label : undefined;
  return (
    <>
      <div className="sheet-layer" data-open={page ? 'true' : 'false'} aria-hidden={page ? undefined : true}>
        <Backdrop onClick={onClose} />
        {p ? (
          <div ref={ref} className="sheet" role="dialog" aria-modal="true" aria-label={p.label} tabIndex={-1}>
            <button type="button" className="sheet__handle" aria-label="Close" onClick={onClose}><span /></button>
            <div className="sheet__title">
              <AppIcon name={p.icon} />
              <span>{p.label}</span>
            </div>
            <ul className="sheet__rows">
              {p.tabs.map((t) => (
                <li key={t.path}>
                  <Link href={t.path} className="sheet-row" data-selected={t.label === activeTab ? 'true' : 'false'} onClick={onClose}>
                    <span className="sheet-row__label">{t.label}</span>
                    {t.label === activeTab ? <span className="sheet-row__dot" aria-hidden="true" /> : null}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </>
  );
}

/** Mobile profile sheet: avatar and username, Messages and Notifications with counters, then the profile links. */
export function ProfileSheet({ open, onClose, onNotifications }: { open: boolean; onClose: () => void; onNotifications: () => void }) {
  const nav = useNav();
  const session = useSession();
  const ref = useSheetKeys(open, onClose);
  const row = (icon: AppIconName, label: string, href: string, count?: number) => (
    <Link href={href} className="sheet-row" data-selected="false" onClick={onClose}>
      <AppIcon name={icon} />
      <span className="sheet-row__label">{label}</span>
      {count ? <span className="sheet-row__count">{counterText(count)}</span> : null}
    </Link>
  );
  return (
    <div className="sheet-layer" data-open={open ? 'true' : 'false'} aria-hidden={open ? undefined : true}>
      <Backdrop onClick={onClose} />
      <div ref={ref} className="sheet" role="dialog" aria-modal="true" aria-label="Profile" tabIndex={-1} hidden={!open}>
        <button type="button" className="sheet__handle" aria-label="Close" onClick={onClose}><span /></button>
        <div className="sheet__profile">
          <span className="hdr-avatar__circle hdr-avatar__circle--lg">{session.initials || 'KA'}</span>
          <span className="sheet__username">{session.username || 'kemiadeyemi'}</span>
        </div>
        <ul className="sheet__rows">
          <li>{row('messages', 'Messages', DEST.messages, COUNTERS.messages)}</li>
          <li>
            <button type="button" className="sheet-row" data-selected="false" onClick={() => { onClose(); onNotifications(); }}>
              <AppIcon name="notifications" />
              <span className="sheet-row__label">Notifications</span>
              <span className="sheet-row__count">{counterText(COUNTERS.notifications)}</span>
            </button>
          </li>
        </ul>
        <div className="sheet__rule" />
        <ul className="sheet__rows">
          <li>{row('user', 'View profile', DEST.profile)}</li>
          <li>{row('user-check', 'Complete your profile', DEST.completeProfile)}</li>
          <li>{row('settings', 'Settings', DEST.settings)}</li>
          <li>{row('help', 'Help', DEST.help)}</li>
        </ul>
        <div className="sheet__rule" />
        <ul className="sheet__rows">
          <li>
            <button type="button" className="sheet-row" data-selected="false" onClick={() => { onClose(); signOut(); nav.push('/'); }}>
              <AppIcon name="log-out" />
              <span className="sheet-row__label">Log out</span>
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
}
