'use client';

import { useState } from 'react';
import { Button } from '@/ui';
import { asset } from '@/lib/assets';
import { BackLink, Heading, IconEye } from './cc-ui';
import { matchRowsFor, PEOPLE, personRoutes, R, whyNoteFor, WIDE_PHOTO, type PersonId } from './data';
import { CcOverlays, type OverlayId } from './overlays';

/**
 * B4 Why this match of Amina (Figma 17216:16167, route /collaborate/collaborators/why-this-match) and the ones of 12.28 to 12.30
 * (Kunle 17972:139787, Funmi 17972:141398, Chidi 17972:142259), route /collaborate/collaborators/<id>/why-this-match.
 */
export function WhyMatchScreen({ id }: { id: PersonId }) {
  const [ov, setOv] = useState<OverlayId | null>(null);
  const person = PEOPLE[id];
  const routes = personRoutes(id);
  return (
    <>
      <div className="cc-page cc-why">
        <div className="cc-why__main">
          <BackLink href={R.discovery}>Back to collaborators</BackLink>
          <Heading eyebrow="Why this match" title="You may bring different strengths to the same purpose." support="Here’s what makes this collaboration worth exploring." />
          <ol className="cc-rows" data-m="stagger">
            {matchRowsFor(id).map((row, i) => (
              <li className="cc-row" key={row.category}>
                <div className="cc-row__meta">
                  <span className="cc-row__no">{String(i + 1).padStart(2, '0')}</span>
                  <span className="cc-row__cat">{row.category}</span>
                </div>
                <div className="cc-row__body">
                  <p className="cc-row__text">{row.text}</p>
                  <p className="cc-row__src">
                    <IconEye size={14} strokeWidth={1.5} />
                    <span>{row.source}</span>
                  </p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <aside className="cc-why__side" aria-label="Match summary">
          <div className="cc-summary" data-m="up">
            <div className="cc-summary__photo">
              {/* Figma node 17216:16271 "Photo" (382 x 300); the others are cropped from their Why this match frames */}
              <img src={asset(WIDE_PHOTO[id])} alt="" loading="lazy" decoding="async" width={382} height={300} />
            </div>
            <p className="cc-card__avail-text">
              <span className="cc-dot" aria-hidden="true" />
              {person.availability}
            </p>
            <h2 className="cc-summary__name">{person.name}</h2>
            <p className="cc-card__role">{person.role}</p>
            <Button fullWidth href={routes.profile} arrow="up-right">
              View profile
            </Button>
            <Button fullWidth variant="secondary" href={routes.request}>
              Request introduction
            </Button>
            <Button variant="link" onClick={() => setOv('ask')}>
              Ask Akines why
            </Button>
            <div className="cc-summary__privacy">
              <hr className="cc-rule" />
              <p>
                <IconEye size={16} strokeWidth={1.5} />
                <span>{whyNoteFor(id)}</span>
              </p>
              <Button variant="link" onClick={() => setOv('privacy')}>
                What’s visible and why
              </Button>
            </div>
          </div>
        </aside>
      </div>
      <CcOverlays open={ov} onClose={() => setOv(null)} person={id} />
    </>
  );
}

export default function WhyMatch() {
  return <WhyMatchScreen id="amina" />;
}
