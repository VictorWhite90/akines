'use client';

/**
 * Complete profile: a progress pill in the header, left of Messages. It opens a dropdown with what is left to do
 * (what Akines needs from a member, src/features/profile/progress.ts). Every open step goes to the "Complete your profile"
 * placeholder page until the profile is designed. Hidden once the profile is complete. Compact = ring only (tablet, mobile).
 */
import { useId, useRef, useState } from 'react';
import { Camera, Check, ChevronRight, ChevronUp, Fingerprint, Image as ImageIcon, MailCheck, MapPin, PenLine, Sparkles, Users } from 'lucide-react';
import { Link } from '@/lib/nav';
import { useDismiss } from '@/lib/hooks';
import { PROFILE_COPY, PROFILE_TASKS, profilePercent, type ProfileIconName } from '@/features/profile/progress';
import { DEST } from './nav-model';

const ICONS: Record<ProfileIconName, React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }>> = {
  sparkles: Sparkles, pen: PenLine, fingerprint: Fingerprint, image: ImageIcon, camera: Camera, pin: MapPin, mail: MailCheck, users: Users,
};

const R = 15; // ring radius in a 36 box, stroke 3
const C = 2 * Math.PI * R;

export function ProgressRing({ percent }: { percent: number }) {
  return (
    <span className="pp-ring" aria-hidden="true">
      <svg viewBox="0 0 36 36" width="36" height="36">
        <circle className="pp-ring__track" cx="18" cy="18" r={R} />
        <circle className="pp-ring__bar" cx="18" cy="18" r={R} style={{ strokeDasharray: C, strokeDashoffset: C * (1 - percent / 100) }} transform="rotate(-90 18 18)" />
      </svg>
      <span className="pp-ring__n">{percent}%</span>
    </span>
  );
}

export function ProfileProgress({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const panelId = useId();
  useDismiss(open, ref, () => setOpen(false));
  const percent = profilePercent();
  if (percent >= 100) return null;
  const todo = PROFILE_TASKS.filter((t) => !t.done);
  const done = PROFILE_TASKS.filter((t) => t.done);
  return (
    <div className="pp" ref={ref} data-open={open ? 'true' : 'false'} data-compact={compact ? 'true' : 'false'}>
      <button
        type="button"
        className="pp-pill"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        aria-label={`${PROFILE_COPY.pill}, ${percent}% done`}
        onClick={() => setOpen((o) => !o)}
      >
        <ProgressRing percent={percent} />
        <span className="pp-pill__label">{PROFILE_COPY.pill}</span>
        <ChevronUp size={16} strokeWidth={1.5} className="pp-pill__chev" aria-hidden="true" />
      </button>
      {open ? (
        <div className="pp-panel" id={panelId} role="dialog" aria-label="Profile progress">
          <div className="pp-panel__head">
            <h2 className="pp-panel__title">{PROFILE_COPY.title}</h2>
            <p className="pp-panel__text">{PROFILE_COPY.left(todo.length)}</p>
          </div>
          <p className="pp-label">{PROFILE_COPY.todo}</p>
          <ul className="pp-list">
            {todo.map((t) => {
              const Icon = ICONS[t.icon];
              return (
                <li key={t.id}>
                  <Link href={DEST.completeProfile} className="pp-row" onClick={() => setOpen(false)}>
                    <span className="pp-ico"><Icon size={20} strokeWidth={1.5} /></span>
                    <span className="pp-txt">
                      <span className="pp-t">{t.title}</span>
                      <span className="pp-s">{t.text}</span>
                    </span>
                    <ChevronRight size={16} strokeWidth={1.5} className="pp-go" aria-hidden="true" />
                  </Link>
                </li>
              );
            })}
          </ul>
          <p className="pp-label pp-label--done">{PROFILE_COPY.done}</p>
          <ul className="pp-list pp-list--done">
            {done.map((t) => (
              <li key={t.id} className="pp-row pp-row--done">
                <span className="pp-ico pp-ico--done"><Check size={18} strokeWidth={1.75} /></span>
                <span className="pp-txt">
                  <span className="pp-t">{t.title}</span>
                </span>
                <span className="pp-note">{PROFILE_COPY.doneNote}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
