import type { StatusItem } from './dash';

/**
 * Copy and numbers of the Project overview dashboard (Figma 12.11 Project overview 17364:24207, Overview Empty 17364:24822, 12.33 Adire Stories
 * Project overview 17759:89371 and the two sample projects of 12.26, 17703:73613 and 17703:74159). Text is word for word from the frames.
 * One set per project: Career Guidance for Everyone here, Adire Stories in art-data.ts (which also picks the set of the page being shown),
 * same shape; the sample projects further down.
 * The pages these cards link to are not in the data: they come from the project's navigation paths (see Overview.tsx).
 */

export type Metric = {
  value: string;
  caption: string;
  /** Amber dot before the caption ("needs you", "to make"). */
  dot?: boolean;
};

export type OverviewDash = {
  /** The one line under the project name. */
  lead: string;
  /** Name shown when the page cannot read it from the project header (Adire Stories and the samples; Career reads the saved project details). */
  name: string;
  metrics: { milestones: Metric; tasks: Metric; review: Metric; decisions: Metric };
  /** Project progress: DONE / DUE / PLANNED line and the stage name. */
  stages: { state: 'done' | 'doing' | 'next'; when: string; title: string }[];
  /** Task status: counts in the order of the legend (Not started, In progress, In review, Completed). */
  status: StatusItem[];
  /** This week: the total, its caption, the seven bars Monday to Sunday and the index of today (Thursday). */
  week: { total: number; caption: string; bars: number[]; today: number };
  /** Brief at a glance: audience, goal, scope. */
  glance: { label: string; value: string }[];
  /** Continue working: two rows, "Continue" at the right. */
  work: { title: string; status: string }[];
};

/** The bars of the design (30, 50, 40 and 60 px, then three empty days) as relative heights. Thursday is today. */
export const WEEK_BARS = [3, 5, 4, 6, 0, 0, 0];
export const WEEK_CAPTION = 'updates from the team';

export const statusItems = (notStarted: number, inProgress: number, inReview: number, completed: number): StatusItem[] => [
  { label: 'Not started', n: notStarted, tone: 'gray' },
  { label: 'In progress', n: inProgress, tone: 'accent' },
  { label: 'In review', n: inReview, tone: 'ink' },
  { label: 'Completed', n: completed, tone: 'green' },
];

export const GLANCE_LABELS = ['AUDIENCE', 'GOAL', 'SCOPE'] as const;
export const glance = (audience: string, goal: string, scope: string) => GLANCE_LABELS.map((label, i) => ({ label, value: [audience, goal, scope][i] }));

/** The review and reply rows of "Continue working" share their status lines in every project. */
export const NEEDS_REVIEW = 'Needs your review';
export const WAITING_REPLY = 'Waiting for your reply';

/* ------------------------------------------------------------------ Career Guidance for Everyone */

export const CAREER_OVERVIEW_DASH: OverviewDash = {
  name: 'Career Guidance for Everyone',
  lead: 'Helping Nigerian students make informed career decisions.',
  metrics: {
    milestones: { value: '1/3', caption: 'complete' },
    tasks: { value: '7', caption: '1 in review' },
    review: { value: '1', caption: 'needs you', dot: true },
    decisions: { value: '1', caption: 'to make', dot: true },
  },
  stages: [
    { state: 'done', when: 'DONE 12 OCT', title: 'Project brief approved' },
    { state: 'doing', when: 'DUE 28 NOV', title: 'Student experience definition' },
    { state: 'next', when: 'PLANNED 12 DEC', title: 'Prototype review' },
  ],
  status: statusItems(3, 4, 1, 2),
  week: { total: 18, caption: WEEK_CAPTION, bars: WEEK_BARS, today: 3 },
  glance: glance('Students aged 14 to 18', '200 complete the interest check', 'Exploration and a personal shortlist'),
  work: [
    { title: 'Review the student onboarding draft', status: NEEDS_REVIEW },
    { title: 'Respond to the research findings', status: WAITING_REPLY },
  ],
};

/** Overview Empty (17364:24822): the project has nothing yet. The same four cards, all at zero. */
export const EMPTY_METRICS: OverviewDash['metrics'] = {
  milestones: { value: '0', caption: 'none yet' },
  tasks: { value: '0', caption: 'none yet' },
  review: { value: '0', caption: 'all clear' },
  decisions: { value: '0', caption: 'none yet' },
};

/* ------------------------------------------------------------------ 12.26 Sample projects */

export type SamplePerson = { name: string; photo: string; presence: 'available' | 'working' | 'away'; tasks: number };

/** What the project rail of a sample project shows (the shared rail only knows Career Guidance for Everyone and Adire Stories). */
export type SampleRail = {
  meeting: { day: string; time: string; title: string; meta: string };
  people: SamplePerson[];
  review: { title: string; caption: string }[];
};

export type SampleDash = OverviewDash & { rail: SampleRail };

const KEMI = '/images/app/team/kemi.jpg';

export const COMMUNITY_LEARNING_DASH: SampleDash = {
  name: 'Community Learning Initiative',
  lead: 'A weekend learning programme pairing tutors with students.',
  metrics: {
    milestones: { value: '1/3', caption: 'complete' },
    tasks: { value: '5', caption: '2 in review' },
    review: { value: '2', caption: 'need you', dot: true },
    decisions: { value: '1', caption: 'to make', dot: true },
  },
  stages: [
    { state: 'done', when: 'DONE 20 OCT', title: 'Project brief approved' },
    { state: 'doing', when: 'DUE 30 NOV', title: 'Weekend session format' },
    { state: 'next', when: 'PLANNED 14 DEC', title: 'Tutor onboarding plan' },
  ],
  status: statusItems(2, 1, 2, 3),
  week: { total: 11, caption: WEEK_CAPTION, bars: WEEK_BARS, today: 3 },
  glance: glance('Senior secondary students', '30 students attend at least four sessions', 'Tutors, session format and a six week pilot'),
  work: [
    { title: 'Confirm the tutor list', status: NEEDS_REVIEW },
    { title: 'Respond to the session format proposal', status: WAITING_REPLY },
  ],
  rail: {
    meeting: { day: 'THU', time: '5 PM', title: 'Session format workshop', meta: '45 min, 4 people' },
    people: [
      { name: 'Kemi', photo: KEMI, presence: 'working', tasks: 2 },
      { name: 'Ayo', photo: '/images/app/team/ayo-balogun.jpg', presence: 'available', tasks: 1 },
      { name: 'Tolu', photo: '/images/app/team/tolu.jpg', presence: 'working', tasks: 1 },
      { name: 'Funke', photo: '/images/app/team/funke.jpg', presence: 'away', tasks: 1 },
    ],
    review: [
      { title: 'Tutor list', caption: 'Tolu Okafor, 2 hours ago' },
      { title: 'Choose the session length', caption: 'Decision, waiting for you' },
    ],
  },
};

export const MENTORSHIP_CIRCLE_DASH: SampleDash = {
  name: 'Mentorship Circle',
  lead: 'A peer mentoring programme for final-year students.',
  metrics: {
    milestones: { value: '1/3', caption: 'complete' },
    tasks: { value: '4', caption: '1 in review' },
    review: { value: '1', caption: 'needs you', dot: true },
    decisions: { value: '1', caption: 'to make', dot: true },
  },
  stages: [
    { state: 'done', when: 'DONE 18 OCT', title: 'Project brief approved' },
    { state: 'doing', when: 'DUE 27 NOV', title: 'Mentor recruitment' },
    { state: 'next', when: 'PLANNED 11 DEC', title: 'Mentor guide' },
  ],
  status: statusItems(2, 1, 1, 3),
  week: { total: 9, caption: WEEK_CAPTION, bars: WEEK_BARS, today: 3 },
  glance: glance('Final-year students and early-career professionals', 'Six mentors complete a full eight week cycle', 'Mentors, a guide and a first circle'),
  work: [
    { title: 'Review the mentor sign-up form', status: NEEDS_REVIEW },
    { title: 'Respond to the mentor shortlist', status: WAITING_REPLY },
  ],
  rail: {
    meeting: { day: 'FRI', time: '3 PM', title: 'Mentor shortlist review', meta: '30 min, 3 people' },
    people: [
      { name: 'Kemi', photo: KEMI, presence: 'working', tasks: 2 },
      { name: 'Bisi', photo: '/images/app/team/bisi.jpg', presence: 'available', tasks: 1 },
      { name: 'Emeka', photo: '/images/app/team/emeka.jpg', presence: 'away', tasks: 1 },
    ],
    review: [
      { title: 'Mentor sign-up form', caption: 'Bisi Fashola, 2 hours ago' },
      { title: 'Choose the circle size', caption: 'Decision, waiting for you' },
    ],
  },
};
