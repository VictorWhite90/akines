import type { RouteDef } from '@/routes.types';
import { DecisionAcknowledged, DecisionAcknowledgeModal, DecisionDetail } from './DecisionDetail';
import { Decisions, DecisionsEmpty, DecisionsHistory, DecisionsProposeModal, DecisionsProposed } from './Decisions';
import { DP } from './data';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * Decisions 12.20: Decisions, Empty, Decision detail and History, with Modal:Propose decision, Toast:Decision proposed,
 * Modal:Acknowledge decision and Toast:Decision acknowledged. The "state-" routes are the Figma frames that have no natural trigger
 * in the prototype: Empty is reachable only here, and each modal and toast frame is its parent page with the overlay open or showing
 * (the same way Conversations does it). The modals open from Propose decision and Acknowledge decision.
 */
export const routes: RouteDef[] = [
  { path: DP.list, title: 'Decisions', shell: 'app', nav, component: Decisions },
  { path: DP.empty, title: 'Decisions', shell: 'app', nav, component: DecisionsEmpty },
  { path: DP.detail, title: 'Decision', shell: 'app', nav, component: DecisionDetail },
  { path: DP.history, title: 'Decisions', shell: 'app', nav, component: DecisionsHistory },
  { path: DP.propose, title: 'Decisions', shell: 'app', nav, component: DecisionsProposeModal },
  { path: DP.proposed, title: 'Decisions', shell: 'app', nav, component: DecisionsProposed },
  { path: DP.acknowledge, title: 'Decision', shell: 'app', nav, component: DecisionAcknowledgeModal },
  { path: DP.acknowledged, title: 'Decision', shell: 'app', nav, component: DecisionAcknowledged },
];
