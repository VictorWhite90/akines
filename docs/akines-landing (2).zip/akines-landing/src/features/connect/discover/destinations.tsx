import type { RouteDef } from '@/routes.types';
import { PATHS, PROFILES, profilePath } from './data';
import { EventDetail } from './event';
import { AllInterests, EventsPage, ExploreAll, ForYouAll, InterestPage, Suggestions } from './lists';
import { ProfilePage } from './profile';

/**
 * The pages Discover leads to (Figma 11.66 to 11.73), at the tab URL tails of the design. All are Discover pages (the Discover tab stays
 * selected), except the profiles, which the design files under People. Route files must not be client components, so each screen is wrapped here.
 *
 * State routes, one for each Loading, No results, Empty and Could not load frame that no interaction reaches on its own:
 *  - /connect/for-you/state-no-results, /connect/interests/visual-arts/state-no-results, /connect/events/state-no-results: the page with the
 *    chip of its No results frame on (Studio Visits, Projects, This week). The chips reach the same state by themselves.
 *  - /connect/discover/suggestions/state-empty: All suggestions, Empty.
 *  - /connect/people/state-loading and /connect/people/state-error: the profile Loading frame (it goes to Anaya Smith after 2.5 s) and Could not load
 *    (Try again goes to the Loading frame). The design's address for both frames is /connect/people, which opens the Loading frame.
 * The Registered state, the Register dialog and the toast of the Event page are reached by Register, as in the design (no route of their own).
 */
const nav = { page: 'connect', tab: 'Discover' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

const Explore = () => <ExploreAll />;
const ForYou = () => <ForYouAll />;
const ForYouNone = () => <ForYouAll initial="studio-visits" />;
const Interests = () => <AllInterests />;
const Interest = () => <InterestPage />;
const InterestNone = () => <InterestPage initial="projects" />;
const Events = () => <EventsPage />;
const EventsNone = () => <EventsPage initial="week" />;
const Event = () => <EventDetail />;
const People = () => <Suggestions />;
const PeopleEmpty = () => <Suggestions empty />;
const ProfileLoading = () => <ProfilePage state="loading" />;
const ProfileError = () => <ProfilePage state="error" />;

const profiles: RouteDef[] = PROFILES.map((p) => {
  const Screen = () => <ProfilePage slug={p.slug} />;
  Screen.displayName = `Profile(${p.name})`;
  return def(profilePath(p.slug), `Connect: People, ${p.name}`, Screen);
});

export const routes: RouteDef[] = [
  def(PATHS.explore, 'Connect: Discover, Explore all', Explore),
  def(PATHS.forYou, 'Connect: Discover, For you', ForYou),
  def(`${PATHS.forYou}/state-no-results`, 'Connect: Discover, For you, no results', ForYouNone),
  def(PATHS.interests, 'Connect: Discover, Interests', Interests),
  def(PATHS.interest, 'Connect: Discover, Visual Arts', Interest),
  def(`${PATHS.interest}/state-no-results`, 'Connect: Discover, Visual Arts, no results', InterestNone),
  def(PATHS.events, 'Connect: Discover, Events', Events),
  def(`${PATHS.events}/state-no-results`, 'Connect: Discover, Events, no results', EventsNone),
  def(PATHS.event, 'Connect: Discover, Memory and Cloth', Event),
  def(PATHS.suggestions, 'Connect: Discover, People for you', People),
  def(`${PATHS.suggestions}/state-empty`, 'Connect: Discover, People for you, empty', PeopleEmpty),
  def('/connect/people', 'Connect: People, loading', ProfileLoading),
  def('/connect/people/state-loading', 'Connect: People, loading', ProfileLoading),
  def('/connect/people/state-error', 'Connect: People, could not load', ProfileError),
  ...profiles,
];
