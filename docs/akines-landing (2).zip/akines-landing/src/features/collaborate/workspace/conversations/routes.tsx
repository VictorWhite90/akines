import type { RouteDef } from '@/routes.types';
import { ConversationsInfo, ConversationsMeetMenu, ConversationsScheduleModal, ConversationsScheduled } from './Conversations';
import { CONV_PATHS } from './data';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * The state frames of 12.13 Conversations that came with the Meet button: Dropdown:Meet (17808:109947), Panel:Conversation info
 * (17808:109955), Modal:Schedule meeting (17808:110053) and Toast:Meeting scheduled (17808:110125). Each is the Conversations page with
 * the menu, the panel or the modal open, or the toast showing; no control reaches them by address, the Meet button, the i button and
 * Schedule for later open them in place. workspace/routes.tsx adds these to the routes of the project workspace; the Adire Stories
 * mirror (art-routes.tsx) copies them too.
 */
export const conversationStateRoutes: RouteDef[] = [
  { path: CONV_PATHS.meetMenu, title: 'Conversations', shell: 'app', nav, component: ConversationsMeetMenu },
  { path: CONV_PATHS.info, title: 'Conversations', shell: 'app', nav, component: ConversationsInfo },
  { path: CONV_PATHS.schedule, title: 'Conversations', shell: 'app', nav, component: ConversationsScheduleModal },
  { path: CONV_PATHS.scheduled, title: 'Conversations', shell: 'app', nav, component: ConversationsScheduled },
];
