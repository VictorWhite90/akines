'use client';

import type { ReactNode, SVGProps } from 'react';
import { Link } from '@/lib/nav';
import { Tag } from '@/ui';
import { STATUS_LABEL, type RequestStatus } from './data';
import './people.css';

/* ------------------------------------------------------------------ icons (Figma icon set, stroke 1.25 on 16 px, 1.5 on 24 px) */

type IconProps = { size?: number; strokeWidth?: number } & Omit<SVGProps<SVGSVGElement>, 'width' | 'height'>;

function Svg16({ size = 16, strokeWidth = 1.25, children, ...rest }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" {...rest}>
      {children}
    </svg>
  );
}
function Svg24({ size = 20, strokeWidth = 1.5, children, ...rest }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" {...rest}>
      {children}
    </svg>
  );
}

export const IconArrowRight = (p: IconProps) => (
  <Svg16 {...p}>
    <path d="M3.3 8h9.4M8 3.3 12.7 8 8 12.7" />
  </Svg16>
);
export const IconArrowLeft = (p: IconProps) => (
  <Svg16 {...p}>
    <path d="M12.7 8H3.3M8 3.3 3.3 8 8 12.7" />
  </Svg16>
);
export const IconCheck = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M5 12.5l4.5 4.5L19 7.5" />
  </Svg24>
);
export const IconClose = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Svg24>
);
export const IconChevronDown = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M6 9l6 6 6-6" />
  </Svg24>
);
export const IconChevronUp = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M6 15l6-6 6 6" />
  </Svg24>
);
export const IconEye = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z" />
    <circle cx="12" cy="12" r="3" />
  </Svg24>
);
export const IconShare = (p: IconProps) => (
  <Svg24 {...p}>
    <circle cx="6" cy="12" r="2.5" />
    <circle cx="18" cy="6" r="2.5" />
    <circle cx="18" cy="18" r="2.5" />
    <path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6" />
  </Svg24>
);
export const IconLock = (p: IconProps) => (
  <Svg24 {...p}>
    <rect x="5" y="11" width="14" height="9" rx="1.5" />
    <path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </Svg24>
);
export const IconBookmark = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M7 4h10v16l-5-3.6L7 20V4Z" />
  </Svg24>
);
export const IconArrowUp = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M12 19V5M6 11l6-6 6 6" />
  </Svg24>
);
export const IconSparkle = (p: IconProps) => (
  <Svg24 {...p}>
    <path d="M9.94 15.5A2 2 0 0 0 8.5 14.06l-6.14-1.58a.5.5 0 0 1 0-.96L8.5 9.94A2 2 0 0 0 9.94 8.5l1.58-6.14a.5.5 0 0 1 .96 0L14.06 8.5a2 2 0 0 0 1.44 1.44l6.14 1.58a.5.5 0 0 1 0 .96l-6.14 1.58a2 2 0 0 0-1.44 1.44l-1.58 6.14a.5.5 0 0 1-.96 0z" />
  </Svg24>
);

/* ------------------------------------------------------------------ small pieces */

/** Back link: arrow and label, the label underlines on hover (Figma Back Link). */
export function BackLink({ href, onClick, children }: { href?: string; onClick?: () => void; children: ReactNode }) {
  const inner = (
    <>
      <IconArrowLeft />
      <span className="cc-back__label">{children}</span>
    </>
  );
  if (href) {
    return (
      <Link className="cc-back" href={href}>
        {inner}
      </Link>
    );
  }
  return (
    <button type="button" className="cc-back" onClick={onClick}>
      {inner}
    </button>
  );
}

/** Eyebrow, headline and support line, revealed on scroll. */
export function Heading({ eyebrow, title, support, level = 1, className }: { eyebrow: string; title: ReactNode; support?: ReactNode; level?: 1 | 2; className?: string }) {
  const H = level === 1 ? 'h1' : 'h2';
  return (
    <div className={`cc-heading${className ? ` ${className}` : ''}`}>
      <p className="cc-eyebrow" data-m="up">
        {eyebrow}
      </p>
      <H className="cc-h" data-m="words">
        {title}
      </H>
      {support ? (
        <p className="cc-support" data-m="up">
          {support}
        </p>
      ) : null}
    </div>
  );
}

/** Empty state card: amber rule, serif headline, support line, optional action (Figma Empty state, padding 56, gap 20). */
export function EmptyCard({ title, text, action, textWidth = 560 }: { title: string; text: string; action?: ReactNode; textWidth?: number }) {
  return (
    <section className="cc-empty" data-m="up">
      <span className="cc-empty__rule" aria-hidden="true" />
      <h2 className="cc-empty__title">{title}</h2>
      <p className="cc-empty__text" style={{ maxWidth: textWidth }}>
        {text}
      </p>
      {action}
    </section>
  );
}

/** Status pill: dot and label on a soft tint (Figma Status Pill). Pending is the warning tint, Accepted the success tint, Not now the muted one. */
export function StatusPill({ status }: { status: RequestStatus }) {
  return (
    <Tag tone={status === 'accepted' ? 'success' : 'warning'} className={`cc-status cc-status--${status}`}>
      {STATUS_LABEL[status]}
    </Tag>
  );
}
