/**
 * Public URL of a file in /public. Always wrap image paths with this: in the Next.js app it returns the path unchanged,
 * in the preview artifact (src/lib/assets.preview.ts replaces this module) it becomes a path relative to the page.
 * Never reference images from CSS url(); render them from TSX so this helper is used.
 */
export const asset = (path: string): string => path;
