import { PATHS } from '../workspace/data';
import { ART_PATH, type ProjectKey } from '../workspace/project';

/**
 * Sample data and copy of the Reflection journey (12.23). All text is taken from the Figma frames.
 * Privacy rule of the design: a person's own answers exist only on the check-in screen (see store.ts). Nothing here
 * describes another person's answers: the team summary is made of combined themes only.
 */

/** The routes of the journey under a project's Reflection page (the project navigation goes to `open`). */
const journeyPaths = (base: string) => ({
  open: base,
  notAvailable: `${base}/state-not-available`,
  checkIn: `${base}/check-in`,
  submitted: `${base}/submitted`,
  summary: `${base}/team-summary`,
  /** Frame "Modal:Submit check-in": the check-in with the modal open. */
  submitModal: `${base}/state-submit-check-in`,
  /** Frame "Toast:Check-in saved": the check-in with the toast showing. */
  savedToast: `${base}/state-check-in-saved`,
  /** Frame "Toast:Check-in submitted": the submitted page with the toast showing. */
  submittedToast: `${base}/state-check-in-submitted`,
});

/** Routes of the journey of Career Guidance for Everyone. `PATHS.reflection` is the open page (the project navigation goes there). */
export const RP = journeyPaths(PATHS.reflection);
/** The same journey under Adire Stories (only open, check-in, submitted and summary are registered there). */
export const ART_RP = journeyPaths(`${ART_PATH}/reflection`);

/* ---------------------------------------------------------------- header facts */

export const OPEN_HEAD = {
  label: 'REFLECTION',
  title: 'How are we working together?',
  lead: 'A meaningful project is about the work and the people creating it.',
};

export const OPEN_FACTS = [
  { label: 'CHECK-IN', value: 'Open' },
  { label: 'QUESTIONS', value: 'Six, all optional' },
  { label: 'YOUR ANSWERS', value: 'Private' },
];

export const NOT_AVAILABLE_FACTS = [
  { label: 'NEXT CHECK-IN', value: 'After Prototype Review' },
  { label: 'YOUR ANSWERS', value: 'Private by default' },
];

export const NOT_AVAILABLE = {
  title: 'Take a moment to reflect.',
  text: 'Reflection becomes available after meaningful project milestones.',
  action: 'See the next milestone',
};

/* ---------------------------------------------------------------- open page */

export const INTRO = {
  title: 'Your check-in is private.',
  copy: 'The Prototype Review is done. Take a few minutes to answer six short questions about how the team is working together. You can skip any question.',
  note: 'Only you can see your answers. The team sees combined themes, never who said what.',
  action: 'Start check-in',
};

export const LAST_SUMMARY = {
  label: 'LAST TEAM SUMMARY',
  teaser: 'The team is strongly aligned on purpose. Workload needs further discussion.',
  link: 'View team summary',
};

/* ---------------------------------------------------------------- check-in */

export const CHECK_IN_HEAD = {
  back: 'Back to reflection',
  label: 'PRIVATE CHECK-IN',
  title: 'Six short questions.',
  lead: 'Only you can see your answers. Skip any question you prefer not to answer.',
};

/** The four answers of the Rating Option scale, in the order of the design. */
export const SCALE = ['Not yet', 'Sometimes', 'Mostly', 'Yes'] as const;
export type Choice = number | null;

export type Question = { question: string; hint: string };

export const QUESTIONS: Question[] = [
  { question: 'Did you feel heard?', hint: 'Think about the last few weeks of work.' },
  { question: 'Was your workload fair?', hint: 'Compared with what you agreed to take on.' },
  { question: 'Were decisions transparent?', hint: 'Could you see how and why choices were made?' },
  { question: 'Do you understand your role?', hint: 'You know what you own and where you support others.' },
  { question: 'Is there tension that needs discussion?', hint: 'Yes means there is something worth talking through.' },
  { question: 'Would you work with this team again?', hint: 'Thinking about everything so far.' },
];

/** The check-in frame opens with the first four questions answered (Mostly, Sometimes, Yes, Mostly) and the last two open. */
export const INITIAL_ANSWERS: Choice[] = [2, 1, 3, 2, null, null];

export const IMPROVE = {
  title: 'Anything you would like to improve (optional)',
  placeholder: 'Share a thought, only if you want to.',
  help: 'Optional. This stays private too.',
};

export const CHECK_IN_ACTIONS = { submit: 'Submit privately', save: 'Save for later' };

export const SAVED_TOAST = 'Check-in saved. Pick it up any time.';
export const SUBMITTED_TOAST = 'Check-in submitted. Your answers stay private.';

export const SUBMIT_MODAL = {
  eyebrow: 'SUBMIT CHECK-IN',
  title: 'Submit your check-in privately?',
  description: 'Only you can see your individual answers.',
  facts: [
    { label: 'WHO CAN SEE YOUR ANSWERS', value: 'Only you' },
    { label: 'WHAT THE TEAM SEES', value: 'Combined themes only' },
  ],
  submit: 'Submit privately',
  cancel: 'Cancel',
};

/* ---------------------------------------------------------------- submitted */

export const SUBMITTED = {
  back: 'Back to reflection',
  label: 'CHECK-IN SUBMITTED',
  title: 'Thank you.',
  lead: 'Your answers stay private.',
  headline: 'Only you can see what you wrote.',
  copy: 'The team will see combined themes only, such as shared purpose or workload balance. Never who said what.',
  link: 'View team summary',
};

/* ---------------------------------------------------------------- team summary */

export const SUMMARY_HEAD = {
  back: 'Back to reflection',
  label: 'TEAM SUMMARY',
  title: 'Team summary.',
  lead: 'Combined themes from the team’s check-ins. Individual answers are never shown.',
};

export type Level = 'Strong' | 'Steady' | 'Needs attention';
export type Theme = { name: string; meaning: string; level: Level };

export const THEME_HEADS = { theme: 'THEME', level: 'HOW IT FEELS' };

export const THEMES: Theme[] = [
  { name: 'Shared purpose', meaning: 'The team is aligned on why this work matters.', level: 'Strong' },
  { name: 'Role clarity', meaning: 'People know what they own and where they support others.', level: 'Strong' },
  { name: 'Workload balance', meaning: 'Workload needs further discussion.', level: 'Needs attention' },
  { name: 'Decision transparency', meaning: 'Decisions are mostly clear. Reasons could be shared sooner.', level: 'Steady' },
  { name: 'Communication', meaning: 'Updates reach people. Deadlines need clarification.', level: 'Steady' },
  { name: 'Collaboration confidence', meaning: 'The team feels confident about working together again.', level: 'Strong' },
];

export const SUGGESTIONS_HEAD = {
  label: 'SUGGESTED IMPROVEMENTS',
  support: 'Optional ideas. Akines suggests, and the team decides.',
};

export type Suggestion = { title: string; meaning: string; link: string; href: string };

export const SUGGESTIONS: Suggestion[] = [
  { title: 'Review workload together', meaning: 'Look at what each person agreed to take on, and adjust if it helps.', link: 'Discuss with the team', href: PATHS.conversations },
  { title: 'Establish clearer deadlines', meaning: 'Agree dates for the work that follows the Prototype Review.', link: 'Discuss with the team', href: PATHS.conversations },
  { title: 'Revisit an agreement', meaning: 'Check that the team agreement still matches how you work.', link: 'Open agreements', href: PATHS.agreements },
];

export const PRIVACY_NOTE = {
  title: 'Individual answers are never shown.',
  text: 'Themes are combined across the team, and none of them describes one person.',
};

/* ---------------------------------------------------------------- context panels (Context Panel / Reflection) */

/** Context=Open: used by the open page, the not available page, the check-in and the submitted page. */
export const CONTEXT_OPEN = {
  private: { label: 'WHAT STAYS PRIVATE', heading: 'Only you see your answers.', body: 'Your individual answers and anything you write stay private. No one else on the team can open them.' },
  team: { label: 'WHAT THE TEAM SEES', heading: 'Combined themes only.', body: 'For example, shared purpose or workload balance. Never a score for a person, and never who said what.' },
  why: { label: 'WHY WE ASK', body: 'A short check-in after a meaningful milestone helps the team notice what is working and what needs care.', line: 'Akines may suggest ideas. The team decides what to do.' },
};

/** Context=Summary: used by the team summary. */
export const CONTEXT_SUMMARY = {
  read: { label: 'HOW TO READ THIS', heading: 'The team, together.', body: 'A word like Strong or Needs attention describes the team as a whole. It never describes one person.' },
  never: { label: 'NEVER SHOWN', lines: ['Individual answers', 'Anything written privately', 'Who answered what'] },
  next: { label: 'WHAT HAPPENS NEXT', body: 'Suggestions are optional. Akines suggests, and the team decides what to do.' },
};

/* ---------------------------------------------------------------- per project copy */

/**
 * Everything the Reflection pages read, per project. Career Guidance for Everyone is made of the constants above (the Figma
 * frames, word for word). Adire Stories has the same shape, the same counts and the same order, with the Digital Art copy:
 * plates, patterns, colour and dyers instead of the onboarding prototype. The text that is the same on both projects is shared.
 */
export type ReflectionCopy = {
  openHead: typeof OPEN_HEAD;
  openFacts: typeof OPEN_FACTS;
  intro: typeof INTRO;
  lastSummary: typeof LAST_SUMMARY;
  checkInHead: typeof CHECK_IN_HEAD;
  questions: Question[];
  initialAnswers: Choice[];
  improve: typeof IMPROVE;
  checkInActions: typeof CHECK_IN_ACTIONS;
  savedToast: string;
  submittedToast: string;
  submitModal: typeof SUBMIT_MODAL;
  submitted: typeof SUBMITTED;
  summaryHead: typeof SUMMARY_HEAD;
  themeHeads: typeof THEME_HEADS;
  themes: Theme[];
  suggestionsHead: typeof SUGGESTIONS_HEAD;
  suggestions: Suggestion[];
  privacyNote: typeof PRIVACY_NOTE;
  contextOpen: typeof CONTEXT_OPEN;
  contextSummary: typeof CONTEXT_SUMMARY;
};

export const CAREER_REFLECTION: ReflectionCopy = {
  openHead: OPEN_HEAD,
  openFacts: OPEN_FACTS,
  intro: INTRO,
  lastSummary: LAST_SUMMARY,
  checkInHead: CHECK_IN_HEAD,
  questions: QUESTIONS,
  initialAnswers: INITIAL_ANSWERS,
  improve: IMPROVE,
  checkInActions: CHECK_IN_ACTIONS,
  savedToast: SAVED_TOAST,
  submittedToast: SUBMITTED_TOAST,
  submitModal: SUBMIT_MODAL,
  submitted: SUBMITTED,
  summaryHead: SUMMARY_HEAD,
  themeHeads: THEME_HEADS,
  themes: THEMES,
  suggestionsHead: SUGGESTIONS_HEAD,
  suggestions: SUGGESTIONS,
  privacyNote: PRIVACY_NOTE,
  contextOpen: CONTEXT_OPEN,
  contextSummary: CONTEXT_SUMMARY,
};

/** The Adire Stories questions: the same six, with two hints that speak of the plates and the colour choices. */
const ART_QUESTIONS: Question[] = [
  { question: 'Did you feel heard?', hint: 'Think about the last few weeks on the plates.' },
  QUESTIONS[1],
  { question: 'Were decisions transparent?', hint: 'Could you see how and why colour choices were made?' },
  QUESTIONS[3],
  QUESTIONS[4],
  QUESTIONS[5],
];

const ART_THEMES: Theme[] = [
  { name: 'Shared purpose', meaning: 'The team is aligned on why this series matters.', level: 'Strong' },
  { name: 'Role clarity', meaning: 'People know which plates they own and where they support others.', level: 'Strong' },
  THEMES[2],
  { name: 'Decision transparency', meaning: 'Decisions are mostly clear. The palette reasons could be shared sooner.', level: 'Steady' },
  { name: 'Communication', meaning: 'Updates reach people. Plate deadlines need clarification.', level: 'Steady' },
  THEMES[5],
];

const ART_SUGGESTIONS: Suggestion[] = [
  { ...SUGGESTIONS[0], href: `${ART_PATH}/conversations` },
  { title: 'Establish clearer deadlines', meaning: 'Agree dates for the plates that follow the first three.', link: 'Discuss with the team', href: `${ART_PATH}/conversations` },
  { ...SUGGESTIONS[2], href: `${ART_PATH}/agreements` },
];

export const ART_REFLECTION: ReflectionCopy = {
  ...CAREER_REFLECTION,
  openHead: { ...OPEN_HEAD, lead: 'A shared series is about the plates and the people making them.' },
  intro: {
    ...INTRO,
    copy: 'The first three plates are sketched. Take a few minutes to answer six short questions about how the team is working together. You can skip any question.',
  },
  lastSummary: { ...LAST_SUMMARY, teaser: 'The team is strongly aligned on the series. Workload needs further discussion.' },
  questions: ART_QUESTIONS,
  initialAnswers: [...INITIAL_ANSWERS],
  themes: ART_THEMES,
  suggestions: ART_SUGGESTIONS,
};

export const REFLECTION: Record<ProjectKey, ReflectionCopy> = { career: CAREER_REFLECTION, adire: ART_REFLECTION };
export const REFLECTION_PATHS: Record<ProjectKey, typeof RP> = { career: RP, adire: ART_RP };
