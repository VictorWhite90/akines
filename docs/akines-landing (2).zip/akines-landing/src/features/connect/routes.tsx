import type { RouteDef } from '@/routes.types';
import { placeholderRoutes } from '@/features/placeholder-routes';
import { routes as discover } from './discover/routes';
import { routes as destinations } from './discover/destinations';

/**
 * Section 11 CONNECT. Discover is designed: /connect and its state and filter routes (discover/routes.tsx), and the pages it leads to, at the
 * Figma tab URLs: Explore all, For you, All interests, Interest, Events, Event, All suggestions and the nine People profiles (discover/destinations.tsx).
 * KinCircle (11.11 to 11.65) is design only and not built: every link to it stays a plain control. KinCircle, Rooms, Banter and Activities are
 * placeholder pages. The tab order in the nav stays Discover, KinCircle, Rooms, Banter, Activities.
 */
export const routes: RouteDef[] = [...discover, ...destinations, ...placeholderRoutes('connect', ['/connect'])];
