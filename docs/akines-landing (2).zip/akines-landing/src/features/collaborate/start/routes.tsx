import type { RouteDef } from '@/routes.types';
import { Home, HomeEmpty, HomeLoadingState } from './Home';
import { StartFlow, BriefErrorState, DraftRemovedState, WorkspaceArtState, WorkspaceResearchState } from './StartFlow';
import { PATHS } from './flow-data';

/**
 * Collaborate Home (12.1) and Start a project (12.2).
 * /collaborate                         Home, frame 17182:10780
 * /collaborate/state-empty             Home Empty, frame 17111:9037 (the page of someone with no projects, zero tiles that open the Empty lists)
 * /collaborate/state-loading           Home Loading, frame 17974:166533 (Home also shows it on the first visit of a session)
 * /collaborate/start                   Start a project: entry, idea, purpose Q1 to Q4, progress, people, preparing, review, ready (steps are state)
 * /collaborate/start/state-brief-error A6 Brief error, frame 17214:14484
 * /collaborate/start/state-draft-removed Review brief / Draft removed, frame 17974:155087, with Toast:Draft removed (Undo of Toast:Draft saved leads here)
 * /collaborate/start/workspace-research 12.17 Workspace recommendation (Research), frame 17611:149; Accept Workspace shows 17611:648
 * /collaborate/start/workspace-art      12.18 Workspace recommendation (Digital art), frame 17611:973; Accept Workspace shows 17611:1342
 * (the People step leads to the recommendation the answers point to, Research or Digital art, then Preparing. The 12.18 route is the Figma
 * starting point of the Digital art journey and uses the Adire Stories answers, so its brief is the Adire Stories brief)
 */
export const routes: RouteDef[] = [
  { path: '/collaborate', title: 'Collaborate', shell: 'app', nav: { page: 'collaborate', tab: 'Home' }, component: Home },
  { path: '/collaborate/state-empty', title: 'Collaborate', shell: 'app', nav: { page: 'collaborate', tab: 'Home' }, component: HomeEmpty },
  { path: '/collaborate/state-loading', title: 'Collaborate', shell: 'app', nav: { page: 'collaborate', tab: 'Home' }, component: HomeLoadingState },
  { path: '/collaborate/start', title: 'Start a project', shell: 'app', nav: { page: 'collaborate', tab: 'My Projects' }, component: StartFlow },
  { path: '/collaborate/start/state-brief-error', title: 'Start a project', shell: 'app', nav: { page: 'collaborate', tab: 'My Projects' }, component: BriefErrorState },
  { path: PATHS.draftRemoved, title: 'Start a project', shell: 'app', nav: { page: 'collaborate', tab: 'My Projects' }, component: DraftRemovedState },
  { path: '/collaborate/start/workspace-research', title: 'Start a project', shell: 'app', nav: { page: 'collaborate', tab: 'My Projects' }, component: WorkspaceResearchState },
  { path: '/collaborate/start/workspace-art', title: 'Start a project', shell: 'app', nav: { page: 'collaborate', tab: 'My Projects' }, component: WorkspaceArtState },
];
