'use client';

/**
 * 03 Explore by interest: four interest cards in a horizontal row (PRD section 03, Figma 17893:108774).
 *
 * Wiring (from the logic layer, unchanged):
 *  - INTERESTS (data.ts) holds the four cards in order (InterestCard.tsx draws one). Each card opens the Interest page and reports
 *    interest_card_click { interest_id, position } (1-based).
 *  - The header link "Explore all" goes to All interests; DxSection reports it through onLinkClick as interest_explore_all_click.
 *  - useCarouselTracking(scroller, 'interests') reports horizontal scrolling (the row scrolls where the column is narrower than 984).
 *    There are no arrow buttons in the design.
 *  - `empty` (the empty state route) keeps the heading and shows STATE_COPY.interestsEmpty with no cards and no next action.
 *
 * The empty message is a local component (Figma Section Empty 17897:20959) so this file does not depend on the page-level
 * state parts in states.tsx.
 */
import { useRef, type FocusEvent, type ReactNode } from 'react';
import { useReducedMotion } from '@/lib/hooks';
import { track, useCarouselTracking } from './analytics';
import { INTERESTS, STATE_COPY } from './data';
import { InterestCard } from './InterestCard';
import { DxSection } from './parts';
import './interests.css';

/** Section Empty: one centred line between two hairlines. No action, by design. */
function SectionEmpty({ children }: { children: ReactNode }) {
  return <p className="dxi-empty">{children}</p>;
}

export function Interests({ empty }: { empty?: boolean }) {
  const scroller = useRef<HTMLUListElement>(null);
  useCarouselTracking(scroller, 'interests');
  const reduced = useReducedMotion();
  // Where the row scrolls (a column narrower than 984), bring a card that gets keyboard focus fully into view: a card that is only
  // partly visible is not scrolled by the browser. Not for mouse focus, so the row does not move under a press.
  const reveal = (e: FocusEvent<HTMLUListElement>) => {
    const t = e.target as HTMLElement;
    if (!t.matches(':focus-visible')) return;
    t.closest('li')?.scrollIntoView({ inline: 'nearest', block: 'nearest', behavior: reduced ? 'auto' : 'smooth' });
  };
  return (
    <DxSection section="interests" onLinkClick={() => track('interest_explore_all_click')}>
      {empty ? (
        <SectionEmpty>{STATE_COPY.interestsEmpty}</SectionEmpty>
      ) : (
        <ul className="dxi-row" ref={scroller} data-m="stagger" onFocus={reveal}>
          {INTERESTS.map((it, i) => (
            <li className="dxi-item" key={it.id}>
              <InterestCard interest={it} index={i} />
            </li>
          ))}
        </ul>
      )}
    </DxSection>
  );
}
