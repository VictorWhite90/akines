import { PATHS } from '../workspace/data';
import type { ProjectKey } from '../workspace/project';

/**
 * Sample data of the Decisions screens (12.20). All copy is taken word for word from the Figma frames:
 * Decisions 17729:108407, Empty 17729:113129, Detail 17729:117836, History 17729:113566, Modal:Propose decision 17729:120858,
 * Toast:Decision proposed 17729:120844, Modal:Acknowledge decision 17729:120932, Toast:Decision acknowledged 17729:120851.
 * The constants are those of "Career Guidance for Everyone". Adire Stories has a set of the same shape at the end of this file
 * (ART_DECISIONS); `decisionsDataFor` picks the set of a project.
 */

/** Every URL of the journey. The "state-" paths are the overlay frames: the parent page with the modal open or the toast showing. */
export const DP = {
  list: PATHS.decisions,
  empty: `${PATHS.decisions}/state-empty`,
  detail: `${PATHS.decisions}/choose-the-onboarding-approach`,
  history: `${PATHS.decisions}/history`,
  propose: `${PATHS.decisions}/state-propose-decision`,
  proposed: `${PATHS.decisions}/state-decision-proposed`,
  acknowledge: `${PATHS.decisions}/state-acknowledge-decision`,
  acknowledged: `${PATHS.decisions}/state-decision-acknowledged`,
} as const;

/* ---------------------------------------------------------------- page header */

export const HEAD = {
  label: 'DECISIONS',
  title: 'Decisions that move the project forward.',
  lead: 'Keep important choices clear, shared and understood.',
};

export type FactItem = { label: string; value: string };
export const FACTS: FactItem[] = [
  { label: 'PENDING', value: '3 decisions' },
  { label: 'AWAITING YOU', value: '1 decision' },
  { label: 'IN HISTORY', value: '3 decisions' },
];
export const FACTS_EMPTY: FactItem[] = [
  { label: 'PENDING', value: '0 decisions' },
  { label: 'AWAITING YOU', value: '0 decisions' },
  { label: 'IN HISTORY', value: '0 decisions' },
];

export const EMPTY = {
  title: 'No decisions need attention yet.',
  text: 'When your team needs to make an important choice, it will appear here.',
};

/* ---------------------------------------------------------------- list rows */

export type DecisionStatus = 'Proposed' | 'Under discussion' | 'Awaiting acknowledgement' | 'Approved' | 'Rejected' | 'Superseded';

export type DecisionItem = {
  id: string;
  title: string;
  status: DecisionStatus;
  proposedBy: string;
  milestone: string;
  /** Only the "First Student Experience" milestone has a page in the design. */
  milestoneHref?: string;
  acknowledged: string;
  date: string;
  /** The row opens this page. Rows without it react to hover and press only. */
  href?: string;
};

export const NEEDS_ATTENTION: DecisionItem[] = [
  {
    id: 'onboarding-approach',
    title: 'Choose the onboarding approach',
    status: 'Awaiting acknowledgement',
    proposedBy: 'Adaeze Okoye',
    milestone: 'First Student Experience',
    milestoneHref: PATHS.milestone,
    acknowledged: '2 of 4 acknowledged',
    date: '2 Nov',
    href: DP.detail,
  },
  {
    id: 'first-student-group',
    title: 'Choose the first student group',
    status: 'Under discussion',
    proposedBy: 'Ngozi Eze',
    milestone: 'First Student Experience',
    milestoneHref: PATHS.milestone,
    acknowledged: '0 of 4 acknowledged',
    date: '3 Nov',
  },
  {
    id: 'review-schedule',
    title: 'Agree the review schedule',
    status: 'Proposed',
    proposedBy: 'Tobi Adeyemi',
    milestone: 'Prototype Review',
    acknowledged: '0 of 4 acknowledged',
    date: '4 Nov',
  },
];

export const HISTORY: DecisionItem[] = [
  {
    id: 'one-questionnaire',
    title: 'Use one questionnaire for every school',
    status: 'Superseded',
    proposedBy: 'Ngozi Eze',
    milestone: 'First Student Experience',
    milestoneHref: PATHS.milestone,
    acknowledged: '3 of 4 acknowledged',
    date: 'Outcome 2 Nov',
  },
  {
    id: 'mobile-first',
    title: 'Build the onboarding as a mobile app first',
    status: 'Rejected',
    proposedBy: 'Tobi Adeyemi',
    milestone: 'First Student Experience',
    milestoneHref: PATHS.milestone,
    acknowledged: '4 of 4 acknowledged',
    date: 'Outcome 30 Oct',
  },
  {
    id: 'interviews-first',
    title: 'Run interviews before building screens',
    status: 'Approved',
    proposedBy: 'Kemi Adeyemi',
    milestone: 'First Student Experience',
    milestoneHref: PATHS.milestone,
    acknowledged: '4 of 4 acknowledged',
    date: 'Outcome 28 Oct',
  },
];

export const GROUP_PENDING = 'NEEDS ATTENTION (3)';
export const GROUP_HISTORY = 'HISTORY (3)';

/* ---------------------------------------------------------------- context panel */

export const NEEDS_ATTENTION_PANEL = {
  label: 'NEEDS ATTENTION',
  title: 'Choose the onboarding approach',
  status: 'Awaiting your acknowledgement',
  proposedBy: 'Proposed by Adaeze Okoye',
  link: 'Review decision',
};

export const ACKNOWLEDGERS = [
  { name: 'Adaeze Okoye', status: 'Acknowledged 2 Nov' },
  { name: 'Tobi Adeyemi', status: 'Acknowledged 3 Nov' },
  { name: 'Ngozi Eze', status: 'Not yet acknowledged' },
  { name: 'Kemi Adeyemi', status: 'Waiting for you' },
];
export const ACKNOWLEDGE_NOTE = 'Everyone involved acknowledges a significant decision.';

export const MILESTONE = {
  label: 'RELATED MILESTONE',
  title: 'First Student Experience',
  note: 'Define the first student experience.',
  link: 'View milestone',
};

export const DISCUSSION_PANEL = {
  label: 'DISCUSSION',
  title: 'Choose the onboarding approach',
  count: '3 messages from Tobi, Ngozi and Adaeze.',
  last: 'Last message yesterday, 17:40.',
  link: 'Open discussion',
};

export const HOW = {
  label: 'HOW DECISIONS WORK',
  title: 'Propose, discuss, acknowledge',
  acknowledgement: ACKNOWLEDGE_NOTE,
  ai: 'Create AI can compare options. Your team decides.',
};

/* ---------------------------------------------------------------- Detail */

export const DETAIL = {
  back: 'Back to decisions',
  label: 'DECISION',
  title: 'Choose the onboarding approach',
  lead: 'Decide how students first meet Career Guidance, so the first screens can be finished.',
  acknowledge: 'Acknowledge decision',
  discuss: 'Open discussion',
  proposedBy: 'Adaeze Okoye',
  proposed: 'Monday 2 November',
  decideBy: 'Friday 6 November',
  status: 'Awaiting acknowledgement' as DecisionStatus,
  acknowledged: '2 of 4 people',
  milestone: 'First Student Experience',
  context: 'Students meet Career Guidance on the first screen. The interviews so far show that many want a clear first step, and some are unsure where to begin.',
  problem: 'The second onboarding screen cannot be finished until the team agrees whether students are guided through questions or left to explore on their own.',
  aiNote: 'Create AI can compare options for you. Your team decides.',
  direction:
    'Start with guided questions. Students answer three short questions and see a first step built from their answers. The team reviews how it feels at the prototype session and can revisit the choice.',
  discussion:
    'Tobi Adeyemi worries the open option may feel overwhelming on a first visit. Ngozi Eze agrees, based on the student interviews. Adaeze Okoye prefers the guided option and asked for a decision before Friday.',
  discussionLink: 'Open discussion',
  outcome: 'Not decided yet. The outcome and its date will be recorded here once everyone involved has acknowledged. Still needed: Ngozi Eze and Kemi Adeyemi.',
};

export type DecisionOption = {
  id: string;
  stage: string;
  type: string;
  title: string;
  purpose: string;
  goodFor: string;
  watchFor: string;
};

export const OPTIONS: DecisionOption[] = [
  {
    id: 'guided',
    stage: 'OPTION A',
    type: 'PROPOSED',
    title: 'Guided questions',
    purpose: 'Students answer a few simple questions and are guided to a first step.',
    goodFor: 'A clear first step for every student.',
    watchFor: 'Less room to explore on a first visit.',
  },
  {
    id: 'open',
    stage: 'OPTION B',
    type: 'ALTERNATIVE',
    title: 'Open workspace',
    purpose: 'Students start in a shared workspace and choose what to explore first.',
    goodFor: 'Freedom to explore at their own pace.',
    watchFor: 'May feel overwhelming on a first visit.',
  },
];
/** The design shows option A selected and option B not selected; each card toggles on its own. */
export const OPTIONS_SELECTED_AT_FIRST = ['guided'];

export const FILES = [
  { name: 'Student onboarding draft.pdf', meta: 'PDF, 2.4 MB, shared by Tobi Adeyemi' },
  { name: 'Career interview notes.docx', meta: 'Word, 180 KB, shared by Ngozi Eze' },
];

/* ---------------------------------------------------------------- overlays */

export const PROPOSE = {
  eyebrow: 'NEW DECISION',
  title: 'What needs to be decided?',
  description: 'Describe the choice so your team can discuss it.',
  fields: {
    title: { label: 'Decision title', placeholder: 'For example, Choose the first student group', hint: 'A short, clear choice.' },
    problem: { label: 'Problem', placeholder: 'What is not clear or not agreed yet?', hint: 'Say why it needs deciding now.' },
    options: { label: 'Options', placeholder: 'List the choices, one per line', hint: 'Add at least two options.' },
    milestone: { label: 'Related milestone', value: 'First Student Experience', hint: 'The milestone this decision belongs to.' },
  },
  submit: 'Propose decision',
  cancel: 'Cancel',
  toast: 'Decision proposed. Your team can discuss it now.',
};

export const ACKNOWLEDGE = {
  eyebrow: 'ACKNOWLEDGE DECISION',
  title: 'Acknowledge this decision?',
  description: 'You are saying you have read it and will work with the outcome.',
  summary: [
    { label: 'DECISION', text: 'Choose the onboarding approach', small: false },
    { label: 'PROPOSED DIRECTION', text: 'Guided questions', small: false },
    { label: 'WHAT ACKNOWLEDGING MEANS', text: 'You have read the decision and will work with the outcome. You can still add to the discussion.', small: true },
  ],
  submit: 'Acknowledge',
  cancel: 'Cancel',
  toast: 'Decision acknowledged. 3 of 4 have acknowledged.',
};

/* ---------------------------------------------------------------- per project data */

/** The two views of the list under the root of a project (Career: PROJECT_PATH, Adire Stories: ART_PATH). The suffixes are the same in both. */
export const decisionPaths = (root: string) => ({ list: `${root}/decisions`, history: `${root}/decisions/history` });

/**
 * What the mirrored Decisions pages (the list, History) and their modals show that belongs to a project: the rows, the context panel
 * and the copy that names the people, the milestone and the decisions. Career Guidance for Everyone is the set above; Adire Stories has
 * its own set of the same shape (same counts, same order, same ids). Only the first Career row and the milestone link have a
 * destination (`href`, `milestoneHref`); none of Adire Stories has one, because the decision detail and the milestone pages are not
 * part of its pages.
 */
export type DecisionsData = {
  needsAttention: DecisionItem[];
  history: DecisionItem[];
  panel: typeof NEEDS_ATTENTION_PANEL;
  acknowledgers: typeof ACKNOWLEDGERS;
  milestone: typeof MILESTONE;
  propose: typeof PROPOSE;
  acknowledge: typeof ACKNOWLEDGE;
};

export const CAREER_DECISIONS: DecisionsData = {
  needsAttention: NEEDS_ATTENTION,
  history: HISTORY,
  panel: NEEDS_ATTENTION_PANEL,
  acknowledgers: ACKNOWLEDGERS,
  milestone: MILESTONE,
  propose: PROPOSE,
  acknowledge: ACKNOWLEDGE,
};

/* ---- Adire Stories (the Digital Art project). Today is 5 November, so dates are one day later than the Career ones. */

const ART_MS = 'Headwrap Portrait';

export const ART_NEEDS_ATTENTION: DecisionItem[] = [
  { id: 'onboarding-approach', title: 'Choose the headwrap palette', status: 'Awaiting acknowledgement', proposedBy: 'Amara Obi', milestone: ART_MS, acknowledged: '2 of 4 acknowledged', date: '3 Nov' },
  { id: 'first-student-group', title: 'Choose the pattern for the next plate', status: 'Under discussion', proposedBy: 'Yusuf Danjuma', milestone: ART_MS, acknowledged: '0 of 4 acknowledged', date: '4 Nov' },
  { id: 'review-schedule', title: 'Agree the print proof schedule', status: 'Proposed', proposedBy: 'Ayo Bello', milestone: 'Pattern Study Set', acknowledged: '0 of 4 acknowledged', date: '5 Nov' },
];

export const ART_HISTORY: DecisionItem[] = [
  { id: 'one-questionnaire', title: 'Use one dye palette for every plate', status: 'Superseded', proposedBy: 'Yusuf Danjuma', milestone: ART_MS, acknowledged: '3 of 4 acknowledged', date: 'Outcome 3 Nov' },
  { id: 'mobile-first', title: 'Match colours from phone photos alone', status: 'Rejected', proposedBy: 'Ayo Bello', milestone: ART_MS, acknowledged: '4 of 4 acknowledged', date: 'Outcome 31 Oct' },
  { id: 'interviews-first', title: 'Meet the dyers before drawing the plates', status: 'Approved', proposedBy: 'Kemi Adeyemi', milestone: ART_MS, acknowledged: '4 of 4 acknowledged', date: 'Outcome 29 Oct' },
];

export const ART_DECISIONS: DecisionsData = {
  needsAttention: ART_NEEDS_ATTENTION,
  history: ART_HISTORY,
  panel: { ...NEEDS_ATTENTION_PANEL, title: 'Choose the headwrap palette', proposedBy: 'Proposed by Amara Obi' },
  acknowledgers: [
    { name: 'Amara Obi', status: 'Acknowledged 3 Nov' },
    { name: 'Ayo Bello', status: 'Acknowledged 4 Nov' },
    { name: 'Yusuf Danjuma', status: 'Not yet acknowledged' },
    { name: 'Kemi Adeyemi', status: 'Waiting for you' },
  ],
  milestone: { ...MILESTONE, title: ART_MS, note: 'Finish the headwrap portrait.' },
  propose: {
    ...PROPOSE,
    fields: {
      ...PROPOSE.fields,
      title: { ...PROPOSE.fields.title, placeholder: 'For example, Choose the zine cover plate' },
      milestone: { ...PROPOSE.fields.milestone, value: ART_MS },
    },
  },
  acknowledge: {
    ...ACKNOWLEDGE,
    summary: [
      { label: 'DECISION', text: 'Choose the headwrap palette', small: false },
      { label: 'PROPOSED DIRECTION', text: 'Indigo and cream', small: false },
      { label: 'WHAT ACKNOWLEDGING MEANS', text: 'You have read the decision and will work with the outcome. You can still add to the discussion.', small: true },
    ],
  },
};

/** The data of a project's Decisions pages. */
export const decisionsDataFor = (key: ProjectKey): DecisionsData => (key === 'adire' ? ART_DECISIONS : CAREER_DECISIONS);
