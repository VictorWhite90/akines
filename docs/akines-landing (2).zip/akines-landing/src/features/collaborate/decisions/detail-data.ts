import { DETAIL } from './data';

/**
 * Copy of Decisions / Detail (Figma 12.20, frame 17729:117836), word for word. The detail is a Career Guidance for Everyone page only
 * (Adire Stories mirrors the two list views, not this page). The shorter lines of the dashboard version replace the longer paragraphs of
 * data.ts (DETAIL), which stays in place for the list, the modals and the context panels. The two options and the two files are those
 * of data.ts (OPTIONS, FILES): the same words.
 */

export const DD = {
  back: DETAIL.back,
  label: DETAIL.label,
  title: DETAIL.title,
  lead: 'How students first meet Career Guidance, so the first screens can be finished.',
  acknowledge: DETAIL.acknowledge,
  discuss: DETAIL.discuss,

  metrics: {
    acknowledged: { label: 'ACKNOWLEDGED', value: '2/4', caption: 'of 4 people' },
    decideBy: { label: 'DECIDE BY', value: 'Fri', caption: '6 November' },
    options: { label: 'OPTIONS', value: '2', caption: 'compared' },
    files: { label: 'FILES', value: '2', caption: 'attached' },
  },

  progress: {
    title: 'DECISION PROGRESS',
    steps: [
      { state: 'done' as const, when: 'PROPOSED 2 NOV', title: 'Proposed by Adaeze Okoye' },
      { state: 'doing' as const, when: 'IN PROGRESS', title: 'Acknowledgement, 2 of 4 people' },
      { state: 'next' as const, when: 'DECIDE BY 6 NOV', title: 'Outcome is recorded here' },
    ],
  },

  acknowledgements: {
    title: 'ACKNOWLEDGEMENTS',
    done: 2,
    total: 4,
    count: '2',
    caption: 'of 4 people have acknowledged',
    people: [
      { name: 'Adaeze Okoye', acknowledged: true },
      { name: 'Tobi Adeyemi', acknowledged: true },
      { name: 'Ngozi Eze', acknowledged: false },
      { name: 'Kemi Adeyemi', acknowledged: false },
    ],
  },

  details: {
    title: 'DETAILS',
    rows: [
      { label: 'Proposed by', value: DETAIL.proposedBy },
      { label: 'Proposed', value: DETAIL.proposed },
      { label: 'Decide by', value: DETAIL.decideBy },
    ],
    milestone: { label: 'Milestone', value: DETAIL.milestone },
  },

  /** The note under the options. */
  optionsNote: DETAIL.aiNote,

  columns: [
    { label: 'CONTEXT', text: 'Students meet Career Guidance on the first screen. Many want a clear first step, and some are unsure where to begin.' },
    { label: 'PROBLEM', text: 'The second onboarding screen cannot be finished until the team agrees how students start.' },
    {
      label: 'PROPOSED DIRECTION',
      text: 'Start with guided questions: three short questions, then a first step built from the answers. Review it at the prototype session.',
    },
  ],

  files: { title: 'SUPPORTING INFORMATION' },

  discussion: {
    title: 'DISCUSSION',
    comments: [
      { initials: 'TA', name: 'Tobi Adeyemi', text: 'Worries the open option may feel overwhelming on a first visit.' },
      { initials: 'NE', name: 'Ngozi Eze', text: 'Agrees, based on the student interviews.' },
      { initials: 'AO', name: 'Adaeze Okoye', text: 'Prefers the guided option and asked for a decision before Friday.' },
    ],
    link: DETAIL.discussionLink,
  },

  outcome: {
    title: 'DECISION OUTCOME',
    status: DETAIL.status,
    text: 'Not decided yet. Still needed: Ngozi Eze and Kemi Adeyemi.',
  },
};

/** Ids of the cards the metric cards scroll to (the design scrolls to these frames). */
export const DD_IDS = { acknowledgements: 'dd-ack', options: 'dd-options', files: 'dd-files' } as const;
