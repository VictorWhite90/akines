/**
 * Where every link of the Community Home feed goes (the link targets of the final Figma design).
 * All paths are registered screens (src/routes.ts). Some are still placeholder pages (Connect, Explore, Care);
 * swap a value here when a tab gets its own screen. Substitutions against FEED_SPEC.md are marked SUBSTITUTED.
 */
export const DEST = {
  /** Connect (placeholder, tab "Discover"): the Live room, Game and Activity hero cards, Your circles, rooms, activities, KinCircle */
  connect: '/connect',
  /** Explore (placeholder, tab "Shop Art"): Explore, Shop, Studios, Stories */
  explore: '/explore',
  /** Banter (designed, Figma 10.6): the Banter hero cards, the Banter section and its cards */
  banter: '/community/banter',
  /** Collaborate, Discover projects (designed): "Discover projects" and the two project cards without a project page */
  discover: '/collaborate/discover',
  /** Explore collaborators, Why this match (designed) */
  whyMatch: '/collaborate/collaborators/why-this-match',
  /** SUBSTITUTED: the spec names /collaborate/projects/lagos-makers-zine, which is not registered. The designed zine screen is the community collaboration. */
  zine: '/community/collaborations/lagos-makers-zine',
  /** Care and support, Reflect privately (designed, Figma 10.7) */
  reflect: '/community/care/reflect',
  /** Care (placeholder): Creative DNA, "See your full DNA", "See who shares it" */
  care: '/care',
  /** Settings, Recommendation explanations (designed): the link of the empty match card */
  recommendations: '/community/settings/recommendations',
} as const;
