'use client';

/**
 * Shared pieces of the two team Workspaces (12.15 Research, 12.16 Digital Art): the top bar with project menu, breadcrumb,
 * type chip, title, status pill, presence and actions; the live banners; the People and access panel; the project menu;
 * the version history panel; and the popover and sign-in gate they sit in. Every class is prefixed tw- and lives in shared.css.
 */
import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  ChevronRight,
  CircleAlert,
  CircleCheck,
  CloudOff,
  Eye,
  FileText,
  History,
  MessageSquare,
  Palette,
  PanelLeft,
  RefreshCw,
  type LucideIcon,
} from 'lucide-react';
import { rememberNext } from '@/lib/next-path';
import { Link, useNav, usePath } from '@/lib/nav';
import { useSession } from '@/lib/auth';
import { asset } from '@/lib/assets';
import { Button, IconButton } from '@/ui';
import { useProject } from '../workspace/project';
import {
  BANNER_COPY,
  BANNER_OF,
  MENU_ITEMS,
  PEOPLE,
  SAVE_COPY,
  SAVE_KIND_OF,
  STATUS_OF,
  TW_PATHS,
  type AvatarState,
  type BannerKind,
  type PeopleRow,
  type PersonId,
  type Role,
  type SaveKind,
  type StatusTone,
  type VersionRow,
  type WsState,
} from './data';
import './shared.css';

export const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(' ');

/** Figma icons of the Workspaces: 1.5 px strokes at every size (absolute, so the weight does not scale). */
export function Ic({ icon: Cmp, size = 16, className }: { icon: LucideIcon; size?: number; className?: string }) {
  return <Cmp size={size} strokeWidth={1.5} absoluteStrokeWidth className={className} aria-hidden="true" focusable="false" />;
}

/* ------------------------------------------------------------------ sign-in gate */

/** Workspace screens have no app header, so they carry the same sign-in redirect the app shell has. */
export function WorkspaceGate({ children }: { children: ReactNode }) {
  const session = useSession();
  const nav = useNav();
  const path = usePath();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (mounted && !session.signedIn) {
      rememberNext(path);
      nav.replace('/sign-in');
    }
  }, [mounted, session.signedIn, path, nav]);
  if (!mounted || !session.signedIn) return null;
  return <>{children}</>;
}

/* ------------------------------------------------------------------ avatar and presence */

/** Figma "Workspace / Avatar": 36 px box, photo 32 px, a 2 px ring around it, a status dot at the lower right. */
export function Avatar({ id, state }: { id: PersonId; state: AvatarState }) {
  const p = PEOPLE[id];
  return (
    <span className="tw-av" data-state={state} title={p.name}>
      {state !== 'away' ? <span className="tw-av__ring" /> : null}
      <span className="tw-av__photo">
        {p.photo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={asset(p.photo)} alt="" loading="lazy" decoding="async" />
        ) : (
          <span className="tw-av__initials">{p.initials}</span>
        )}
      </span>
      {state !== 'away' ? <span className="tw-av__dot" /> : null}
    </span>
  );
}

export type PresenceItem = { id: PersonId; state: AvatarState };

/** The overlapped avatars of the top bar with the "+1" chip. A button: it opens People and access. */
export function Presence({ items, more, onClick, expanded }: { items: PresenceItem[]; more?: string; onClick: () => void; expanded: boolean }) {
  const here = items.filter((i) => i.state !== 'offline' && i.state !== 'away').length;
  return (
    <button type="button" className="tw-presence" onClick={onClick} aria-haspopup="dialog" aria-expanded={expanded} aria-label={`People in this workspace, ${here} here now`}>
      {items.map((i) => (
        <Avatar key={i.id} id={i.id} state={i.state} />
      ))}
      {more ? <span className="tw-presence__more">{more}</span> : null}
    </button>
  );
}

/* ------------------------------------------------------------------ status pill */

const STATUS_ICON: Record<StatusTone, LucideIcon> = { saved: CircleCheck, saving: RefreshCw, reconnecting: RefreshCw, lost: CloudOff, view: Eye, failed: CircleAlert };

/**
 * Figma "Workspace / Status". With `onToggle` it is the button that opens the save status popover (see SaveStatusPopover); with `href` it is a
 * link; otherwise it only shows the state.
 */
export function StatusPill({ state, href, onToggle, expanded }: { state: WsState; href?: string; onToggle?: () => void; expanded?: boolean }) {
  const { tone, label } = STATUS_OF[state];
  const body = (
    <>
      <Ic icon={STATUS_ICON[tone]} className="tw-status__icon" />
      <span className="tw-status__label">{label}</span>
    </>
  );
  if (onToggle) {
    return (
      <button type="button" className="tw-status" data-tone={tone} aria-haspopup="dialog" aria-expanded={Boolean(expanded)} onClick={onToggle}>
        {body}
      </button>
    );
  }
  return href ? (
    <Link href={href} className="tw-status" data-tone={tone} aria-live="polite">
      {body}
    </Link>
  ) : (
    <span className="tw-status" data-tone={tone} role="status">
      {body}
    </span>
  );
}

/* ------------------------------------------------------------------ top bar */

/** Where the controls of the save status popover lead (Save now, Version history, Try again). */
export type SaveLinks = { saveNow?: string; history?: string; retry?: string };

export type TopBarLinks = {
  /** Status pill (a link; the screens that have the save status popover use `saveMenu` instead). */
  status?: string;
  /** Version history icon. */
  history?: string;
  /** Comments icon. Without it the icon is shown and does nothing (the comments panel is already open). */
  comments?: string;
};

type TopBarProps = {
  kind: 'research' | 'art';
  state: WsState;
  title: string;
  project: string;
  avatars: PresenceItem[];
  more?: string;
  links: TopBarLinks;
  menuOpen: boolean;
  peopleOpen: boolean;
  onMenu: () => void;
  onPeople: () => void;
  /** The save status popover: which one the pill opens, whether it is open, and where its controls lead. Without it the pill has no popover. */
  save?: { kind: SaveKind; open: boolean; onToggle: () => void; onClose: () => void; links: SaveLinks };
};

/** Figma "Workspace top bar": 64 px, project menu, breadcrumb, type chip, title and status, presence and actions. */
export function TopBar({ kind, state, title, project, avatars, more, links, menuOpen, peopleOpen, onMenu, onPeople, save }: TopBarProps) {
  return (
    <header className="tw-top">
      <IconButton label="Project menu" size="sm" variant="ghost" onClick={onMenu} aria-haspopup="menu" aria-expanded={menuOpen} className="tw-top__menu">
        <Ic icon={PanelLeft} />
      </IconButton>
      <nav className="tw-crumb" aria-label="Breadcrumb">
        <span className="tw-crumb__project">{project}</span>
        <Ic icon={ChevronRight} className="tw-crumb__sep" />
        <span className="tw-crumb__here" aria-current="page">
          Workspace
        </span>
      </nav>
      <span className="tw-chip">
        <Ic icon={kind === 'research' ? FileText : Palette} />
        <span>{kind === 'research' ? 'Research Workspace' : 'Digital Art Workspace'}</span>
      </span>
      <div className="tw-title">
        <h1 className="tw-title__text">{title}</h1>
        {save ? (
          <span className="tw-statuswrap">
            <StatusPill state={state} onToggle={save.onToggle} expanded={save.open} />
            {save.open ? <SaveStatusPopover kind={save.kind} links={save.links} onClose={save.onClose} /> : null}
          </span>
        ) : (
          <StatusPill state={state} href={links.status} />
        )}
      </div>
      <div className="tw-actions">
        <Presence items={avatars} more={more} onClick={onPeople} expanded={peopleOpen} />
        <IconButton label="Version history" size="sm" variant="ghost" href={links.history}>
          <Ic icon={History} />
        </IconButton>
        <IconButton label="Comments" size="sm" variant="ghost" href={links.comments} aria-pressed={links.comments ? undefined : true}>
          <Ic icon={MessageSquare} />
        </IconButton>
        <Button variant="primary" size="sm" onClick={onPeople} aria-haspopup="dialog">
          Share
        </Button>
      </div>
    </header>
  );
}

/* ------------------------------------------------------------------ banners */

const BANNER_ICON: Record<BannerKind, LucideIcon> = { collaborator: RefreshCw, reconnecting: RefreshCw, lost: CloudOff, view: Eye, version: History };
const BANNER_TONE: Record<BannerKind, 'warning' | 'error' | 'info'> = { collaborator: 'warning', reconnecting: 'warning', lost: 'error', view: 'info', version: 'info' };

export type BannerHrefs = { retry?: string; back?: string; restore?: string };

/** Figma "Workspace / Banner": reconnecting, connection lost, view only, version preview. Floats at the top of the canvas. */
export function Banner({ kind, hrefs = {}, title, detail, className }: { kind: BannerKind; hrefs?: BannerHrefs; title?: string; detail?: string; className?: string }) {
  const copy = BANNER_COPY[kind];
  return (
    <div className={cx('tw-banner', className)} data-tone={BANNER_TONE[kind]} data-kind={kind} role={kind === 'lost' ? 'alert' : 'status'}>
      <Ic icon={BANNER_ICON[kind]} size={20} className="tw-banner__icon" />
      <div className="tw-banner__text">
        <p className="tw-banner__title">{title ?? copy.title}</p>
        <p className="tw-banner__detail">{detail ?? copy.detail}</p>
      </div>
      {kind === 'lost' ? (
        <div className="tw-banner__actions">
          <Button variant="secondary" size="sm" href={hrefs.retry}>
            Try again
          </Button>
        </div>
      ) : null}
      {kind === 'view' ? (
        <div className="tw-banner__actions">
          <Button variant="secondary" size="sm">
            Request edit access
          </Button>
        </div>
      ) : null}
      {kind === 'version' ? (
        <div className="tw-banner__actions">
          <Button variant="ghost" size="sm" href={hrefs.back}>
            Back to current
          </Button>
          <Button variant="primary" size="sm" href={hrefs.restore}>
            Restore this version
          </Button>
        </div>
      ) : null}
    </div>
  );
}

export const bannerFor = (state: WsState): BannerKind | null => BANNER_OF[state] ?? null;

/* ------------------------------------------------------------------ popover */

/**
 * An overlay that opens above the screen and closes on a click outside or Escape (Figma: overlay, close when clicking outside).
 * Focus moves into it when it opens and returns to the button that opened it.
 */
export function Popover({ onClose, label, className, kind, children }: { onClose: () => void; label: string; className?: string; kind?: string; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    const first = ref.current?.querySelector<HTMLElement>('a[href], button:not([disabled]), [tabindex="0"]');
    (first ?? ref.current)?.focus({ preventScroll: true });
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close.current();
    };
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('keydown', key);
      if (opener && document.contains(opener)) opener.focus({ preventScroll: true });
    };
  }, []);
  return (
    <>
      <div className="tw-scrim" onClick={onClose} aria-hidden="true" />
      <div ref={ref} className={cx('tw-pop', className)} data-kind={kind} role="dialog" aria-label={label} tabIndex={-1}>
        {children}
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ save status popover */

const SAVE_ICON: Record<SaveKind, LucideIcon> = { saved: CircleCheck, saving: RefreshCw, offline: CloudOff, failed: CircleAlert };

/**
 * Figma "Save Status Popover" (17972:143571): a 320 wide card 8 px under the status pill with a status icon and a serif heading, the details,
 * and for Saved a divider with Save now and Version history, for Could not save a divider with Try again. Opened by the pill and closed by a
 * click outside, by the pill or by Escape (Popover). The content follows the save state: Saved, Saving, Offline, Could not save.
 */
export function SaveStatusPopover({ kind, links, onClose }: { kind: SaveKind; links: SaveLinks; onClose: () => void }) {
  const Icon = SAVE_ICON[kind];
  const copy = SAVE_COPY[kind];
  return (
    <Popover onClose={onClose} label="Save status" className="tw-pop--save" kind={kind}>
      <div className="tw-save__head">
        <Ic icon={Icon} size={20} className="tw-save__icon" />
        <h2 className="tw-save__title">{copy.title}</h2>
      </div>
      {kind === 'saved' ? (
        <>
          <div className="tw-save__details">
            <p>{SAVE_COPY.saved.last}</p>
            <p>{SAVE_COPY.saved.note}</p>
          </div>
          <hr className="tw-save__rule" />
          <div className="tw-save__actions">
            <Button variant="secondary" size="sm" href={links.saveNow}>
              {SAVE_COPY.saved.now}
            </Button>
            {links.history ? (
              <Link href={links.history} className="tw-save__link">
                {SAVE_COPY.saved.history}
              </Link>
            ) : (
              <span className="tw-save__link">{SAVE_COPY.saved.history}</span>
            )}
          </div>
        </>
      ) : null}
      {kind === 'saving' || kind === 'offline' ? (
        <div className="tw-save__details">
          <p>{SAVE_COPY[kind].note}</p>
        </div>
      ) : null}
      {kind === 'failed' ? (
        <>
          <hr className="tw-save__rule" />
          <div className="tw-save__actions">
            <Button size="sm" href={links.retry}>
              {SAVE_COPY.failed.retry}
            </Button>
          </div>
        </>
      ) : null}
    </Popover>
  );
}

/* ------------------------------------------------------------------ project menu */

/** Figma "Project menu": the eight visible items of the project navigation in a popover. Workspace is the current one; every other item opens its page, in both Workspaces. */
export function ProjectMenu({ onClose }: { onClose: () => void }) {
  const { nav } = useProject();
  return (
    <Popover onClose={onClose} label="Project menu" className="tw-pop--menu">
      <nav className="tw-menu" aria-label="Project workspace">
        <p className="tw-menu__eyebrow">PROJECT WORKSPACE</p>
        <ul className="tw-menu__list">
          {MENU_ITEMS.map(({ label, key }, i) => {
            const inner = (
              <>
                <span className="tw-menu__num">{String(i + 1).padStart(2, '0')}</span>
                <span className="tw-menu__label">{label}</span>
              </>
            );
            return (
              <li key={label}>
                {label === 'Workspace' ? (
                  <button type="button" className="tw-menu__item" aria-current="page" onClick={onClose}>
                    {inner}
                  </button>
                ) : (
                  <Link href={nav[key]} className="tw-menu__item">
                    {inner}
                  </Link>
                )}
              </li>
            );
          })}
        </ul>
      </nav>
    </Popover>
  );
}

/* ------------------------------------------------------------------ people and access */

const ROLE_NOTE: Record<Role, string> = { Owner: 'Owner', 'Can edit': 'Can edit', 'Can comment': 'Can comment', 'View only': 'View only' };

/** Figma "People and access": who is here and what each person may do. */
export function PeoplePanel({ rows, summary, onClose }: { rows: PeopleRow[]; summary: string; onClose: () => void }) {
  return (
    <Popover onClose={onClose} label="People and access" className="tw-pop--people">
      <div className="tw-people">
        <header className="tw-people__head">
          <h2 className="tw-people__title">People in this workspace</h2>
          <p className="tw-people__sub">{summary}</p>
        </header>
        <ul className="tw-people__list">
          {rows.map((r) => {
            const p = PEOPLE[r.id];
            return (
              <li key={r.id} className="tw-person">
                <Avatar id={r.id} state={r.avatar} />
                <span className="tw-person__who">
                  <span className="tw-person__name">{p.name + (r.you ? ' (you)' : '')}</span>
                  <span className="tw-person__note">{r.note}</span>
                </span>
                <span className="tw-role" data-owner={p.role === 'Owner' || undefined}>
                  {ROLE_NOTE[p.role]}
                </span>
              </li>
            );
          })}
        </ul>
        <hr className="tw-people__rule" />
        <footer className="tw-people__foot">
          <p>Only the project owner can change who has access. Access follows the project team and its agreements.</p>
          <Button variant="secondary" size="sm">
            Manage access
          </Button>
        </footer>
      </div>
    </Popover>
  );
}

/* ------------------------------------------------------------------ version history */

/** Figma "Version history content": the panel that takes the place of the comments panel. */
export function VersionPanel({ versions, selected, onSelect }: { versions: VersionRow[]; selected: string; onSelect: (v: VersionRow) => void }) {
  return (
    <div className="tw-vh">
      <header className="tw-vh__head">
        <h2 className="tw-vh__title">Version history</h2>
        <p className="tw-vh__sub">Pick a version to preview it</p>
      </header>
      <ul className="tw-vh__list">
        {versions.map((v) => {
          const body = (
            <>
              <i className="tw-vh__dot" aria-hidden="true" />
              <span className="tw-vh__text">
                <span className="tw-vh__time">{v.time}</span>
                <span className="tw-vh__detail">{v.detail}</span>
              </span>
              {v.current ? <span className="tw-vh__current">Current</span> : null}
            </>
          );
          return (
            <li key={v.id}>
              {v.current ? (
                <div className="tw-vh__row" data-state="current">
                  {body}
                </div>
              ) : (
                <button type="button" className="tw-vh__row" data-state={v.id === selected ? 'selected' : 'default'} aria-pressed={v.id === selected} onClick={() => onSelect(v)}>
                  {body}
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ shell */

type ShellProps = {
  kind: 'research' | 'art';
  state: WsState;
  title: string;
  project: string;
  avatars: PresenceItem[];
  more?: string;
  links: TopBarLinks;
  peopleRows: PeopleRow[];
  peopleSummary: string;
  /** Screen specific overlays, rendered inside the root so they share its stacking and size. */
  overlays?: ReactNode;
  /**
   * The save status popover under the status pill: where its controls lead, and whether it opens with the screen (the Could not save frame).
   * The popover that opens follows `state` (SAVE_KIND_OF in data.ts); a state without one leaves the pill plain.
   */
  saveMenu?: { links: SaveLinks; initialOpen?: boolean };
  /** Told when the save status popover opens or closes (the Saving screen waits while it is open). */
  onSaveOpenChange?: (open: boolean) => void;
  children: ReactNode;
};

/** The frame of both Workspaces: sign-in gate, full height root, top bar, the project menu and People and access overlays. */
export function WorkspaceShell({ kind, state, title, project, avatars, more, links, peopleRows, peopleSummary, overlays, saveMenu, onSaveOpenChange, children }: ShellProps) {
  const [menu, setMenu] = useState(false);
  const [people, setPeople] = useState(false);
  const [saveOpen, setSaveOpen] = useState(Boolean(saveMenu?.initialOpen));
  const saveKind = saveMenu ? SAVE_KIND_OF[state] : undefined;
  const saveShown = saveOpen && saveKind !== undefined;
  const told = useRef(onSaveOpenChange);
  told.current = onSaveOpenChange;
  useEffect(() => {
    told.current?.(saveShown);
  }, [saveShown]);
  return (
    <WorkspaceGate>
      <div className="tw-ws" data-kind={kind} data-state={state}>
        <TopBar
          kind={kind}
          state={state}
          title={title}
          project={project}
          avatars={avatars}
          more={more}
          links={links}
          menuOpen={menu}
          peopleOpen={people}
          onMenu={() => setMenu((v) => !v)}
          onPeople={() => setPeople((v) => !v)}
          save={saveMenu && saveKind ? { kind: saveKind, open: saveShown, onToggle: () => setSaveOpen((v) => !v), onClose: () => setSaveOpen(false), links: saveMenu.links } : undefined}
        />
        {children}
        {menu ? <ProjectMenu onClose={() => setMenu(false)} /> : null}
        {people ? <PeoplePanel rows={peopleRows} summary={peopleSummary} onClose={() => setPeople(false)} /> : null}
        {overlays}
      </div>
    </WorkspaceGate>
  );
}

