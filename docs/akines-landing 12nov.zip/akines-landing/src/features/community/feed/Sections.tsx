'use client';

/** The eleven feed sections (FEED_SPEC.md section 6). FeedSection renders one by key; the error and retry flow lives here. */
import { useEffect, useState, type ReactNode } from 'react';
import { Button, Chip } from '@/ui';
import { toast } from '@/ui/toast';
import { Link } from '@/lib/nav';
import { useMemoState } from '@/lib/hooks';
import { IArrow } from '../ui';
import type { FeedKey } from './arrangements';
import {
  ACTIVITY_CARDS, BANTER_CARDS, BANTER_JOIN, EXPLORE_CARDS, FIRST_SECTION_ID, HEADS, PRODUCTS, PROJECT_CARDS, ROOM_CARDS, SHOP_COPY, STORY_CARDS,
  STUDIO_CARDS, TRAITS, TRAIT_LINK, TRAIT_META, WELLBEING,
} from './content';
import { ArrowLink, CardRow, ErrorPanel, Face, FaceStack, FeedPhoto, SectionHeader, SkeletonCards } from './parts';
import { faceImg } from './images';
import { KinCirclePosts } from './Posts';

/* ---------------------------------------------------------------- banter (text-led cards) */
function BanterRow() {
  return (
    <div className="fd-row fd-row--banter" data-m="stagger">
      {BANTER_CARDS.map((b) => (
        <Link className="fd-banter" href={BANTER_JOIN.href} key={b.id}>
          <p className="fd-banter__tag">
            {b.tag.endsWith('LIVE') ? <span className="fd-banter__dot" aria-hidden="true" /> : null}
            {b.tag}
          </p>
          <h3 className="fd-banter__title">{b.title}</h3>
          <p className="fd-banter__text">{b.text}</p>
          <div className="fd-banter__foot">
            <div className="fd-banter__people">
              <FaceStack faces={b.faces} size={32} overlap={8} />
              <span>{b.talking}</span>
            </div>
            <span className="fd-link fd-link--static">
              <span>{BANTER_JOIN.label}</span>
              <IArrow />
            </span>
          </div>
        </Link>
      ))}
    </div>
  );
}

/* ---------------------------------------------------------------- shop */
function ShopRow() {
  return (
    <div className="fd-row fd-row--shop" data-m="stagger">
      {PRODUCTS.map((p) => (
        <article className="fd-card fd-product" key={p.id}>
          <Link className="fd-product__link" href={SHOP_COPY.href}>
            <FeedPhoto image={p.image} className="fd-card__photo" />
            <p className="fd-card__tag">{p.tag}</p>
            <h3 className="fd-card__title fd-product__title">{p.title}</h3>
          </Link>
          <div className="fd-product__maker">
            <Face image={faceImg(p.face)} size={24} />
            <span>{p.maker}</span>
          </div>
          <div className="fd-product__buy">
            <p className="fd-product__price">
              <span>{p.price}</span>
              {p.edition ? <span className="fd-product__edition">{p.edition}</span> : null}
            </p>
            <Button variant="secondary" onClick={() => toast.show({ message: SHOP_COPY.toast })} aria-label={`${SHOP_COPY.buy} ${p.title}`}>
              {SHOP_COPY.buy}
            </Button>
          </div>
          <span className="fd-card__rule" aria-hidden="true" />
        </article>
      ))}
    </div>
  );
}

/* ---------------------------------------------------------------- creative DNA */
function DnaRow() {
  return (
    <div className="fd-row fd-row--dna" data-m="stagger">
      {TRAITS.map((t) => (
        <article className="fd-trait" key={t.id}>
          <p className="fd-trait__eyebrow">{t.eyebrow}</p>
          <h3 className="fd-trait__title">{t.title}</h3>
          <p className="fd-trait__text">{t.text}</p>
          <div className="fd-trait__foot">
            <div className="fd-trait__people">
              <FaceStack faces={t.faces} size={32} overlap={8} />
              <span>{TRAIT_META}</span>
            </div>
            <ArrowLink href={TRAIT_LINK.href}>{TRAIT_LINK.label}</ArrowLink>
          </div>
        </article>
      ))}
    </div>
  );
}

/* ---------------------------------------------------------------- creative wellbeing (single wide band) */
function Wellbeing({ id }: { id?: string }) {
  const [choice, setChoice] = useMemoState<string | null>('feed.wellbeing', null);
  const reply = WELLBEING.options.find((o) => o.id === choice)?.reply;
  return (
    <section className="fd-section fd-well" id={id} data-feed-section="wellbeing" aria-labelledby="fd-title-wellbeing" data-m="up">
      <div className="fd-well__body">
        <p className="fd-well__eyebrow">{WELLBEING.eyebrow}</p>
        <h2 className="fd-well__title" id="fd-title-wellbeing">
          {HEADS.wellbeing.title}
        </h2>
        <p className="fd-well__support">{HEADS.wellbeing.support}</p>
        <div className="fd-well__chips" role="group" aria-label="How is your creative energy today?">
          {WELLBEING.options.map((o) => (
            <Chip key={o.id} selected={choice === o.id} onClick={() => setChoice(choice === o.id ? null : o.id)}>
              {o.label}
            </Chip>
          ))}
        </div>
        <p className="fd-well__reply" aria-live="polite">
          {reply ? <span key={choice}>{reply}</span> : null}
        </p>
        <ArrowLink href={WELLBEING.link.href}>{WELLBEING.link.label}</ArrowLink>
      </div>
      <FeedPhoto image={WELLBEING.image} className="fd-well__photo" />
    </section>
  );
}

/* ---------------------------------------------------------------- one section */
function Body({ name }: { name: Exclude<FeedKey, 'wellbeing'> }): ReactNode {
  switch (name) {
    case 'explore':
      return <CardRow cards={EXPLORE_CARDS} />;
    case 'kincircle':
      return <KinCirclePosts />;
    case 'banter':
      return <BanterRow />;
    case 'rooms':
      return <CardRow cards={ROOM_CARDS} />;
    case 'activities':
      return <CardRow cards={ACTIVITY_CARDS} />;
    case 'collaborate':
      return <CardRow cards={PROJECT_CARDS} />;
    case 'shop':
      return <ShopRow />;
    case 'studios':
      return <CardRow cards={STUDIO_CARDS} />;
    case 'stories':
      return <CardRow cards={STORY_CARDS} />;
    case 'dna':
      return <DnaRow />;
  }
}

type Phase = 'error' | 'loading' | 'live';

/**
 * `first` marks the section "See how it works" scrolls to. `failing` starts the section in its error state
 * (the state route); "Try again" shows the skeleton for a moment and then the live section.
 */
export function FeedSection({ name, first, failing }: { name: FeedKey; first?: boolean; failing?: boolean }) {
  const [phase, setPhase] = useState<Phase>(failing ? 'error' : 'live');
  useEffect(() => {
    if (phase !== 'loading') return;
    const t = window.setTimeout(() => setPhase('live'), 900);
    return () => window.clearTimeout(t);
  }, [phase]);

  if (name === 'wellbeing') {
    // The band has no error or retry variant in the spec.
    return <Wellbeing id={first ? FIRST_SECTION_ID : undefined} />;
  }

  const head = HEADS[name];
  const titleId = `fd-title-${name}`;
  return (
    <section className="fd-section" id={first ? FIRST_SECTION_ID : undefined} data-feed-section={name} aria-labelledby={titleId}>
      <SectionHeader id={titleId} head={head} />
      {phase === 'error' ? <ErrorPanel onRetry={() => setPhase('loading')} /> : phase === 'loading' ? <SkeletonCards /> : <Body name={name} />}
    </section>
  );
}
