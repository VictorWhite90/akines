'use client';

import { forwardRef, useEffect, useRef, useState, type ReactNode } from 'react';
import { asset } from '@/lib/assets';
import { IconButton } from '@/ui';
import { MicIcon, MicOffIcon, CloseIcon } from './CallIcons';
import type { Cast, SelfView } from './parts';

/**
 * The two panels of the call (Figma Call panel / People and Call panel / Chat): a white card on the right of the stage, and a bottom sheet on
 * a phone. Both are local state of the call: the people come from the project team, the chat only lives during the call.
 */

export type PanelKind = 'people' | 'chat';

const Shell = forwardRef<HTMLElement, { title: string; subtitle: string; onClose: () => void; children: ReactNode; footer?: ReactNode }>(function Shell(
  { title, subtitle, onClose, children, footer },
  ref,
) {
  return (
    <aside ref={ref} className="mc-panel" aria-label={title} tabIndex={-1}>
      <div className="mc-panel__head">
        <div className="mc-panel__heading">
          <h2 className="mc-panel__title">{title}</h2>
          <p className="mc-panel__sub">{subtitle}</p>
        </div>
        <IconButton variant="ghost" size="sm" tooltip={false} label={`Close ${title.toLowerCase()}`} onClick={onClose}>
          <CloseIcon size={16} />
        </IconButton>
      </div>
      {children}
      {footer}
    </aside>
  );
});

/* ------------------------------------------------------------------ People */

export const PeoplePanel = forwardRef<HTMLElement, { cast: Cast; self: SelfView; onClose: () => void }>(function PeoplePanel({ cast, self, onClose }, ref) {
  const muted = cast.others[2];
  return (
    <Shell ref={ref} title="People" subtitle={`${cast.roster.length} in this meeting`} onClose={onClose}>
      <ul className="mc-people">
        {cast.roster.map((p) => {
          const you = p.id === cast.you.id;
          const off = you ? self.micMuted : p.id === muted.id;
          return (
            <li key={p.id} className="mc-person">
              {p.photo ? <img className="mc-person__img" src={asset(p.photo)} alt="" width={40} height={40} draggable={false} /> : <span className="mc-person__img" aria-hidden="true" />}
              <span className="mc-person__text">
                <span className="mc-person__name">{you ? cast.youName : p.name}</span>
                <span className="mc-person__role">{p.role}</span>
              </span>
              <span className={`mc-person__mic${off ? ' mc-person__mic--off' : ''}`} role="img" aria-label={off ? 'Microphone off' : 'Microphone on'}>
                {off ? <MicOffIcon size={18} /> : <MicIcon size={18} />}
              </span>
            </li>
          );
        })}
      </ul>
    </Shell>
  );
});

/* ------------------------------------------------------------------ Chat */

export type ChatMessage = { id: string; name: string; time: string; text: string };

export const ChatPanel = forwardRef<HTMLElement, { messages: ChatMessage[]; onSend: (text: string) => void; onClose: () => void }>(function ChatPanel(
  { messages, onSend, onClose },
  ref,
) {
  const [draft, setDraft] = useState('');
  const list = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = list.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  return (
    <Shell
      ref={ref}
      title="Chat"
      subtitle="Messages are only visible during the call"
      onClose={onClose}
      footer={
        <form
          className="mc-chat__footer"
          onSubmit={(e) => {
            e.preventDefault();
            const text = draft.trim();
            if (!text) return;
            onSend(text);
            setDraft('');
          }}
        >
          <input
            className="mc-chat__field"
            type="text"
            name="message"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Send a message"
            aria-label="Send a message"
            autoComplete="off"
            enterKeyHint="send"
          />
        </form>
      }
    >
      <div ref={list} className="mc-chat__list" role="log" aria-live="polite" aria-label="Messages">
        {messages.map((m) => (
          <div key={m.id} className="mc-msg">
            <div className="mc-msg__meta">
              <span className="mc-msg__name">{m.name}</span>
              <span className="mc-msg__time">{m.time}</span>
            </div>
            <p className="mc-msg__text">{m.text}</p>
          </div>
        ))}
      </div>
    </Shell>
  );
});
