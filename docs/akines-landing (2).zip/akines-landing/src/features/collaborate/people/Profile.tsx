'use client';

import { useState } from 'react';
import { Button, toast } from '@/ui';
import { asset } from '@/lib/assets';
import { BackLink, IconArrowRight, IconEye } from './cc-ui';
import { PEOPLE, PERSON_COPY, PROFILES, R, personRoutes, type PersonId } from './data';
import { CcOverlays, type OverlayId } from './overlays';
import { ccStore } from './store';

/**
 * B5 Profile preview of Amina (Figma 17216:16505, route /collaborate/collaborators/profile-preview) and the profiles of 12.28 to 12.30:
 * Kunle Afolabi (17706:74545), Funmi Okoro (17706:75314) and Chidi Nwosu (17706:76083), route /collaborate/collaborators/<id>.
 * Every profile opens its own full explanation (Why this match), Not relevant feedback, Ask Akines why drawer and privacy modal
 * (12.28 to 12.30 clones, written for the person). Save for later shows the toast (Undo takes the save back).
 */
export function ProfileScreen({ id }: { id: PersonId }) {
  const [ov, setOv] = useState<OverlayId | null>(null);
  const person = PEOPLE[id];
  const P = PROFILES[id];
  const routes = personRoutes(id);
  const save = () => {
    const undo = ccStore.save(id);
    toast.show({ message: 'Saved to your collaborators.', actionLabel: 'Undo', onAction: undo });
  };
  return (
    <>
      <div className="cc-page cc-prof">
        <div className="cc-prof__main">
          <BackLink href={R.discovery}>Back to collaborators</BackLink>

          <header className="cc-prof__head">
            <div className="cc-prof__photo" data-m="frame">
              {/* Figma portrait 280 x 352 (Amina: node 17216:16515) */}
              <img className="cover" src={asset(person.photo)} alt="" decoding="async" width={280} height={352} />
            </div>
            <div className="cc-prof__id">
              <p className="cc-prof__avail">
                <span className="cc-dot" aria-hidden="true" />
                {person.availability}
              </p>
              <h1 className="cc-prof__name" data-m="words">
                {person.name}
              </h1>
              <p className="cc-prof__role">{person.role}</p>
              <p className="cc-prof__intro">{person.intro}</p>
              <ul className="cc-tags" aria-label="Key skills">
                {P.keySkills.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ul>
            </div>
          </header>

          <section className="cc-sec" aria-labelledby="cc-sec-about" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-about">
              About
            </h2>
            <p className="cc-sec__body">{P.about}</p>
          </section>

          <section className="cc-sec" aria-labelledby="cc-sec-exp" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-exp">
              Experience
            </h2>
            <ul className="cc-items">
              {P.experience.map((e) => (
                <li key={e.title}>
                  <p className="cc-items__title">{e.title}</p>
                  <p className="cc-items__detail">{e.detail}</p>
                </li>
              ))}
            </ul>
          </section>

          <section className="cc-sec" aria-labelledby="cc-sec-skills" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-skills">
              Skills
            </h2>
            <ul className="cc-tags">
              {P.skills.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </section>

          <section className="cc-sec" aria-labelledby="cc-sec-int" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-int">
              Interests
            </h2>
            <ul className="cc-tags">
              {P.interests.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </section>

          <section className="cc-sec" aria-labelledby="cc-sec-pref" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-pref">
              Working preferences
            </h2>
            <dl className="cc-prefs">
              {P.preferences.map((p) => (
                <div key={p.label}>
                  <dt>{p.label}</dt>
                  <dd>{p.value}</dd>
                </div>
              ))}
            </dl>
          </section>

          <section className="cc-sec" aria-labelledby="cc-sec-con" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-con">
              Contributions
            </h2>
            <ul className="cc-items">
              {P.contributions.map((c) => (
                <li key={c.title}>
                  <p className="cc-items__title">{c.title}</p>
                  <p className="cc-items__detail">{c.detail}</p>
                </li>
              ))}
            </ul>
          </section>

          <section className="cc-sec" aria-labelledby="cc-sec-ctx" data-m="up">
            <h2 className="cc-eyebrow" id="cc-sec-ctx">
              Match context
            </h2>
            <div className="cc-context-box">
              <p className="cc-context-box__text">{P.matchContext}</p>
              <div>
                <Button variant="link" href={routes.why} iconRight={<IconArrowRight />}>
                  See the full explanation
                </Button>
              </div>
            </div>
          </section>
        </div>

        <aside className="cc-prof__side" aria-label="Actions">
          <section className="cc-panel" data-m="up">
            <h2 className="cc-eyebrow">Interested in {person.firstName}?</h2>
            <Button fullWidth href={routes.request} arrow="up-right">
              Request introduction
            </Button>
            <Button fullWidth variant="secondary" onClick={save}>
              Save for later
            </Button>
            <div className="cc-panel__links">
              <Button variant="link" onClick={() => setOv('notrelevant')}>
                Not relevant
              </Button>
              <Button variant="link" onClick={() => setOv('ask')}>
                Ask Akines why
              </Button>
            </div>
          </section>

          <section className="cc-panel cc-panel--note" data-m="up">
            <h2 className="cc-panel__head">
              <IconEye size={16} strokeWidth={1.5} />
              <span className="cc-eyebrow">What you’re seeing</span>
            </h2>
            <p className="cc-panel__text">{PERSON_COPY[id].seeing}</p>
            <div>
              <Button variant="link" onClick={() => setOv('privacy')}>
                See what’s shared
              </Button>
            </div>
          </section>
        </aside>
      </div>
      <CcOverlays open={ov} onClose={() => setOv(null)} person={id} />
    </>
  );
}

export default function Profile() {
  return <ProfileScreen id="amina" />;
}
