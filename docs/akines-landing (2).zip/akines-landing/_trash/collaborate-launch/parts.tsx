'use client';

import type { ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { CheckIcon, Ctx, cx } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { LAUNCH, LAUNCH_PATHS, NEEDS, OWNER, type Credit, type LaunchPage, type MaterialRowData, type MaterialStatus, type ReadinessRowData, type ReadinessStatus } from './data';

/**
 * Pieces of the Launch pages: the three row components (Readiness Item 17729:92085, Material Row 17729:92193, Credit Row 17729:92262),
 * the list they sit in, the progress bar of the checklist and the Context Panel / Launch (17729:92343), one variant per page.
 * Every class is prefixed ln- and lives in launch.css.
 */

/**
 * Career Guidance for Everyone and Adire Stories render the same Launch pages. This gives a page the copy, the page paths and the Tasks
 * path of its own project, so an Adire Stories page never links into Career.
 */
export function useLaunch() {
  const { key, nav } = useProject();
  return { key, ...LAUNCH[key], lp: LAUNCH_PATHS[key], tasksPath: nav.tasks };
}

/* ------------------------------------------------------------------ rows */

/**
 * Default, Hover, Pressed and Focus of the rows come from CSS. A row with a destination is a link. A row without one is a button that
 * reacts to hover, press and focus but goes nowhere (the design gives those rows the states and no click).
 */
function RowShell({ href, className, children }: { href?: string; className: string; children: ReactNode }) {
  if (href) {
    return (
      <Link href={href} className={cx('ln-row', className)}>
        {children}
      </Link>
    );
  }
  return (
    <button type="button" className={cx('ln-row', 'ln-row--inert', className)} aria-disabled="true">
      {children}
    </button>
  );
}

/** The 24 px marker of a Readiness Item: a filled ring with a tick, an amber ring with a dot, or an empty ring. */
function Marker({ status }: { status: ReadinessStatus }) {
  return (
    <span className={cx('ln-mk', status === 'Done' ? 'ln-mk--done' : status === 'In progress' ? 'ln-mk--doing' : 'ln-mk--idle')} aria-hidden="true">
      {status === 'Done' ? (
        <svg width="10" height="7.5" viewBox="0 0 10 7.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" focusable="false">
          <path d="M0.9 3.9 3.6 6.6 9.1 0.9" />
        </svg>
      ) : null}
    </span>
  );
}

export function ReadinessRow({ row }: { row: ReadinessRowData }) {
  return (
    <RowShell href={row.href} className="ln-row--ri">
      <Marker status={row.status} />
      <span className="ln-row__body">
        <span className="ln-row__title">{row.title}</span>
        <span className="ln-row__detail">{row.detail}</span>
      </span>
      <span className={cx('ln-row__status', row.status === 'Not started' && 'ln-row__status--muted')}>{row.status}</span>
    </RowShell>
  );
}

const DOT: Record<MaterialStatus, string> = { Ready: 'ok', Draft: 'draft', 'Not started': 'idle' };

export function MaterialRow({ row }: { row: MaterialRowData }) {
  return (
    <RowShell className="ln-row--mr">
      <span className="ln-row__body">
        <span className="ln-row__title">{row.title}</span>
        <span className="ln-row__detail">{row.detail}</span>
      </span>
      <span className="ln-slot">
        <i className={cx('ln-dot', `ln-dot--${DOT[row.status]}`)} aria-hidden="true" />
        <span className="ln-slot__label">{row.status}</span>
      </span>
      <span className="ln-row__action">{row.action}</span>
    </RowShell>
  );
}

export function CreditRow({ credit }: { credit: Credit }) {
  return (
    <RowShell className="ln-row--cr">
      <span className="ln-av" aria-hidden="true">
        {credit.initials}
      </span>
      <span className="ln-cr__body">
        <span className="ln-cr__person">
          <span className="ln-row__title">{credit.name}</span>
          <span className="ln-row__detail">{credit.role}</span>
        </span>
        <span className="ln-cr__text">{credit.contribution}</span>
      </span>
      <span className="ln-cr__attr">
        <span className="ln-cr__label">AGREED ATTRIBUTION</span>
        <span className="ln-cr__value">{credit.attribution}</span>
      </span>
    </RowShell>
  );
}

/** The bordered list that holds the rows. */
export function RowList({ label, children }: { label: string; children: ReactNode }) {
  return (
    <ul className="ln-list" aria-label={label}>
      {children}
    </ul>
  );
}

/** Progress line of the readiness checklist: label and value over a 4 px bar. */
export function Progress({ label, value, met, total }: { label: string; value: string; met: number; total: number }) {
  return (
    <div className="ln-prog">
      <div className="ln-prog__text">
        <span className="ln-prog__label">{label}</span>
        <span className="ln-prog__value">{value}</span>
      </div>
      <div className="ln-prog__bar" role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={total} aria-valuenow={met} aria-valuetext={value}>
        <i style={{ width: `${(met / total) * 100}%` }} />
      </div>
    </div>
  );
}

/** Approval checkbox of the share modal (Criteria Item, Done No and Yes): the row toggles, ticked text turns secondary. */
export function ApprovalItem({ checked, onChange, children }: { checked: boolean; onChange: (v: boolean) => void; children: ReactNode }) {
  return (
    <div className="ln-appr">
      <button type="button" role="checkbox" aria-checked={checked} className="ln-appr__item" onClick={() => onChange(!checked)}>
        <span className={cx('ln-box', checked && 'ln-box--on')} aria-hidden="true">
          {checked ? <CheckIcon size={14} sw={1.5} /> : null}
        </span>
        <span>{children}</span>
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ context panel */

const Summary = ({ label, headline, detail }: { label: string; headline: string; detail: string }) => (
  <Ctx label={label}>
    <p className="cw-session__title">{headline}</p>
    <p className="cw-ctx__line">{detail}</p>
  </Ctx>
);
const Person = ({ label, name, note }: { label: string; name: string; note: string }) => (
  <Ctx label={label}>
    <p className="cw-ctx__item">{name}</p>
    <p className="ln-note">{note}</p>
  </Ctx>
);
const Phase = ({ name, note }: { name: string; note: string }) => <Person label="PROJECT PHASE" name={name} note={note} />;
const CreateAi = ({ note }: { note: string }) => (
  <Ctx label="CREATE AI">
    <p className="ln-note">{note}</p>
  </Ctx>
);

/** Context Panel / Launch: Not ready (Career only), Readiness, Materials, Attribution, Sharing, Outcome. */
export function LaunchContext({ page }: { page: LaunchPage }) {
  const { context: c } = useLaunch();
  switch (page) {
    case 'notReady':
      return (
        <>
          <Ctx label="WHAT READINESS NEEDS">
            {NEEDS.map((n) => (
              <p className="ln-need" key={n}>
                {n}
              </p>
            ))}
          </Ctx>
          <Phase name={c.phase} note="Launch opens up when the work is ready to be shared." />
          <CreateAi note="Create AI can help prepare launch materials when you ask. It suggests, and your team decides. It never publishes." />
        </>
      );
    case 'readiness':
      return (
        <>
          <Summary label="READINESS" headline={c.readiness.headline} detail={c.readiness.detail} />
          <Person label="WAITING FOR APPROVAL" name={OWNER} note={c.readiness.waiting} />
          <Phase name={c.phase} note={c.phaseNote} />
          <CreateAi note={c.readiness.ai} />
        </>
      );
    case 'materials':
      return (
        <>
          <Summary label="MATERIALS" headline={c.materials.headline} detail={c.materials.detail} />
          <CreateAi note={c.materials.ai} />
          <Phase name={c.phase} note={c.phaseNote} />
        </>
      );
    case 'attribution':
      return (
        <>
          <Summary label="ATTRIBUTION" headline={c.attribution.headline} detail={c.attribution.detail} />
          <CreateAi note={c.attribution.ai} />
          <Phase name={c.phase} note={c.phaseNote} />
        </>
      );
    case 'sharing':
      return (
        <>
          <Summary label="BEFORE YOU SHARE" headline={c.sharing.headline} detail={c.sharing.detail} />
          <Person label="PROJECT OWNER" name={OWNER} note={c.sharing.owner} />
          <CreateAi note={c.sharing.ai} />
        </>
      );
    case 'outcome':
      return (
        <>
          <Summary label="SHARED" headline={c.outcome.headline} detail={c.outcome.detail} />
          <Person label="APPROVED BY" name={OWNER} note={c.outcome.approved} />
          <Ctx label="CREDITS">
            <p className="ln-note">{c.outcome.credits}</p>
          </Ctx>
        </>
      );
  }
}
