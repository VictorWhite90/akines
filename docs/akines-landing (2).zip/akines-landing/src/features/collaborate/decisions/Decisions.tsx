'use client';

import '../workspace/workspace.css';
import './decisions.css';
import { useEffect, useState } from 'react';
import { useNav, usePath } from '@/lib/nav';
import { Button, EmptyState, toast } from '@/ui';
import { MetricCard, MetricRow } from '../workspace/dash';
import { ActionButton, CardLink, PageHead, WorkspaceFrame } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { DP, EMPTY, GROUP_HISTORY, GROUP_PENDING, HEAD, decisionPaths } from './data';
import { ProposeModal } from './modals';
import { DecisionList, ViewTabs, useDecisionsData } from './parts';

/**
 * 12.20 Decisions: Decisions (17729:108407), Empty (17729:113129) and History (17729:113566), with Modal:Propose decision and
 * Toast:Decision proposed. One screen component drives the three frames. Each shows three metric cards (Pending, Awaiting you, In
 * history) and the shared project rail (the short one on Empty). The cards have no destination in the design: their reactions only
 * change them to the hover and pressed look. Their counts come from the rows of the project (the Empty frame shows zeros).
 * Propose decision opens the modal on every frame; the modal's button shows the toast over the same page (nothing is added to the list,
 * the design only shows the toast). The "state-" routes are the overlay frames: this page with the modal open or the toast showing.
 * Without a destination in the design (shown, they do nothing): rows 2 and 3 of the list, the rows of History, the Prototype Review
 * milestone link, View pending decisions and View decision history on Empty.
 * The list and History also run for Adire Stories under its own root, with the rows and copy of that project (useDecisionsData). There
 * no row, Review decision or View milestone has a destination, and Propose decision opens the modal with Adire Stories copy.
 */

const TOAST_MS = 2500;
/** The toast of the "state-" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

type View = 'list' | 'empty' | 'history';

/** SCROLL_TO of the design: the list scrolls into view (under the sticky headers). */
function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const reduce = typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
}

const noun = (n: number) => (n === 1 ? 'decision' : 'decisions');

const LIST_ID = 'dc-list';
const HISTORY_ID = 'dc-history-list';

function Screen({ view, proposeOpen, proposedToast }: { view: View; proposeOpen?: boolean; proposedToast?: boolean }) {
  const nav = useNav();
  const path = usePath();
  const paths = decisionPaths(useProject().root);
  const { needsAttention, history, propose: copy } = useDecisionsData();
  const [modal, setModal] = useState(Boolean(proposeOpen));

  // the "state-decision-proposed" frame: the Decisions page with the toast already showing
  useEffect(() => {
    if (proposedToast) toast.show({ message: copy.toast, duration: STATE_TOAST_MS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [proposedToast]);

  // the modal's button closes it and shows the toast over the page it was opened on (the state frame goes back to Decisions first)
  const propose = () => {
    setModal(false);
    if (path === DP.propose) nav.push(DP.list);
    toast.show({ message: copy.toast, duration: TOAST_MS });
  };

  // Pending: the rows that need attention. Awaiting you: those that wait for the acknowledgement of the reader. In history: the closed ones.
  const empty = view === 'empty';
  const pending = empty ? 0 : needsAttention.length;
  const awaiting = empty ? 0 : needsAttention.filter((d) => d.status === 'Awaiting acknowledgement').length;
  const closed = empty ? 0 : history.length;

  const modalEl = <ProposeModal open={modal} onClose={() => setModal(false)} onPropose={propose} />;

  const head = (
    <PageHead label={HEAD.label} title={HEAD.title} lead={HEAD.lead}>
      <div className="dc-metrics">
        <MetricRow>
          <MetricCard label="PENDING" value={pending} caption={noun(pending)} />
          <MetricCard label="AWAITING YOU" value={awaiting} caption={noun(awaiting)} dot={awaiting > 0} />
          <MetricCard label="IN HISTORY" value={closed} caption={noun(closed)} />
        </MetricRow>
      </div>
      <div className="cw-actions cw-actions--btns">
        <ActionButton onClick={() => setModal(true)}>Propose decision</ActionButton>
        {view === 'list' ? (
          <>
            <ActionButton variant="secondary" onClick={() => scrollToId(LIST_ID)}>
              View pending decisions
            </ActionButton>
            <CardLink href={paths.history}>View decision history</CardLink>
          </>
        ) : view === 'history' ? (
          <>
            <ActionButton variant="secondary" href={paths.list}>
              View pending decisions
            </ActionButton>
            <CardLink onClick={() => scrollToId(HISTORY_ID)}>View decision history</CardLink>
          </>
        ) : (
          <>
            {/* Empty: the design gives these two no destination */}
            <ActionButton variant="secondary">View pending decisions</ActionButton>
            <CardLink>View decision history</CardLink>
          </>
        )}
      </div>
    </PageHead>
  );

  if (view === 'empty') {
    return (
      <WorkspaceFrame active="decisions" rail="short">
        {head}
        <div className="dc-empty" data-m="up">
          <EmptyState
            className="cw-empty"
            title={EMPTY.title}
            text={EMPTY.text}
            action={
              <Button arrow="up-right" onClick={() => setModal(true)}>
                Propose decision
              </Button>
            }
          />
        </div>
        {modalEl}
      </WorkspaceFrame>
    );
  }

  return (
    <WorkspaceFrame active="decisions" rail>
      {head}
      <div className="dc-views">
        <ViewTabs view={view === 'history' ? 'history' : 'list'} />
        {view === 'history' ? <DecisionList id={HISTORY_ID} group={GROUP_HISTORY} items={history} tight /> : <DecisionList id={LIST_ID} group={GROUP_PENDING} items={needsAttention} />}
      </div>
      {modalEl}
    </WorkspaceFrame>
  );
}

export const Decisions = () => <Screen view="list" />;
export const DecisionsEmpty = () => <Screen view="empty" />;
export const DecisionsHistory = () => <Screen view="history" />;
/** Frame "Modal:Propose decision": Decisions with the modal open. */
export const DecisionsProposeModal = () => <Screen view="list" proposeOpen />;
/** Frame "Toast:Decision proposed": Decisions with the toast showing. */
export const DecisionsProposed = () => <Screen view="list" proposedToast />;
