'use client';

/**
 * Shared pieces of the Collaborate "Discover projects" screens (12.5 to 12.9): icons, back and card links, status pills,
 * notices, the bordered empty and error panel, the page head and the project card. Classes are prefixed dsc- (projects.css).
 */
import './projects.css';
import type { ReactNode, SVGProps } from 'react';
import { Link } from '@/lib/nav';
import { Button } from '@/ui';
import type { Project } from './data';

/* ------------------------------------------------------------------ icons (Figma icon set) */

type IconProps = { size?: number } & Omit<SVGProps<SVGSVGElement>, 'width' | 'height'>;
const base = { fill: 'none', stroke: 'currentColor', strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, focusable: 'false' } as const;

/** icon/bookmark: the mark is 14 x 18 inside the 20 x 20 frame and is not clipped by it (Figma 17309:13575). */
export const IconBookmark = ({ size = 20, filled, ...p }: IconProps & { filled?: boolean }) => (
  <svg width={size} height={size} viewBox="0 0 20 20" {...base} strokeWidth={1.5} style={{ overflow: 'visible' }} {...p}>
    <path d="M5.75 3.75h12.5v16.5L12 16.5l-6.25 3.75Z" fill={filled ? 'currentColor' : 'none'} />
  </svg>
);
/** The 12 px bookmark of the "Saved" pill (Figma 17310:13747). */
export const IconBookmarkSmall = (p: IconProps) => (
  <svg width={12} height={12} viewBox="0 0 12 12" {...base} strokeWidth={0.75} {...p}>
    <path d="M2.875 1.875h6.25v8.25L6 8.25l-3.125 1.875Z" />
  </svg>
);
export const IconArrowRight = ({ size = 16, strokeWidth = 1.25, ...p }: IconProps & { strokeWidth?: number }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...base} strokeWidth={strokeWidth} {...p}>
    <path d="M3.3 8h9.3M8 3.3 12.7 8 8 12.7" />
  </svg>
);
export const IconArrowLeft = ({ size = 16, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...base} strokeWidth={1} {...p}>
    <path d="M12.6 8H3.3M8 3.3 3.3 8 8 12.7" />
  </svg>
);
/** The arrow of the card call to action (10.5 x 8 mark, 1.4 stroke, Figma 17310:13745). */
export const IconCardArrow = (p: IconProps) => (
  <svg width={16} height={16} viewBox="0 0 16 16" {...base} strokeWidth={1.4} {...p}>
    <path d="M2.5 8H13M9 4l4 4-4 4" />
  </svg>
);
export const IconSearch = (p: IconProps) => (
  <svg width={20} height={20} viewBox="0 0 20 20" {...base} strokeWidth={1.5} {...p}>
    <circle cx="10.5" cy="10.5" r="6.75" />
    <path d="M15.4 15.4 19 19" />
  </svg>
);
export const IconX = ({ size = 18, strokeWidth = 1.5, ...p }: IconProps & { strokeWidth?: number }) => (
  <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} {...base} strokeWidth={strokeWidth} {...p}>
    <path d={size === 18 ? 'M4.5 4.5l9 9M13.5 4.5l-9 9' : 'M5 5l10 10M15 5L5 15'} />
  </svg>
);
export const IconEye = (p: IconProps) => (
  <svg width={16} height={16} viewBox="0 0 16 16" {...base} strokeWidth={1} {...p}>
    <path d="M1.3 8s2.4-4.7 6.7-4.7S14.7 8 14.7 8s-2.4 4.7-6.7 4.7S1.3 8 1.3 8Z" />
    <circle cx="8" cy="8" r="2" />
  </svg>
);

/* ------------------------------------------------------------------ small pieces */

/** Back Link (Figma 17209:14005): arrow and a semibold label, underlined on hover. */
export function BackLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link href={href} className="dsc-back">
      <IconArrowLeft />
      <span>{children}</span>
    </Link>
  );
}

/** Card Link, dark tone (Figma 17139:20140): underlined semibold label, optional arrow. */
export function CardLink({ href, onClick, arrow, children }: { href?: string; onClick?: () => void; arrow?: boolean; children: ReactNode }) {
  const inner = (
    <>
      <span className="dsc-link__label">{children}</span>
      {arrow ? <IconArrowRight /> : null}
    </>
  );
  if (href) {
    return (
      <Link href={href} className="dsc-link">
        {inner}
      </Link>
    );
  }
  return (
    <button type="button" className="dsc-link" onClick={onClick}>
      {inner}
    </button>
  );
}

const STATUS_LABEL = { open: 'Open', closed: 'Closed', pending: 'Pending' } as const;
/** Project Status Tag and Status Pill (Figma 17344:13596, 17344:13599, 17210:13257): dot and label on a soft tint. */
export function StatusPill({ status }: { status: keyof typeof STATUS_LABEL }) {
  return (
    <span className={`dsc-status dsc-status--${status}`}>
      <i aria-hidden="true" />
      {STATUS_LABEL[status]}
    </span>
  );
}

/** Notice (Figma 17210:13239): amber (or red) rule, serif title, text. */
export function Notice({ title, text, tone }: { title: string; text: string; tone?: 'error' }) {
  return (
    <div className={`dsc-notice${tone === 'error' ? ' dsc-notice--error' : ''}`} role={tone === 'error' ? 'alert' : undefined}>
      <span className="dsc-notice__rule" aria-hidden="true" />
      <div className="dsc-notice__body">
        <p className="dsc-notice__title">{title}</p>
        <p className="dsc-notice__text">{text}</p>
      </div>
    </div>
  );
}

/**
 * Bordered panel for the empty and "could not load" states (Figma Empty state, 17354:14116): amber rule, serif headline, support, actions.
 * With two actions Figma wraps them in a 100 px high row (buttons centred), so `pair` keeps that height.
 */
export function StatePanel({ headline, support, pair, role, children }: { headline: string; support: string; pair?: boolean; role?: 'alert'; children: ReactNode }) {
  return (
    <section className="dsc-state" role={role}>
      <span className="dsc-state__rule" aria-hidden="true" />
      <h2 className="dsc-state__headline">{headline}</h2>
      <p className="dsc-state__support">{support}</p>
      <div className="dsc-state__actions" data-pair={pair || undefined}>
        {children}
      </div>
    </section>
  );
}

/** Eyebrow, serif headline and support of a page, with an optional link at the bottom right. */
export function PageHead({ eyebrow, title, lead, link }: { eyebrow: string; title: string; lead: string; link?: ReactNode }) {
  return (
    <header className="dsc-head">
      <div className="dsc-head__copy">
        <p className="dsc-eyebrow" data-m="up">
          {eyebrow}
        </p>
        <h1 className="dsc-h1" data-m="words">
          {title}
        </h1>
        <p className="dsc-lead" data-m="up">
          {lead}
        </p>
      </div>
      {link ? <div className="dsc-head__link">{link}</div> : null}
    </header>
  );
}

/** Amber dot, stage and type in small capitals (Figma "Stage group", 17310:13580). */
export function StageLine({ stage, type }: { stage: string; type: string }) {
  return (
    <div className="dsc-stage">
      <i aria-hidden="true" />
      <span className="dsc-stage__name">{stage}</span>
      <span className="dsc-stage__sep" aria-hidden="true">
        ·
      </span>
      <span className="dsc-stage__type">{type}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ project card (Figma Project Discovery Card, 17310:13578) */

export function ProjectCard({ project: p, mode, saved, onSave }: { project: Project; mode: 'discover' | 'saved'; saved: boolean; onSave: () => void }) {
  const closed = Boolean(p.closed);
  return (
    <article className="dsc-card" data-closed={closed || undefined}>
      <div className="dsc-card__top">
        <StageLine stage={p.stage} type={p.type} />
        {saved && closed && mode === 'discover' ? (
          // Figma 12.5 (17721:84212): the Closed card carries the Saved pill but its Save control has no click
          <span className="dsc-card__saved dsc-card__saved--static">
            <IconBookmarkSmall />
            Saved
          </span>
        ) : saved ? (
          <button type="button" className="dsc-card__saved" aria-pressed="true" aria-label={mode === 'saved' ? `Remove ${p.title} from saved projects` : `Saved: ${p.title}. Select to remove`} onClick={onSave}>
            <IconBookmarkSmall />
            Saved
          </button>
        ) : (
          <button type="button" className="dsc-card__save" aria-pressed="false" aria-label={`Save ${p.title}`} onClick={onSave}>
            <IconBookmark />
          </button>
        )}
      </div>
      <div className="dsc-card__group">
        <h3 className="dsc-card__title">
          <Link href={`/collaborate/projects/${p.slug}`}>{p.title}</Link>
        </h3>
        <p className="dsc-card__purpose">{p.purpose}</p>
      </div>
      <div className="dsc-card__divider" />
      <div className="dsc-card__field">
        <span className="dsc-label">Looking for</span>
        <p className="dsc-card__skills">{closed ? 'No longer looking for people' : p.roles.join(' · ')}</p>
      </div>
      <div className="dsc-card__field dsc-card__field--team">
        <span className="dsc-label">Current team</span>
        <div className="dsc-card__team">
          <span className="dsc-card__avatars">
            {p.avatars.map((a) => (
              <span key={a} className="dsc-card__avatar">
                {a}
              </span>
            ))}
          </span>
          <span>{p.teamCount} people</span>
        </div>
      </div>
      <div className="dsc-card__field">
        <span className="dsc-label">Commitment</span>
        <p className="dsc-card__text dsc-card__text--commit">{p.commitment}</p>
      </div>
      <div className="dsc-card__field">
        <span className="dsc-label">Project owner</span>
        <p className="dsc-card__text">{p.owner}</p>
      </div>
      <Button variant="link" href={`/collaborate/projects/${p.slug}`} className="dsc-card__cta" iconRight={<IconCardArrow />}>
        {closed ? 'View project' : 'Explore project'}
      </Button>
      {mode === 'saved' || closed ? (
        <span className="dsc-card__status">
          <StatusPill status={closed ? 'closed' : 'open'} />
        </span>
      ) : null}
    </article>
  );
}

/** Project Card Skeleton (Figma 17310:13754): pulses between two greys. */
export function CardSkeleton() {
  return (
    <div className="dsc-skel-card" aria-hidden="true">
      <span className="dsc-bar" style={{ width: 150, height: 12 }} />
      <div className="dsc-skel-card__group">
        <span className="dsc-bar" style={{ width: 300, height: 28 }} />
        <span className="dsc-bar" style={{ width: '100%', height: 14 }} />
        <span className="dsc-bar" style={{ width: 260, height: 14 }} />
      </div>
      <span className="dsc-skel-card__divider" />
      <div className="dsc-skel-card__field">
        <span className="dsc-bar" style={{ width: 91, height: 10 }} />
        <span className="dsc-bar" style={{ width: '100%', height: 16 }} />
        <span className="dsc-bar" style={{ width: 220, height: 16 }} />
      </div>
      <div className="dsc-skel-card__field">
        <span className="dsc-bar" style={{ width: 105, height: 10 }} />
        <div className="dsc-skel-card__team">
          <span className="dsc-bar" style={{ width: 28, height: 28, borderRadius: 14 }} />
          <span className="dsc-bar" style={{ width: 70, height: 14 }} />
        </div>
      </div>
      <div className="dsc-skel-card__field">
        <span className="dsc-bar" style={{ width: 94, height: 10 }} />
        <span className="dsc-bar" style={{ width: 300, height: 16 }} />
      </div>
      <div className="dsc-skel-card__field">
        <span className="dsc-bar" style={{ width: 115, height: 10 }} />
        <span className="dsc-bar" style={{ width: 140, height: 16 }} />
      </div>
      <span className="dsc-bar" style={{ width: 110, height: 16 }} />
    </div>
  );
}

/** A pulsing skeleton bar. */
export function Bar({ w, h, r, className }: { w: number | string; h: number; r?: number; className?: string }) {
  return <span className={`dsc-bar${className ? ` ${className}` : ''}`} style={{ width: w, height: h, borderRadius: r }} />;
}
