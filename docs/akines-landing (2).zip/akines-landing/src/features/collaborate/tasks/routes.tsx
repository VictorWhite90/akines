import type { RouteDef } from '@/routes.types';
import { TP } from './data';
import { TaskChangeStatus, TaskCompleted, TaskCompletedToast, TaskEditInvalid, TaskEditOpen, TaskInProgress, TaskInReview, TaskRequestModal, TaskReviewRequested, TaskUpdated } from './TaskDetail';
import { TasksBoard, TasksCreated, TasksCreateModal, TasksEmpty, TasksFilter, TasksList, TasksMilestones } from './Tasks';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;
const TASK = 'Write the guided onboarding questions';

/**
 * Tasks 12.14: Tasks (17674:851), Board view (17675:149), Milestone view (17675:873), Empty (17675:1499), Task detail (17677:149),
 * Task detail / In review (17678:1287), Task detail / Completed (17678:1754) and the overlay frames Modal:Create task (17680:460),
 * Modal:Request review (17680:546), Toast:Task created (17680:603), Toast:Review requested (17680:610), Toast:Task completed (17680:617),
 * Dropdown:Filter tasks (17680:624) and Dropdown:Change status (17680:898), and the Edit task frames: Slide-out:Edit task (17972:163075),
 * Slide-out:Edit task / Needs attention (17972:163242), Task detail (updated) (17972:163401) and Toast:Task updated (17972:163929).
 * The three views and the three stages of the task detail are reached from the UI (tabs, View milestones, task rows, Request review,
 * Complete task, Change status). The "state-" routes are the Figma state frames that have no natural trigger in the prototype (they are
 * not linked from the UI): the empty list, and the overlay frames that open with the modal, the menu or the toast already showing.
 */
export const routes: RouteDef[] = [
  { path: TP.list, title: 'Tasks', shell: 'app', nav, component: TasksList },
  { path: TP.board, title: 'Tasks', shell: 'app', nav, component: TasksBoard },
  { path: TP.milestones, title: 'Tasks', shell: 'app', nav, component: TasksMilestones },
  { path: TP.empty, title: 'Tasks', shell: 'app', nav, component: TasksEmpty },
  { path: TP.createModal, title: 'Tasks', shell: 'app', nav, component: TasksCreateModal },
  { path: TP.created, title: 'Tasks', shell: 'app', nav, component: TasksCreated },
  { path: TP.filter, title: 'Tasks', shell: 'app', nav, component: TasksFilter },

  { path: TP.detail, title: TASK, shell: 'app', nav, component: TaskInProgress },
  { path: TP.inReview, title: TASK, shell: 'app', nav, component: TaskInReview },
  { path: TP.completed, title: TASK, shell: 'app', nav, component: TaskCompleted },
  { path: TP.requestModal, title: TASK, shell: 'app', nav, component: TaskRequestModal },
  { path: TP.changeStatus, title: TASK, shell: 'app', nav, component: TaskChangeStatus },
  { path: TP.reviewRequested, title: TASK, shell: 'app', nav, component: TaskReviewRequested },
  { path: TP.taskCompleted, title: TASK, shell: 'app', nav, component: TaskCompletedToast },
  // Edit task: the Edit task button opens the slide-out; these are the frames with the slide-out open, its Needs attention state and the saved task
  { path: TP.editTask, title: TASK, shell: 'app', nav, component: TaskEditOpen },
  { path: TP.editTaskInvalid, title: TASK, shell: 'app', nav, component: TaskEditInvalid },
  { path: TP.taskUpdated, title: TASK, shell: 'app', nav, component: TaskUpdated },
];
