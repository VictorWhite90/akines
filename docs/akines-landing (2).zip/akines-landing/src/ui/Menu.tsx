'use client';

import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState, type ReactNode, type Ref } from 'react';
import { createPortal } from 'react-dom';
import { cx, useEscape, usePresence } from './internal';

export type MenuItem = { label: string; onSelect: () => void; icon?: ReactNode; /** A second, quieter line under the label (the Meet menu of Conversations). */ description?: string; danger?: boolean; disabled?: boolean } | 'divider';
export type MenuProps = {
  trigger: (p: {
    ref: Ref<HTMLButtonElement>;
    onClick: () => void;
    'aria-expanded': boolean;
    'aria-haspopup': 'menu';
  }) => ReactNode;
  items: MenuItem[];
  align?: 'start' | 'end';
  className?: string;
};

/**
 * Dropdown menu in a portal, positioned from its trigger (flips up near the bottom edge).
 * Keyboard: Enter, Space or ArrowDown on the trigger opens it; arrows, Home, End and letters move; Enter selects; Escape and Tab close.
 */
export function Menu({ trigger, items, align = 'start', className }: MenuProps) {
  const [open, setOpen] = useState(false);
  const { mounted, state } = usePresence(open, 220);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const id = useId();
  const [pos, setPos] = useState<{ top: number; left: number; minWidth: number; up: boolean } | null>(null);
  const [client, setClient] = useState(false);
  useEffect(() => setClient(true), []);

  const close = useCallback((returnFocus = true) => {
    setOpen(false);
    if (returnFocus) requestAnimationFrame(() => triggerRef.current?.focus({ preventScroll: true }));
  }, []);
  useEscape(open, () => close());

  const place = useCallback(() => {
    const t = triggerRef.current;
    const m = menuRef.current;
    if (!t) return;
    const r = t.getBoundingClientRect();
    const h = m?.offsetHeight ?? 0;
    const w = m?.offsetWidth ?? r.width;
    const up = h > 0 && r.bottom + 8 + h > window.innerHeight && r.top - 8 - h > 0;
    let left = align === 'end' ? r.right - w : r.left;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    setPos({ top: up ? r.top - 8 - h : r.bottom + 8, left, minWidth: r.width, up });
  }, [align]);

  useLayoutEffect(() => {
    if (!open) return;
    place();
  }, [open, place, items.length]);
  useEffect(() => {
    if (!open) return;
    const on = () => place();
    window.addEventListener('resize', on);
    window.addEventListener('scroll', on, true);
    return () => {
      window.removeEventListener('resize', on);
      window.removeEventListener('scroll', on, true);
    };
  }, [open, place]);

  // outside press closes (the trigger toggles on its own)
  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => {
      const n = e.target as Node;
      if (menuRef.current?.contains(n) || triggerRef.current?.contains(n)) return;
      setOpen(false);
    };
    document.addEventListener('pointerdown', down);
    return () => document.removeEventListener('pointerdown', down);
  }, [open]);

  const enabled = useCallback(() => Array.from(menuRef.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not([disabled])') ?? []), []);
  // focus the first item when opened
  useEffect(() => {
    if (!open || !pos) return;
    const first = enabled()[0];
    if (first && !menuRef.current?.contains(document.activeElement)) first.focus({ preventScroll: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, pos === null]);

  const onKey = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const list = enabled();
    const i = list.indexOf(document.activeElement as HTMLButtonElement);
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      list[(i + 1) % list.length]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      list[(i - 1 + list.length) % list.length]?.focus();
    } else if (e.key === 'Home') {
      e.preventDefault();
      list[0]?.focus();
    } else if (e.key === 'End') {
      e.preventDefault();
      list[list.length - 1]?.focus();
    } else if (e.key === 'Tab') {
      close(false);
    } else if (e.key.length === 1 && /\S/.test(e.key)) {
      const ch = e.key.toLowerCase();
      const from = i + 1;
      const next = [...list.slice(from), ...list.slice(0, from)].find((b) => (b.textContent ?? '').trim().toLowerCase().startsWith(ch));
      next?.focus();
    }
  };

  const onTriggerKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown' && !open) {
      e.preventDefault();
      setOpen(true);
    }
  };

  const trig = trigger({
    ref: (el) => {
      triggerRef.current = el;
    },
    onClick: () => setOpen((o) => !o),
    'aria-expanded': open,
    'aria-haspopup': 'menu',
  });

  return (
    <>
      <span className="k-menu-anchor" onKeyDown={onTriggerKey} data-open={open || undefined}>
        {trig}
      </span>
      {client && mounted
        ? createPortal(
            <div
              ref={menuRef}
              id={id}
              role="menu"
              className={cx('k-menu', pos?.up && 'k-menu--up', align === 'end' && 'k-menu--end', className)}
              data-state={state}
              data-k-overlay
              style={{ top: pos?.top ?? 0, left: pos?.left ?? 0, minWidth: Math.max(pos?.minWidth ?? 0, 200), visibility: pos ? 'visible' : 'hidden' }}
              onKeyDown={onKey}
            >
              {items.map((it, k) =>
                it === 'divider' ? (
                  <div key={`d${k}`} className="k-menu__rule" role="separator" />
                ) : (
                  <button
                    key={`${k}-${it.label}`}
                    type="button"
                    role="menuitem"
                    className={cx('k-menu__item', it.danger && 'k-menu__item--danger')}
                    disabled={it.disabled}
                    tabIndex={-1}
                    onClick={() => {
                      close(true);
                      it.onSelect();
                    }}
                  >
                    {it.icon ? <span className="k-menu__icon" aria-hidden="true">{it.icon}</span> : null}
                    <span className="k-menu__label">
                      {it.label}
                      {it.description ? <span className="k-menu__desc">{it.description}</span> : null}
                    </span>
                  </button>
                ),
              )}
            </div>,
            document.body,
          )
        : null}
    </>
  );
}
