import type { RouteDef } from '@/routes.types';
import { LandingPage } from './LandingPage';
import SignInLanding from './SignInLanding';
import { NotFoundView } from './NotFoundView';

export const routes: RouteDef[] = [
  { path: '/', title: '', shell: 'site', component: LandingPage },
  { path: '/sign-in', title: 'Sign in', shell: 'site', component: SignInLanding },
  // "/404" is served by src/app/not-found.tsx in Next; the preview artifact needs it in the registry
  { path: '/404', title: 'Page not found', shell: 'bare', component: NotFoundView },
];
