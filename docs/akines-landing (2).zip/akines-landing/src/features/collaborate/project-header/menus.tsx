'use client';

import { useCallback, useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { Link } from '@/lib/nav';
import { Toggle } from '@/ui';
import { useEscape, usePresence } from '@/ui/internal';
import { NOTIFICATIONS, NOTIFICATIONS_TITLE, NOTIFICATION_PREFERENCES, SETTINGS, SWITCHER_ALL, SWITCHER_LABEL, SWITCHER_PROJECTS, type ProjectSlug } from './data';
import { CurrentCheck } from './icons';
import { headerStore } from './store';

/**
 * The three dropdowns of the project header (Figma 12.25: Project switcher, Notifications, Project settings).
 * A dropdown has no dimming scrim in the design (the scrim is invisible and only closes it): here a press outside, Escape
 * or choosing an item closes it. It sits 6 px under the button that opened it (the Figma menus start 8 px under the 40 px
 * button box) and is placed in a portal so the sticky header never clips it.
 */

type PopoverProps = {
  open: boolean;
  onClose: (returnFocus?: boolean) => void;
  triggerRef: RefObject<HTMLElement | null>;
  /** The right aligned menus end where this element ends (the group of buttons); the switcher starts 20 px left of its button. */
  edgeRef?: RefObject<HTMLElement | null>;
  align: 'start' | 'end';
  width: number;
  label: string;
  role: 'menu' | 'dialog';
  className?: string;
  children: ReactNode;
};

function Popover({ open, onClose, triggerRef, edgeRef, align, width, label, role, className, children }: PopoverProps) {
  const [client, setClient] = useState(false);
  useEffect(() => setClient(true), []);
  const { mounted, state } = usePresence(open, 180);
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number; w: number } | null>(null);

  useEscape(open, () => onClose(true));

  const place = useCallback(() => {
    const t = triggerRef.current;
    if (!t) return;
    const r = t.getBoundingClientRect();
    const w = Math.min(width, window.innerWidth - 32);
    const edge = (edgeRef?.current ?? t).getBoundingClientRect();
    let left = align === 'end' ? edge.right - w : r.left - 18;
    left = Math.max(16, Math.min(left, window.innerWidth - w - 16));
    setPos({ top: Math.round(r.bottom + 6), left: Math.round(left), w });
  }, [align, edgeRef, triggerRef, width]);

  useLayoutEffect(() => {
    if (open) place();
  }, [open, place]);
  useEffect(() => {
    if (!open) return;
    const on = () => place();
    window.addEventListener('resize', on);
    window.addEventListener('scroll', on, true);
    return () => {
      window.removeEventListener('resize', on);
      window.removeEventListener('scroll', on, true);
    };
  }, [open, place]);

  // a press outside closes it (the button that opened it toggles on its own)
  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => {
      const n = e.target as Node;
      if (ref.current?.contains(n) || triggerRef.current?.contains(n)) return;
      onClose(false);
    };
    document.addEventListener('pointerdown', down);
    return () => document.removeEventListener('pointerdown', down);
  }, [open, onClose, triggerRef]);

  const items = useCallback(() => Array.from(ref.current?.querySelectorAll<HTMLElement>('a[href], button:not([disabled])') ?? []), []);

  // focus the first item once the menu is placed
  useEffect(() => {
    if (!open || !pos) return;
    if (ref.current && !ref.current.contains(document.activeElement)) items()[0]?.focus({ preventScroll: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, pos === null]);

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const list = items();
    const i = list.indexOf(document.activeElement as HTMLElement);
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      list[(i + 1) % list.length]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      list[(i - 1 + list.length) % list.length]?.focus();
    } else if (e.key === 'Home') {
      e.preventDefault();
      list[0]?.focus();
    } else if (e.key === 'End') {
      e.preventDefault();
      list[list.length - 1]?.focus();
    } else if (e.key === 'Tab') {
      e.preventDefault();
      onClose(true);
    }
  };

  if (!client || !mounted) return null;
  return createPortal(
    <div
      ref={ref}
      role={role}
      aria-label={label}
      tabIndex={-1}
      className={['ph-pop', className].filter(Boolean).join(' ')}
      data-state={state}
      data-k-overlay
      style={{ top: pos?.top ?? 0, left: pos?.left ?? 0, width: pos?.w ?? width, visibility: pos ? 'visible' : 'hidden' }}
      onKeyDown={onKey}
    >
      {children}
    </div>,
    document.body,
  );
}

const Eyebrow = ({ children }: { children: ReactNode }) => <p className="ph-eyebrow">{children}</p>;
const Rule = () => <div className="ph-rule" role="separator" />;

/* ------------------------------------------------------------------ Project switcher */

export function SwitcherMenu({ open, onClose, triggerRef, currentSlug, currentName }: { open: boolean; onClose: (returnFocus?: boolean) => void; triggerRef: RefObject<HTMLElement | null>; currentSlug: ProjectSlug; currentName: string }) {
  return (
    <Popover open={open} onClose={onClose} triggerRef={triggerRef} align="start" width={400} label="Your projects" role="menu" className="ph-pop--switch">
      <Eyebrow>{SWITCHER_LABEL}</Eyebrow>
      {SWITCHER_PROJECTS.map((p) => {
        const current = p.id === currentSlug;
        // the Career entry shows the name from the edit details form, but only while you are in that project (on another project `currentName` is that project's name)
        const name = p.id === 'career-guidance-for-everyone' && currentSlug === p.id ? currentName : p.name;
        const body = (
          <>
            <span className="ph-item__text">
              <span className="ph-item__serif">{name}</span>
              <span className="ph-item__cap">{p.line}</span>
            </span>
            {current ? (
              <span className="ph-item__check">
                <CurrentCheck />
              </span>
            ) : null}
          </>
        );
        // the project you are in only closes the menu; the others open their page
        return current ? (
          <button key={p.id} type="button" role="menuitem" className="ph-item" aria-current="true" onClick={() => onClose(true)}>
            {body}
          </button>
        ) : (
          <Link key={p.id} href={p.href} role="menuitem" className="ph-item" onClick={() => onClose(false)}>
            {body}
          </Link>
        );
      })}
      <Rule />
      <Link href={SWITCHER_ALL.href} role="menuitem" className="ph-item" onClick={() => onClose(false)}>
        <span className="ph-item__label">{SWITCHER_ALL.label}</span>
      </Link>
    </Popover>
  );
}

/* ------------------------------------------------------------------ Notifications */

export function NotificationsMenu({
  open,
  onClose,
  triggerRef,
  edgeRef,
  projectName,
  unread,
  onPreferences,
}: {
  open: boolean;
  onClose: (returnFocus?: boolean) => void;
  triggerRef: RefObject<HTMLElement | null>;
  edgeRef: RefObject<HTMLElement | null>;
  projectName: string;
  unread: string[];
  onPreferences: () => void;
}) {
  const allRead = unread.length === 0;
  return (
    <Popover open={open} onClose={onClose} triggerRef={triggerRef} edgeRef={edgeRef} align="end" width={456} label={NOTIFICATIONS_TITLE} role="dialog" className="ph-pop--notes">
      <div className="ph-head">
        <p className="ph-head__title">{NOTIFICATIONS_TITLE}</p>
        {allRead ? (
          <span className="ph-head__done">All caught up</span>
        ) : (
          <button
            type="button"
            className="ph-head__link"
            onClick={(e) => {
              headerStore.markAllRead();
              // the button is replaced by "All caught up": keep the keyboard inside the menu
              (e.currentTarget.closest('.ph-pop') as HTMLElement | null)?.focus();
            }}
          >
            Mark all as read
          </button>
        )}
      </div>
      {NOTIFICATIONS.map((n) => {
        const isUnread = unread.includes(n.id);
        return (
          <Link
            key={n.id}
            href={n.href}
            className="ph-item ph-note"
            data-unread={isUnread || undefined}
            onClick={() => {
              headerStore.markRead(n.id);
              onClose(false);
            }}
          >
            <span className="ph-note__mark" aria-hidden="true" />
            <span className="ph-note__text">
              <span className="ph-note__title">
                {isUnread ? <span className="sr-only">Unread. </span> : null}
                {n.title}
              </span>
              <span className="ph-item__cap">
                {projectName}. {n.who}. {n.when}
              </span>
              <span className="ph-note__act">{n.action}</span>
            </span>
          </Link>
        );
      })}
      <Rule />
      <button
        type="button"
        className="ph-item ph-item--col"
        onClick={() => {
          onClose(false);
          onPreferences();
        }}
      >
        <span className="ph-item__label">{NOTIFICATION_PREFERENCES.title}</span>
        <span className="ph-item__cap">{NOTIFICATION_PREFERENCES.text}</span>
      </button>
    </Popover>
  );
}

/* ------------------------------------------------------------------ Project settings */

export function SettingsMenu({
  open,
  onClose,
  triggerRef,
  edgeRef,
  openToCollaborators,
  onToggleOpen,
  onEdit,
  onArchive,
  onLeave,
}: {
  open: boolean;
  onClose: (returnFocus?: boolean) => void;
  triggerRef: RefObject<HTMLElement | null>;
  edgeRef: RefObject<HTMLElement | null>;
  openToCollaborators: boolean;
  onToggleOpen: (next: boolean) => void;
  onEdit: () => void;
  onArchive: () => void;
  onLeave: () => void;
}) {
  const pick = (fn: () => void) => () => {
    onClose(false);
    fn();
  };
  return (
    <Popover open={open} onClose={onClose} triggerRef={triggerRef} edgeRef={edgeRef} align="end" width={340} label={SETTINGS.label} role="menu" className="ph-pop--settings">
      <Eyebrow>{SETTINGS.label}</Eyebrow>
      <button type="button" role="menuitem" className="ph-item ph-item--col" onClick={pick(onEdit)}>
        <span className="ph-item__label">{SETTINGS.edit.title}</span>
        <span className="ph-item__cap">{SETTINGS.edit.text}</span>
      </button>
      {/* the row switches "Open to new collaborators" and keeps the menu open (Figma: the toggle changes, nothing closes) */}
      <div
        className="ph-item ph-item--toggle"
        onClick={(e) => {
          if (!(e.target as HTMLElement).closest('button')) onToggleOpen(!openToCollaborators);
        }}
      >
        <span className="ph-item__text">
          <span className="ph-item__label">{SETTINGS.open.title}</span>
          <span className="ph-item__cap">{SETTINGS.open.text}</span>
        </span>
        <Toggle checked={openToCollaborators} onChange={onToggleOpen} aria-label={SETTINGS.open.title} />
      </div>
      <Rule />
      <button type="button" role="menuitem" className="ph-item ph-item--col" onClick={pick(onArchive)}>
        <span className="ph-item__label">{SETTINGS.archive.title}</span>
        <span className="ph-item__cap">{SETTINGS.archive.text}</span>
      </button>
      <button type="button" role="menuitem" className="ph-item ph-item--col ph-item--danger" onClick={pick(onLeave)}>
        <span className="ph-item__label">{SETTINGS.leave.title}</span>
        <span className="ph-item__cap">{SETTINGS.leave.text}</span>
      </button>
    </Popover>
  );
}
