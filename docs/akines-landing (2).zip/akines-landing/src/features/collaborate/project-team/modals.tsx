'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { Button, Field, Modal, TextInput } from '@/ui';
import { CardLink } from '../workspace/parts';
import { useTeam } from './parts';

/**
 * Modal:Invite collaborator (17729:119986) and Modal:Not now (17729:120071). Both are 640 wide with the eyebrow, headline and support
 * line of the design, Line Fields, and the primary button with a Cancel link. The scrim, the close button, Escape and Cancel close them.
 * The design shows no validation: Send always works.
 */

const filled = (v: string) => (v.trim() ? 'pt-filled' : undefined);

/* ------------------------------------------------------------------ Modal:Invite collaborator */

export function InviteModal({ open, onClose, onSend }: { open: boolean; onClose: () => void; onSend: () => void }) {
  const { invite } = useTeam();
  const [who, setWho] = useState('');
  const [role, setRole] = useState('');
  const [message, setMessage] = useState('');

  // every opening starts again from the frame: all three fields empty
  useEffect(() => {
    if (open) {
      setWho('');
      setRole('');
      setMessage('');
    }
  }, [open]);

  const send = (e?: FormEvent) => {
    e?.preventDefault();
    onSend();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={invite.eyebrow}
      title={invite.title}
      description={invite.description}
      footer={
        <>
          <Button type="submit" form="pt-invite-form">
            {invite.send}
          </Button>
          <CardLink onClick={onClose}>{invite.cancel}</CardLink>
        </>
      }
    >
      <form id="pt-invite-form" className="cw-form pt-form" onSubmit={send} noValidate>
        <Field label={invite.name.label} hint={invite.name.hint}>
          <TextInput className={filled(who)} value={who} placeholder={invite.name.placeholder} onChange={(e) => setWho(e.target.value)} />
        </Field>
        <Field label={invite.role.label} hint={invite.role.hint}>
          <TextInput className={filled(role)} value={role} placeholder={invite.role.placeholder} onChange={(e) => setRole(e.target.value)} />
        </Field>
        <Field label={invite.message.label} hint={invite.message.hint}>
          <TextInput className={filled(message)} value={message} placeholder={invite.message.placeholder} onChange={(e) => setMessage(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal:Not now */

export function NotNowModal({ open, onClose, onSend }: { open: boolean; onClose: () => void; onSend: () => void }) {
  const { notNow } = useTeam();
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (open) setMessage('');
  }, [open]);

  const send = (e?: FormEvent) => {
    e?.preventDefault();
    onSend();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={notNow.eyebrow}
      title={notNow.title}
      description={notNow.description}
      footer={
        <>
          <Button type="submit" form="pt-notnow-form">
            {notNow.send}
          </Button>
          <CardLink onClick={onClose}>{notNow.cancel}</CardLink>
        </>
      }
    >
      <form id="pt-notnow-form" className="cw-form pt-form" onSubmit={send} noValidate>
        {/* the recipient is fixed (the toast names her); the field shows the Filled state of the design */}
        <Field label={notNow.to.label} hint={notNow.to.hint}>
          <TextInput className="pt-filled" value={notNow.to.value} readOnly />
        </Field>
        <Field label={notNow.message.label} hint={notNow.message.hint}>
          <TextInput className={filled(message)} value={message} placeholder={notNow.message.placeholder} onChange={(e) => setMessage(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}
