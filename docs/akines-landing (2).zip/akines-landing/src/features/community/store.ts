'use client';

/**
 * Community state: the Figma prototype variables ("Community Home state" collection) as one small store.
 * It lives at module level so choices survive route changes (Home, Messages, Care and so on).
 */
import { useSyncExternalStore } from 'react';

export type ModalId =
  | 'quick' | 'talk' | 'create' | 'circle' | 'play' | 'support'
  | 'cc-amara' | 'cc-folake' | 'cc-zine'
  | 'why-tunde' | 'why-ngozi' | 'why-chuka'
  | 'intro-tunde' | 'intro-ngozi' | 'intro-chuka'
  | 'up-project' | 'up-banter' | 'up-kin' | 'up-game'
  | 'inv-kin' | 'inv-walk'
  | 'encourage' | 'trust'
  | 'sent-invitation' | 'sent-intro' | 'sent-encourage' | 'sent-message';

export type Mood = 'none' | 'good' | 'okay' | 'low' | 'support';

export type ThreadMsg = { id: string; from: 'me' | 'them'; text: string; time: string };

export type CommunityState = {
  modal: ModalId | null;
  /** 1 to 8, the intention chip chosen on Home (0 shows no result band) */
  intention: number;
  /** Continue cards still showing: Amara, Folake */
  cont: [boolean, boolean];
  /** Introductions: cards shown, intro sent, "See more" opened */
  intro: { show: [boolean, boolean, boolean]; sent: [boolean, boolean, boolean]; more: boolean };
  /** Invitations: cards shown, accepted */
  inv: { show: [boolean, boolean]; acc: [boolean, boolean] };
  /** Reminder set in the four Upcoming panels */
  rem: [boolean, boolean, boolean, boolean];
  mood: Mood;
  /** Selected time slot (1 to 3) of each plan modal, keyed by modal id */
  slot: Record<string, 1 | 2 | 3>;
  /** Selected person (1 to 3) in Encourage / Message someone I trust */
  encourageWho: 1 | 2 | 3;
  trustWho: 1 | 2 | 3;
  /** Share why we matched toggles of the three Introduce us panels */
  share: [boolean, boolean, boolean];
  /** Drafts typed in the plan, introduce and message modals, keyed by modal id */
  draft: Record<string, string>;
  /** Banter (Join the conversation) and Lagos Makers Zine (Join the project) */
  banterJoined: boolean;
  zineJoined: boolean;
  /** Reflect privately: form open or saved, and the text */
  reflectSaved: boolean;
  reflectText: string;
  /** Settings: saved confirmation per screen and the values */
  saved: [boolean, boolean, boolean, boolean];
  prefs: {
    interests: string[];
    suggestCircles: boolean;
    useTimes: boolean;
    useIntention: boolean;
    showReason: boolean;
    showProfile: boolean;
    showCollabs: boolean;
    showActive: boolean;
    invitePolicy: 1 | 2 | 3;
    ways: string[];
    free: string[];
    remind: boolean;
    quietWhenBusy: boolean;
  };
  /** Messages appended per thread slug (on top of the Figma conversation) */
  sent: Record<string, ThreadMsg[]>;
  /** Home first visit shows the loading skeleton once */
};

const initial: CommunityState = {
  modal: null,
  intention: 1,
  cont: [true, true],
  intro: { show: [true, true, true], sent: [false, false, false], more: false },
  inv: { show: [true, true], acc: [false, false] },
  rem: [false, false, false, false],
  mood: 'none',
  slot: {},
  encourageWho: 1,
  trustWho: 1,
  share: [true, true, true],
  draft: {},
  banterJoined: false,
  zineJoined: false,
  reflectSaved: false,
  reflectText: 'A slow morning, one honest conversation with a friend, and time to finish the outreach plan.',
  saved: [false, false, false, false],
  prefs: {
    interests: ['Community health', 'Making and craft', 'Food systems'],
    suggestCircles: true,
    useTimes: true,
    useIntention: true,
    showReason: true,
    showProfile: true,
    showCollabs: false,
    showActive: false,
    invitePolicy: 1,
    ways: ['Short catch-ups', 'Making something together', 'Quiet company'],
    free: ['Evenings', 'Weekends'],
    remind: true,
    quietWhenBusy: false,
  },
  sent: {},
};

let state: CommunityState = initial;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}
export function setCommunity(patch: Partial<CommunityState> | ((s: CommunityState) => Partial<CommunityState>)) {
  const next = typeof patch === 'function' ? patch(state) : patch;
  state = { ...state, ...next };
  emit();
}
export function getCommunity() {
  return state;
}
export function useCommunity(): CommunityState {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => state,
    () => initial,
  );
}

/** Open a modal (or swap the open one for another: the Figma SWAP_OVERLAY reaction). */
export const openModal = (id: ModalId) => setCommunity({ modal: id });
export const closeModal = () => setCommunity({ modal: null });

export const setIntention = (n: number) => setCommunity({ intention: n });
export const dismissContinue = (i: 0 | 1) => setCommunity((s) => ({ cont: s.cont.map((v, k) => (k === i ? false : v)) as [boolean, boolean] }));
export const dismissIntro = (i: 0 | 1 | 2) =>
  setCommunity((s) => ({ intro: { ...s.intro, show: s.intro.show.map((v, k) => (k === i ? false : v)) as [boolean, boolean, boolean] } }));
export const sendIntro = (i: 0 | 1 | 2) =>
  setCommunity((s) => ({ intro: { ...s.intro, sent: s.intro.sent.map((v, k) => (k === i ? true : v)) as [boolean, boolean, boolean] } }));
export const seeMoreIntros = () => setCommunity((s) => ({ intro: { ...s.intro, more: true } }));
export const dismissInvite = (i: 0 | 1) =>
  setCommunity((s) => ({ inv: { ...s.inv, show: s.inv.show.map((v, k) => (k === i ? false : v)) as [boolean, boolean] } }));
export const acceptInvite = (i: 0 | 1) =>
  setCommunity((s) => ({ inv: { ...s.inv, acc: s.inv.acc.map((v, k) => (k === i ? true : v)) as [boolean, boolean] } }));
export const setReminder = (i: 0 | 1 | 2 | 3) => setCommunity((s) => ({ rem: s.rem.map((v, k) => (k === i ? true : v)) as CommunityState['rem'] }));
export const setMood = (m: Mood) => setCommunity((s) => ({ mood: s.mood === m ? 'none' : m }));
export const setSlot = (modal: string, n: 1 | 2 | 3) => setCommunity((s) => ({ slot: { ...s.slot, [modal]: n } }));
export const setDraft = (key: string, text: string) => setCommunity((s) => ({ draft: { ...s.draft, [key]: text } }));
export const setPrefs = (p: Partial<CommunityState['prefs']>) => setCommunity((s) => ({ prefs: { ...s.prefs, ...p } }));
export const markSaved = (i: 0 | 1 | 2 | 3) =>
  setCommunity((s) => ({ saved: s.saved.map((v, k) => (k === i ? true : v)) as CommunityState['saved'] }));
export const clearSaved = () => setCommunity({ saved: [false, false, false, false] });
export const appendMessage = (slug: string, text: string) =>
  setCommunity((s) => ({
    sent: { ...s.sent, [slug]: [...(s.sent[slug] ?? []), { id: `${slug}-${(s.sent[slug]?.length ?? 0) + 1}`, from: 'me', text, time: 'Just now' }] },
  }));

