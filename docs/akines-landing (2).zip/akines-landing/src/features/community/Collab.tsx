'use client';

/**
 * Collaborations (Figma 10.3: Community Health Initiative 17106:7625, Lagos Makers Zine 17106:7791) and Banter (10.6, 17106:7962).
 * A split page: content on the left, a full-height photograph on the right.
 */
import type { ReactNode } from 'react';
import { Button } from '@/ui';
import './community.css';
import { P, type AvKey } from './data';
import { openModal, setCommunity, useCommunity } from './store';
import { AvatarStack, IArrow, ICalendar, ICheck, ICheckCircle, ICircle, IClock, Photo, TextLink } from './ui';

function Split({ photo, children }: { photo: string; children: ReactNode }) {
  return (
    <div className="ch-page">
      <div className="ch-split">
        <div className="ch-split__main">{children}</div>
        <div className="ch-split__photo">
          <Photo name={photo} fill eager />
        </div>
      </div>
    </div>
  );
}

const Back = () => <TextLink href={P.home}>Back to Community Home</TextLink>;

type Step = { text: string; status: string; done?: boolean };

function Steps({ steps }: { steps: Step[] }) {
  return (
    <div className="ch-steps" data-m="stagger">
      {steps.map((st) => (
        <div className={`ch-step ${st.done ? 'ch-step--done' : 'ch-step--todo'}`} key={st.text}>
          {st.done ? <ICheckCircle /> : <ICircle />}
          <span className="ch-step__text">{st.text}</span>
          <span className="ch-step__status">{st.status}</span>
        </div>
      ))}
    </div>
  );
}

/** 10.3 Collaborations: Community Health Initiative with Amara (photo 17106:7790) */
export function Collaboration() {
  return (
    <Split photo="health-tall">
      <Back />
      <p className="ch-label">Collaboration · With Amara</p>
      <h1 className="ch-split__title" data-m="words">
        Community Health Initiative
      </h1>
      <p className="ch-split__desc">You and Amara are developing a community-health project.</p>
      <Steps
        steps={[
          { text: 'Agreed the three clinics to visit first', status: 'Done · Thursday', done: true },
          { text: 'Drafting the outreach plan, which you will send', status: 'In progress · This week' },
          { text: 'Plan the first clinic visit together', status: 'Next · Not yet planned' },
        ]}
      />
      <p className="ch-line">
        <IClock />
        <span>Last activity six days ago</span>
      </p>
      <div className="ch-acts">
        <Button iconRight={<IArrow />} href={P.thread('amara')}>
          Message Amara
        </Button>
        <Button variant="secondary" onClick={() => openModal('cc-amara')}>
          Arrange a Create Call
        </Button>
      </div>
    </Split>
  );
}

/** 10.3 Collaborations: Lagos Makers Zine (photo 17106:7961) */
export function ZineCollaboration() {
  const s = useCommunity();
  return (
    <Split photo="zine-tall">
      <Back />
      <p className="ch-label">Collaboration · With Folake and Chuka</p>
      <h1 className="ch-split__title" data-m="words">
        Lagos Makers Zine
      </h1>
      <p className="ch-split__desc">You, Folake and Chuka are putting together the second issue.</p>
      <Steps
        steps={[
          { text: 'Agreed the theme for the second issue', status: 'Done · Last month', done: true },
          { text: 'Collecting contributions from makers', status: 'In progress · This week' },
          { text: 'Lay out the pages and print', status: 'Next · Not yet planned' },
        ]}
      />
      <p className="ch-line">
        <IClock />
        <span>Last activity two days ago</span>
      </p>
      <div className="ch-acts">
        {s.zineJoined ? (
          <p className="ch-confirm" aria-live="polite">
            <ICheckCircle />
            <span>Contribution noted. Folake and Chuka will see it.</span>
          </p>
        ) : (
          <Button iconRight={<IArrow />} onClick={() => setCommunity({ zineJoined: true })}>
            Add a contribution
          </Button>
        )}
        <Button variant="secondary" onClick={() => openModal('cc-zine')}>
          Arrange a Create Call
        </Button>
      </div>
    </Split>
  );
}

/** 10.6 Banter (photo 17106:8134) */
export function Banter() {
  const s = useCommunity();
  const people: AvKey[] = ['folake', 'amara', 'chuka'];
  return (
    <Split photo="friends">
      <Back />
      <p className="ch-label">Banter · Open conversation</p>
      <h1 className="ch-split__title" data-m="words">
        Can ambition and rest coexist?
      </h1>
      <p className="ch-split__desc">An open conversation. Listen first, or join in when you feel like it.</p>
      <p className="ch-when">
        <ICalendar s={20} />
        <span>Today · 6:00 PM · 45 minutes</span>
      </p>
      <div className="ch-ppl">
        <AvatarStack people={people} size={40} overlap={10} />
        <span className="ch-ppl__text">Hosted by Folake, with Amara, Chuka and 10 others</span>
      </div>
      <p className="ch-label">How it works</p>
      <ul className="ch-bullets">
        {['A short prompt from the host', 'Open conversation, with no pressure to speak', 'A quiet minute to close'].map((t) => (
          <li key={t}>
            <ICheck />
            <span>{t}</span>
          </li>
        ))}
      </ul>
      <div className="ch-acts ch-acts--col">
        {s.banterJoined ? (
          <>
            <p className="ch-confirm" aria-live="polite">
              <ICheckCircle />
              <span>You are in. We will remind you at 5:45 PM.</span>
            </p>
            <TextLink onClick={() => setCommunity({ banterJoined: false })}>Leave Banter</TextLink>
          </>
        ) : (
          <Button iconRight={<IArrow />} onClick={() => setCommunity({ banterJoined: true })}>
            Join Banter
          </Button>
        )}
      </div>
    </Split>
  );
}
