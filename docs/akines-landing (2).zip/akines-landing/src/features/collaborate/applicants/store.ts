'use client';

/**
 * In-memory state of the applicant journeys 12.45 and 12.46 (module scope, lives for the whole visit like projects/store.ts):
 * the status of every person of both lists, the people ticked to compare (up to three, per list), the private notes (saved, and the text
 * in the field), the status a person had before Not now (for Undo) and whether the call is open or closed.
 *
 * Frames that show another state of the same page (Offer sent, Joined, Not now, Applicants ready, Closed, Compare selected) are seeded
 * into this state when their route opens, so everything on them keeps working (Undo, Shortlist, the next action).
 */
import { useLayoutEffect, useState, useSyncExternalStore } from 'react';
import { COMPARE, INITIAL_DRAFTS, INITIAL_NOTES, INITIAL_STATUS, ORDER, type ApplicantId, type Group, type Status } from './data';

export type State = {
  status: Record<ApplicantId, Status>;
  /** The status a person had before Not now, for Undo. */
  before: Partial<Record<ApplicantId, Status>>;
  /** Saved private notes. */
  notes: Partial<Record<ApplicantId, string>>;
  /** The text in the private note field (what is typed, saved or not). */
  drafts: Partial<Record<ApplicantId, string>>;
  /** The people ticked on each list, in the order they were ticked. */
  compare: Record<Group, ApplicantId[]>;
  callOpen: boolean;
};

const fresh = (): State => ({
  status: { ...INITIAL_STATUS },
  before: {},
  notes: { ...INITIAL_NOTES },
  drafts: { ...INITIAL_NOTES, ...INITIAL_DRAFTS },
  compare: { project: [], call: [] },
  callOpen: true,
});

let state: State = fresh();
const listeners = new Set<() => void>();
const set = (next: State) => {
  state = next;
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};
const get = () => state;

export const useApplicantState = () => useSyncExternalStore(subscribe, get, get);

/** Returns a copy of the state with one list put back to the start of the journey. */
function resetGroup(s: State, group: Group): State {
  const next: State = { ...s, status: { ...s.status }, before: { ...s.before }, notes: { ...s.notes }, drafts: { ...s.drafts }, compare: { ...s.compare, [group]: [] } };
  for (const id of ORDER[group]) {
    next.status[id] = INITIAL_STATUS[id];
    delete next.before[id];
    if (INITIAL_NOTES[id] !== undefined) next.notes[id] = INITIAL_NOTES[id];
    else delete next.notes[id];
    const draft = INITIAL_DRAFTS[id] ?? INITIAL_NOTES[id];
    if (draft !== undefined) next.drafts[id] = draft;
    else delete next.drafts[id];
  }
  if (group === 'call') next.callOpen = true;
  return next;
}

export type ProjectSeed = 'compare-selected' | 'offer-sent' | 'joined' | 'not-now';
export type CallSeed = 'compare-selected' | 'ready' | 'closed';

/** The state of a frame of 12.45 seeded on top of the start of the journey (a copy; the store is not touched). */
export function seededProject(base: State, seed: ProjectSeed): State {
  const next = resetGroup(base, 'project');
  if (seed === 'compare-selected') next.compare.project = ['amina', 'kunle'];
  if (seed === 'offer-sent') next.status.funmi = 'Offer sent';
  if (seed === 'joined') next.status.chidi = 'Joined';
  if (seed === 'not-now') {
    next.before.amina = next.status.amina;
    next.status.amina = 'Not now';
  }
  return next;
}
/** The same for a frame of 12.46. */
export function seededCall(base: State, seed: CallSeed): State {
  const next = resetGroup(base, 'call');
  if (seed === 'compare-selected') next.compare.call = ['folake', 'tunde'];
  if (seed === 'ready' || seed === 'closed') {
    next.status.folake = 'Shortlisted';
    next.status.tunde = 'Shortlisted';
  }
  if (seed === 'closed') next.callOpen = false;
  return next;
}

export const applicants = {
  /** A frame of 12.45 or 12.46 that shows another state of the page: put the list back to the start, then apply the state. */
  seedProject(seed: ProjectSeed) {
    set(seededProject(state, seed));
  },
  seedCall(seed: CallSeed) {
    set(seededCall(state, seed));
  },

  setStatus(id: ApplicantId, status: Status) {
    set({ ...state, status: { ...state.status, [id]: status } });
  },
  shortlist(id: ApplicantId) {
    applicants.setStatus(id, 'Shortlisted');
  },
  sendOffer(id: ApplicantId) {
    applicants.setStatus(id, 'Offer sent');
  },
  /** Not now: the person stays on the list (dimmed) and Undo puts the earlier status back. */
  markNotNow(id: ApplicantId) {
    if (state.status[id] === 'Not now') return;
    set({ ...state, before: { ...state.before, [id]: state.status[id] }, status: { ...state.status, [id]: 'Not now' } });
  },
  undoNotNow(id: ApplicantId) {
    if (state.status[id] !== 'Not now') return;
    const before = { ...state.before };
    const back = before[id] ?? 'New';
    delete before[id];
    set({ ...state, before, status: { ...state.status, [id]: back } });
  },

  setDraft(id: ApplicantId, text: string) {
    set({ ...state, drafts: { ...state.drafts, [id]: text } });
  },
  /** Save note: the text in the field becomes the saved note (read by the compare table). */
  saveNote(id: ApplicantId) {
    set({ ...state, notes: { ...state.notes, [id]: (state.drafts[id] ?? '').trim() }, drafts: { ...state.drafts, [id]: (state.drafts[id] ?? '').trim() } });
  },

  /** Tick or untick a person to compare. At most three per list: a fourth tick is ignored. Returns whether the tick went through. */
  toggleCompare(group: Group, id: ApplicantId): boolean {
    const list = state.compare[group];
    if (list.includes(id)) {
      set({ ...state, compare: { ...state.compare, [group]: list.filter((x) => x !== id) } });
      return true;
    }
    if (list.length >= COMPARE.max) return false;
    set({ ...state, compare: { ...state.compare, [group]: [...list, id] } });
    return true;
  },
  setCompare(group: Group, ids: ApplicantId[]) {
    set({ ...state, compare: { ...state.compare, [group]: ids.slice(0, COMPARE.max) } });
  },
  clearCompare(group: Group) {
    if (state.compare[group].length === 0) return;
    set({ ...state, compare: { ...state.compare, [group]: [] } });
  },

  closeCall() {
    set({ ...state, callOpen: false });
  },
  reopenCall() {
    set({ ...state, callOpen: true });
  },
};

/** The sample pair the Compare frames show (Amina and Kunle, Folake and Tunde): a Compare page opened without anyone ticked shows them. */
export const SAMPLE_COMPARE: Record<Group, ApplicantId[]> = { project: ['amina', 'kunle'], call: ['folake', 'tunde'] };

/* ------------------------------------------------------------------ derived */

export const peopleOf = (s: State, group: Group) => ORDER[group].map((id) => ({ id, status: s.status[id] }));

export function countsOf(s: State, group: Group): Record<Status, number> {
  const counts: Record<Status, number> = { New: 0, Shortlisted: 0, 'Talk booked': 0, 'Offer sent': 0, Joined: 0, 'Not now': 0 };
  for (const id of ORDER[group]) counts[s.status[id]] += 1;
  return counts;
}

/** Note state of the Private Note component: Empty (nothing typed), Focus (typed, not saved), Saved (typed and saved). */
export function noteState(s: State, id: ApplicantId): 'empty' | 'draft' | 'saved' {
  const draft = (s.drafts[id] ?? '').trim();
  const saved = (s.notes[id] ?? '').trim();
  if (draft && draft === saved) return 'saved';
  if (draft) return 'draft';
  return 'empty';
}

/**
 * The state a page reads. A page opened at a frame that shows another state of the list (".../state-offer-sent", "Applicants, ready")
 * shows that state from its first render, then writes it into the store when it mounts, so Undo and the next action keep working on it.
 */
export function useSeeded(group: Group, seed?: ProjectSeed | CallSeed): State {
  const s = useApplicantState();
  const [applied, setApplied] = useState(false);
  useLayoutEffect(() => {
    if (!seed) return;
    if (group === 'project') applicants.seedProject(seed as ProjectSeed);
    else applicants.seedCall(seed as CallSeed);
    setApplied(true);
    // the seed belongs to the route: once per opening of the page
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (!seed || applied) return s;
  return group === 'project' ? seededProject(s, seed as ProjectSeed) : seededCall(s, seed as CallSeed);
}
