'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { Button, Field, Modal, TextInput } from '@/ui';
import { CardLink } from '../workspace/parts';
import { useDecisionsData } from './parts';

/**
 * Modal:Propose decision (17729:120858) and Modal:Acknowledge decision (17729:120932). Both are 640 wide with the eyebrow, headline and
 * support line of the design. The scrim, the close button and Cancel close the modal; the primary button leads to the toast of the design.
 * A field with a value shows the dark border of the Filled state (the milestone field has one when the modal opens).
 */

const filled = (v: string) => (v.trim() ? 'dc-filled' : undefined);

/* ------------------------------------------------------------------ Modal: Propose decision */

export function ProposeModal({ open, onClose, onPropose }: { open: boolean; onClose: () => void; onPropose: () => void }) {
  // the copy is that of the project of the page
  const { propose } = useDecisionsData();
  const f = propose.fields;
  const [title, setTitle] = useState('');
  const [problem, setProblem] = useState('');
  const [options, setOptions] = useState('');
  const [milestone, setMilestone] = useState(f.milestone.value);

  // every opening starts again from the frame: three empty fields and the milestone filled
  useEffect(() => {
    if (open) {
      setTitle('');
      setProblem('');
      setOptions('');
      setMilestone(f.milestone.value);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    onPropose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={propose.eyebrow}
      title={propose.title}
      description={propose.description}
      footer={
        <>
          <Button type="submit" form="dc-propose-form">
            {propose.submit}
          </Button>
          <CardLink onClick={onClose}>{propose.cancel}</CardLink>
        </>
      }
    >
      <form id="dc-propose-form" className="cw-form" onSubmit={submit} noValidate>
        <Field label={f.title.label} hint={f.title.hint}>
          <TextInput className={filled(title)} value={title} placeholder={f.title.placeholder} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label={f.problem.label} hint={f.problem.hint}>
          <TextInput className={filled(problem)} value={problem} placeholder={f.problem.placeholder} onChange={(e) => setProblem(e.target.value)} />
        </Field>
        <Field label={f.options.label} hint={f.options.hint}>
          <TextInput className={filled(options)} value={options} placeholder={f.options.placeholder} onChange={(e) => setOptions(e.target.value)} />
        </Field>
        <Field label={f.milestone.label} hint={f.milestone.hint}>
          <TextInput className={filled(milestone)} value={milestone} onChange={(e) => setMilestone(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal: Acknowledge decision */

export function AcknowledgeModal({ open, onClose, onAcknowledge }: { open: boolean; onClose: () => void; onAcknowledge: () => void }) {
  const { acknowledge } = useDecisionsData();
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={acknowledge.eyebrow}
      title={acknowledge.title}
      description={acknowledge.description}
      footer={
        <>
          <Button onClick={onAcknowledge}>{acknowledge.submit}</Button>
          <CardLink onClick={onClose}>{acknowledge.cancel}</CardLink>
        </>
      }
    >
      <div className="dc-summary">
        {acknowledge.summary.map((s) => (
          <div className="dc-summary__item" key={s.label}>
            <p className="dc-summary__label">{s.label}</p>
            <p className={s.small ? 'dc-summary__text dc-summary__text--small' : 'dc-summary__text'}>{s.text}</p>
          </div>
        ))}
      </div>
    </Modal>
  );
}
