/**
 * Copy, sample data and validation rules of the join flow (Figma section 08, frames 1a to 5).
 * Pure functions only, so the screen file stays about layout and state.
 */
import { DUMMY } from '@/lib/auth';

/* ---------- step 1: email or mobile number ---------- */
export type ContactKind = 'email' | 'mobile';
export type ContactCheck = { ok: true; kind: ContactKind; value: string } | { ok: false; error: 'missing' | 'invalid' };

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const MOBILE_DIGITS = /^\+?\d{10,14}$/;

export function checkContact(raw: string): ContactCheck {
  const value = raw.trim();
  if (!value) return { ok: false, error: 'missing' };
  if (EMAIL.test(value)) return { ok: true, kind: 'email', value };
  if (MOBILE_DIGITS.test(value.replace(/[\s().-]/g, ''))) return { ok: true, kind: 'mobile', value };
  return { ok: false, error: 'invalid' };
}

/** Accounts that already exist (the "Already registered" state). The dummy account is NOT here, so its values walk the happy path. */
const REGISTERED = ['ndegoyit@example.com', 'amara@example.com', 'folake@example.com', 'hello@akines.com', '08031234567', '+2348031234567'];
export const isRegistered = (value: string): boolean => {
  const v = value.trim().toLowerCase();
  // emails compare as typed, numbers without spaces, brackets, dots and dashes
  return REGISTERED.includes(v.includes('@') ? v : v.replace(/[\s().-]/g, ''));
};

/* ---------- step 2: the code ---------- */
export type CodeCheck = 'ok' | 'missing' | 'wrong' | 'expired';
/** DUMMY.code is the good one, 000000 plays an expired code, any other six digits do not match. */
export const EXPIRED_CODE = '000000';
export function checkCode(digits: string): CodeCheck {
  if (digits.length < 6) return 'missing';
  if (digits === DUMMY.code) return 'ok';
  if (digits === EXPIRED_CODE) return 'expired';
  return 'wrong';
}
/** "123456" shown as "123 456" (the Figma placeholder and sample values are grouped). */
export const groupCode = (digits: string): string => (digits.length > 3 ? `${digits.slice(0, 3)} ${digits.slice(3)}` : digits);
export const onlyDigits = (v: string, max = 6): string => v.replace(/\D/g, '').slice(0, max);

/* ---------- step 3: username and password ---------- */
export const stripAt = (v: string): string => v.trim().replace(/^@/, '');
const USERNAME = /^[A-Za-z0-9_.]{3,20}$/;
const TAKEN_USERNAMES = ['ndegoyit', 'akines', 'admin', 'community', 'support', 'kemi'];

export type UsernameCheck = 'missing' | 'invalid' | 'taken' | 'available';
export function checkUsername(raw: string): UsernameCheck {
  const v = stripAt(raw);
  if (!v) return 'missing';
  if (!USERNAME.test(v)) return 'invalid';
  if (TAKEN_USERNAMES.includes(v.toLowerCase())) return 'taken';
  return 'available';
}
/** Figma 3c chips: name_, name24 and the.name */
export const suggestUsernames = (raw: string): string[] => {
  const v = stripAt(raw).slice(0, 14);
  return [`@${v}_`, `@${v}24`, `@the.${v}`];
};

export type Strength = 'empty' | 'weak' | 'okay' | 'strong';
/**
 * Length based, as in the design ("12 or more characters"): under 12 is weak, 12 to 15 is okay, 16 and over is strong.
 * The dummy password (17 characters) therefore reads as strong.
 */
export function passwordStrength(pw: string): Strength {
  if (!pw) return 'empty';
  if (pw.length < 12) return 'weak';
  return pw.length < 16 ? 'okay' : 'strong';
}
export const passwordAccepted = (pw: string): boolean => {
  const s = passwordStrength(pw);
  return s === 'okay' || s === 'strong';
};
export const STRENGTH_LABEL: Record<Strength, string> = {
  empty: 'Use 12 or more characters.',
  weak: 'Weak. Add more characters.',
  okay: 'Okay. A longer phrase is stronger.',
  strong: 'Strong. Nice.',
};

/* ---------- step 4: what brings you here ---------- */
export type Reason = { id: number; label: string; photo: string };
/** Photos are the landing photographs (public/images). */
export const REASONS: Reason[] = [
  { id: 1, label: 'I want to see how others do their work', photo: 'create' },
  { id: 2, label: 'I feel stuck or burnt out', photo: 'wellbeing' },
  { id: 3, label: 'I want to write about my life', photo: 'creation' },
  { id: 4, label: "I'm far from home", photo: 'continuity' },
  { id: 5, label: "I'm lonely and want to talk", photo: 'conversation' },
  { id: 6, label: 'I want to meet people like me', photo: 'kincircle' },
  { id: 7, label: 'I want to learn something new', photo: 'immersive' },
  { id: 8, label: "I'm starting a business", photo: 'mystore' },
  { id: 9, label: "I'm looking for collaborators", photo: 'playtogether' },
];
/** The live flow starts with this one chosen (Figma 4b) so the Confirm button completes the step. */
export const DEFAULT_REASON = 5;

/* ---------- timings (Figma AFTER_TIMEOUT reactions) ---------- */
export const T = { sending: 1500, provider: 1800, checking: 1600, creating: 1500, confirming: 1400, exit: 200 } as const;
