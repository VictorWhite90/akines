'use client';

import '../workspace/workspace.css';
import './tasks.css';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { useNav, usePath } from '@/lib/nav';
import { Button, EmptyState, toast, type ButtonProps } from '@/ui';
import { MetricCard, MetricRow } from '../workspace/dash';
import { CardLink, PageHead } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { FRAME_FILTERS, YOU, matches, sortTasks, STATUSES, viewPaths, type Filters, type Task } from './data';
import { FilterMenu } from './menus';
import { CreateTaskModal } from './modals';
import { BoardCard, MilestoneHead, Popover, TaskRow, TasksFrame, ViewTabs } from './parts';
import { useTasksActions, useTasksData, useTasksStore } from './store';

/**
 * 12.14 Tasks: Tasks (List), Board view, Milestone view and Empty, with Modal:Create task, Dropdown:Filter tasks and Toast:Task created.
 * Every screen shows three metric cards (Open, In review, Assigned to you) in the page header. List and Milestone view show the shared
 * project rail (Empty the short one); the Board has no right column (a 1088 centre). The Tasks page has no cards or rail of its own.
 * The three views are three screens (each tab opens its own page, as in the prototype). The "state-" routes are the Figma frames
 * that have no natural trigger: the empty list and the overlay frames (see routes.tsx).
 * Controls with no destination in the design are shown and do nothing: Filter tasks on Board, Milestone view and Empty (only the List
 * opens the menu), View milestones on Milestone view and Empty, View milestone of Prototype Review, Review work, and every task row
 * and card except "Write the guided onboarding questions".
 * The same pages (List, Board view, Milestone view) also run for Adire Stories under its own root: the tasks, people, milestones and copy
 * come from the project of the page (useTasksData), each project has its own store, and no task row or card is a link on Adire
 * (it has no task detail screens).
 */

const TOAST_MS = 2500;
/** The toast of the "state-task-created" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

/* ------------------------------------------------------------------ create task (modal, toast, new task in the store) */

/**
 * Create task in the modal adds the task to the store, goes to the List (from any other screen too) and shows "Task created".
 * The toast's Undo takes the new task off the list again.
 */
function useCreate(startOpen = false) {
  const nav = useNav();
  const path = usePath();
  const { root } = useProject();
  const { copy } = useTasksData();
  const store = useTasksActions();
  const [open, setOpen] = useState(startOpen);
  const created = (task: Task) => {
    store.add(task);
    setOpen(false);
    const list = viewPaths(root).list;
    if (path !== list) nav.push(list);
    toast.show({ message: copy.created, actionLabel: 'Undo', duration: TOAST_MS, onAction: () => store.remove(task.id) });
  };
  return {
    openModal: () => setOpen(true),
    modal: <CreateTaskModal open={open} onClose={() => setOpen(false)} onCreate={created} />,
  };
}

/* ------------------------------------------------------------------ page header */

type Page = 'list' | 'board' | 'milestones' | 'empty';

const FilterButton = (props: Omit<ButtonProps, 'variant' | 'icon' | 'children'>) => (
  <Button variant="secondary" icon={<SlidersHorizontal aria-hidden="true" focusable="false" strokeWidth={1.5} />} {...props}>
    Filter tasks
  </Button>
);

const noun = (n: number) => (n === 1 ? 'task' : 'tasks');

/**
 * Header of every view: the title, three metric cards (Open, In review, Assigned to you), Create task, Filter tasks and View milestones.
 * The cards have no destination in the design (their reactions only change the card to its hover and pressed look). `zero` is the Empty frame.
 */
function Header({ page, zero, onCreate, filter }: { page: Page; zero?: boolean; onCreate: () => void; filter?: ReactNode }) {
  const tasks = useTasksStore((s) => s.tasks);
  const { copy } = useTasksData();
  const paths = viewPaths(useProject().root);
  const open = zero ? 0 : tasks.filter((t) => t.status !== 'Completed').length;
  const review = zero ? 0 : tasks.filter((t) => t.status === 'In review').length;
  const mine = zero ? 0 : tasks.filter((t) => t.owner === YOU && t.status !== 'Completed').length;
  return (
    <PageHead label={copy.label} title={copy.title} lead={copy.lead}>
      <div className="tk-metrics">
        <MetricRow>
          <MetricCard label="OPEN" value={open} caption={noun(open)} />
          <MetricCard label="IN REVIEW" value={review} caption={noun(review)} />
          <MetricCard label="ASSIGNED TO YOU" value={mine} caption={noun(mine)} dot={mine > 0} />
        </MetricRow>
      </div>
      <div className="cw-actions cw-actions--btns">
        <Button onClick={onCreate}>Create task</Button>
        {filter ?? <FilterButton />}
        {page === 'list' || page === 'board' ? <CardLink href={paths.milestones}>View milestones</CardLink> : <CardLink>View milestones</CardLink>}
      </div>
    </PageHead>
  );
}

/* ------------------------------------------------------------------ List */

function ListView() {
  const tasks = useTasksStore((s) => s.tasks);
  const filters = useTasksStore((s) => s.filters);
  const shown = useMemo(() => sortTasks(tasks.filter((t) => matches(t, filters))), [tasks, filters]);
  const open = shown.filter((t) => t.status !== 'Completed');
  const done = shown.filter((t) => t.status === 'Completed');
  return (
    <section className="tk-views" data-m="up" aria-label="Tasks">
      <ViewTabs active="list" />
      <div className="tk-list">
        <div className="tk-heads" aria-hidden="true">
          <span className="tk-heads__task">TASK</span>
          <span className="tk-heads__owner" />
          <span className="tk-heads__status">STATUS</span>
          <span className="tk-heads__due">DUE</span>
        </div>
        {shown.length === 0 ? <p className="tk-list__none">No tasks match these filters.</p> : null}
        {open.length > 0 ? (
          <>
            <h2 className="tk-group">OPEN ({open.length})</h2>
            <ul className="tk-rows">
              {open.map((t) => (
                <li key={t.id}>
                  <TaskRow task={t} withMilestone />
                </li>
              ))}
            </ul>
          </>
        ) : null}
        {done.length > 0 ? (
          <>
            <h2 className="tk-group">COMPLETED ({done.length})</h2>
            <ul className="tk-rows">
              {done.map((t) => (
                <li key={t.id}>
                  <TaskRow task={t} withMilestone />
                </li>
              ))}
            </ul>
          </>
        ) : null}
      </div>
    </section>
  );
}

function ListScreen({ filterOpen, createOpen, createdToast }: { filterOpen?: boolean; createOpen?: boolean; createdToast?: boolean }) {
  const create = useCreate(createOpen);
  const store = useTasksActions();
  const { copy } = useTasksData();
  const filters = useTasksStore((s) => s.filters);
  const [menu, setMenu] = useState(Boolean(filterOpen));
  // the "state-filter-tasks" frame opens with In progress ticked; every later opening starts from the filters that are applied
  const [frame, setFrame] = useState<Filters | null>(filterOpen ? FRAME_FILTERS : null);
  const closeMenu = () => {
    setMenu(false);
    setFrame(null);
  };

  // the "state-task-created" frame: the List with the toast already showing
  useEffect(() => {
    if (createdToast) toast.show({ message: copy.created, actionLabel: 'Undo', duration: STATE_TOAST_MS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [createdToast]);

  return (
    <TasksFrame rail>
      <Header
        page="list"
        onCreate={create.openModal}
        filter={
          <Popover
            open={menu}
            onClose={closeMenu}
            trigger={<FilterButton data-tk-trigger="" aria-haspopup="dialog" aria-expanded={menu} onClick={() => setMenu((o) => !o)} />}
          >
            <FilterMenu
              initial={frame ?? filters}
              onApply={(f) => {
                store.setFilters(f);
                closeMenu();
              }}
            />
          </Popover>
        }
      />
      <ListView />
      {create.modal}
    </TasksFrame>
  );
}

export const TasksList = () => <ListScreen />;
/** Frame "Modal:Create task": the List with the modal open. */
export const TasksCreateModal = () => <ListScreen createOpen />;
/** Frame "Toast:Task created": the List with the toast showing. */
export const TasksCreated = () => <ListScreen createdToast />;
/** Frame "Dropdown:Filter tasks": the List with the filter menu open. */
export const TasksFilter = () => <ListScreen filterOpen />;

/* ------------------------------------------------------------------ Board view */

export function TasksBoard() {
  const create = useCreate();
  const tasks = useTasksStore((s) => s.tasks);
  const sorted = useMemo(() => sortTasks(tasks), [tasks]);
  return (
    <TasksFrame wide>
      <Header page="board" onCreate={create.openModal} />
      <section className="tk-views" data-m="up" aria-label="Tasks">
        <ViewTabs active="board" />
        <div className="tk-board">
          {STATUSES.map((s) => {
            const cards = sorted.filter((t) => t.status === s);
            return (
              <section className="tk-col" key={s} aria-label={s}>
                <header className="tk-col__head">
                  <h2 className="tk-col__title">{s.toUpperCase()}</h2>
                  <span className="tk-col__count">{cards.length}</span>
                </header>
                <ul className="tk-col__cards">
                  {cards.map((t) => (
                    <li key={t.id}>
                      <BoardCard task={t} />
                    </li>
                  ))}
                </ul>
              </section>
            );
          })}
        </div>
      </section>
      {create.modal}
    </TasksFrame>
  );
}

/* ------------------------------------------------------------------ Milestone view */

export function TasksMilestones() {
  const create = useCreate();
  const { milestones } = useTasksData();
  const tasks = useTasksStore((s) => s.tasks);
  const sorted = useMemo(() => sortTasks(tasks), [tasks]);
  return (
    <TasksFrame rail>
      <Header page="milestones" onCreate={create.openModal} />
      <section className="tk-views tk-views--groups" data-m="up" aria-label="Tasks">
        <ViewTabs active="milestones" />
        {milestones.map((m) => {
          const group = sorted.filter((t) => t.milestone === m.name);
          if (group.length === 0) return null;
          return (
            <section className="tk-msgroup" key={m.name} aria-label={m.name}>
              <MilestoneHead name={m.name} done={group.filter((t) => t.status === 'Completed').length} total={group.length} />
              <div className="tk-list">
                <ul className="tk-rows">
                  {group.map((t) => (
                    <li key={t.id}>
                      <TaskRow task={t} />
                    </li>
                  ))}
                </ul>
              </div>
            </section>
          );
        })}
      </section>
      {create.modal}
    </TasksFrame>
  );
}

/* ------------------------------------------------------------------ Empty */

/** The empty list: zero counts and the Empty State. Create task (header or Empty State) opens the modal; creating goes to the List. */
export function TasksEmpty() {
  const create = useCreate();
  const { copy } = useTasksData();
  return (
    <TasksFrame rail="short">
      <Header page="empty" zero onCreate={create.openModal} />
      <div className="tk-empty" data-m="up">
        <EmptyState
          className="cw-empty"
          title={copy.empty.title}
          text={copy.empty.text}
          action={
            <Button arrow="up-right" onClick={create.openModal}>
              Create task
            </Button>
          }
        />
      </div>
      {create.modal}
    </TasksFrame>
  );
}
