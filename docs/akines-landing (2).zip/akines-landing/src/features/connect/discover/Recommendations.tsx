'use client';

/**
 * 04 People whose journeys complement yours: four "Someone to meet" cards (PRD section 04). Figma section 17893:108776,
 * Recommendation Card set 17897:20909 (Default, Hover, Focus, Sent, Dismissed), Section Label Tag 17897:20951. Styles: recs.css (dxr-).
 *
 * Wiring (unchanged from the stub):
 *  - Props: `failing` starts the section in its error state (state route), `empty` shows the empty state. The section keeps its label
 *    and heading in every phase. "Try again" shows the skeleton for RETRY_MS (900 ms) and then the live cards; the other sections are untouched.
 *  - useDiscover().recStatus(rec.id) is 'idle' | 'sent' | 'dismissed'. idle: both buttons. sent: sentNote(rec) replaces them.
 *    dismissed: dismissedNote(rec) with an Undo button. sayHello(id), dismiss(id) and undo(id) (state.ts) change the status and track.
 *  - useRecommendationView(cardRef, rec.id) reports recommendation_view once per card per visit.
 *  - The profile (photo, name and place are one link) opens that person's profile page (Figma 11.73) and calls track('recommendation_profile_click', ...).
 *  - The header link "See all" goes to All suggestions; DxSection reports it through onLinkClick as recommendation_see_all.
 *  - There is no pager in the design, so recommendation_next and recommendation_previous are not sent from here.
 *
 * Sizes stay the same in every state: the Sent note takes the place of the buttons (same 62 px slot), and the Dismissed note
 * is laid over the card while the card's own content stays in the layout (hidden and inert), so the card never changes size.
 * Focus follows the member's action: Say hello moves it to the note, Not now to Undo, Undo back to Not now.
 */
import './recs.css';
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/ui';
import { Link } from '@/lib/nav';
import { AssistantMark } from '@/components/AssistantMark';
import { track, useRecommendationView } from './analytics';
import {
  RECOMMENDATIONS,
  RECS_COPY,
  RETRY_MS,
  STATE_COPY,
  dismissedNote,
  matchLabel,
  profilePath,
  recPosition,
  sentNote,
  slugOf,
  type Recommendation,
} from './data';
import { src } from './images';
import { DxSection } from './parts';
import { CardsSkeleton, EmptyText, SectionError } from './states';
import { dismiss, sayHello, undo, useDiscover } from './state';

type Phase = 'error' | 'loading' | 'live';
/** Where focus goes once the status of the card has changed because of the member's action. */
type FocusTarget = 'sent' | 'undo' | 'not-now';

/** One Someone to meet card. Also the card of All suggestions (Suggestions.tsx). */
export function RecCard({ rec, index }: { rec: Recommendation; index: number }) {
  const ref = useRef<HTMLLIElement>(null);
  useRecommendationView(ref, rec.id);
  const status = useDiscover().recStatus(rec.id);

  const notNow = useRef<HTMLButtonElement | HTMLAnchorElement>(null);
  const sentNoteEl = useRef<HTMLParagraphElement>(null);
  const undoBtn = useRef<HTMLButtonElement>(null);
  const focusAfter = useRef<FocusTarget | null>(null);
  useEffect(() => {
    const want = focusAfter.current;
    focusAfter.current = null;
    if (want === 'sent' && status === 'sent') sentNoteEl.current?.focus();
    else if (want === 'undo' && status === 'dismissed') undoBtn.current?.focus();
    else if (want === 'not-now' && status === 'idle') notNow.current?.focus();
  }, [status]);

  const nameId = `dxr-name-${rec.id}`;
  const noteId = `dxr-note-${rec.id}`;
  const onHello = () => {
    focusAfter.current = 'sent';
    sayHello(rec.id);
  };
  const onNotNow = () => {
    focusAfter.current = 'undo';
    dismiss(rec.id);
  };
  const onUndo = () => {
    focusAfter.current = 'not-now';
    undo(rec.id);
  };

  return (
    <li ref={ref} className="dxr-card" data-status={status} style={{ ['--dxr-i' as string]: index }}>
      <div className="dxr-card__body" inert={status === 'dismissed'}>
        <div className="dxr-top">
          <p className="dxr-eyebrow">{RECS_COPY.heading}</p>
          <p className="dxr-match">{matchLabel(rec)}</p>
        </div>

        <Link
          href={profilePath(slugOf(rec.name))}
          className="dxr-who"
          onClick={() => track('recommendation_profile_click', { recommendation_id: rec.id, position: recPosition(rec.id), source: 'section' })}
        >
          <span className="dxr-photo">
            <img src={src(rec.image)} alt="" width={72} height={72} loading="lazy" decoding="async" draggable={false} />
          </span>
          <span className="dxr-who__text">
            <span className="dxr-name" id={nameId}>
              {rec.name}
            </span>
            <span className="dxr-role">{rec.identity}</span>
          </span>
        </Link>

        <ul className="dxr-tags">
          {rec.tags.map((tag) => (
            <li key={tag}>{tag}</li>
          ))}
        </ul>

        <p className="dxr-reason">{`“${rec.prompt}”`}</p>

        {/* One slot for the buttons and for the note that replaces them: same height, so the card keeps its size */}
        <div className="dxr-slot">
          {status === 'sent' ? (
            <p className="dxr-sent" ref={sentNoteEl} tabIndex={-1}>
              {sentNote(rec)}
            </p>
          ) : (
            <div className="dxr-actions">
              <Button variant="secondary" fullWidth ref={notNow} onClick={onNotNow} aria-describedby={nameId}>
                {RECS_COPY.notNow}
              </Button>
              <Button fullWidth onClick={onHello} aria-describedby={nameId}>
                {RECS_COPY.sayHello}
              </Button>
            </div>
          )}
        </div>
      </div>

      {status === 'dismissed' ? (
        <div className="dxr-dismissed">
          <p className="dxr-dismissed__text" id={noteId}>
            {dismissedNote(rec)}
          </p>
          <button type="button" className="fd-link" ref={undoBtn} onClick={onUndo} aria-describedby={noteId}>
            {RECS_COPY.undo}
          </button>
        </div>
      ) : null}
    </li>
  );
}

export function Recommendations({ empty, failing }: { empty?: boolean; failing?: boolean }) {
  const [phase, setPhase] = useState<Phase>(failing ? 'error' : 'live');
  useEffect(() => {
    if (phase !== 'loading') return;
    const t = window.setTimeout(() => setPhase('live'), RETRY_MS);
    return () => window.clearTimeout(t);
  }, [phase]);

  return (
    <DxSection section="recommendations" className="dxr-section" onLinkClick={() => track('recommendation_see_all')}>
      {/* Drawn above the heading (Figma Section Label Tag); it comes after the header in the DOM so the heading stays first for assistive technology */}
      <p className="dxr-label">
        <AssistantMark colourway="deep-amber-on-ivory" size={16} decorative />
        <span>{RECS_COPY.label}</span>
      </p>
      {phase === 'error' ? (
        <SectionError onRetry={() => setPhase('loading')} />
      ) : phase === 'loading' ? (
        <CardsSkeleton cards={4} />
      ) : empty ? (
        <EmptyText>{STATE_COPY.recommendationsEmpty}</EmptyText>
      ) : (
        <div className="dxr-cards">
          <ul className="dxr-grid">
            {RECOMMENDATIONS.map((rec, i) => (
              <RecCard key={rec.id} rec={rec} index={i} />
            ))}
          </ul>
        </div>
      )}
    </DxSection>
  );
}
