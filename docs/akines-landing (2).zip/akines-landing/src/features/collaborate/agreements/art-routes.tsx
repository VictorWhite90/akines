import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { AP } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Only the Agreements page is mirrored. The stage pages (Roles, Formal Agreement, Acknowledged), the empty page and the overlay frames are not:
 * the stage cards of Adire Stories have no destination, and the Create agreement modal and its toast work on the Agreements page itself.
 */
const MIRRORED: string[] = [AP.overview];

export const artRoutes: RouteDef[] = routes.filter((r) => MIRRORED.includes(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
