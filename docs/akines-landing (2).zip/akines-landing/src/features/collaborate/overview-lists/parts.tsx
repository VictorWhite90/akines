'use client';

/**
 * Pieces shared by the three lists behind the Collaborate Home count tiles (12.48, 12.49, 12.50): the page frame (back link, header,
 * tab row with its count), the Empty panel, the Loading skeletons, the Awaiting Decision Row (17972:140296) and the Introduction
 * Request (17972:142869). Every class is prefixed ol- (overview-lists.css); the request card reuses the Interest Request of the Team
 * page (pt-req, 17729:98852) it was cloned from.
 */
import './overview-lists.css';
import '../workspace/workspace.css';
import '../project-team/team.css';
import type { ReactNode } from 'react';
import { Link } from '@/lib/nav';
import { Button } from '@/ui';
import { BackLink, Bar, CardLink } from '../projects/ui';
import { StatusTag } from '../decisions/parts';
import { Over } from '../workspace/parts';
import { Photo, SkillTags } from '../project-team/parts';
import { AWAITING_STATUS, BACK, INTRODUCTION, type AwaitingDecision } from './data';

/* ------------------------------------------------------------------ page frame */

type FrameProps = {
  eyebrow: string;
  title: string;
  lead: string;
  tab: string;
  /** The count at the right of the tab row ("2 decisions", "Loading"). */
  count: string;
  busy?: boolean;
  children: ReactNode;
};

/**
 * Figma frame of a list: Back link, Header row (eyebrow, serif title, support), Tabs (one open tab and the count) and the results.
 * Content is 1384 wide with 64 px sides, 48 px between the blocks, 72 px under the header and 120 px at the bottom.
 */
export function ListPage({ eyebrow, title, lead, tab, count, busy, children }: FrameProps) {
  return (
    <div className="ol-page">
      <div className="ol-stack">
        <BackLink href={BACK.href}>{BACK.label}</BackLink>
        <header className="ol-head">
          <p className="ol-eyebrow" data-m="up">
            {eyebrow}
          </p>
          <h1 className="ol-h1" data-m="words">
            {title}
          </h1>
          <p className="ol-lead" data-m="up">
            {lead}
          </p>
        </header>
        <div className="ol-tabs">
          <span className="ol-tab" aria-current="page">
            {tab}
          </span>
          <span className="ol-count" aria-live="polite">
            {count}
          </span>
        </div>
        <section className="ol-results" aria-label={title} aria-busy={busy || undefined}>
          {children}
        </section>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Empty */

/** Empty State (17354:14116): amber rule, serif headline, support and one action. */
export function EmptyPanel({ headline, support, action, href }: { headline: string; support: string; action: string; href: string }) {
  return (
    <div className="ol-state">
      <span className="ol-state__rule" aria-hidden="true" />
      <h2 className="ol-state__headline">{headline}</h2>
      <p className="ol-state__support">{support}</p>
      <div>
        <Button href={href} arrow="up-right">
          {action}
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Loading */

/** Skeleton / List Row (17972:143921): title and status bars, then meta and date bars. */
export function SkeletonRow() {
  return (
    <div className="ol-skrow" aria-hidden="true">
      <div className="ol-skrow__line">
        <Bar w={300} h={16} />
        <Bar w={150} h={14} />
      </div>
      <div className="ol-skrow__line">
        <Bar w={260} h={12} />
        <Bar w={180} h={12} />
      </div>
    </div>
  );
}

/** Decision list skeleton and Task list skeleton: one bordered box of rows. */
export function SkeletonList({ rows }: { rows: number }) {
  return (
    <div className="ol-box" aria-hidden="true">
      {Array.from({ length: rows }, (_, i) => (
        <SkeletonRow key={i} />
      ))}
    </div>
  );
}

/** Skeleton / Request Card (17972:143964). */
export function SkeletonRequest() {
  return (
    <div className="ol-skreq" aria-hidden="true">
      <div className="ol-skreq__top">
        <Bar w={56} h={56} r={28} />
        <div className="ol-skreq__text">
          <Bar w={200} h={22} />
          <Bar w={140} h={12} />
        </div>
      </div>
      <div className="ol-skreq__chips">
        <Bar w={120} h={36} />
        <Bar w={140} h={36} />
        <Bar w={110} h={36} />
      </div>
      <div className="ol-skreq__rule" />
      <div className="ol-skreq__fields">
        <div className="ol-skreq__field ol-skreq__field--purpose">
          <Bar w={110} h={10} />
          <Bar w="100%" h={16} />
        </div>
        <div className="ol-skreq__field">
          <Bar w={80} h={10} />
          <Bar w="100%" h={16} />
        </div>
      </div>
      <div className="ol-skreq__actions">
        <Bar w={81} h={36} />
        <Bar w={89} h={36} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Awaiting Decision Row */

/**
 * Awaiting Decision Row (17972:140296): title and status, who asked and the project, when it was proposed and the deadline, and a Review
 * button. The row and the button open the same page. Default, Hover (subtle fill), Pressed (muted fill) and Focus (2 px ink ring) are CSS.
 * The project name is underlined like the milestone of the Decision Row it was cloned from and has no destination in the design.
 */
export function AwaitingDecisionRow({ item }: { item: AwaitingDecision }) {
  return (
    <li className="ol-drow">
      <div className="ol-drow__content">
        <div className="ol-drow__top">
          <Link href={item.href} className="ol-drow__hit">
            {item.title}
          </Link>
          <StatusTag status={AWAITING_STATUS} />
        </div>
        <div className="ol-drow__bottom">
          <div className="ol-drow__meta">
            <span>Asked by {item.askedBy}</span>
            <span aria-hidden="true">·</span>
            <button type="button" className="ol-drow__project">
              {item.project}
            </button>
          </div>
          <div className="ol-drow__meta">
            <span>{item.proposed}</span>
            <span aria-hidden="true">·</span>
            <span>{item.deadline}</span>
          </div>
        </div>
      </div>
      <Button size="sm" variant="secondary" arrow="up-right" href={item.href} aria-label={`Review ${item.title}`}>
        Review
      </Button>
    </li>
  );
}

/* ------------------------------------------------------------------ Introduction Request */

/**
 * Introduction Request (17972:142869): who asked, their skills, the shared purpose and their note, then Accept, Not now and View profile.
 * Cloned from the Interest Request of the Team page, with the View profile link added.
 */
export function IntroductionRequest({ onAccept, onNotNow, profileHref }: { onAccept: () => void; onNotNow: () => void; profileHref: string }) {
  const r = INTRODUCTION;
  return (
    <article className="pt-req ol-req" aria-label={`Introduction request from ${r.name}`}>
      <div className="pt-req__top">
        <div className="pt-req__person">
          <Photo src={r.photo} size={56} />
          <div className="pt-req__text">
            <h3 className="pt-req__name">{r.name}</h3>
            <p className="pt-req__role">{r.role}</p>
          </div>
        </div>
        <p className="pt-req__sent">{r.received}</p>
      </div>
      <SkillTags labels={r.skills.map((label) => ({ label }))} />
      <div className="pt-rule" aria-hidden="true" />
      <div className="pt-req__fields ol-req__fields">
        <div className="pt-req__field ol-req__purpose">
          <Over className="cw-over--12">{r.purposeLabel}</Over>
          <p className="pt-req__value">{r.purpose}</p>
        </div>
        <div className="pt-req__field pt-req__field--grow">
          <Over className="cw-over--12">{r.noteLabel}</Over>
          <p className="pt-req__value pt-req__value--msg">{r.note}</p>
        </div>
      </div>
      <div className="pt-req__actions">
        <Button size="sm" onClick={onAccept}>
          Accept
        </Button>
        <Button size="sm" variant="secondary" onClick={onNotNow}>
          Not now
        </Button>
        <CardLink href={profileHref}>View profile</CardLink>
      </div>
    </article>
  );
}
