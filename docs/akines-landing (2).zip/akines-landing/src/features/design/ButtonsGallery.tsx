'use client';

/**
 * Living gallery of the one Akines button (src/ui/Button.tsx): every variant by tone by size by state, with and without icons,
 * plus IconButton. Hover, pressed and focus are forced with the `state` prop so they can be seen without a pointer.
 * Not linked from any navigation. Styles: design.css. Spec: BUTTON_SPEC.md.
 */
import './design.css';
import { Bell, Bookmark, ChevronLeft, ChevronRight, Plus, Search, Send, SlidersHorizontal } from 'lucide-react';
import { asset } from '@/lib/assets';
import { Button, IconButton, type ButtonSize, type ButtonState, type ButtonTone, type ButtonVariant } from '@/ui/Button';

const SIZES: { id: ButtonSize; label: string }[] = [
  { id: 'sm', label: 'sm 36' },
  { id: 'md', label: 'md 48' },
  { id: 'lg', label: 'lg 56' },
  { id: 'xl', label: 'xl 62 (48 below 1280)' },
];

type Cell = { id: string; label: string; state?: ButtonState; disabled?: boolean; loading?: boolean };
const CELLS: Cell[] = [
  { id: 'default', label: 'Default' },
  { id: 'hover', label: 'Hover', state: 'hover' },
  { id: 'pressed', label: 'Pressed', state: 'pressed' },
  { id: 'focus', label: 'Focus', state: 'focus' },
  { id: 'disabled', label: 'Disabled', disabled: true },
  { id: 'loading', label: 'Loading', loading: true },
];
const ICON_CELLS = CELLS.filter((c) => c.id !== 'loading');

const JUMPS: [string, string][] = [
  ['dark', 'Dark tone'],
  ['light', 'Light tone'],
  ['icon', 'Icon buttons'],
  ['more', 'More'],
  ['props', 'Props'],
];
/** In-page scroll without changing the address (the preview artifact routes by the hash). */
const jump = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });

const DARK_VARIANTS: ButtonVariant[] = ['primary', 'secondary', 'accent', 'ghost', 'danger', 'link'];
const LIGHT_VARIANTS: ButtonVariant[] = ['primary', 'secondary', 'accent', 'ghost', 'link'];

function ColumnHeads({ cells }: { cells: Cell[] }) {
  return (
    <>
      <span className="bgal__colhead" aria-hidden="true" />
      {cells.map((c) => (
        <span key={c.id} className="bgal__colhead">
          {c.label}
        </span>
      ))}
    </>
  );
}

/** One variant in one tone: a row per size and icon option, a column per state. */
function VariantBlock({ variant, tone }: { variant: ButtonVariant; tone: ButtonTone }) {
  return (
    <section className="bgal__block" aria-label={`${variant}, ${tone} tone`}>
      <h3 className="bgal__blockhead">
        <span className="bgal__variant">{variant}</span>
        <span className="bgal__tone">{tone} tone</span>
      </h3>
      <div className="bgal__grid">
        <ColumnHeads cells={CELLS} />
        {SIZES.map((s) =>
          [false, true].map((withIcon) => (
            <div className="bgal__row" key={`${s.id}-${withIcon}`}>
              <span className="bgal__rowlabel">
                {s.label}
                <small>{withIcon ? 'with arrow' : 'label only'}</small>
              </span>
              {CELLS.map((c) => (
                <span className="bgal__cell" key={c.id}>
                  <span className="bgal__cap">{c.label}</span>
                  <Button
                    variant={variant}
                    tone={tone}
                    size={s.id}
                    state={c.state}
                    disabled={c.disabled}
                    loading={c.loading}
                    arrow={withIcon ? 'right' : undefined}
                  >
                    Continue
                  </Button>
                </span>
              ))}
            </div>
          )),
        )}
      </div>
    </section>
  );
}

type IconVariant = 'solid' | 'outline' | 'ghost';
const ICON_SIZES = [
  { id: 'sm', label: 'sm 36' },
  { id: 'md', label: 'md 44' },
  { id: 'lg', label: 'lg 52' },
] as const;

function IconBlock({ tone }: { tone: ButtonTone }) {
  const variants: IconVariant[] = ['solid', 'outline', 'ghost'];
  return (
    <div className="bgal__icons">
      {variants.map((v) => (
        <section className="bgal__block" key={v} aria-label={`icon button ${v}, ${tone} tone`}>
          <h3 className="bgal__blockhead">
            <span className="bgal__variant">{v}</span>
            <span className="bgal__tone">{tone} tone</span>
          </h3>
          <div className="bgal__grid bgal__grid--icon">
            <ColumnHeads cells={ICON_CELLS} />
            {ICON_SIZES.map((s) => (
              <div className="bgal__row" key={s.id}>
                <span className="bgal__rowlabel">{s.label}</span>
                {ICON_CELLS.map((c) => (
                  <span className="bgal__cell" key={c.id}>
                    <span className="bgal__cap">{c.label}</span>
                    <IconButton label="Next" variant={v} tone={tone} size={s.id} state={c.state} disabled={c.disabled} tooltip={false}>
                      <ChevronRight />
                    </IconButton>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

const PROPS: [string, string, string][] = [
  ['variant', 'primary, secondary, accent, ghost, danger, link', 'link is underlined text with no sweep'],
  ['tone', 'dark (default), light', 'dark is for light surfaces, light is for photographs and dark surfaces'],
  ['size', 'sm 36, md 48 (default), lg 56, xl 62', 'xl is 48 below 1280 and 62 from 1280'],
  ['fluid', 'boolean', 'landing only: the landing box (md 48 then 50, padding 12/20 then 14/24; xl padding 24 then 32)'],
  ['icon, iconRight', 'ReactNode', 'iconRight nudges on hover'],
  ['arrow', 'up-right, down, right', 'built-in arrow after the label, nudging the way it points'],
  ['loading', 'boolean', 'spinner left of the label, keeps the resting width, ignores clicks, aria-busy'],
  ['disabled', 'boolean', 'native disabled, or aria-disabled for links'],
  ['looksDisabled', 'boolean', 'looks disabled but still takes clicks (forms that explain what is missing)'],
  ['fullWidth, href, onClick, className, type', '', 'href renders the app link; external URLs get rel="noopener"'],
  ['state', 'hover, pressed, focus', 'this page only: forces a state for static display (data-force)'],
  ['IconButton', 'label, variant solid, outline, ghost, tone, size sm 36, md 44, lg 52, href, tooltip', 'label is the aria-label and the tooltip'],
];

export function ButtonsGallery() {
  return (
    <div className="bgal">
      <header className="bgal__head bgal__wrap">
        <p className="bgal__eyebrow">Design system</p>
        <h1 className="bgal__title">Buttons</h1>
        <p className="bgal__lede">
          One button for the whole product, taken from the landing page. On hover (pointer devices) a fill rises from the bottom edge, the label
          colour swaps, a hairline ring fades in and the arrow nudges. Press scales to 0.97. Reduced motion turns every transition off.
        </p>
        <nav className="bgal__jump" aria-label="On this page">
          {JUMPS.map(([id, label]) => (
            <Button key={id} variant="link" onClick={() => jump(id)}>
              {label}
            </Button>
          ))}
        </nav>
      </header>

      <section id="dark" className="bgal__sec bgal__wrap" aria-labelledby="bgal-dark">
        <h2 id="bgal-dark" className="bgal__h2">
          Dark tone, on ivory
        </h2>
        <p className="bgal__note">For light surfaces. Hover is forced with the state prop; try the real hover on the Default column too.</p>
        {DARK_VARIANTS.map((v) => (
          <VariantBlock key={v} variant={v} tone="dark" />
        ))}
      </section>

      <section id="light" className="bgal__band" aria-labelledby="bgal-light">
        <img className="bgal__bandimg" src={asset('/images/hero.jpg')} alt="" />
        <div className="bgal__scrim" aria-hidden="true" />
        <div className="bgal__bandin bgal__wrap">
          <h2 id="bgal-light" className="bgal__h2">
            Light tone, on a photograph
          </h2>
          <p className="bgal__note">For photographs and dark surfaces. Danger has one tone only.</p>
          {LIGHT_VARIANTS.map((v) => (
            <VariantBlock key={v} variant={v} tone="light" />
          ))}
        </div>
      </section>

      <section id="icon" className="bgal__sec bgal__wrap" aria-labelledby="bgal-icon">
        <h2 id="bgal-icon" className="bgal__h2">
          Icon buttons, dark tone
        </h2>
        <p className="bgal__note">Round, the label is the accessible name. Solid, outline and ghost follow the primary, secondary and ghost colours.</p>
        <IconBlock tone="dark" />
      </section>

      <section className="bgal__band bgal__band--short" aria-labelledby="bgal-icon-light">
        <img className="bgal__bandimg" src={asset('/images/hero.jpg')} alt="" />
        <div className="bgal__scrim" aria-hidden="true" />
        <div className="bgal__bandin bgal__wrap">
          <h2 id="bgal-icon-light" className="bgal__h2">
            Icon buttons, light tone
          </h2>
          <IconBlock tone="light" />
        </div>
      </section>

      <section id="more" className="bgal__sec bgal__wrap" aria-labelledby="bgal-more">
        <h2 id="bgal-more" className="bgal__h2">
          More
        </h2>
        <div className="bgal__more">
          <div className="bgal__moregroup">
            <h3 className="bgal__blockhead">
              <span className="bgal__variant">Icons</span>
            </h3>
            <div className="bgal__flow">
              <span className="bgal__cell">
                <span className="bgal__cap">Leading icon</span>
                <Button variant="secondary" icon={<Plus />}>
                  Start a project
                </Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Arrow right</span>
                <Button arrow="right">Continue</Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Arrow up-right</span>
                <Button arrow="up-right">Find my kind of connection</Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Arrow down</span>
                <Button variant="secondary" arrow="down">
                  Discover Akines
                </Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Icon with link</span>
                <Button variant="link" arrow="right">
                  Explore project
                </Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Save toggle</span>
                <Button variant="secondary" icon={<Bookmark />} aria-pressed="false">
                  Save project
                </Button>
              </span>
            </div>
          </div>

          <div className="bgal__moregroup">
            <h3 className="bgal__blockhead">
              <span className="bgal__variant">Landing sizes</span>
              <span className="bgal__tone">fluid: resize the window past 1280</span>
            </h3>
            <div className="bgal__flow bgal__flow--dark">
              <span className="bgal__cell">
                <span className="bgal__cap">md fluid (48, then 50)</span>
                <Button fluid arrow="up-right">
                  Join the Akines community
                </Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">md fluid outline</span>
                <Button fluid variant="secondary" arrow="up-right">
                  Explore the Akines philosophy
                </Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">xl fluid (48, then 62)</span>
                <Button fluid size="xl" arrow="up-right">
                  Find my kind of connection
                </Button>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">xl (62 from 1280)</span>
                <Button size="xl" variant="secondary">
                  Explore Akines
                </Button>
              </span>
            </div>
          </div>

          <div className="bgal__moregroup">
            <h3 className="bgal__blockhead">
              <span className="bgal__variant">Full width and behaviour</span>
            </h3>
            <div className="bgal__flow bgal__flow--stack">
              <span className="bgal__cell bgal__cell--wide">
                <span className="bgal__cap">Full width</span>
                <Button fullWidth arrow="right">
                  Log in
                </Button>
              </span>
              <span className="bgal__cell bgal__cell--wide">
                <span className="bgal__cap">Full width, loading</span>
                <Button fullWidth loading>
                  Log in
                </Button>
              </span>
              <span className="bgal__cell bgal__cell--wide">
                <span className="bgal__cap">Looks disabled, still takes clicks</span>
                <Button fullWidth looksDisabled arrow="right">
                  Confirm my choice
                </Button>
              </span>
              <span className="bgal__cell bgal__cell--wide">
                <span className="bgal__cap">Link (renders a link)</span>
                <Button fullWidth variant="secondary" href="/design/buttons">
                  This page
                </Button>
              </span>
            </div>
          </div>

          <div className="bgal__moregroup">
            <h3 className="bgal__blockhead">
              <span className="bgal__variant">Icon button in use</span>
              <span className="bgal__tone">hover or tab to see the tooltip</span>
            </h3>
            <div className="bgal__flow">
              <span className="bgal__cell">
                <span className="bgal__cap">Previous, next</span>
                <span className="bgal__pair">
                  <IconButton label="Previous profile">
                    <ChevronLeft />
                  </IconButton>
                  <IconButton label="Next profile">
                    <ChevronRight />
                  </IconButton>
                </span>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Outline</span>
                <span className="bgal__pair">
                  <IconButton variant="outline" label="Search">
                    <Search />
                  </IconButton>
                  <IconButton variant="outline" label="Filters">
                    <SlidersHorizontal />
                  </IconButton>
                </span>
              </span>
              <span className="bgal__cell">
                <span className="bgal__cap">Solid</span>
                <span className="bgal__pair">
                  <IconButton variant="solid" label="Send">
                    <Send />
                  </IconButton>
                  <IconButton variant="solid" size="lg" label="Notifications">
                    <Bell />
                  </IconButton>
                </span>
              </span>
            </div>
          </div>
        </div>
      </section>

      <section id="props" className="bgal__sec bgal__wrap" aria-labelledby="bgal-props">
        <h2 id="bgal-props" className="bgal__h2">
          Props
        </h2>
        <div className="bgal__tablewrap">
          <table className="bgal__table">
            <thead>
              <tr>
                <th scope="col">Prop</th>
                <th scope="col">Values</th>
                <th scope="col">Notes</th>
              </tr>
            </thead>
            <tbody>
              {PROPS.map(([a, b, c]) => (
                <tr key={a}>
                  <th scope="row">{a}</th>
                  <td>{b}</td>
                  <td>{c}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
