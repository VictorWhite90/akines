import type { ComponentType } from 'react';

/** The six main pages of the signed-in header. */
export type MainPage = 'community' | 'connect' | 'collaborate' | 'make-sell' | 'explore' | 'care';

export type RouteDef = {
  /** Static path, starts with "/". */
  path: string;
  /** Browser tab title (without the " | Akines" suffix). */
  title: string;
  /**
   * site : public page, no app header (landing, join). Signed in or not.
   * app  : signed-in screen with the app header and (tablet, mobile) bottom bar. Signed-out visitors are sent to the sign-in panel.
   * bare : nothing around it (404).
   */
  shell: 'site' | 'app' | 'bare';
  /** Which main page and sub tab are active in the header (shell "app" only). Tab is the label shown in the sub row. */
  nav?: { page: MainPage; tab?: string };
  /** The screen. Must be a client component ('use client' at the top of its file). */
  component: ComponentType;
};
