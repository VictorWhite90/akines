'use client';

/**
 * Static frames of the join flow (routes /join/state-*). Each one is the real screen started in the state of a Figma frame,
 * with the sample values the frame shows (see join-frames.ts). Every state is also reachable from /join by its trigger (see JoinPage.tsx).
 */
import { usePath } from '@/lib/nav';
import { JoinPage } from './JoinPage';
import { JOIN_FRAMES } from './join-frames';

/** One component for every /join/state-* route: it picks its preset from the current path. */
export function JoinStateFrame() {
  const path = usePath();
  const frame = JOIN_FRAMES.find((f) => path === `/join/state-${f.slug}`);
  return <JoinPage preset={frame ? frame.preset : undefined} />;
}
