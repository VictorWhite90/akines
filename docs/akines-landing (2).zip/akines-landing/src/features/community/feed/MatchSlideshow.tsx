'use client';

/**
 * "You two would get along": a slideshow of 5 to 10 profiles (FEED_SPEC.md section 5).
 * No autoplay. Dots, counter and arrows, swipe or drag (40 px), Left and Right while the card has focus.
 */
import { useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';
import { Button, IconButton } from '@/ui';
import { toast } from '@/ui/toast';
import { Link } from '@/lib/nav';
import { useMemoState } from '@/lib/hooks';
import { cx, ICheckCircle, INext, IPrev } from '../ui';
import { MATCHES, MATCH_COPY, type Match } from './content';
import { Face } from './parts';

const MAX = 10;
/** Drag distance in px that turns a swipe into a change of profile. */
const THRESHOLD = 40;

type Gesture = { x: number; y: number; id: number; drag: boolean };

/**
 * `profileHref` is optional: where it is given and returns a path, the photo and name of that slide are one link to it (Connect / Discover
 * links them to the person's profile). Community Home does not pass it, so there the slide is unchanged.
 */
export function MatchSlideshow({ profiles = MATCHES, empty, profileHref }: { profiles?: Match[]; empty?: boolean; profileHref?: (m: Match) => string | undefined }) {
  const list = profiles.slice(0, MAX);
  const n = list.length;
  const [index, setIndex] = useState(0);
  const [offset, setOffset] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [sent, setSent] = useMemoState<Record<string, boolean>>('feed.hello', {});
  const gesture = useRef<Gesture | null>(null);

  if (empty || n === 0) {
    return (
      <section className="fd-box fd-match fd-match--empty" aria-labelledby="fd-match-title">
        <h2 className="fd-box__title" id="fd-match-title">
          {MATCH_COPY.title}
        </h2>
        <p className="fd-match__nothing">{MATCH_COPY.empty.text}</p>
        <Link className="fd-link" href={MATCH_COPY.empty.link.href}>
          {MATCH_COPY.empty.link.label}
        </Link>
      </section>
    );
  }

  const go = (to: number) => setIndex(((to % n) + n) % n);
  const current = list[index];
  const first = current.name.split(' ')[0];
  const isSent = !!sent[current.id];

  const sayHello = () => {
    setSent((s) => ({ ...s, [current.id]: true }));
    toast.show({ message: `Hello sent to ${first}` });
  };

  const onKeyDown = (e: KeyboardEvent<HTMLElement>) => {
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      go(index - 1);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      go(index + 1);
    }
  };

  const onDown = (e: PointerEvent<HTMLDivElement>) => {
    if (n < 2 || (e.pointerType === 'mouse' && e.button !== 0)) return;
    gesture.current = { x: e.clientX, y: e.clientY, id: e.pointerId, drag: false };
  };
  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    const g = gesture.current;
    if (!g || g.id !== e.pointerId) return;
    const dx = e.clientX - g.x;
    const dy = e.clientY - g.y;
    if (!g.drag) {
      if (Math.abs(dx) < 8 || Math.abs(dx) < Math.abs(dy)) return;
      g.drag = true;
      setDragging(true);
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* capture can fail for synthetic pointers; the drag still works */
      }
    }
    setOffset(dx);
  };
  const onUp = (e: PointerEvent<HTMLDivElement>) => {
    const g = gesture.current;
    if (!g || g.id !== e.pointerId) return;
    gesture.current = null;
    const dx = e.clientX - g.x;
    const dy = e.clientY - g.y;
    setDragging(false);
    setOffset(0);
    if (Math.abs(dx) >= THRESHOLD && Math.abs(dx) > Math.abs(dy)) go(index + (dx < 0 ? 1 : -1));
  };
  const onCancel = () => {
    gesture.current = null;
    setDragging(false);
    setOffset(0);
  };

  return (
    <section
      className="fd-box fd-match"
      aria-roledescription="carousel"
      aria-labelledby="fd-match-title"
      tabIndex={0}
      onKeyDown={onKeyDown}
      data-index={index}
    >
      <h2 className="fd-box__title fd-match__title" id="fd-match-title">
        {MATCH_COPY.title}
      </h2>

      <div className="fd-match__view" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onCancel}>
        <div
          className={cx('fd-match__track', dragging && 'is-dragging')}
          style={{ ['--fd-i' as string]: index, ['--fd-drag' as string]: `${offset}px` }}
        >
          {list.map((m, k) => {
            const who = (
              <>
                <Face image={m.image} size={56} />
                <div className="fd-slide__id">
                  <p className="fd-slide__name" id={`fd-name-${m.id}`}>
                    {m.name}
                  </p>
                  <p className="fd-slide__role">
                    {m.role} · {m.place}
                  </p>
                </div>
              </>
            );
            const href = profileHref?.(m);
            return (
              <div className="fd-slide" role="group" aria-roledescription="slide" aria-label={`${k + 1} of ${n}`} inert={k !== index} key={m.id}>
                {href ? (
                  <Link className="fd-slide__who fd-slide__who--link" href={href} draggable={false}>
                    {who}
                  </Link>
                ) : (
                  <div className="fd-slide__who">{who}</div>
                )}
                <p className="fd-slide__quote">{`“${m.quote}”`}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="fd-match__side">
        {/* order as drawn in Figma: the link under the quote, the two buttons (or the confirmation), then the pager last */}
        <Link className="fd-link fd-match__why" href={MATCH_COPY.link.href}>
          {MATCH_COPY.link.label}
        </Link>

        {/* One slot for both states, so the card never changes height when the buttons turn into the confirmation */}
        <div className="fd-match__slot">
          {isSent ? (
            <p className="fd-match__sent" role="status">
              <ICheckCircle />
              <span>Hello sent to {first}. We will let you know when they reply.</span>
            </p>
          ) : (
            <div className="fd-match__actions">
              <Button variant="secondary" fullWidth onClick={() => go(index + 1)} aria-describedby={`fd-name-${current.id}`}>
                {MATCH_COPY.skip}
              </Button>
              <Button fullWidth onClick={sayHello} aria-describedby={`fd-name-${current.id}`}>
                {MATCH_COPY.hello}
              </Button>
            </div>
          )}
        </div>

        <div className="fd-match__ctrl">
          <div className="fd-match__nav">
            <div className="fd-dots" role="group" aria-label="Choose a profile">
              {list.map((m, k) => (
                <button
                  type="button"
                  className="fd-dot"
                  key={m.id}
                  aria-label={`Show profile ${k + 1} of ${n}`}
                  aria-current={k === index ? 'true' : undefined}
                  onClick={() => go(k)}
                >
                  <span />
                </button>
              ))}
            </div>
            <span className="fd-match__count">
              {index + 1} / {n}
            </span>
          </div>
          <div className="fd-match__arrows">
            <IconButton variant="ghost" className="fd-arrow" label="Previous profile" onClick={() => go(index - 1)}>
              <IPrev s={24} />
            </IconButton>
            <IconButton variant="ghost" className="fd-arrow" label="Next profile" onClick={() => go(index + 1)}>
              <INext s={24} />
            </IconButton>
          </div>
        </div>
      </div>
    </section>
  );
}
