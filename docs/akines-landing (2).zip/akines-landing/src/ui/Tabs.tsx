'use client';

import { useRef, type KeyboardEvent } from 'react';
import { cx } from './internal';

export type TabItem = { id: string; label: string; count?: number };
export type TabsProps = {
  items: TabItem[];
  value: string;
  onChange: (id: string) => void;
  variant?: 'underline' | 'pill';
  ariaLabel: string;
  className?: string;
  /** Optional: ids become `${idBase}-tab-${id}` and `aria-controls` points at `${idBase}-panel-${id}`, so panels can be linked. */
  idBase?: string;
};

/** Tab list (role="tablist"): arrow keys, Home and End move and select, roving tabindex. Panels are rendered by the screen. */
export function Tabs({ items, value, onChange, variant = 'underline', ariaLabel, className, idBase }: TabsProps) {
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const i = items.findIndex((t) => t.id === value);
    let next = -1;
    if (e.key === 'ArrowRight') next = (i + 1) % items.length;
    else if (e.key === 'ArrowLeft') next = (i - 1 + items.length) % items.length;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = items.length - 1;
    if (next < 0) return;
    e.preventDefault();
    const t = items[next];
    onChange(t.id);
    refs.current[t.id]?.focus();
  };
  return (
    <div role="tablist" aria-label={ariaLabel} aria-orientation="horizontal" className={cx('k-tabs', `k-tabs--${variant}`, className)} onKeyDown={onKey}>
      {items.map((t) => {
        const on = t.id === value;
        return (
          <button
            key={t.id}
            ref={(el) => {
              refs.current[t.id] = el;
            }}
            type="button"
            role="tab"
            id={idBase ? `${idBase}-tab-${t.id}` : undefined}
            aria-selected={on}
            aria-controls={idBase ? `${idBase}-panel-${t.id}` : undefined}
            tabIndex={on ? 0 : -1}
            data-active={on || undefined}
            className="k-tab"
            onClick={() => onChange(t.id)}
          >
            <span className="k-tab__label">{t.label}</span>
            {t.count !== undefined ? <span className="k-tab__count">{t.count}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
