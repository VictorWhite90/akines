# Akines build guide (read this first, every worker)

Goal: replicate the current V2 Figma designs 100% as they look, as working screens in this Next.js project, connected by the
prototype flows, with every form prefilled with dummy data. The same source also builds the single-file preview artifact.
**Excluded: 12.13 Conversations (the "Project Conversation Flow"), do not build it.**
Motion: reuse the existing Akines motion language (see "Motion"). Editorial, Dior-like, calm, long soft easings.

## Figma
File key `fUBokQffAL4k4OJCxJy6Bb`, use_figma `sessionId` `283928f7-8391-48d9-af0a-6ee7576d226f` (pass it on every Figma tool call).
Pages: V2 Desktop `12001:8778`, V2 Tablet `16165:274`, V2 Mobile `16833:15326`, Components `1:1120`. Design widths: desktop 1512, tablet 1194, mobile 402.
Frames sit inside a fake "Browser chrome" bar (88 px desktop and tablet, 106 mobile) that is NOT part of the product: ignore it.
The sandbox cannot download from figma.com (curl is blocked), so use these tools:

1. **Structure and exact values** (preferred): `mcp__Figma__use_figma` with the read-only script `tools/figdump.js` (open the file, copy its
   whole content as `code`, set `NODE_ID`, `DEPTH`, `MAX_NODES`). It prints size, position, auto layout (gap, padding, alignment, sizing),
   fills with variable names, strokes, radius, shadows, opacity, text (characters, font, size, line height, letter spacing, colour) and
   component instance names. Pass `skillNames: "figma-use"`. NEVER write to the file (no create, no edit, no setReactions): read only.
   Dump big frames in slices (children one by one) to stay under MAX_NODES. Hidden layers are marked HIDDEN: do not render them.
2. **Look**: `mcp__Figma__get_screenshot` with `enableBase64Response: true` (the image is shown to you inline AND saved on disk; the result
   prints `[Image: source: /root/.claude/.../tool-results/....png]`, that path is a real file you can convert). Use `maxDimension` around
   1512 for a full frame, higher for detail.
3. `mcp__Figma__get_metadata` for a node tree overview with ids.
Frame ids and what they are: see `/home/claude/akines-landing-handoff.md` (search the section for your feature; line ranges are in your brief).
Every colour in Figma is bound to a variable. The CSS tokens are already extracted: `src/styles/app-tokens.css` (semantic colours, radii,
shadows) and `src/styles/tokens.css` (landing tokens, fonts `--font-serif` Alice, `--font-sans` Manrope, easing `--ease-out`, `--ease-io`).
Use `var(--token)` everywhere; no raw hex except where Figma has an unbound paint (then add a comment).
Typography: headings Alice (serif, Regular), UI and body Manrope. Figma text styles: Display/Title/Subtitle/Heading/Subheading/Body/Button/Caption/Overline,
read size, line height % and letter spacing from the dump and write the CSS with exactly those numbers.

## Responsive rule
The signed-in screens are designed at DESKTOP 1512 only (Tablet and Mobile pages only have landing, menu, sign-in panel and join flow, plus the
tablet/mobile navigation components that the shell already implements). Build the desktop screens pixel-exact at 1512 (container content is
centred; if a frame is exactly 1512 wide with 64 px side padding, use `max-width` 1512 and the same padding). Below 1280 (tablet) and below
768 (mobile) make the layout collapse gracefully (grids to fewer columns, rails stack under the main column, 48 px then 16 px side padding,
type scales down one step, modals become bottom sheets on mobile, never horizontal page scroll). Landing, menu, sign-in panel and join flow
have real designs at all three sizes: match those exactly.

## Project layout and rules
- Stack: Next 15 App Router, React 19, TypeScript, plain CSS. No new dependencies (lucide-react is available for icons; prefer the Figma icon look).
- **Routes**: each screen is a static path. A feature registers its screens in ITS OWN `src/features/<name>/routes.ts(x)` (`RouteDef` in
  `src/routes.types.ts`: `path`, `title`, `shell: 'app' | 'site' | 'bare'`, `nav: { page, tab }` for the header highlight, `component`).
  Do not edit `src/routes.ts`, `src/app/**`, `src/app-shell/**`, `src/lib/{nav,auth,motion}*` (ask the lead in your report if you need a change).
  Sample records get their own static paths (no params), e.g. `/collaborate/projects/tide-and-thread`.
  Header main pages and tabs and their canonical paths are in `src/app-shell/nav-model.ts` (e.g. `/community`, `/connect/banter`, `/collaborate/discover`).
- **Every screen file starts with `'use client'`.** Screen components are default or named exports referenced by the route.
- **Navigation**: only `import { Link, useNav, usePath } from '@/lib/nav'`. `<Link href="/x">` for internal paths, `useNav().push('/x')`. Never import `next/link`,
  `next/navigation` or `next/router`, never use `window.location` or `<a href="/x">` for internal paths (the preview artifact uses a hash router).
- **Images**: only through TSX with `asset('/images/app/<feature>/<name>.jpg')` from `@/lib/assets`; never `url()` in CSS, never `next/image` in app screens (use `<img loading="lazy" decoding="async" alt="">`).
  To get a photo from Figma: screenshot the photo layer ONLY (`get_screenshot` with the photo node id, `contentsOnly: true`, `enableBase64Response: true`, `maxDimension` about 2x the displayed size), then
  `node scripts/img.mjs <png path from the result> public/images/app/<feature>/<name>.jpg 1200 74`. Keep every image under about 160 KB (cards 800 px wide, hero-like 1400 px). Many photos already exist in `public/images/` (landing set): reuse them when the Figma photo is the same.
  If the photo layer cannot be isolated, crop the screenshot with sharp (`node -e`) to the photo rectangle. Record each image in a comment next to its use: Figma node id and name.
- **Auth and test data**: `src/lib/auth.ts` has `DUMMY` (email `kemi.adeyemi@example.com`, username `kemiadeyemi`, mobile `+234 803 555 0142`, password `Akines2026!`, code `123456`, name Kemi Adeyemi). EVERY form field in the app must be prefilled with plausible dummy data
  (names, messages, titles, dates, amounts) so each flow can be completed by pressing the primary button. Validation still works: clearing a field shows its Figma error state. Do not add visible "test data" notices.
- **Overlays** (modals, drawers, sheets, popovers, toasts) are React state inside the screen, not routes. Figma overlay frames named `Modal:`, `Drawer:`, `Dropdown:`, `Toast:` map to components opened by the same triggers as the prototype reactions (read the reactions with figdump `reactions=` counts and the destination names via a short use_figma script when unsure).
  Use the shared kit from `src/ui` (see below) for modal shell, drawer, toast (`toast.show({ message, actionLabel, onAction })` from `@/ui/toast`), focus trap, Escape to close, scroll lock (`useScrollLock`, `useDismiss`, `useLayout` in `@/lib/hooks`).
- **Prototype logic**: Figma variables and variant `CHANGE_TO` reactions are state machines; implement them as React state. Every button, link, tab, chip, card, row, toggle and form control in the frame must do what its Figma reaction does. Where a control has no destination in Figma,
  make it inert (or the obvious local state change) and list it in your report: do not invent destinations.
- **CSS**: one stylesheet per feature, imported from the feature's screen file (`import './community.css'`; Next and the preview bundler both handle it). **Prefix every class with a short feature prefix** (e.g. `ch-` community home, `co-` collaborate, `au-` auth) so parallel workers never collide.
  Never restyle global classes (`.container`, `.eyebrow`, `.h2`, `.card` and any non-prefixed landing class). Kit classes (`.k-*`) belong to the UI kit worker.
- **Typecheck**: `npx tsc --noEmit` must pass. Do NOT run `next build`, `next dev` or `next start` (parallel workers share `.next` and would corrupt each other).
- **Verify with the preview bundle** (isolated per worker): `node scripts/build-preview.mjs /tmp/<yourname>-prev && python3 -m http.server -d /tmp/<yourname>-prev <port>` (pick a free port: lead 8123, auth 8201, kit 8202, community 8203, collab A 8204, collab B 8205, collab C 8206, other 8207).
  Open `http://localhost:<port>/#<hash>` in Playwright (`require('playwright')` works anywhere; chromium launches with no options). Hash = path without the leading slash and with `/` replaced by `-` (`/collaborate/discover` is `#collaborate-discover`, `/` is empty, `/join` is `#join`).
  To be signed in run `localStorage.setItem('akines.session.v1','1')` first. Take screenshots (deviceScaleFactor 1) at 1512 wide for desktop screens, compare against the Figma screenshot of the same frame, fix differences (spacing, type, colour, radius, image crop) until they match by eye at full size, and check 1194 and 402 for no overflow.
  Write throwaway scripts in `/tmp/claude-0/-home-claude/4f1309c3-2218-54e7-8722-56d639642547/scratchpad/<yourname>/` and keep screenshots there (never in the project).
- Text: no em dashes or en dashes anywhere in UI copy or comments you write (use a comma, colon or hyphen). Keep Figma copy exactly as designed (including curly quotes and punctuation).
- Accessibility: real buttons and links, labels on inputs, visible `:focus-visible`, `aria-*` on dialogs and tabs, keyboard operable, `prefers-reduced-motion` respected.

## Motion (the Akines landing language: premium, editorial, patient)
- Easing tokens `--ease-out` (long soft landing, for arrivals and hovers) and `--ease-io` (masks, exits). Durations 0.4 to 1.1 s for arrivals, 0.25 to 0.45 s for exits and small feedback. Nothing bounces, nothing loops (except existing loaders), no parallax inside app screens.
- **Scroll reveals** are attribute driven (`src/lib/motion.ts`): put `data-m="up"` on a block to fade-rise it when it scrolls into view; `data-m="words"` on a headline to rise word by word; `data-m="frame"` on a photo wrapper (`position: relative; overflow: hidden`, contains `img.cover`) for the curtain open; `data-m="stagger"` on a parent to reveal its children one after another (100 ms steps).
  Blocks that appear together cascade automatically in reading order within the nearest `section` or `[data-m-group]`. New nodes added later (tabs, lists, conditional content) are picked up automatically. Use reveals on page headings, band headings, cards in grids, photos; not on every tiny element.
- **Route change**: the shell already fades and rises the new screen. **Hover and press**: buttons use the rising-sweep fill (the kit `Button` and `IconButton`, `.k-btn` in `src/styles/ui.css`), press scales to 0.97, links draw an underline in, cards lift or zoom their photo slowly (`scale 1.04`, 1.2 s, `--ease-out`) inside `@media (hover: hover)`.
- **Overlays**: modal fades in with a 14 px rise (0.45 s `--ease-out`), backdrop fades (0.35 s), drawers slide from their side (0.55 s `--ease-out`), bottom sheets slide up (0.6 s), all reverse faster on close (0.28 s `--ease-io`). Toasts slide up 12 px and fade.
- Use individual transform properties (`translate`, `scale`, `rotate`) so effects compose. Start states that hide content must only exist under `.js` and `@media (prefers-reduced-motion: no-preference)`; with reduced motion everything is visible and instant.

## Report back (final message, concise)
List: screens/routes built (paths), Figma frame ids covered, anything NOT matched exactly (and why), every control without a Figma destination, files you added, images added with sizes, and any change you need the lead to make. No em dashes.

## Extra rules (added at launch)
- **UI kit**: `KIT_API.md` is the contract. Import from `@/ui`. The kit worker lands a working `src/ui/index.ts` first and restyles it afterwards; until it exists, write your screens and logic and check again before you first build (`ls src/ui/index.ts`). If the kit is not there after 15 minutes of other work, wait with `sleep 60` loops (max 10 more minutes) and keep working on your CSS meanwhile.
- **Frames list**: `tools/listframes.js` (read-only use_figma script) lists a section's frames with ids, sizes and reaction counts. Run it with your section prefix and `NAME_FILTER` for your journeys.
- **Every Figma frame is a screen to reproduce**, including the state frames (Loading, Empty, Could not load, Section error, answers-saved variants, success states) and every `Modal:`, `Drawer:`, `Dropdown:` and `Toast:` overlay.
  Reach each state through its natural trigger where Figma has one (a first visit shows the Loading skeleton for about the same time as the Figma AFTER_TIMEOUT reaction, then the real screen; a failing action shows its error state with Retry; Empty shows when the list has no items, e.g. after the last item is removed or deleted).
  A state that has no natural trigger in the prototype gets its own static route `<screen path>/state-<name>` (for example `/collaborate/discover/state-loading`), which renders exactly that Figma frame. Do not link these from the UI unless Figma does; list them in your report.
- **Frame to code**: the screen route renders the "main" frame; everything that is a different content state of the same page (e.g. 12.5 "D1 Filtered by project type") is the same component driven by state.
- **Dummy data**: sample records use the names and copy in the Figma frames (Amara, Folake, Tunde, Ngozi, Chuka, Lagos Makers Zine, ...). Where a form is shown empty in a frame only to demonstrate the empty or error state, the live screen starts PREFILLED (see "Auth and test data") and clearing a field reaches the Figma error state.
- **Ownership** (do not edit files owned by another worker; ask the lead in your report):
  auth: `src/features/auth/**` (except `panel-store.ts`, keep its exports), `src/styles/auth.css`.
  kit: `src/ui/**`, `src/styles/ui.css`.
  community: `src/features/community/**`, `src/styles/community.css`.
  collaborate start (12.1, 12.2): `src/features/collaborate/start/**`, prefix `cs-`. people (12.3, 12.4): `.../people/**`, prefix `cc-`. projects (12.5 to 12.9): `.../projects/**`, prefix `cd-`. workspace (12.10 to 12.12): `.../workspace/**`, prefix `cw-`.
  Each part exports `routes` from its own `routes.tsx` (already stubbed). CSS files live next to your screens (`import './x.css'`), not in `src/styles`.
  Community prefix `ch-`. Images: `public/images/app/<feature>/` where feature is auth, community, collab-start, collab-people, collab-projects, collab-workspace.
- **Canonical Collaborate paths** (register exactly these for your entry screens so cross links work; sub screens go below them):
  `/collaborate` Home (12.1; Empty state at `/collaborate/state-empty`), `/collaborate/start` (12.2 Start a project flow, steps are state inside it),
  `/collaborate/collaborators` (12.3 Explore collaborators, B2 to B5, B9, B10 are screens or states below `/collaborate/collaborators/...`), `/collaborate/saved-collaborators` (12.4 Saved and requests), `/collaborate/introduction-requests` (12.4 B12),
  `/collaborate/discover` (12.5), `/collaborate/projects/<slug>` (12.6 project detail; sample slugs from the Figma copy, kebab-case, e.g. `lagos-makers-zine`), `/collaborate/projects/<slug>/interest` (12.8), `/collaborate/members/<slug>` (12.7), `/collaborate/saved` (12.9),
  `/collaborate/my-projects` (12.10), `/collaborate/my-projects/<slug>` (12.11 overview). The Studio routes (`/studio`, `/studio/<work-slug>`) were removed on 5 Nov 2026.
  Community: `/community`, `/community/messages` (+ `/community/messages/<thread-slug>`), `/community/collaborations` (+ `/<slug>`), `/community/care` (+ `/reflect`, `/professional-support`), `/community/settings` (+ `/recommendations`, `/privacy`, `/connection`), `/community/banter`.
  Header tabs and sub rows link to the tab paths in `src/app-shell/nav-model.ts`; do not render your own header.
- **Where a link has no built destination** (Connect, Make & Sell, Explore, Care tabs, `/profile`): link to the real placeholder paths in `nav-model.ts`; never to `/404`.
- **Shared build dir caution**: all workers build from the same `src/`. If the preview build fails in a file you do not own, wait 60 seconds and retry; never edit it. `npx tsc --noEmit` shows everyone's errors: only fix the ones in your files.
- Do not commit with git. Do not install packages.
