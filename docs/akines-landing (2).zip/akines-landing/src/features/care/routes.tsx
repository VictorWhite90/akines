import { placeholderRoutes } from '@/features/placeholder-routes';

/** Section 15 CARE: placeholder pages (Creative Wellbeing, Creative DNA). */
export const routes = placeholderRoutes('care');
