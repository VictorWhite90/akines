import type { RouteDef } from '@/routes.types';
import { DecisionsScreen, IntroductionsScreen, TasksScreen } from './Lists';
import { OL } from './data';

const nav = { page: 'collaborate', tab: 'Home' } as const;
const def = (path: string, title: string, component: RouteDef['component']): RouteDef => ({ path, title, shell: 'app', nav, component });

const decisions = (variant?: 'empty' | 'loading') => {
  const Screen = () => <DecisionsScreen variant={variant} />;
  return Screen;
};
const introductions = (variant?: 'empty' | 'loading' | 'accepted' | 'not-now') => {
  const Screen = () => <IntroductionsScreen variant={variant} />;
  return Screen;
};
const tasks = (variant?: 'empty' | 'loading') => {
  const Screen = () => <TasksScreen variant={variant} />;
  return Screen;
};

/**
 * The three lists behind the count tiles of the Collaborate Home (the address bars of the Figma frames):
 * /collaborate/decisions                         12.48 Decisions awaiting you, frame 17972:150992
 * /collaborate/decisions/state-empty             Empty, 17972:160702
 * /collaborate/decisions/state-loading           Loading, 17972:161086 (the list also shows it on the first visit)
 * /collaborate/introductions                     12.49 Introduction requests, 17974:131855
 * /collaborate/introductions/state-accepted      Accepted, 17974:132361 (reached by Accept, with Toast:Introduction accepted 17974:166519)
 * /collaborate/introductions/state-not-now       Not now, 17974:132650 (reached by Not now, with Toast:Response sent 17974:166526)
 * /collaborate/introductions/state-empty         Empty, 17974:132922
 * /collaborate/introductions/state-loading       Loading, 17974:133310
 * /collaborate/tasks                             12.50 Tasks due this week, 17974:155481
 * /collaborate/tasks/state-empty                 Empty, 17974:155938
 * /collaborate/tasks/state-loading               Loading, 17974:156322
 * The Home tab stays active in the header. The "Start a conversation" modal is the one of the Conversations screen.
 */
export const routes: RouteDef[] = [
  def(OL.decisions, 'Decisions', decisions()),
  def(OL.decisionsEmpty, 'Decisions', decisions('empty')),
  def(OL.decisionsLoading, 'Decisions', decisions('loading')),

  def(OL.introductions, 'Introduction requests', introductions()),
  def(OL.introductionsAccepted, 'Introduction requests', introductions('accepted')),
  def(OL.introductionsNotNow, 'Introduction requests', introductions('not-now')),
  def(OL.introductionsEmpty, 'Introduction requests', introductions('empty')),
  def(OL.introductionsLoading, 'Introduction requests', introductions('loading')),

  def(OL.tasks, 'Tasks', tasks()),
  def(OL.tasksEmpty, 'Tasks', tasks('empty')),
  def(OL.tasksLoading, 'Tasks', tasks('loading')),
];
