'use client';

import { useEffect, type ComponentType } from 'react';
import { useNav } from '@/lib/nav';
import { toast } from '@/ui';
import { MyProjectsScreen } from '../workspace/MyProjects';
import { Overview } from '../workspace/Overview';
import { PATHS } from '../workspace/data';
import { ARCHIVE_MODAL, LEAVE_MODAL } from './data';
import { HeaderInitialContext, type HeaderInitial } from './ProjectHeader';
import { CommunityLearningPage, MentorshipCirclePage } from './SampleProject';

/**
 * The "state-" frames of 12.25 and 12.26: the page behind an overlay with the overlay already open (the Project overview,
 * or a sample project for its switcher). They are not linked from the UI: every overlay is opened from the header.
 */

const STATE_TOAST_MS = 8000;

const over = (page: ComponentType, value: HeaderInitial) =>
  function StateFrame() {
    const Page = page;
    return (
      <HeaderInitialContext.Provider value={value}>
        <Page />
      </HeaderInitialContext.Provider>
    );
  };

/* 12.25 on the Project overview */
export const StateSwitcher = over(Overview, 'switcher');
export const StateNotifications = over(Overview, 'notifications');
export const StateNotificationsRead = over(Overview, 'notifications-read');
export const StateSettings = over(Overview, 'settings');
export const StateCreateAI = over(Overview, 'ai');
export const StateCreateAIThinking = over(Overview, 'ai-thinking');
export const StateCreateAIAnswer = over(Overview, 'ai-answer');
export const StateEditDetails = over(Overview, 'edit');
export const StateDetailsSaved = over(Overview, 'edit-saved');
export const StateArchive = over(Overview, 'archive');
export const StateLeave = over(Overview, 'leave');
export const StatePreferences = over(Overview, 'prefs');
export const StatePreferencesSaved = over(Overview, 'prefs-saved');

/* 12.26: the switcher of each sample project */
export const StateCommunitySwitcher = over(CommunityLearningPage, 'switcher');
export const StateMentorshipSwitcher = over(MentorshipCirclePage, 'switcher');

/** Archive and Leave end on My projects with their toast (Figma: navigate to My projects, toast over it). */
function ToastOverList({ message }: { message: string }) {
  const nav = useNav();
  useEffect(() => {
    toast.show({ message, actionLabel: 'Undo', duration: STATE_TOAST_MS, onAction: () => nav.push(PATHS.overview) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [message]);
  return <MyProjectsScreen />;
}
export const StateArchived = () => <ToastOverList message={ARCHIVE_MODAL.done} />;
export const StateLeft = () => <ToastOverList message={LEAVE_MODAL.done} />;
