// Studio page, removed 5 Nov 2026 (Tasks, Conversations, Files and Workspace cover it). Commented out, not deleted. Figma: parked on the TRASH page.
// To bring it back: remove the leading "// " of every commented line below.
export {};

// import type { RouteDef } from '@/routes.types';
// import { PATHS, PROJECT_PATH } from './data';
// import { ART_PATH } from './project';
// import { routes } from './routes';
//
// /**
//  * Routes of the Adire Stories Studio (the same pages as Career Guidance for Everyone, with the Adire Stories data):
//  * 12.12 Studio and Shared canvas. The filters of the canvas are page state, not routes.
//  * Not mirrored: the Studio Empty state, the work detail pages, the milestone detail and the "state-" frames. Nothing on an Adire page
//  * links to them (the Adire work rows, canvas cards and the milestone have no destination).
//  */
// const MIRRORED: string[] = [PATHS.studio, PATHS.canvas];
//
// export const artRoutes: RouteDef[] = routes.filter((r) => MIRRORED.includes(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
