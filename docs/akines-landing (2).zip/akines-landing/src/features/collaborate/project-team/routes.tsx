import type { RouteDef } from '@/routes.types';
import { MemberDetail } from './MemberDetail';
import { Team, TeamAccepted, TeamAcceptedToast, TeamDismissed, TeamEmpty, TeamInvitationSent, TeamInviteModal, TeamNotNowModal, TeamResponseSent } from './Team';
import { TEAM_PATHS as P } from './data';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;

/**
 * Team 12.21: Team (17729:100721), Empty (17729:110484), Member detail (17729:111084), Interest request accepted (17729:116651),
 * Request dismissed (17729:117247) and the overlay frames Modal:Invite collaborator (17729:119986), Toast:Invitation sent (17729:120057),
 * Toast:Request accepted (17729:120064), Modal:Not now (17729:120071) and Toast:Response sent (17729:120118).
 * Team and the member detail (Adaeze Okoye) are reached from the UI. Accept goes to the accepted state and Not now, then Send, goes to
 * the dismissed state, each with its toast. The "state-" routes are the Figma frames that no control reaches by itself: the empty team,
 * and the overlay frames that open with the modal or the toast already showing.
 */
export const routes: RouteDef[] = [
  { path: P.team, title: 'Team', shell: 'app', nav, component: Team },
  { path: P.empty, title: 'Team', shell: 'app', nav, component: TeamEmpty },
  { path: P.member, title: 'Adaeze Okoye', shell: 'app', nav, component: MemberDetail },
  { path: P.accepted, title: 'Team', shell: 'app', nav, component: TeamAccepted },
  { path: P.dismissed, title: 'Team', shell: 'app', nav, component: TeamDismissed },
  { path: P.inviteModal, title: 'Team', shell: 'app', nav, component: TeamInviteModal },
  { path: P.invitationSent, title: 'Team', shell: 'app', nav, component: TeamInvitationSent },
  { path: P.acceptedToast, title: 'Team', shell: 'app', nav, component: TeamAcceptedToast },
  { path: P.notNowModal, title: 'Team', shell: 'app', nav, component: TeamNotNowModal },
  { path: P.responseSent, title: 'Team', shell: 'app', nav, component: TeamResponseSent },
];
