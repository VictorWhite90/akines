'use client';

import './workspace.css';
import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Link, useNav } from '@/lib/nav';
import { Button, EmptyState, Modal, Skeleton, toast } from '@/ui';
import { PATHS, PROJECTS, type DraftCard, type ProjectCard } from './data';
import { useWorkspace, workspace } from './store';
import { ActionButton, ArrowRight, AvStack, BackLink, CardLink, Dot, Over } from './parts';

/**
 * 12.10 My projects: Active and Drafts (tabs), Empty, Loading, Could not load, Modal: Delete draft, Toast: Draft deleted.
 * One component drives all the frames. The first visit of a session shows the Loading skeleton for 2.5 s (Figma AFTER_TIMEOUT),
 * then the list. The state frames also have their own static routes (see routes.tsx).
 */

type View = 'list' | 'loading' | 'error' | 'empty';
type Tab = 'active' | 'drafts';

const LOAD_MS = 2500;

function Progress({ text, done }: { text: string; done: number }) {
  return (
    <div className="cw-prog">
      <div className="cw-prog__row">
        <Over className="cw-over--12">PROGRESS</Over>
        <span className="cw-prog__text">{text}</span>
      </div>
      <div className="cw-prog__bar" role="img" aria-label={text}>
        {[0, 1, 2, 3, 4].map((i) => (
          <i key={i} data-on={i < done ? 'true' : 'false'} />
        ))}
      </div>
    </div>
  );
}

function ProjectCardView({ p }: { p: ProjectCard }) {
  const body = (
    <>
      <div className="cw-pc__top">
        <span className="cw-pc__stage">
          <Dot />
          {p.stage}
        </span>
        <span className="cw-pc__act">{p.activity}</span>
      </div>
      <div className="cw-pc__title">
        <h2>{p.title}</h2>
        <p>{p.description}</p>
      </div>
      <hr className="cw-pc__rule" />
      <dl className="cw-pc__details">
        <div>
          <dt className="cw-over cw-over--12">CURRENT MILESTONE</dt>
          <dd>{p.milestone}</dd>
        </div>
        <div>
          <dt className="cw-over cw-over--12">NEXT ACTION</dt>
          <dd>{p.next}</dd>
        </div>
      </dl>
      <Progress text={p.progressLabel} done={p.done} />
      <div className="cw-pc__foot">
        <div className="cw-pc__team">
          <AvStack initials={p.initials} />
          <span>{p.team}</span>
        </div>
        <span className="cw-pc__open">
          Open project
          <ArrowRight />
        </span>
      </div>
    </>
  );
  // Career Guidance for Everyone opens its Overview, Community Learning Initiative and Mentorship Circle their sample project pages (12.26) and Adire Stories its own Overview
  return p.href ? (
    <Link href={p.href} className="cw-pc">
      {body}
    </Link>
  ) : (
    <article className="cw-pc">{body}</article>
  );
}

function DraftCardView({ d, onDelete }: { d: DraftCard; onDelete: (d: DraftCard) => void }) {
  return (
    <article className="cw-dc">
      <div className="cw-dc__top">
        <span className="cw-dc__state">
          <Dot tone="gray" />
          DRAFT
        </span>
        <span className="cw-dc__edited">{d.edited}</span>
      </div>
      <div className="cw-dc__title">
        <h2>{d.title}</h2>
        <p>{d.description}</p>
      </div>
      <hr className="cw-pc__rule" />
      <Progress text={`Step ${d.step} of 5`} done={d.step} />
      <div className="cw-dc__foot">
        <CardLink href={PATHS.start} arrow>
          Continue draft
        </CardLink>
        <CardLink onClick={() => onDelete(d)}>Delete draft</CardLink>
      </div>
    </article>
  );
}

/** Project Card Skeleton (Figma 17310:13754, Pulse A and B): the pulse is the kit's skeleton animation. */
function SkeletonCard() {
  return (
    <div className="cw-sk" aria-hidden="true">
      <Skeleton width={150} height={12} radius={0} />
      <div className="cw-sk__group">
        <Skeleton width={300} height={28} radius={0} />
        <Skeleton width={379} height={14} radius={0} />
        <Skeleton width={260} height={14} radius={0} />
      </div>
      <hr className="cw-sk__rule" />
      <div className="cw-sk__group cw-sk__group--8">
        <Skeleton width={91} height={10} radius={0} />
        <Skeleton width={379} height={16} radius={0} />
        <Skeleton width={220} height={16} radius={0} />
      </div>
      <div className="cw-sk__group cw-sk__group--8">
        <Skeleton width={105} height={10} radius={0} />
        <div className="cw-sk__row">
          <Skeleton width={28} height={28} radius="50%" />
          <Skeleton width={70} height={14} radius={0} />
        </div>
      </div>
      <div className="cw-sk__group cw-sk__group--8">
        <Skeleton width={94} height={10} radius={0} />
        <Skeleton width={300} height={16} radius={0} />
      </div>
      <div className="cw-sk__group cw-sk__group--8">
        <Skeleton width={115} height={10} radius={0} />
        <Skeleton width={140} height={16} radius={0} />
      </div>
      <Skeleton width={110} height={16} radius={0} />
    </div>
  );
}

function Tabs({ tab, onTab, count }: { tab: Tab; onTab: (t: Tab) => void; count?: string }) {
  const refs = useRef<Record<Tab, HTMLButtonElement | null>>({ active: null, drafts: null });
  const order: Tab[] = ['active', 'drafts'];
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    const next = order[(order.indexOf(tab) + (e.key === 'ArrowRight' ? 1 : -1) + order.length) % order.length];
    onTab(next);
    refs.current[next]?.focus();
  };
  return (
    <div className="cw-tabs" data-m="up">
      <div className="cw-tabs__list" role="tablist" aria-label="My projects" onKeyDown={onKey}>
        {order.map((t) => (
          <button
            key={t}
            ref={(el) => {
              refs.current[t] = el;
            }}
            type="button"
            role="tab"
            id={`cw-tab-${t}`}
            aria-selected={tab === t}
            aria-controls="cw-tabpanel"
            tabIndex={tab === t ? 0 : -1}
            className="cw-tab"
            onClick={() => onTab(t)}
          >
            <span className="cw-tab__label">{t === 'active' ? 'Active' : 'Drafts'}</span>
            <span className="cw-tab__rule" />
          </button>
        ))}
      </div>
      {count ? <span className="cw-tabs__count">{count}</span> : null}
    </div>
  );
}

export function MyProjects({ initialTab = 'active', force }: { initialTab?: Tab; force?: Exclude<View, 'list'> }) {
  const nav = useNav();
  const drafts = useWorkspace((s) => s.drafts);
  const [view, setView] = useState<View>(() => force ?? (workspace.listLoaded ? 'list' : 'loading'));
  const [tab, setTab] = useState<Tab>(initialTab);
  const [deleting, setDeleting] = useState<DraftCard | null>(null);
  // the card the modal was opened for stays readable while the modal fades out
  const lastDeleting = useRef<DraftCard | null>(null);
  if (deleting) lastDeleting.current = deleting;

  // Loading: after 2.5 s the list appears (Figma AFTER_TIMEOUT to Active). The static route sends the visitor to the list route.
  useEffect(() => {
    if (view !== 'loading') return;
    const t = window.setTimeout(() => {
      workspace.markListLoaded();
      if (force) nav.replace(PATHS.list);
      else setView('list');
    }, LOAD_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  const confirmDelete = () => {
    if (!deleting) return;
    const gone = workspace.deleteDraft(deleting.id);
    setDeleting(null);
    if (!gone) return;
    toast.show({
      message: 'Draft deleted.',
      actionLabel: 'Undo',
      duration: 2500,
      onAction: () => {
        workspace.restoreDraft(gone.draft, gone.index);
        setTab('drafts');
      },
    });
  };

  if (view === 'error') {
    return (
      <div className="cw-page cw-page--state">
        <div data-m="up">
          <BackLink href={PATHS.home}>Back to Collaborate</BackLink>
        </div>
        <div data-m="up">
          <EmptyState className="cw-empty" title="We could not load your projects." text="Check your connection and try again. Your drafts are safe." action={<ActionButton onClick={() => setView('loading')}>Try again</ActionButton>} />
        </div>
      </div>
    );
  }

  const heading = (
    <header className="cw-head" data-m="up">
      <div className="cw-head__copy">
        <Over>MY PROJECTS</Over>
        <h1 className="cw-h1">Your projects.</h1>
        <p className="cw-lead">The projects you started and the ones you have joined.</p>
      </div>
      <ActionButton href={PATHS.start} arrow>
        Start a project
      </ActionButton>
    </header>
  );

  const count = view !== 'list' ? undefined : tab === 'active' ? `${PROJECTS.length} projects` : `${drafts.length} ${drafts.length === 1 ? 'draft' : 'drafts'}`;

  return (
    <div className="cw-page">
      {heading}
      <Tabs
        tab={view === 'list' ? tab : 'active'}
        onTab={(t) => {
          // the tabs of the Loading and Empty frames are shown but only the list switches
          if (view === 'list') setTab(t);
        }}
        count={count}
      />
      <div id="cw-tabpanel" role="tabpanel" aria-labelledby={`cw-tab-${tab}`} aria-busy={view === 'loading'} className="cw-panel">
        {view === 'loading' ? (
          <div className="cw-grid" role="status" aria-label="Loading your projects">
            <SkeletonCard />
            <SkeletonCard />
          </div>
        ) : null}

        {view === 'empty' ? (
          <div className="cw-panel__empty" data-m="up">
            <EmptyState className="cw-empty" title="You have no projects yet." text="Start a project of your own, or find one to join. Your projects will appear here." action={<ActionButton href={PATHS.start} arrow>Start a project</ActionButton>} />
            <CardLink href={PATHS.discover} arrow>
              Discover projects
            </CardLink>
          </div>
        ) : null}

        {view === 'list' && tab === 'active' ? (
          <div className="cw-grid" data-m="stagger">
            {PROJECTS.map((p) => (
              <ProjectCardView key={p.slug} p={p} />
            ))}
          </div>
        ) : null}

        {view === 'list' && tab === 'drafts' ? (
          drafts.length ? (
            <div className="cw-grid" data-m="stagger">
              {drafts.map((d) => (
                <DraftCardView key={d.id} d={d} onDelete={setDeleting} />
              ))}
            </div>
          ) : (
            <EmptyState className="cw-empty" title="You have no drafts." text="A project you save for later will wait here." action={<ActionButton href={PATHS.start} arrow>Start a project</ActionButton>} />
          )
        ) : null}
      </div>

      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        width={640}
        eyebrow="DELETE DRAFT"
        title="Delete this draft?"
        description={`${lastDeleting.current?.title ?? ''} and the answers you saved will be removed. This cannot be undone.`}
        footer={
          <>
            <Button onClick={confirmDelete}>Delete draft</Button>
            <CardLink onClick={() => setDeleting(null)}>Keep draft</CardLink>
          </>
        }
      />
    </div>
  );
}

export const MyProjectsScreen = () => <MyProjects />;
export const MyProjectsDraftsScreen = () => <MyProjects initialTab="drafts" />;
export const MyProjectsEmptyScreen = () => <MyProjects force="empty" />;
export const MyProjectsLoadingScreen = () => <MyProjects force="loading" />;
export const MyProjectsErrorScreen = () => <MyProjects force="error" />;
