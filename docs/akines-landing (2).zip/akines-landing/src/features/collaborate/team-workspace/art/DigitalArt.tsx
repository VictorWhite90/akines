'use client';

/**
 * 12.16 Digital Art Workspace (Figma a1 to a8 with the overlays d1 to d4): tool rail, canvas with the artboard, live cursors
 * and comment pins, the layers panel with the colour picker, and the state frames (saving, collaborator offline, connection
 * lost, reconnecting, view only, version history). The top bar, banners, People and access, project menu and version panel
 * come from the shared kit. Every class is prefixed ta- and lives in art.css.
 */
import { useEffect, useRef, useState } from 'react';
import {
  Eraser,
  Eye,
  EyeOff,
  Hand,
  Maximize,
  Move,
  PaintBucket,
  Pipette,
  Plus,
  Redo2,
  Shapes,
  SquareDashed,
  Type,
  Undo2,
  ZoomIn,
  ZoomOut,
  createLucideIcon,
  type LucideIcon,
} from 'lucide-react';
import { Link, useNav } from '@/lib/nav';
import { asset } from '@/lib/assets';
import { Button } from '@/ui';
import { PEOPLE, PEOPLE_SUMMARY, TW_PATHS, versionBannerTitle, type PeopleRow, type VersionRow, type WsState } from '../data';
import { Banner, Ic, Popover, VersionPanel, WorkspaceShell, bannerFor, type PresenceItem, type SaveLinks } from '../shared';
import './art.css';

/** The Figma brush icon (a handle and a round ferrule), which is not the drawing of the installed lucide Brush. Same grid and stroke rules. */
const Brush = createLucideIcon('ArtBrush', [
  ['path', { d: 'm9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08' }],
  ['path', { d: 'M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z' }],
]);

/* ------------------------------------------------------------------ routes and data */

const P = {
  main: TW_PATHS.art,
  thread: `${TW_PATHS.art}/state-comment-thread`,
  saving: `${TW_PATHS.art}/state-saving`,
  couldNotSave: `${TW_PATHS.art}/state-could-not-save`,
  reconnecting: `${TW_PATHS.art}/state-reconnecting`,
  history: `${TW_PATHS.art}/state-version-history`,
};

/** Save status popover: Save now shows the Saving screen, Version history opens it, Try again goes back to the default screen. */
const SAVE_LINKS: SaveLinks = { saveNow: P.saving, history: P.history, retry: P.main };

/** Figma d1: the People and access panel of the Digital Art Workspace. */
const ART_PEOPLE: PeopleRow[] = [
  { id: 'kemi', you: true, note: 'Editing the layers', avatar: 'editing' },
  { id: 'amara', note: 'Editing the colour layer', avatar: 'editing' },
  { id: 'ayo', note: 'Viewing the canvas', avatar: 'viewing' },
  { id: 'yusuf', note: 'Last seen yesterday', avatar: 'away' },
];

/** Figma a8: the version rows of this Workspace. */
const ART_VERSIONS: VersionRow[] = [
  { id: 'now', time: 'Today, 10:42', detail: 'Amara Obi, colour layer', current: true },
  { id: 'today-0915', time: 'Today, 09:15', detail: 'Kemi Adeyemi, linework' },
  { id: 'yest-1620', time: 'Yesterday, 16:20', detail: 'Ayo Bello, highlights' },
  { id: 'yest-1102', time: 'Yesterday, 11:02', detail: 'Amara Obi, colour layer' },
  { id: 'oct12', time: '12 Oct, 15:40', detail: 'Kemi Adeyemi, sketch' },
  { id: 'oct11', time: '11 Oct, 09:30', detail: 'Kemi Adeyemi, new canvas' },
];
const ART_DEFAULT_VERSION = 'yest-1620';

type Tool = { id: string; label: string; icon: LucideIcon };
const TOOLS_TOP: Tool[] = [
  { id: 'select', label: 'Select', icon: SquareDashed },
  { id: 'move', label: 'Move', icon: Move },
];
const TOOLS_DRAW: Tool[] = [
  { id: 'brush', label: 'Brush', icon: Brush },
  { id: 'eraser', label: 'Eraser', icon: Eraser },
  { id: 'smudge', label: 'Smudge', icon: Hand },
  { id: 'fill', label: 'Fill', icon: PaintBucket },
  { id: 'shapes', label: 'Shapes', icon: Shapes },
  { id: 'text', label: 'Text', icon: Type },
  { id: 'eyedropper', label: 'Eyedropper', icon: Pipette },
];

type Layer = { id: string; name: string; detail: string; hidden?: boolean; editor?: 'amara' };
const LAYERS: Layer[] = [
  { id: 'highlights', name: 'Highlights', detail: 'Normal, 100%' },
  { id: 'linework', name: 'Linework', detail: 'Multiply, 100%' },
  { id: 'colour', name: 'Colour: Adire pattern', detail: 'Normal, 100%', editor: 'amara' },
  { id: 'sketch', name: 'Sketch', detail: 'Normal, 40%', hidden: true },
  { id: 'paper', name: 'Paper', detail: 'Normal, 100%' },
];

const BRUSHES = [
  { id: 'dry-ink', name: 'Dry ink', active: true },
  { id: 'soft-pencil', name: 'Soft pencil' },
  { id: 'gouache', name: 'Gouache' },
  { id: 'fine-liner', name: 'Fine liner' },
  { id: 'watercolour-wash', name: 'Watercolour wash' },
];

const RECENT = ['#1F3A6E', '#C4562A', '#E8B04A', '#2F7D5B', '#F4EFE6', '#2B2B2B'];

/* ------------------------------------------------------------------ tool rail */

function ToolButton({ tool, active, disabled, onClick, expanded, popup }: { tool: Tool; active?: boolean; disabled?: boolean; onClick?: () => void; expanded?: boolean; popup?: boolean }) {
  return (
    <button
      type="button"
      className="ta-tool"
      data-active={active || undefined}
      aria-label={tool.label}
      aria-pressed={active ? true : undefined}
      aria-haspopup={popup ? 'dialog' : undefined}
      aria-expanded={popup ? !!expanded : undefined}
      disabled={disabled}
      onClick={onClick}
    >
      <Ic icon={tool.icon} size={22} />
    </button>
  );
}

function ToolRail({ locked, brushLive, onBrush, onColour, brushOpen, colourOpen }: { locked: boolean; brushLive: boolean; onBrush: () => void; onColour: () => void; brushOpen: boolean; colourOpen: boolean }) {
  return (
    <div className="ta-rail" role="toolbar" aria-label="Tools" aria-orientation="vertical">
      {TOOLS_TOP.map((t) => (
        <ToolButton key={t.id} tool={t} disabled={locked && t.id !== 'move'} />
      ))}
      <i className="ta-rail__rule" aria-hidden="true" />
      {TOOLS_DRAW.map((t) =>
        t.id === 'brush' ? <ToolButton key={t.id} tool={t} active={!locked} disabled={locked} popup={brushLive} expanded={brushOpen} onClick={brushLive ? onBrush : undefined} /> : <ToolButton key={t.id} tool={t} disabled={locked} />,
      )}
      <span className="ta-rail__spacer" aria-hidden="true" />
      {locked || !brushLive ? (
        <span className="ta-swatch" role="img" aria-label="Current colour #1F3A6E" />
      ) : (
        <button type="button" className="ta-swatch" aria-label="Colour, #1F3A6E" aria-haspopup="dialog" aria-expanded={colourOpen} onClick={onColour} />
      )}
      <i className="ta-rail__rule" aria-hidden="true" />
      <ToolButton tool={{ id: 'undo', label: 'Undo', icon: Undo2 }} disabled={locked} />
      <ToolButton tool={{ id: 'redo', label: 'Redo', icon: Redo2 }} disabled={locked} />
    </div>
  );
}

/* ------------------------------------------------------------------ canvas pieces */

function Cursor({ person, faded }: { person: 'Amara' | 'Ayo'; faded?: boolean }) {
  return (
    <div className="ta-cursor" data-person={person} data-faded={faded || undefined} aria-hidden="true">
      <svg className="ta-cursor__ptr" width="20" height="20" viewBox="0 0 20 20" focusable="false">
        <path d="M3.7 3.2 3.7 17.2 7.5 13.9 10.3 19.1 12.9 17.9 10.2 12.9 15.3 12.9Z" strokeWidth="1.4" strokeLinejoin="round" />
      </svg>
      <span className="ta-cursor__tag">{person}</span>
    </div>
  );
}

function Pin({ n, selected, href, onClick, label }: { n: number; selected?: boolean; href?: string; onClick?: () => void; label: string }) {
  const cls = 'ta-pin';
  if (href) {
    return (
      <Link href={href} className={cls} data-n={n} data-selected={selected || undefined} aria-label={label}>
        {n}
      </Link>
    );
  }
  return (
    <button type="button" className={cls} data-n={n} data-selected={selected || undefined} aria-label={label} aria-pressed={onClick ? !!selected : undefined} onClick={onClick}>
      {n}
    </button>
  );
}

/** Figma a2 "Comment thread / Pin 1". Reply and Resolve have no destination in the design. */
function Thread() {
  return (
    <section className="ta-thread" aria-label="Comment thread on pin 1">
      <div className="ta-thread__messages">
        <div className="ta-msg">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="ta-msg__av" src={asset(PEOPLE.ayo.photo ?? '')} alt="" loading="lazy" decoding="async" />
          <div className="ta-msg__body">
            <p className="ta-msg__head">
              <span className="ta-msg__name">Ayo Bello</span>
              <span className="ta-msg__time">10:42</span>
            </p>
            <p className="ta-msg__text">Could the Adire pattern repeat here? It feels sparse next to the rest of the headwrap.</p>
          </div>
        </div>
        <div className="ta-msg">
          <span className="ta-msg__av ta-msg__av--init" aria-hidden="true">
            KA
          </span>
          <div className="ta-msg__body">
            <p className="ta-msg__head">
              <span className="ta-msg__name">Kemi Adeyemi</span>
              <span className="ta-msg__time">10:51</span>
            </p>
            <p className="ta-msg__text">Yes, I will extend the pattern on the colour layer.</p>
          </div>
        </div>
      </div>
      <div className="ta-thread__actions">
        <Button variant="ghost" size="sm">
          Reply
        </Button>
        <Button variant="secondary" size="sm">
          Resolve
        </Button>
      </div>
    </section>
  );
}

function BrushOptions() {
  return (
    <div className="ta-brushbar" role="group" aria-label="Brush options">
      <div className="ta-brushbar__row">
        <Ic icon={Brush} size={20} />
        <span className="ta-brushbar__name">Dry ink</span>
        <i className="ta-brushbar__rule" aria-hidden="true" />
        <span className="ta-brushbar__label" data-w="size">Size</span>
        <span className="ta-slider" style={{ ['--ta-fill' as string]: '28px' }} aria-hidden="true" />
        <span className="ta-brushbar__value" data-w="size">24 px</span>
        <i className="ta-brushbar__rule" aria-hidden="true" />
        <span className="ta-brushbar__label" data-w="opacity">Opacity</span>
        <span className="ta-slider" style={{ ['--ta-fill' as string]: '58px' }} aria-hidden="true" />
        <span className="ta-brushbar__value" data-w="opacity">80%</span>
      </div>
    </div>
  );
}

function ZoomControl() {
  return (
    <div className="ta-zoom" role="group" aria-label="Zoom">
      <button type="button" className="ta-compact" aria-label="Zoom out">
        <Ic icon={ZoomOut} size={20} />
      </button>
      <span className="ta-zoom__value">100%</span>
      <button type="button" className="ta-compact" aria-label="Zoom in">
        <Ic icon={ZoomIn} size={20} />
      </button>
      <i className="ta-zoom__rule" aria-hidden="true" />
      <button type="button" className="ta-compact" aria-label="Fit to screen">
        <Ic icon={Maximize} size={20} />
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ right panel */

/** Figma "Colour picker": hue field, hue bar and recent colours. Shown in the panel and in the d3 popover. */
function ColourPicker({ faded }: { faded?: boolean }) {
  return (
    <div className="ta-colour" data-faded={faded || undefined}>
      <div className="ta-colour__head">
        <h2 className="ta-colour__title">Colour</h2>
        <span className="ta-colour__hex">#1F3A6E</span>
      </div>
      <div className="ta-colour__field" aria-hidden="true">
        <span className="ta-colour__picker" />
      </div>
      <div className="ta-colour__hue" aria-hidden="true">
        <span className="ta-colour__knob" />
      </div>
      <ul className="ta-colour__recent" aria-label="Recent colours">
        {RECENT.map((hex, i) => (
          <li key={hex} className="ta-colour__swatch" data-on={i === 0 || undefined} style={{ background: hex }} title={hex} />
        ))}
      </ul>
    </div>
  );
}

function LayerRow({ layer, selected, onToggle }: { layer: Layer; selected: boolean; onToggle: () => void }) {
  const body = (
    <>
      <span className="ta-layer__thumb" data-layer={layer.id} />
      <span className="ta-layer__text">
        <span className="ta-layer__name">{layer.name}</span>
        <span className="ta-layer__detail">{layer.detail}</span>
      </span>
      {layer.editor ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img className="ta-layer__editor" src={asset(PEOPLE[layer.editor].photo ?? '')} alt="" loading="lazy" decoding="async" title={`${PEOPLE[layer.editor].name} is editing this layer`} />
      ) : null}
      <span className="ta-layer__eye" aria-hidden="true">
        <Ic icon={layer.hidden ? EyeOff : Eye} size={18} />
      </span>
    </>
  );
  if (layer.hidden) {
    return (
      <div className="ta-layer" data-hidden aria-label={`${layer.name}, hidden`}>
        {body}
      </div>
    );
  }
  return (
    <button type="button" className="ta-layer" data-selected={selected || undefined} aria-pressed={selected} onClick={onToggle}>
      {body}
    </button>
  );
}

/* ------------------------------------------------------------------ the screen */

export function DigitalArt({ state = 'saved', thread = false }: { state?: WsState; thread?: boolean }) {
  const nav = useNav();
  const navRef = useRef(nav);
  navRef.current = nav;

  const [brushOpen, setBrushOpen] = useState(false);
  const [colourOpen, setColourOpen] = useState(false);
  const [layersOn, setLayersOn] = useState<Set<string>>(() => new Set(['colour']));
  const [pin2, setPin2] = useState(false);
  const [version, setVersion] = useState(ART_DEFAULT_VERSION);
  const [settled, setSettled] = useState(false);
  // the save status popover under the status pill; the Saving and Reconnecting screens wait while it is open
  const [saveOpen, setSaveOpen] = useState(false);

  // Figma a3 and a6: the Saving frame returns to the default screen after 2 s (the pill reads "All changes saved" from 1.5 s),
  // the Reconnecting frame after 3 s. A popover that is open holds them (the Saving screen goes on from the start when it closes).
  useEffect(() => {
    if (saveOpen) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    if (state === 'saving') {
      timers.push(setTimeout(() => setSettled(true), 1500));
      timers.push(setTimeout(() => navRef.current.replace(P.main), 2000));
    } else if (state === 'reconnecting') {
      timers.push(setTimeout(() => navRef.current.replace(P.main), 3000));
    }
    return () => timers.forEach(clearTimeout);
  }, [state, saveOpen]);

  const locked = state === 'viewOnly';
  const history = state === 'versionHistory';
  const shown: WsState = state === 'saving' && settled ? 'saved' : state;
  const banner = bannerFor(state);
  const current = ART_VERSIONS.find((v) => v.id === version) ?? ART_VERSIONS[2];
  const brushLive = !locked && !history;

  const avatars: PresenceItem[] = [
    { id: 'kemi', state: 'editing' },
    { id: 'amara', state: state === 'collaboratorOffline' ? 'offline' : 'editing' },
    { id: 'ayo', state: 'viewing' },
  ];

  const toggleLayer = (id: string) =>
    setLayersOn((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  // Top bar links (Figma reactions): Version history opens a8 and a8 returns; Comments opens the thread from the default screen and
  // returns from every other screen. The status pill opens the save status popover (not on the comment thread frame).
  const isDefault = state === 'saved' && !thread;
  const links = {
    history: history ? P.main : P.history,
    comments: isDefault ? P.thread : P.main,
  };

  // Comment pin 1: default and the state frames open the thread, the thread closes it, the version preview has no link.
  const pin1Href = history ? undefined : thread ? P.main : P.thread;

  const overlays = (
    <>
      {brushOpen ? (
        <Popover onClose={() => setBrushOpen(false)} label="Brush library" className="ta-pop ta-pop--brush">
          <div className="ta-brushes">
            <h2 className="ta-brushes__title">Brushes</h2>
            <ul className="ta-brushes__list">
              {BRUSHES.map((b) => (
                <li key={b.id} className="ta-brush" data-active={b.active || undefined} aria-current={b.active ? 'true' : undefined}>
                  <span className="ta-brush__name">{b.name}</span>
                  <span className="ta-brush__stroke" data-brush={b.id} aria-hidden="true" />
                </li>
              ))}
            </ul>
          </div>
        </Popover>
      ) : null}
      {colourOpen ? (
        <Popover onClose={() => setColourOpen(false)} label="Colour picker" className="ta-pop ta-pop--colour">
          <ColourPicker />
        </Popover>
      ) : null}
    </>
  );

  return (
    <WorkspaceShell
      kind="art"
      state={shown}
      title="Visual identity and illustration series"
      project="Adire Stories"
      avatars={avatars}
      more="+1"
      links={links}
      saveMenu={thread ? undefined : { links: SAVE_LINKS, initialOpen: state === 'couldNotSave' }}
      onSaveOpenChange={setSaveOpen}
      peopleRows={ART_PEOPLE}
      peopleSummary={PEOPLE_SUMMARY}
      overlays={overlays}
    >
      <div className="ta-body" data-banner={banner ? '' : undefined}>
        <ToolRail locked={locked} brushLive={brushLive} onBrush={() => setBrushOpen((v) => !v)} onColour={() => setColourOpen((v) => !v)} brushOpen={brushOpen} colourOpen={colourOpen} />

        <div className="ta-canvas">
          <div className="ta-scroll">
            <div className="ta-stage">
              <div className="ta-board">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img className="ta-board__art" src={asset('/images/app/workspace/art-adire-portrait.jpg')} alt="" width={880} height={660} loading="lazy" decoding="async" />
                <Cursor person="Amara" faded={state === 'collaboratorOffline'} />
                <Cursor person="Ayo" />
                <Pin n={1} selected={thread} href={pin1Href} label={thread ? 'Close comment 1' : 'Open comment 1'} />
                <Pin n={2} selected={pin2} onClick={() => setPin2((v) => !v)} label="Comment 2" />
                {thread ? <Thread /> : null}
              </div>
            </div>
          </div>

          {!locked && !history ? <BrushOptions /> : null}
          <ZoomControl />
          <div className="ta-size">4000 x 3000 px, 300 dpi</div>
          {banner ? (
            <Banner
              kind={banner}
              className="ta-banner"
              title={banner === 'version' ? versionBannerTitle(current.time) : undefined}
              hrefs={{ retry: P.reconnecting, back: P.main, restore: P.main }}
            />
          ) : null}
        </div>

        <aside className="ta-panel" aria-label={history ? 'Version history' : 'Layers'}>
          {history ? (
            <VersionPanel versions={ART_VERSIONS} selected={version} onSelect={(v) => setVersion(v.id)} />
          ) : (
            <div className="ta-layers">
              <header className="ta-layers__head">
                <h2 className="ta-layers__title">Layers</h2>
                <button type="button" className="ta-compact" aria-label="Add layer" disabled={locked}>
                  <Ic icon={Plus} size={20} />
                </button>
              </header>
              {LAYERS.map((l) => (
                <LayerRow key={l.id} layer={l} selected={layersOn.has(l.id)} onToggle={() => toggleLayer(l.id)} />
              ))}
              <ColourPicker faded={locked} />
            </div>
          )}
        </aside>
      </div>
    </WorkspaceShell>
  );
}

