'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { useNav, usePath } from '@/lib/nav';
import { useSession } from '@/lib/auth';
import { useLayout } from '@/lib/hooks';
import { NotificationsModal } from '@/features/community/NotificationsModal';
import type { RouteDef, MainPage } from '@/routes.types';
import { DesktopHeader, MobileHeader, TabletHeader } from './AppHeader';
import { BottomBar, PageSheet, ProfileSheet } from './BottomNav';
import { ToastHost } from '@/ui/toast';
import { Motion } from '@/components/Motion';
import { rememberNext } from '@/lib/next-path';

export { NEXT_KEY, rememberNext, takeNext } from '@/lib/next-path';

/**
 * Signed-in frame: header (desktop), header and bottom bar (tablet), header, bottom bar and sheets (mobile),
 * plus the page content. Signed-out visitors are sent to the sign-in panel and come back to the page they asked for.
 */
export function AppShell({ route, children }: { route: RouteDef; children: ReactNode }) {
  const session = useSession();
  const nav = useNav();
  const path = usePath();
  const layout = useLayout();
  const [mounted, setMounted] = useState(false);
  const [sheet, setSheet] = useState<MainPage | null>(null);
  const [profile, setProfile] = useState(false);
  const [notifications, setNotifications] = useState(false);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (mounted && !session.signedIn) {
      rememberNext(path);
      nav.replace('/sign-in');
    }
  }, [mounted, session.signedIn, path, nav]);
  // close sheets when the screen changes
  useEffect(() => {
    setSheet(null);
    setProfile(false);
  }, [path]);

  const active = route.nav;
  const openNotifications = () => setNotifications(true);
  // Lets overlay styles (portalled outside .app) follow the section: Community modals use a flat 28% scrim, Collaborate a blurred 35% one.
  const activePage = active?.page;
  useEffect(() => {
    if (!activePage) return;
    document.documentElement.dataset.page = activePage;
    return () => {
      delete document.documentElement.dataset.page;
    };
  }, [activePage]);

  return (
    <div className="app" data-layout={layout} data-ready={mounted && session.signedIn ? 'true' : 'false'}>
      <a className="skip-link" href="#main">Skip to content</a>
      {layout === 'desktop' ? <DesktopHeader active={active} onNotifications={openNotifications} /> : null}
      {layout === 'tablet' ? <TabletHeader active={active} onNotifications={openNotifications} /> : null}
      {layout === 'mobile' ? <MobileHeader active={active} onProfile={() => setProfile(true)} /> : null}
      <main id="main" className="app__main" tabIndex={-1}>
        {mounted && session.signedIn ? (
          <div className="route-stage" key={path}>{children}</div>
        ) : null}
      </main>
      {layout !== 'desktop' ? <BottomBar active={active} onOpenPage={setSheet} /> : null}
      {layout !== 'desktop' ? <PageSheet page={sheet} active={active} onClose={() => setSheet(null)} /> : null}
      {layout === 'mobile' ? <ProfileSheet open={profile} onClose={() => setProfile(false)} onNotifications={openNotifications} /> : null}
      <NotificationsModal open={notifications} onClose={() => setNotifications(false)} />
      <ToastHost />
      {mounted && session.signedIn ? <Motion key={path} /> : null}
    </div>
  );
}
