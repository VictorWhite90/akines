'use client';

/**
 * 12.31 Opportunities: list (Figma 17711:90709, eight open roles) and Empty (17711:91587).
 * The cards open their project detail; the "Discover projects" link and the empty state action open Discover projects (17311:18092).
 * The empty frame has no trigger in the prototype, so it lives at /collaborate/opportunities/state-empty.
 */
import { Button } from '@/ui';
import { OPPORTUNITIES } from './data';
import { OpportunityCard } from './OpportunityCard';
import { CardLink, PageHead, StatePanel } from '../projects/ui';

const DISCOVER = '/collaborate/discover';

function Head() {
  return (
    <PageHead
      eyebrow="Opportunities"
      title="Where you could help."
      lead="Open roles on projects that are looking for people. Choose one to read about the project."
      link={<CardLink href={DISCOVER}>Discover projects</CardLink>}
    />
  );
}

export function Opportunities() {
  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        <Head />
        <section className="dsc-results" aria-label="Open roles">
          <div className="dsc-summary">
            <p className="dsc-summary__count" aria-live="polite">
              {OPPORTUNITIES.length} open roles
            </p>
            <span className="dsc-summary__note">Best match to your profile first</span>
          </div>
          <div className="dsc-grid" data-m="stagger">
            {OPPORTUNITIES.map((item) => (
              <OpportunityCard key={item.id} item={item} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export function OpportunitiesEmpty() {
  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        <Head />
        <StatePanel
          headline="No open roles right now."
          support="When a project looks for people whose skills match yours, the role will appear here. You can also explore projects that are still forming a team."
        >
          <Button href={DISCOVER}>Discover projects</Button>
        </StatePanel>
      </div>
    </div>
  );
}
