'use client';

import { useRef, useState } from 'react';
import { Logo } from '@/components/Logo';
import { IconButton } from '@/ui/Button';
import { Link, useNav } from '@/lib/nav';
import { signOut, useSession } from '@/lib/auth';
import { useDismiss } from '@/lib/hooks';
import type { MainPage } from '@/routes.types';
import { AppIcon } from './icons';
import { ProfileProgress } from './ProfileProgress';
import { COUNTERS, DEST, NAV, counterText, pageOf, type AppIconName } from './nav-model';

export type ActiveNav = { page: MainPage; tab?: string } | undefined;

function Counter({ n }: { n: number }) {
  if (n <= 0) return null;
  return <span className="hdr-count" aria-hidden="true">{counterText(n)}</span>;
}

/** Round icon button with counter and a dark tooltip (Messages, Notifications). */
export function HeaderIconButton({ icon, label, count, href, onClick }: { icon: AppIconName; label: string; count: number; href?: string; onClick?: () => void }) {
  const aria = count > 0 ? `${label}, ${count} unread` : label;
  // `hdr-iconbtn` is kept as a hook for tests; the look is the kit IconButton (ghost, 44) and its tooltip
  return (
    <IconButton className="hdr-iconbtn" label={aria} href={href} onClick={onClick}>
      <AppIcon name={icon} />
      <Counter n={count} />
    </IconButton>
  );
}

/** The items of the avatar menu (desktop and tablet dropdown). Log out clears the test session and returns to the landing page. */
export const MENU_ITEMS = [
  { label: 'View profile', href: DEST.profile },
  { label: 'Complete your profile', href: DEST.completeProfile },
  { label: 'Settings', href: DEST.settings },
  { label: 'Help', href: DEST.help },
] as const;

export function AvatarMenu() {
  const session = useSession();
  const nav = useNav();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useDismiss(open, ref, () => setOpen(false));
  return (
    <div className="hdr-avatar" ref={ref} data-open={open ? 'true' : 'false'}>
      <button type="button" className="hdr-avatar__btn" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        <span className="hdr-avatar__circle">{session.initials || 'KA'}</span>
        <span className="hdr-avatar__name">{session.username || 'kemiadeyemi'}</span>
        <AppIcon name="chevron-down" size={16} className="hdr-avatar__chev" />
      </button>
      {open ? (
        <div className="hdr-menu" role="menu">
          {MENU_ITEMS.map((item) => (
            <Link key={item.label} href={item.href} role="menuitem" className="hdr-menu__item" onClick={() => setOpen(false)}>
              {item.label}
            </Link>
          ))}
          <div className="hdr-menu__rule" role="separator" />
          <button
            type="button"
            role="menuitem"
            className="hdr-menu__item"
            onClick={() => {
              setOpen(false);
              signOut();
              nav.push('/');
            }}
          >
            Log out
          </button>
        </div>
      ) : null}
    </div>
  );
}

export function useHeaderTitle(active: ActiveNav) {
  if (!active) return { eyebrow: '', title: '' };
  const page = pageOf(active.page);
  if (page.key === 'community') return { eyebrow: '', title: page.label };
  return { eyebrow: page.label, title: active.tab || page.tabs[0]?.label || page.label };
}

/** Desktop header (option A: icons only, name in a tooltip on hover) plus the sub row when the page has nested pages. */
export function DesktopHeader({ active, onNotifications }: { active: ActiveNav; onNotifications: () => void }) {
  const page = active ? pageOf(active.page) : undefined;
  const tabs = page?.tabs ?? [];
  const activeTab = active?.tab ?? tabs[0]?.label;
  return (
    <header className="hdr" data-layout="desktop">
      <div className="hdr__row">
        <div className="hdr__left">
          <Link href="/community" className="hdr__logo" aria-label="Akines, Community Home">
            <Logo />
          </Link>
          <nav className="hdr-nav" aria-label="Main">
            {NAV.map((p) => {
              const isActive = active?.page === p.key;
              return (
                <Link key={p.key} href={p.path} className="hdr-nav__item" aria-label={p.label} aria-current={isActive ? 'page' : undefined} data-active={isActive ? 'true' : 'false'}>
                  <AppIcon name={p.icon} />
                  <span className="hdr-nav__bar" aria-hidden="true" />
                  <span className="hdr-tip" role="presentation">{p.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="hdr__actions">
          <ProfileProgress />
          <HeaderIconButton icon="messages" label="Messages" count={COUNTERS.messages} href={DEST.messages} />
          <HeaderIconButton icon="notifications" label="Notifications" count={COUNTERS.notifications} onClick={onNotifications} />
          <span className="hdr__divider" aria-hidden="true" />
          <AvatarMenu />
        </div>
      </div>
      {tabs.length > 0 ? (
        <nav className="hdr-tabs" aria-label={page?.label}>
          {tabs.map((t) => (
            <Link key={t.path} href={t.path} className="hdr-tab" aria-current={t.label === activeTab ? 'page' : undefined} data-active={t.label === activeTab ? 'true' : 'false'}>
              {t.label}
            </Link>
          ))}
        </nav>
      ) : null}
    </header>
  );
}

/** Tablet header: logo, divider, eyebrow and page title, then Messages, Notifications and the avatar menu with username. */
export function TabletHeader({ active, onNotifications }: { active: ActiveNav; onNotifications: () => void }) {
  const { eyebrow, title } = useHeaderTitle(active);
  return (
    <header className="hdr hdr--tablet" data-layout="tablet">
      <div className="hdr__row">
        <div className="hdr__left">
          <Link href="/community" className="hdr__logo" aria-label="Akines, Community Home"><Logo /></Link>
          <span className="hdr__divider hdr__divider--tall" aria-hidden="true" />
          <div className="hdr__title">
            {eyebrow ? <span className="hdr__eyebrow">{eyebrow}</span> : null}
            <span className="hdr__h">{title}</span>
          </div>
        </div>
        <div className="hdr__actions">
          <ProfileProgress compact />
          <HeaderIconButton icon="messages" label="Messages" count={COUNTERS.messages} href={DEST.messages} />
          <HeaderIconButton icon="notifications" label="Notifications" count={COUNTERS.notifications} onClick={onNotifications} />
          <span className="hdr__divider" aria-hidden="true" />
          <AvatarMenu />
        </div>
      </div>
    </header>
  );
}

/**
 * Mobile header (Figma "Header Mobile"): logo mark, eyebrow and title, and only the avatar (with an orange dot when anything is unread).
 * The avatar opens the profile sheet. No profile progress ring here: the profile sheet carries "Complete your profile".
 */
export function MobileHeader({ active, open, onProfile }: { active: ActiveNav; open?: boolean; onProfile: () => void }) {
  const session = useSession();
  const { eyebrow, title } = useHeaderTitle(active);
  return (
    <header className="hdr hdr--mobile" data-layout="mobile">
      <div className="hdr__row">
        <div className="hdr__left">
          <Link href="/community" className="hdr__logo" aria-label="Akines, Community Home"><Logo wordmark={false} /></Link>
          <div className="hdr__title">
            {eyebrow ? <span className="hdr__eyebrow">{eyebrow}</span> : null}
            <span className="hdr__h">{title}</span>
          </div>
        </div>
        <div className="hdr__actions">
          <button
            type="button"
            className="hdr-avatar__btn hdr-avatar__btn--solo"
            aria-label="Profile, messages and notifications"
            aria-haspopup="dialog"
            aria-expanded={open ? true : false}
            data-open={open ? 'true' : undefined}
            onClick={onProfile}
          >
            <span className="hdr-avatar__circle">{session.initials || 'KA'}</span>
            {COUNTERS.messages + COUNTERS.notifications > 0 ? <span className="hdr-dot" aria-hidden="true" /> : null}
          </button>
        </div>
      </div>
    </header>
  );
}
