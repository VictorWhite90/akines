'use client';

import './opportunities.css';
import { Link } from '@/lib/nav';
import { IconCardArrow, StageLine } from '../projects/ui';
import type { Opportunity } from './data';

/**
 * Opportunity Card (Figma set 17709:91102, 445 x 542): the whole card opens the project detail.
 * States: Default (17709:90994), Hover (17709:91030, ink border), Pressed (17709:91054, subtle ground and ink border) and
 * Focus (17709:91078, 2 px ink border). The states are in opportunities.css.
 */
export function OpportunityCard({ item }: { item: Opportunity }) {
  return (
    <Link href={item.href} className="op-card" aria-label={`${item.role}, ${item.project}. View project`}>
      <div className="op-card__top">
        <StageLine stage="Open role" type={item.type} />
      </div>
      <div className="op-card__group">
        <h2 className="op-card__title">{item.role}</h2>
        <p className="op-card__summary">{item.summary}</p>
      </div>
      <div className="op-card__divider" />
      <div className="op-card__field">
        <span className="dsc-label">Project</span>
        <p className="op-card__value op-card__value--project">{item.project}</p>
      </div>
      <div className="op-card__field">
        <span className="dsc-label">Commitment</span>
        <p className="op-card__value op-card__value--commit">{item.commitment}</p>
      </div>
      <div className="op-card__field">
        <span className="dsc-label">Project owner</span>
        <p className="op-card__value">{item.owner}</p>
      </div>
      <span className="op-card__cta">
        View project
        <IconCardArrow />
      </span>
    </Link>
  );
}
