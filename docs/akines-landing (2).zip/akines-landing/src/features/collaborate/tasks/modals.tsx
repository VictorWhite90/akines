'use client';

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Button, Field, Modal, TextArea, TextInput } from '@/ui';
import { CardLink } from '../workspace/parts';
import { SlideOut } from '../workspace/slideout';
import { DETAIL, EDIT, PEOPLE, longDate, parseDay, personOf, type MilestoneInfo, type Task } from './data';
import { useTasksData } from './store';

/**
 * Modal:Create task (17680:460) and Modal:Request review (17680:546). Both are 640 wide with the eyebrow, headline and support line
 * of the design, Line Fields, and the primary button with a Cancel link. The scrim, the close button and Cancel close the modal.
 * "Filled" fields (dark border) are the ones the design shows with a value.
 * Slide-out:Edit task (17972:163075) and its Needs attention state (17972:163242) are at the end of the file.
 */

/** Line Field with a value shows the dark border of the Filled state. */
const filled = (v: string) => (v.trim() ? 'tk-filled' : undefined);

/* ------------------------------------------------------------------ Modal: Create task */

/** Reads the milestone field: a name (or part of a name) of one of the two milestones, otherwise the first one. */
function milestoneOf(text: string, milestones: MilestoneInfo[]): string {
  const t = text.trim().toLowerCase();
  const hit = t ? milestones.find((m) => m.name.toLowerCase().includes(t) || t.includes(m.name.toLowerCase())) : undefined;
  return (hit ?? milestones[0]).name;
}

export function CreateTaskModal({ open, onClose, onCreate }: { open: boolean; onClose: () => void; onCreate: (task: Task) => void }) {
  // the starting values, the people and the milestones are those of the project of the page
  const { milestones, people, copy, create: start } = useTasksData();
  const initial = { title: '', description: '', who: start.who, due: start.due, milestone: milestones[0].name };
  const [title, setTitle] = useState(initial.title);
  const [description, setDescription] = useState(initial.description);
  const [who, setWho] = useState(initial.who);
  const [due, setDue] = useState(initial.due);
  const [milestone, setMilestone] = useState(initial.milestone);

  // every opening starts again from the frame: title and description empty, the other three fields filled
  useEffect(() => {
    if (open) {
      setTitle(initial.title);
      setDescription(initial.description);
      setWho(initial.who);
      setDue(initial.due);
      setMilestone(initial.milestone);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const create = (e?: FormEvent) => {
    e?.preventDefault();
    const day = parseDay(due);
    onCreate({
      id: `new-${Date.now()}`,
      title: title.trim() || copy.fallbackTitle,
      milestone: milestoneOf(milestone, milestones),
      priority: 'Medium',
      owner: personOf(who, people),
      status: 'Not started',
      day: day ?? 999,
      dueText: day === null && due.trim() ? due.trim() : undefined,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow="NEW TASK"
      title="What needs to be done?"
      description="Name the task and say who is responsible."
      footer={
        <>
          <Button type="submit" form="tk-create-form">
            Create task
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="tk-create-form" className="cw-form" onSubmit={create} noValidate>
        <Field label="Task title" hint="A short, clear name.">
          <TextInput className={filled(title)} value={title} placeholder={start.titlePlaceholder} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Description" hint="Optional.">
          <TextInput className={filled(description)} value={description} placeholder="What does done look like?" onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <div className="tk-pair">
          <Field label="Responsible" hint="Who is accountable.">
            <TextInput className={filled(who)} value={who} onChange={(e) => setWho(e.target.value)} />
          </Field>
          <Field label="Due date" hint="When it should be done.">
            <TextInput className={filled(due)} value={due} onChange={(e) => setDue(e.target.value)} />
          </Field>
        </div>
        <Field label="Milestone" hint="The milestone this task belongs to.">
          <TextInput className={filled(milestone)} value={milestone} onChange={(e) => setMilestone(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal: Request review */

export function RequestReviewModal({ open, reviewer, onClose, onRequest }: { open: boolean; reviewer: string; onClose: () => void; onRequest: (reviewer: string, note: string) => void }) {
  const [who, setWho] = useState(reviewer);
  const [note, setNote] = useState('');

  useEffect(() => {
    if (open) {
      setWho(reviewer);
      setNote('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const request = (e?: FormEvent) => {
    e?.preventDefault();
    onRequest(who.trim() || reviewer, note.trim());
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow="REQUEST REVIEW"
      title="Who should review this?"
      description="They will be told that the task is ready."
      footer={
        <>
          <Button type="submit" form="tk-review-form">
            Request review
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="tk-review-form" className="cw-form" onSubmit={request} noValidate>
        <Field label="Reviewer" hint="They will be told straight away.">
          <TextInput className={filled(who)} value={who} onChange={(e) => setWho(e.target.value)} />
        </Field>
        <Field label="Note" hint="Optional.">
          <TextInput className={filled(note)} value={note} placeholder="Anything the reviewer should know?" onChange={(e) => setNote(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Slide-out: Edit task */

/** What the Edit task form hands back: the five fields read into the shape of a task. */
export type TaskEdit = Pick<Task, 'title' | 'description' | 'owner' | 'day' | 'dueText' | 'milestone'>;

/** The person is shown as in the design ("Kemi Adeyemi (you)"). */
const ownerLabel = (owner: string) => PEOPLE.find((p) => p.name === owner)?.label ?? owner;
const FIRST_DUE_DAY = parseDay(DETAIL.due);

/**
 * Slide-out:Edit task (Figma Slide-out Form 17972:147077), 480 wide from the right edge over the page: the small EDIT TASK label with the
 * close button, the headline, the five fields (Task title, Description, Responsible, Due date, Milestone) and Save changes with Cancel.
 * Needs attention: a task without a title shows "Add a title to continue." under the field and Save changes does not save. The scrim,
 * the close button, Cancel and Escape close it. `invalid` opens it in the Needs attention state (the frame with the empty title).
 */
export function EditTaskSlideOut({ open, task, invalid, onClose, onSave }: { open: boolean; task: Task; invalid?: boolean; onClose: () => void; onSave: (edit: TaskEdit) => void }) {
  const { milestones, create } = useTasksData();
  const title = useRef<HTMLInputElement>(null);
  // the fields start from the task; the due date starts from the design's new date while the task still has its first one
  const start = () => ({
    title: invalid ? '' : task.title,
    description: task.description ?? DETAIL.description,
    who: ownerLabel(task.owner),
    due: task.dueText ?? (task.day === FIRST_DUE_DAY ? EDIT.dueSample : longDate(task.day)),
    milestone: task.milestone,
  });
  const [f, setF] = useState(start);
  const [tried, setTried] = useState(Boolean(invalid));
  const set = (k: keyof ReturnType<typeof start>) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }));

  // every opening starts again from the task
  useEffect(() => {
    if (open) {
      setF(start());
      setTried(Boolean(invalid));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const save = (e?: FormEvent) => {
    e?.preventDefault();
    if (!f.title.trim()) {
      setTried(true);
      title.current?.focus();
      return;
    }
    const day = parseDay(f.due);
    onSave({
      title: f.title.trim(),
      description: f.description.trim(),
      owner: personOf(f.who, PEOPLE),
      day: day ?? task.day,
      dueText: day === null && f.due.trim() ? f.due.trim() : undefined,
      milestone: milestoneOf(f.milestone, milestones),
    });
  };

  return (
    <SlideOut
      open={open}
      onClose={onClose}
      eyebrow={EDIT.eyebrow}
      label={EDIT.title}
      footer={
        <>
          <Button type="submit" form="tk-edit-form">
            {EDIT.save}
          </Button>
          <Button variant="secondary" onClick={onClose}>
            {EDIT.cancel}
          </Button>
        </>
      }
    >
      <form id="tk-edit-form" className="tk-edit" onSubmit={save} noValidate>
        <h2 className="tk-edit__title">{EDIT.title}</h2>
        <Field label="Task title" error={tried && !f.title.trim() ? EDIT.titleError : undefined}>
          <TextInput ref={title} className={filled(f.title)} value={f.title} placeholder={create.titlePlaceholder} onChange={set('title')} />
        </Field>
        <Field label="Description">
          <TextArea className={filled(f.description)} rows={3} value={f.description} onChange={set('description')} />
        </Field>
        <Field label="Responsible">
          <TextInput className={filled(f.who)} value={f.who} onChange={set('who')} />
        </Field>
        <Field label="Due date">
          <TextInput className={filled(f.due)} value={f.due} onChange={set('due')} />
        </Field>
        <Field label="Milestone">
          <TextInput className={filled(f.milestone)} value={f.milestone} onChange={set('milestone')} />
        </Field>
      </form>
    </SlideOut>
  );
}
