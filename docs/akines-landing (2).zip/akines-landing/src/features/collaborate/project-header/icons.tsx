import type { ReactNode } from 'react';

/**
 * Icons of the project header (Figma strokes, currentColor). Kept here so this folder does not import workspace/parts.tsx
 * (parts.tsx imports the project header).
 */
function Icon({ size = 20, box = 20, sw = 1.4, children }: { size?: number; box?: number; sw?: number; children: ReactNode }) {
  return (
    <svg width={size} height={size} viewBox={`0 0 ${box} ${box}`} fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      {children}
    </svg>
  );
}

/** Project switcher button (Figma icon "Switcher"). */
export const SwitcherIcon = () => (
  <Icon>
    <path d="m5 7.5 5 5 5-5" />
  </Icon>
);
export const BellIcon = () => (
  <Icon>
    <path d="M5.5 8.5a4.5 4.5 0 0 1 9 0c0 4.2 1.8 5.5 1.8 5.5H3.7s1.8-1.3 1.8-5.5ZM8.4 16.5a1.8 1.8 0 0 0 3.2 0" />
  </Icon>
);
export const SlidersIcon = () => (
  <Icon>
    <path d="M3 6h7M14 6h3M3 14h3M10 14h7" />
    <circle cx="12" cy="6" r="2" />
    <circle cx="8" cy="14" r="2" />
  </Icon>
);
/** The check of the current project in the switcher (24 px). */
export const CurrentCheck = () => (
  <Icon size={24} box={24} sw={1.5}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </Icon>
);
