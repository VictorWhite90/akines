'use client';

/** Community building blocks (prefix ch-). Buttons, chips, tags, toggles and overlays come from the kit (@/ui). */
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowRight, Calendar, Check, ChevronLeft, ChevronRight, Circle, CircleAlert, CircleCheck, Clock, Lock, MessageCircle, PencilLine, RefreshCw, ShieldCheck } from 'lucide-react';
import { Link } from '@/lib/nav';
import { IconButton } from '@/ui';
import { useReducedMotion } from '@/lib/hooks';
import { AV, IMG, type AvKey } from './data';

export const cx = (...p: Array<string | false | null | undefined>) => p.filter(Boolean).join(' ');

/* Icons: the Figma set is 16 or 20 px with a 1.25 stroke */
const ic = (C: typeof ArrowRight, size: number, w = 1.25) => <C size={size} strokeWidth={w} absoluteStrokeWidth aria-hidden focusable={false} />;
export const IArrow = ({ s = 16 }: { s?: number }) => ic(ArrowRight, s);
export const IChevron = ({ s = 16 }: { s?: number }) => ic(ChevronRight, s, 1.5);
export const IPrev = ({ s = 24 }: { s?: number }) => ic(ChevronLeft, s, 1.5);
export const INext = ({ s = 24 }: { s?: number }) => ic(ChevronRight, s, 1.5);
export const IClock = ({ s = 16 }: { s?: number }) => ic(Clock, s);
export const ICalendar = ({ s = 16 }: { s?: number }) => ic(Calendar, s);
export const ILock = ({ s = 16 }: { s?: number }) => ic(Lock, s);
export const ICheck = ({ s = 16 }: { s?: number }) => ic(Check, s, 1.5);
export const ICheckCircle = ({ s = 20 }: { s?: number }) => ic(CircleCheck, s);
export const ICircle = ({ s = 20 }: { s?: number }) => ic(Circle, s);
export const IMessage = ({ s = 40 }: { s?: number }) => ic(MessageCircle, s);
export const IPencil = ({ s = 16 }: { s?: number }) => ic(PencilLine, s);
export const IShield = ({ s = 16 }: { s?: number }) => ic(ShieldCheck, s);
export const IAlert = ({ s = 24 }: { s?: number }) => ic(CircleAlert, s);
export const IRefresh = ({ s = 16 }: { s?: number }) => ic(RefreshCw, s);

/** Section Header (Figma component, Large 48 px headline, Medium 32 px) */
export function SectionHeader({ label, headline, support, size = 'lg', className }: { label: string; headline: string; support: string; size?: 'lg' | 'md'; className?: string }) {
  return (
    <header className={cx('ch-sh', `ch-sh--${size}`, className)}>
      <p className="ch-sh__label">{label}</p>
      <h2 className="ch-sh__headline" data-m="words">
        {headline}
      </h2>
      <p className="ch-sh__support">{support}</p>
    </header>
  );
}

/** Photograph with the curtain reveal. `fill` makes it cover its positioned parent. */
export function Photo({ name, fill, className, position, eager }: { name: string; fill?: boolean; className?: string; position?: string; eager?: boolean }) {
  return (
    <div className={cx('ch-photo', fill && 'ch-photo--fill', className)} data-m="frame">
      <img className="cover" src={IMG(name)} alt="" loading={eager ? 'eager' : 'lazy'} decoding="async" style={position ? { objectPosition: position } : undefined} />
    </div>
  );
}
/** Dark gradient and progressive blur laid over a photograph (Figma "Scrim" and "Progressive blur") */
export const Veil = () => (
  <>
    <span className="ch-pblur" aria-hidden="true" />
    <span className="ch-scrim" aria-hidden="true" />
  </>
);

export function Avatar({ k, size = 28, ring }: { k: AvKey; size?: number; ring?: 'light' | 'accent' }) {
  return (
    <span className={cx('ch-av', ring && `ch-av--${ring}`)} style={{ width: size, height: size }}>
      <img src={AV(k)} alt="" loading="lazy" decoding="async" />
    </span>
  );
}
export function AvatarStack({ people, size = 28, overlap = 8 }: { people: AvKey[]; size?: number; overlap?: number }) {
  return (
    <span className="ch-avs" style={{ ['--ch-av-gap' as string]: `-${overlap}px` }}>
      {people.map((p) => (
        <Avatar key={p} k={p} size={size} ring="light" />
      ))}
    </span>
  );
}

type LinkBase = { href?: string; onClick?: () => void; children: ReactNode; className?: string };
/** Card Link (underlined, light on photographs, dark on the page) */
export function CardLink({ tone = 'dark', href, onClick, children, className }: LinkBase & { tone?: 'light' | 'dark' }) {
  const cls = cx('ch-clink', `ch-clink--${tone}`, className);
  return href ? (
    <Link href={href} className={cls}>
      {children}
    </Link>
  ) : (
    <button type="button" className={cls} onClick={onClick}>
      {children}
    </button>
  );
}
/** Text Link (14 px semibold, 6 / 8 padding) */
export function TextLink({ href, onClick, children, className }: LinkBase) {
  const cls = cx('ch-tlink', className);
  return href ? (
    <Link href={href} className={cls}>
      {children}
    </Link>
  ) : (
    <button type="button" className={cls} onClick={onClick}>
      {children}
    </button>
  );
}

/** List Row (Figma component): avatar, title and description, meta, chevron */
export function ListRow({ title, text, meta, avatar, onClick, href, className }: { title: string; text: string; meta?: string; avatar?: AvKey | null; onClick?: () => void; href?: string; className?: string }) {
  const inner = (
    <>
      {avatar ? <Avatar k={avatar} size={44} /> : null}
      <span className="ch-row__text">
        <span className="ch-row__title">{title}</span>
        <span className="ch-row__desc">{text}</span>
      </span>
      {meta ? <span className="ch-row__meta">{meta}</span> : null}
      <span className="ch-row__chev">
        <IChevron />
      </span>
    </>
  );
  return href ? (
    <Link href={href} className={cx('ch-row', className)}>
      {inner}
    </Link>
  ) : (
    <button type="button" className={cx('ch-row', className)} onClick={onClick}>
      {inner}
    </button>
  );
}

/** Row Link (Controls band and Settings): Alice title, description, round arrow */
export function RowLink({ title, text, href }: { title: string; text: string; href: string }) {
  return (
    <Link href={href} className="ch-rowlink">
      <span className="ch-rowlink__text">
        <span className="ch-rowlink__title">{title}</span>
        <span className="ch-rowlink__desc">{text}</span>
      </span>
      <span className="ch-rowlink__arrow">
        <IArrow />
      </span>
    </Link>
  );
}

/** Carousel state: pages, 5 s autoplay (Figma AFTER_TIMEOUT), pause on hover and focus, wraps around */
export function useCarousel(pages: number, ms = 5000) {
  const [page, setPage] = useState(0);
  const [hold, setHold] = useState(false);
  const reduced = useReducedMotion();
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (hold || reduced || pages < 2) return;
    timer.current = setTimeout(() => setPage((p) => (p + 1) % pages), ms);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [page, hold, reduced, pages, ms]);
  return {
    page,
    next: () => setPage((p) => (p + 1) % pages),
    prev: () => setPage((p) => (p - 1 + pages) % pages),
    hold: { onMouseEnter: () => setHold(true), onMouseLeave: () => setHold(false), onFocus: () => setHold(true), onBlur: () => setHold(false) },
  };
}

export function CarouselControls({ page, pages, onPrev, onNext, label, className }: { page: number; pages: number; onPrev: () => void; onNext: () => void; label: string; className?: string }) {
  return (
    <div className={cx('ch-ctrl', className)} role="group" aria-label={`${label} controls`}>
      <IconButton label={`Previous ${label}`} onClick={onPrev}>
        <IPrev />
      </IconButton>
      <span className="ch-ctrl__count" aria-live="polite">
        {page + 1} / {pages}
      </span>
      <IconButton label={`Next ${label}`} onClick={onNext}>
        <INext />
      </IconButton>
    </div>
  );
}

/** Empty block. "line" is the Home variant (rules above and below), "panel" the muted state board: 32 px title, copy and one action */
export function EmptyPanel({ title, text, children, variant = 'line', narrow, className }: { title: string; text: string; children: ReactNode; variant?: 'line' | 'panel'; narrow?: boolean; className?: string }) {
  return (
    <div className={cx('ch-pad', className)}>
      <div className={cx('ch-empty', `ch-empty--${variant}`, narrow && 'ch-empty--narrow')}>
        <h3 className="ch-empty__title">{title}</h3>
        <p className="ch-empty__text">{text}</p>
        <div>{children}</div>
      </div>
    </div>
  );
}
