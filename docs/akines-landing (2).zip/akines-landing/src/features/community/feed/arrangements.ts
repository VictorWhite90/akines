/**
 * Community Home feed: the eleven sections, the four arrangements and the rotation rule (FEED_SPEC.md sections 2 and 6).
 * Plain module on purpose (no 'use client'): the route registry and the client components both read it.
 */

export type FeedKey =
  | 'explore'
  | 'banter'
  | 'kincircle'
  | 'rooms'
  | 'activities'
  | 'collaborate'
  | 'shop'
  | 'studios'
  | 'stories'
  | 'wellbeing'
  | 'dna';

export type FeedVersion = 'a' | 'b' | 'c' | 'd';

export const FEED_VERSIONS: FeedVersion[] = ['a', 'b', 'c', 'd'];

/** localStorage key holding the version shown on the last visit. */
export const FEED_LAST_KEY = 'akines.feed.last.v1';

/** Position 1 is the most important. Each arrangement shows six of the eleven sections. */
export const ARRANGEMENTS: Record<FeedVersion, { name: string; sections: FeedKey[] }> = {
  a: { name: 'Discover', sections: ['explore', 'kincircle', 'banter', 'stories', 'studios', 'shop'] },
  b: { name: 'Belong', sections: ['kincircle', 'rooms', 'collaborate', 'activities', 'wellbeing', 'explore'] },
  c: { name: 'Make together', sections: ['collaborate', 'dna', 'rooms', 'studios', 'banter', 'shop'] },
  d: { name: 'Heritage and craft', sections: ['stories', 'studios', 'wellbeing', 'shop', 'dna', 'activities'] },
};

export const isFeedVersion = (v: unknown): v is FeedVersion => typeof v === 'string' && (FEED_VERSIONS as string[]).includes(v);

/**
 * Picks uniformly at random from the versions that are not `last`. With no usable `last` (first visit, cleared
 * storage) any of the four can come up. `random` is injectable so the rule can be tested.
 */
export function pickVersion(last: unknown, random: () => number = Math.random): FeedVersion {
  const pool = FEED_VERSIONS.filter((v) => v !== last);
  return pool[Math.min(pool.length - 1, Math.floor(random() * pool.length))];
}
