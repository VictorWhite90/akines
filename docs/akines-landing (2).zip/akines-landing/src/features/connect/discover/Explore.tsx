'use client';

/**
 * 01 Explore: five category cards in a horizontally scrollable row (PRD section 01, Figma 17893:108770).
 *
 * Wiring (from the logic layer, unchanged):
 *  - EXPLORE (data.ts) holds the cards in order: id, title, text, image (resolved with src() from images.ts), href.
 *  - A card with `href` is a <Link>; a card without one (Circles: KinCircle is design only) is a plain <button> that does nothing
 *    (see ExploreCard.tsx). Pressing a card calls track('discover_category_click', { category: id, position }), position 1-based.
 *  - The header row leads to Explore all (Figma 11.1: the row is the link, there is no "Explore all" label). The title is the link,
 *    stretched over the whole row; the two arrow buttons sit above it and keep their own job.
 *  - useCarouselTracking(scroller, 'explore') reports horizontal scrolling; the arrow buttons call
 *    trackCarouselStep('explore', 'previous' | 'next', position) instead of track().
 *
 * Why this section does not use DxSection: its header row also holds the two arrow buttons (44 x 44, Carousel Arrow), and the
 * Explore header has no support line and no link. The section keeps the same element, ids and view tracking as DxSection.
 * The arrows scroll the row to its start or end (smooth, instant for reduced motion). The cards are the focus stops, so keyboard
 * and screen reader users never need the arrows: the browser scrolls a focused card into view.
 */
import { useRef, type FocusEvent } from 'react';
import { Link } from '@/lib/nav';
import { useReducedMotion } from '@/lib/hooks';
import { IconButton } from '@/ui';
import { INext, IPrev } from '@/features/community/ui';
import { trackCarouselStep, useCarouselTracking, useSectionView } from './analytics';
import { EXPLORE, HEADS, SECTION_DOM } from './data';
import { ExploreCard } from './ExploreCard';
import './explore.css';

const LIST_ID = 'dx-explore-cards';

/** 1-based index of the first card still (at least partly) inside the row when it is scrolled to `left`. */
function firstVisibleAt(row: HTMLElement, left: number) {
  const i = (Array.from(row.children) as HTMLElement[]).findIndex((k) => k.offsetLeft + k.offsetWidth > left + 8);
  return i < 0 ? 1 : i + 1;
}

export function Explore() {
  const section = useRef<HTMLElement>(null);
  const scroller = useRef<HTMLUListElement>(null);
  const reduced = useReducedMotion();
  useSectionView(section, 'explore');
  useCarouselTracking(scroller, 'explore');
  const dom = SECTION_DOM.explore;

  const step = (dir: 'previous' | 'next') => {
    const row = scroller.current;
    if (!row) return;
    const left = dir === 'next' ? row.scrollWidth - row.clientWidth : 0;
    trackCarouselStep('explore', dir, firstVisibleAt(row, left));
    row.scrollTo({ left, behavior: reduced ? 'auto' : 'smooth' });
  };

  // Chrome leaves a card that is partly in view where it is when it gets focus; a keyboard user would be left with a ring that is
  // mostly out of sight (WCAG 2.2 focus not obscured). Bring the card fully in, with the row's scroll padding. Not for mouse
  // focus: the row must not move under a press.
  const reveal = (e: FocusEvent<HTMLUListElement>) => {
    const t = e.target as HTMLElement;
    if (!t.matches(':focus-visible')) return;
    t.closest('li')?.scrollIntoView({ inline: 'nearest', block: 'nearest', behavior: reduced ? 'auto' : 'smooth' });
  };

  return (
    <section ref={section} className="fd-section dx-section" id={dom.id} aria-labelledby={dom.titleId} data-dx-section="explore">
      <header className="dxe-head" data-m="up">
        <h2 className="fd-head__title" id={dom.titleId}>
          <Link className="dxe-headlink" href={HEADS.explore.href ?? ''}>
            {HEADS.explore.title}
          </Link>
        </h2>
        <div className="dxe-arrows">
          <IconButton variant="ghost" className="fd-arrow" label="Previous categories" tooltip={false} aria-controls={LIST_ID} onClick={() => step('previous')}>
            <IPrev s={24} />
          </IconButton>
          <IconButton variant="ghost" className="fd-arrow" label="Next categories" tooltip={false} aria-controls={LIST_ID} onClick={() => step('next')}>
            <INext s={24} />
          </IconButton>
        </div>
      </header>
      <ul className="dxe-scroller" id={LIST_ID} ref={scroller} onFocus={reveal}>
        {EXPLORE.map((c, i) => (
          <li className="dxe-item" key={c.id} style={{ ['--i' as string]: i }}>
            <ExploreCard c={c} index={i} eager={i < 4} />
          </li>
        ))}
      </ul>
    </section>
  );
}
