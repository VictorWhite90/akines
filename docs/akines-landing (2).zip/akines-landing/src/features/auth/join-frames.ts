/**
 * Data of the static join frames (routes /join/state-*). Kept out of the client module so the route registry can read it on the server.
 */
import { DUMMY } from '@/lib/auth';
import type { JoinPreset } from './JoinPage';

/** A strong sample password for the frames that show the filled, verified field (the dots are all the design shows). */
const STRONG = 'lagos-evenings-2026!';

/** [route suffix, tab title, Figma frame, preset] */
export const JOIN_FRAMES: { slug: string; title: string; figma: string; preset: JoinPreset }[] = [
  { slug: 'email-focus', title: 'Join Akines', figma: '1b Focus', preset: { focus: true, contact: '' } },
  { slug: 'email-missing', title: 'Join Akines', figma: '1c Missing', preset: { contact: '', contactErr: 'missing' } },
  { slug: 'email-invalid', title: 'Join Akines', figma: '1d Invalid entry', preset: { contact: 'kemi.adeyemi@example', contactErr: 'invalid' } },
  { slug: 'email-registered', title: 'Join Akines', figma: '1e Already registered', preset: { contact: DUMMY.email, contactErr: 'registered' } },
  { slug: 'email-sending', title: 'Join Akines', figma: '1f Sending', preset: { contact: DUMMY.email, sending: true } },
  { slug: 'google', title: 'Join Akines', figma: '08.2 Continue with Google', preset: { contact: '', provider: 'google' } },
  { slug: 'apple', title: 'Join Akines', figma: '08.3 Continue with Apple', preset: { contact: '', provider: 'apple' } },
  { slug: 'code', title: 'Confirm', figma: '2a Confirm code', preset: { step: 2, code: '' } },
  { slug: 'code-focus', title: 'Confirm', figma: '2b Focus', preset: { step: 2, code: '', focus: true } },
  { slug: 'code-missing', title: 'Confirm', figma: '2c Missing', preset: { step: 2, code: '', codeErr: 'missing' } },
  { slug: 'code-wrong', title: 'Confirm', figma: '2d Wrong code', preset: { step: 2, code: '482190', codeErr: 'wrong' } },
  { slug: 'code-expired', title: 'Confirm', figma: '2e Expired code', preset: { step: 2, code: '482190', codeErr: 'expired' } },
  { slug: 'code-checking', title: 'Confirm', figma: '2f Checking', preset: { step: 2, code: '719304', checking: true } },
  { slug: 'code-sent', title: 'Confirm', figma: '2g New code sent', preset: { step: 2, code: '', sent: true } },
  { slug: 'account', title: 'Create account', figma: '3a Create account', preset: { step: 3, username: '', password: '', age: false } },
  { slug: 'account-missing', title: 'Create account', figma: '3b All fields missing', preset: { step: 3, username: '', password: '', age: false, submitted: true } },
  { slug: 'account-taken', title: 'Create account', figma: '3c Username taken', preset: { step: 3, username: '@ndegoyit', password: '', age: false } },
  { slug: 'account-ready', title: 'Create account', figma: '3d Ready to create', preset: { step: 3, username: '@ndegoyit', available: true, password: STRONG, age: true } },
  { slug: 'account-creating', title: 'Create account', figma: '3e Creating account', preset: { step: 3, username: '@ndegoyit', available: true, password: STRONG, age: true, creating: true } },
  { slug: 'account-invalid', title: 'Create account', figma: '3f Invalid username and weak password', preset: { step: 3, username: 'nde goyit!', password: 'lagos2024!', showPw: true, age: false } },
  { slug: 'reason', title: 'Your reason', figma: '4a What brings you here', preset: { step: 4, reason: null } },
  { slug: 'reason-selected', title: 'Your reason', figma: '4b Choice selected', preset: { step: 4, reason: 5 } },
  { slug: 'reason-error', title: 'Your reason', figma: '4c Nothing chosen error', preset: { step: 4, reason: null, reasonErr: true } },
  { slug: 'reason-confirming', title: 'Your reason', figma: '4d Confirming', preset: { step: 4, reason: 5, confirming: true } },
  { slug: 'welcome', title: 'Welcome', figma: '5 Welcome', preset: { step: 5, welcomeUser: 'ndegoyit' } },
];
