'use client';

/**
 * Connect / Discover / Event (Figma 11.71): Memory and Cloth, one page for every event card (as drawn). Four states of the one page:
 *  - Event: the Register panel (Register, Save event, Share this event) and What to bring.
 *  - Modal:Register: Register opens the dialog (name from the profile, the email the confirmation goes to). Register there closes it,
 *    shows the Registered state and the toast "You are registered for this event." with Undo (2.5 s). Cancel and the scrim close it.
 *  - Registered: the panel reads REGISTRATION with the pill "Registered", the note with the address, Save event, Cancel registration
 *    (back to the Register panel) and Share this event. Undo on the toast does the same.
 * The registration is kept in the Discover store (state.ts) for the visit. Save event and Share this event have no destination in the design
 * (Share needs the browser share sheet), so they are plain controls. The host row opens Anaya Smith's profile. No analytics: the Discover
 * events have none for this page.
 */
import '../../community/feed/feed.css';
import './event.css';
import { useEffect, useId, useRef, useState } from 'react';
import { Bookmark, Check } from 'lucide-react';
import { Button, Field, Modal, TextInput, toast } from '@/ui';
import { Link } from '@/lib/nav';
import { EVENT_PAGE as E, PATHS } from './data';
import { src } from './images';
import { BackLink } from './list-parts';
import { cancelRegistration, registerForEvent, useDiscover } from './state';

const EMAIL_OK = /^\S+@\S+\.\S+$/;

function RegisterDialog({ open, onClose, onRegistered }: { open: boolean; onClose: () => void; onRegistered: () => void }) {
  const formId = useId();
  const [email, setEmail] = useState<string>(E.modal.email.value);
  useEffect(() => {
    if (open) setEmail(E.modal.email.value);
  }, [open]);
  const valid = EMAIL_OK.test(email.trim());
  const submit = () => {
    if (!valid) return;
    registerForEvent(E.slug, email.trim());
    onRegistered();
    toast.show({ message: E.toast.message, actionLabel: E.toast.undo, onAction: () => cancelRegistration(E.slug) });
  };
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={480}
      hideClose
      className="dxv-dialog"
      title={E.modal.title}
      description={E.modal.text}
      footer={
        <>
          <Button type="submit" form={formId} disabled={!valid}>
            {E.modal.submit}
          </Button>
          <Button variant="secondary" onClick={onClose}>
            {E.modal.cancel}
          </Button>
        </>
      }
    >
      <form
        id={formId}
        className="dxv-form"
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <Field label={E.modal.name.label} hint={E.modal.name.hint}>
          <TextInput readOnly value={E.modal.name.value} autoComplete="name" />
        </Field>
        <Field label={E.modal.email.label} hint={E.modal.email.hint}>
          <TextInput type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" data-autofocus />
        </Field>
      </form>
    </Modal>
  );
}

export function EventDetail() {
  const email = useDiscover().registration(E.slug);
  const registered = email !== undefined;
  const [open, setOpen] = useState(false);

  // Where focus goes once the panel has changed because of the member's action: the pill after Register, the Register button after Cancel
  const focusAfter = useRef<'pill' | 'register' | null>(null);
  const pill = useRef<HTMLDivElement>(null);
  const registerBtn = useRef<HTMLButtonElement | HTMLAnchorElement>(null);
  useEffect(() => {
    const want = focusAfter.current;
    focusAfter.current = null;
    if (want === 'pill' && registered) pill.current?.focus({ preventScroll: true });
    else if (want === 'register' && !registered) registerBtn.current?.focus({ preventScroll: true });
  }, [registered]);

  const save = (
    <Button variant="secondary" fullWidth className="dxv-save" icon={<Bookmark size={20} strokeWidth={1.25} absoluteStrokeWidth aria-hidden="true" focusable="false" />}>
      {E.save}
    </Button>
  );
  const share = (
    <button type="button" className="fd-link dxv-share">
      {E.share}
    </button>
  );

  return (
    <div className="fd-page dxv-page">
      <div className="dxv-body">
        <article className="dxv-main" aria-labelledby="dxv-title">
          <BackLink href={PATHS.events}>{E.back}</BackLink>
          <div className="fd-photo dxv-hero" data-m="frame">
            <img className="cover" src={src(E.image)} alt="" decoding="async" draggable={false} />
          </div>
          <div className="dxv-title">
            <p className="dxv-tag">{E.tag}</p>
            <h1 className="dxv-h1" id="dxv-title">
              {E.title}
            </h1>
            <Link href={E.hostHref} className="dxv-host">
              <span className="dxv-av">
                <img src={src(E.hostImage)} alt="" decoding="async" draggable={false} />
              </span>
              <span className="dxv-host__text">
                <span className="dxv-host__label">{E.hostLabel}</span>
                <span className="dxv-host__name">{E.host}</span>
              </span>
            </Link>
          </div>
          <dl className="dxv-facts">
            {E.facts.map((f) => (
              <div className="dxv-fact" key={f.label}>
                <dt>{f.label}</dt>
                <dd>{f.value}</dd>
              </div>
            ))}
          </dl>
          <section className="dxl-block dxv-about" aria-labelledby="dxv-about">
            <h2 className="dxl-eyebrow" id="dxv-about">
              {E.aboutLabel}
            </h2>
            <p className="dxl-body">{E.about}</p>
          </section>
        </article>

        <aside className="dxv-side" aria-label="Registration">
          <section className="dxl-panel" aria-labelledby="dxv-reg">
            <h2 className="dxl-eyebrow" id="dxv-reg">
              {registered ? E.registered.label : E.register.label}
            </h2>
            {registered ? (
              <>
                <div className="dxl-pill dxv-registered" role="status" tabIndex={-1} ref={pill}>
                  <Check size={16} strokeWidth={1.5} absoluteStrokeWidth aria-hidden="true" focusable="false" />
                  <span>{E.registered.done}</span>
                </div>
                <p className="dxl-note">{E.registered.note(email)}</p>
                {save}
                <button
                  type="button"
                  className="fd-link dxv-share"
                  onClick={() => {
                    focusAfter.current = 'register';
                    cancelRegistration(E.slug);
                  }}
                >
                  {E.registered.cancel}
                </button>
                {share}
              </>
            ) : (
              <>
                <Button
                  fullWidth
                  ref={registerBtn}
                  onClick={() => {
                    focusAfter.current = 'pill';
                    setOpen(true);
                  }}
                >
                  {E.register.action}
                </Button>
                {save}
                {share}
              </>
            )}
          </section>
          <section className="dxl-panel dxl-panel--tight dxv-bring" aria-labelledby="dxv-bring">
            <h2 className="dxl-eyebrow" id="dxv-bring">
              {E.bring.label}
            </h2>
            <div className="dxl-note dxl-note--plain">
              {E.bring.lines.map((l) => (
                <p key={l}>{l}</p>
              ))}
            </div>
          </section>
        </aside>
      </div>
      <RegisterDialog
        open={open}
        // closed with Cancel or the scrim: nothing changed, the kit puts focus back on Register
        onClose={() => {
          setOpen(false);
          focusAfter.current = null;
        }}
        // Register: the panel changes and focus goes to the pill (see the effect above)
        onRegistered={() => setOpen(false)}
      />
    </div>
  );
}
