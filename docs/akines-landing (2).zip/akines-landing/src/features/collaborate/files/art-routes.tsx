import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { FP } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data):
 * 12.19 Files, the main page only. Not mirrored: File preview, the Empty state and the four modal and toast "state-" frames. The Upload file
 * and Create document modals open from the buttons of the page, so they work on Adire Stories without a route of their own.
 */
const MIRRORED: string[] = [FP.list];

export const artRoutes: RouteDef[] = routes.filter((r) => MIRRORED.includes(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
