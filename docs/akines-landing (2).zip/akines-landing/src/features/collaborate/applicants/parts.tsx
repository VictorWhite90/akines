'use client';

import './applicants.css';
import '../workspace/workspace.css';
import type { ReactNode } from 'react';
import { asset } from '@/lib/assets';
import { Button, Checkbox, Skeleton } from '@/ui';
import { StatusPill } from '../applications/shared';
import { CardLink, Dot, Over } from '../workspace/atoms';
import { cx } from '../workspace/util';
import { COMPARE, ROW, subline, type Applicant, type Group, type Status } from './data';

/**
 * The pieces the applicant screens share: Applicant Filter, Applicant Row, Compare Bar, Compare Table, the notice with the amber rule,
 * the Joined notice and the Applicant Row Skeleton.
 */

/* ------------------------------------------------------------------ people */

export function Portrait({ src, size = 56 }: { src: string; size?: number }) {
  return (
    <span className="ap-portrait" style={{ ['--ap-p' as string]: `${size}px` }} aria-hidden="true">
      <img src={asset(src)} alt="" width={size} height={size} decoding="async" />
    </span>
  );
}

/* ------------------------------------------------------------------ Applicant Filter */

export type ChipItem = { key: string; label: string; count: number };

/** The chips of the filter row: the label is the status or role in the chip and the number of people in it ("New 2"). */
export function FilterChips({ items, value, onChange, label }: { items: ChipItem[]; value: string; onChange: (key: string) => void; label: string }) {
  return (
    <div className="ap-chips" role="group" aria-label={label}>
      {items.map((i) => (
        <button type="button" key={i.key} className="ap-chip" aria-pressed={i.key === value} onClick={() => onChange(i.key)}>
          {i.label} {i.count}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ Applicant Row */

/**
 * What the buttons of a row do. A handler that is missing leaves the control plain (it draws and reacts to the pointer, and does
 * nothing), which is how the design leaves the controls it does not wire.
 */
export type RowHandlers = {
  open?: () => void;
  shortlist?: () => void;
  propose?: () => void;
  offer?: () => void;
  notNow?: () => void;
  undo?: () => void;
  /** Joined: See on Team. */
  team?: string;
};

function RowActions({ group, status, h }: { group: Group; status: Status; h: RowHandlers }) {
  if (group === 'call') {
    return (
      <>
        {status === 'New' ? (
          <Button size="sm" onClick={h.shortlist}>
            {ROW.shortlist}
          </Button>
        ) : null}
        {status === 'New' || status === 'Shortlisted' ? (
          <Button size="sm" variant="secondary" onClick={h.notNow}>
            {ROW.notNow}
          </Button>
        ) : null}
      </>
    );
  }
  switch (status) {
    case 'New':
      return (
        <>
          <Button size="sm" onClick={h.shortlist}>
            {ROW.shortlist}
          </Button>
          <Button size="sm" variant="secondary" onClick={h.notNow}>
            {ROW.notNow}
          </Button>
        </>
      );
    case 'Shortlisted':
      return (
        <>
          <Button size="sm" onClick={h.propose}>
            {ROW.proposeTimes}
          </Button>
          <Button size="sm" variant="secondary" onClick={h.notNow}>
            {ROW.notNow}
          </Button>
        </>
      );
    case 'Talk booked':
      return (
        <>
          <Button size="sm" onClick={h.offer}>
            {ROW.sendOffer}
          </Button>
          <Button size="sm" variant="secondary" onClick={h.notNow}>
            {ROW.notNow}
          </Button>
        </>
      );
    case 'Offer sent':
      return <p className="ap-row__info">{ROW.offerInfo}</p>;
    case 'Joined':
      return (
        <Button size="sm" variant="secondary" href={h.team}>
          {ROW.seeOnTeam}
        </Button>
      );
    case 'Not now':
      return (
        <Button size="sm" variant="secondary" onClick={h.undo}>
          {ROW.undo}
        </Button>
      );
  }
}

export function ApplicantRow({
  a,
  status,
  selected,
  tickLocked,
  onTick,
  h,
}: {
  a: Applicant;
  status: Status;
  selected: boolean;
  /** Three people are ticked already: a fourth box cannot be ticked. */
  tickLocked: boolean;
  onTick: () => void;
  h: RowHandlers;
}) {
  return (
    <article className="ap-row" data-status={status} data-selected={selected || undefined} aria-label={a.name}>
      <div className="ap-row__top">
        <Portrait src={a.photo} />
        <div className="ap-row__who">
          <h3 className="ap-row__name">{a.name}</h3>
          <p className="ap-row__sub">{subline(a, status)}</p>
        </div>
        <StatusPill status={status} />
        <Checkbox
          className="ap-row__tick"
          checked={selected}
          disabled={tickLocked && !selected}
          onChange={onTick}
          label={
            <>
              {ROW.compare}
              <span className="sr-only"> {a.name}</span>
            </>
          }
        />
      </div>
      <div className="ap-row__rule" aria-hidden="true" />
      <div className="ap-row__fields">
        <div className="ap-field ap-field--wants">
          <Over className="cw-over--12">{ROW.wants}</Over>
          <p className="ap-field__value">{a.wants}</p>
        </div>
        <div className="ap-field ap-field--avail">
          <Over className="cw-over--12">{ROW.availability}</Over>
          <p className="ap-field__value">{a.availability}</p>
        </div>
        <div className="ap-field ap-field--message">
          <Over className="cw-over--12">{ROW.message}</Over>
          <p className="ap-field__value">{a.message}</p>
        </div>
      </div>
      <div className="ap-row__actions">
        <RowActions group={a.group} status={status} h={h} />
        <CardLink className={cx('ap-row__view', h.open && 'ap-row__view--go')} onClick={h.open}>
          {ROW.view}
          <span className="sr-only"> {a.name}</span>
        </CardLink>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ Compare Bar */

export function CompareBar({ count, names, onClear, onCompare }: { count: number; names: string; onClear: () => void; onCompare: () => void }) {
  return (
    <section className="ap-bar" aria-label="Compare" data-m="up">
      <div className="ap-bar__text">
        <p className="ap-bar__summary" aria-live="polite">
          {COMPARE.summary(count)}
        </p>
        <p className="ap-bar__names">{names}</p>
      </div>
      <CardLink onClick={onClear}>{COMPARE.clear}</CardLink>
      <Button size="sm" onClick={onCompare}>
        {COMPARE.compare}
      </Button>
    </section>
  );
}

/* ------------------------------------------------------------------ Notice, Joined notice */

/** Notice (17210:13239): an amber rule, a serif line and a grey line. */
export function Notice({ title, text }: { title: string; text: string }) {
  return (
    <div className="ap-notice">
      <div className="ap-notice__body">
        <p className="ap-notice__title">{title}</p>
        <p className="ap-notice__text">{text}</p>
      </div>
    </div>
  );
}

/** Confirmation Line (17729:114781): the green dot and one line. */
export function JoinedNotice({ message }: { message: string }) {
  return (
    <p className="ap-joined" role="status">
      <Dot tone="green" size={8} />
      <span>{message}</span>
    </p>
  );
}

/* ------------------------------------------------------------------ Applicant Row Skeleton */

export function RowSkeleton() {
  return (
    <div className="ap-skel">
      <div className="ap-skel__top">
        <Skeleton width={20} height={20} radius={4} />
        <Skeleton width={56} height={56} radius={28} />
        <div className="ap-skel__text">
          <Skeleton width={220} height={20} radius={4} />
          <Skeleton width={160} height={14} radius={4} />
        </div>
        <Skeleton width={96} height={31} radius={16} />
      </div>
      <div className="ap-skel__fields">
        <Skeleton width={160} height={44} radius={4} />
        <Skeleton width={200} height={44} radius={4} />
        <Skeleton width={420} height={44} radius={4} />
      </div>
      <div className="ap-skel__actions">
        <Skeleton width={100} height={36} radius={18} />
        <Skeleton width={96} height={36} radius={18} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Compare Table */

export type CompareColumn = { a: Applicant; status: Status; note: string; actions: ReactNode };

/**
 * Compare Table (Columns 2 and 3): the label column and a white column per person with the role, what they want to join as, availability,
 * skills, experience, message, your notes and the actions of their status. A real table, so the rows line up across the people.
 */
export function CompareTable({ columns }: { columns: CompareColumn[] }) {
  const rows: { key: string; label: string; value: (c: CompareColumn) => ReactNode; muted?: (c: CompareColumn) => boolean }[] = [
    { key: 'role', label: COMPARE.rows[0], value: (c) => c.a.role },
    { key: 'wants', label: COMPARE.rows[1], value: (c) => c.a.wants },
    { key: 'avail', label: COMPARE.rows[2], value: (c) => c.a.availability },
    { key: 'skills', label: COMPARE.rows[3], value: (c) => c.a.compareSkills ?? c.a.skills.join(', ') },
    { key: 'exp', label: COMPARE.rows[4], value: (c) => c.a.experience },
    { key: 'message', label: COMPARE.rows[5], value: (c) => c.a.message },
    { key: 'notes', label: COMPARE.rows[6], value: (c) => c.note || COMPARE.noNote, muted: (c) => !c.note },
  ];
  return (
    <div className="ap-cmp-wrap" data-m="up">
      <table className="ap-cmp" data-columns={columns.length}>
        <caption className="sr-only">Applicants side by side</caption>
        <colgroup>
          <col className="ap-cmp__lab" />
          {columns.map((c) => (
            <col key={c.a.id} />
          ))}
        </colgroup>
        <thead>
          <tr>
            <td className="ap-cmp__corner" aria-hidden="true" />
            {columns.map((c) => (
              <th key={c.a.id} scope="col" className="ap-cmp__col">
                <div className="ap-cmp__who">
                  <Portrait src={c.a.photo} size={64} />
                  <p className="ap-cmp__name">{c.a.name}</p>
                  <StatusPill status={c.status} />
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.key} data-h={r.key}>
              <th scope="row" className="ap-cmp__label">
                <span>
                  <Over className="cw-over--12">{r.label}</Over>
                </span>
              </th>
              {columns.map((c) => (
                <td key={c.a.id}>
                  <div className={cx('ap-cmp__in', r.muted?.(c) && 'ap-cmp__in--muted')}>{r.value(c)}</div>
                </td>
              ))}
            </tr>
          ))}
          <tr data-h="actions">
            <th scope="row" className="ap-cmp__label">
              <span>
                <span className="sr-only">Actions</span>
              </span>
            </th>
            {columns.map((c) => (
              <td key={c.a.id}>
                <div className="ap-cmp__acts">{c.actions}</div>
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
