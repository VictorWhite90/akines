import { CAREER_OVERVIEW_DASH, NEEDS_REVIEW, WAITING_REPLY, WEEK_BARS, WEEK_CAPTION, glance, statusItems, type OverviewDash } from './overview-data';
import { useProject, type ProjectKey } from './project';

/**
 * Overview dashboard copy of Adire Stories (Figma 12.33 Project overview 17759:89371): the same shape as the Career Guidance for Everyone
 * set in overview-data.ts, so the one Overview page renders both. Only the Overview (route PATHS.overview) is mirrored on Adire Stories:
 * the brief and the milestone pages are not, so the progress step of the brief and "View full brief" have no destination there, while the
 * milestone steps open the Tasks milestone view (as in the Figma prototype).
 * The status bar and the weekly bars of the Adire frame are the Career bars (the frame only changed the numbers); the legend counts are used.
 */
export const ART_OVERVIEW: OverviewDash = {
  name: 'Adire Stories',
  lead: 'A shared illustration series celebrating adire patterns.',
  metrics: {
    milestones: { value: '1/3', caption: 'complete' },
    tasks: { value: '7', caption: '1 in review' },
    review: { value: '2', caption: 'needs you', dot: true },
    decisions: { value: '1', caption: 'to make', dot: true },
  },
  stages: [
    { state: 'done', when: 'DONE 8 OCT', title: 'Series brief approved' },
    { state: 'doing', when: 'DUE 26 NOV', title: 'Headwrap portrait' },
    { state: 'next', when: 'PLANNED 10 DEC', title: 'Pattern study set' },
  ],
  status: statusItems(3, 3, 1, 2),
  week: { total: 14, caption: WEEK_CAPTION, bars: WEEK_BARS, today: 3 },
  glance: glance('Young Nigerians who love cloth', 'Twelve plates and every dyer credited', 'A printed zine and a small exhibition'),
  work: [
    { title: 'Review the headwrap colour layer', status: NEEDS_REVIEW },
    { title: 'Respond to the pattern history notes', status: WAITING_REPLY },
  ],
};

/* ------------------------------------------------------------------ the set each project reads */

export const OVERVIEW_DASH_OF: Record<ProjectKey, OverviewDash> = { career: CAREER_OVERVIEW_DASH, adire: ART_OVERVIEW };

/** The dashboard data of the project of the page being shown. */
export const useOverviewDash = (): OverviewDash => OVERVIEW_DASH_OF[useProject().key];
