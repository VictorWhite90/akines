import { useId } from 'react';

/**
 * Akines AI assistant mark, traced from the supplied logo (99% pixel overlap) and drawn in a 600 x 600 box.
 * Colours come only from the design system. Sixteen colourways: solid, two-tone, badge (the launcher) and gradients,
 * three of them animated. Standalone SVG files live in public/brand/assistant/.
 *
 * Palette (token): ink #181818 Surface/Inverse, paper #FEFEFE Surface/Default, ivory #F4F1EB Surface/Akines/Primary/Strong,
 * amber #F4A63A Action/Akines/Secondary/Default, amberHover #E3890D, amberDeep #AE690A (Secondary pressed, accent text),
 * amberSubtle #FEF6EC Surface/Akines/Secondary/Subtle, border #CCCCCC Border/Default.
 */
export type AssistantColourway = 'ink-on-ivory' | 'paper-on-ink' | 'ivory-on-ink' | 'amber-on-ink' | 'ink-on-amber' | 'deep-amber-on-ivory' | 'ink-on-amber-tint' | 'duo-on-ivory' | 'duo-on-ink' | 'badge-ink' | 'badge-amber' | 'badge-paper' | 'gradient-amber' | 'animated-sheen' | 'animated-badge-amber' | 'animated-arc-ink';

export const ASSISTANT_COLOURWAYS: { id: AssistantColourway; name: string; background: string; family: string; animated: boolean; contrast: number }[] = [
  {
    "id": "ink-on-ivory",
    "name": "Ink on Ivory",
    "background": "#F4F1EB",
    "family": "Solid",
    "animated": false,
    "contrast": 15.75
  },
  {
    "id": "paper-on-ink",
    "name": "Paper on Ink (as supplied)",
    "background": "#181818",
    "family": "Solid",
    "animated": false,
    "contrast": 17.61
  },
  {
    "id": "ivory-on-ink",
    "name": "Ivory on Ink",
    "background": "#181818",
    "family": "Solid",
    "animated": false,
    "contrast": 15.75
  },
  {
    "id": "amber-on-ink",
    "name": "Amber on Ink",
    "background": "#181818",
    "family": "Solid",
    "animated": false,
    "contrast": 8.76
  },
  {
    "id": "ink-on-amber",
    "name": "Ink on Amber",
    "background": "#F4A63A",
    "family": "Solid",
    "animated": false,
    "contrast": 8.76
  },
  {
    "id": "deep-amber-on-ivory",
    "name": "Deep amber on Ivory",
    "background": "#F4F1EB",
    "family": "Solid",
    "animated": false,
    "contrast": 3.86
  },
  {
    "id": "ink-on-amber-tint",
    "name": "Ink on Amber tint",
    "background": "#FEF6EC",
    "family": "Solid",
    "animated": false,
    "contrast": 16.58
  },
  {
    "id": "duo-on-ivory",
    "name": "Two-tone on Ivory",
    "background": "#F4F1EB",
    "family": "Two-tone",
    "animated": false,
    "contrast": 3.86
  },
  {
    "id": "duo-on-ink",
    "name": "Two-tone on Ink",
    "background": "#181818",
    "family": "Two-tone",
    "animated": false,
    "contrast": 8.76
  },
  {
    "id": "badge-ink",
    "name": "Badge, Ink",
    "background": "#F4F1EB",
    "family": "Badge",
    "animated": false,
    "contrast": 15.75
  },
  {
    "id": "badge-amber",
    "name": "Badge, Amber",
    "background": "#F4F1EB",
    "family": "Badge",
    "animated": false,
    "contrast": 8.76
  },
  {
    "id": "badge-paper",
    "name": "Badge, Paper",
    "background": "#F4F1EB",
    "family": "Badge",
    "animated": false,
    "contrast": 17.61
  },
  {
    "id": "gradient-amber",
    "name": "Gradient, Amber to Deep amber",
    "background": "#181818",
    "family": "Gradient",
    "animated": false,
    "contrast": 4.08
  },
  {
    "id": "animated-sheen",
    "name": "Animated gradient, Sheen",
    "background": "#181818",
    "family": "Animated gradient",
    "animated": true,
    "contrast": 4.08
  },
  {
    "id": "animated-badge-amber",
    "name": "Animated gradient, Amber badge",
    "background": "#F4F1EB",
    "family": "Animated gradient",
    "animated": true,
    "contrast": 8.76
  },
  {
    "id": "animated-arc-ink",
    "name": "Animated gradient, Ink badge, flowing arc",
    "background": "#F4F1EB",
    "family": "Animated gradient",
    "animated": true,
    "contrast": 4.08
  }
];

const P = {
  ink: '#181818',
  paper: '#FEFEFE',
  ivory: '#F4F1EB',
  amber: '#F4A63A',
  amberHover: '#E3890D',
  amberDeep: '#AE690A',
  amberSubtle: '#FEF6EC',
  border: '#CCCCCC',
};

const ARC = 'M104.9 378.5A222.75 222.75 0 1 1 495.1 378.5';
const BUBBLE = 'M300.0 577.5L431.2 489.8A155 66 0 1 0 300.0 520.3Z';
const SW = 49.5;
const EYES: [number, number][] = [[225.0, 258.0], [376.0, 258.0]];
const ER = 42.5;

const FLOW_CSS =
  '.akm-flow{animation:akm-flow 4.8s linear infinite}@keyframes akm-flow{to{transform:translateX(-600px)}}@media (prefers-reduced-motion:reduce){.akm-flow{animation:none}}';

function Mark({ arc, face, mask }: { arc: string; face: string; mask?: boolean }) {
  return (
    <>
      <path d={ARC} fill="none" stroke={arc} strokeWidth={SW} strokeLinecap="round" />
      <circle cx={EYES[0][0]} cy={EYES[0][1]} r={ER} fill={face} />
      <circle cx={EYES[1][0]} cy={EYES[1][1]} r={ER} fill={face} />
      <path d={BUBBLE} fill={face} />
    </>
  );
}

const Face = ({ fill }: { fill: string }) => (
  <>
    <circle cx={EYES[0][0]} cy={EYES[0][1]} r={ER} fill={fill} />
    <circle cx={EYES[1][0]} cy={EYES[1][1]} r={ER} fill={fill} />
    <path d={BUBBLE} fill={fill} />
  </>
);

const Arc = ({ stroke }: { stroke: string }) => (
  <path d={ARC} fill="none" stroke={stroke} strokeWidth={SW} strokeLinecap="round" />
);

/** Mark scaled about its centre, for use inside a badge. */
const Inset = ({ children }: { children: React.ReactNode }) => (
  <g transform="translate(300 300.5) scale(0.56) translate(-300 -300.5)">{children}</g>
);

function flowStops(stops: [number, string][]) {
  return stops.map(([o, c]) => <stop key={o} offset={o} stopColor={c} />);
}

export type AssistantMarkProps = {
  colourway?: AssistantColourway;
  /** Rendered size in px (the mark is square). */
  size?: number;
  /** Accessible name. Pass `decorative` when the mark sits next to a text label. */
  title?: string;
  decorative?: boolean;
  className?: string;
};

export function AssistantMark({
  colourway = 'ink-on-ivory',
  size = 56,
  title = 'Akines assistant',
  decorative = false,
  className,
}: AssistantMarkProps) {
  const uid = useId().replace(/:/g, '');
  const gid = 'akm-g' + uid;
  const mid = 'akm-m' + uid;
  const cid = 'akm-c' + uid;
  let defs: React.ReactNode = null;
  let body: React.ReactNode = null;
  let animated = false;

  switch (colourway) {
    case 'ink-on-ivory': body = <Mark arc={P.ink} face={P.ink} />; break;
    case 'paper-on-ink': body = <Mark arc={P.paper} face={P.paper} />; break;
    case 'ivory-on-ink': body = <Mark arc={P.ivory} face={P.ivory} />; break;
    case 'amber-on-ink': body = <Mark arc={P.amber} face={P.amber} />; break;
    case 'ink-on-amber': body = <Mark arc={P.ink} face={P.ink} />; break;
    case 'deep-amber-on-ivory': body = <Mark arc={P.amberDeep} face={P.amberDeep} />; break;
    case 'ink-on-amber-tint': body = <Mark arc={P.ink} face={P.ink} />; break;
    case 'duo-on-ivory': body = <Mark arc={P.amberDeep} face={P.ink} />; break;
    case 'duo-on-ink': body = <Mark arc={P.amber} face={P.paper} />; break;
    case 'badge-ink':
      body = (<><circle cx="300" cy="300" r="300" fill={P.ink} /><Inset><Mark arc={P.ivory} face={P.ivory} /></Inset></>);
      break;
    case 'badge-amber':
      body = (<><circle cx="300" cy="300" r="300" fill={P.amber} /><Inset><Mark arc={P.ink} face={P.ink} /></Inset></>);
      break;
    case 'badge-paper':
      body = (<><circle cx="300" cy="300" r="299" fill={P.paper} stroke={P.border} strokeWidth="2" /><Inset><Mark arc={P.ink} face={P.ink} /></Inset></>);
      break;
    case 'gradient-amber':
      defs = (<linearGradient id={gid} x1="90" y1="40" x2="510" y2="560" gradientUnits="userSpaceOnUse"><stop offset="0" stopColor={P.amber} /><stop offset="1" stopColor={P.amberDeep} /></linearGradient>);
      body = <Mark arc={`url(#${gid})`} face={`url(#${gid})`} />;
      break;
    case 'animated-sheen':
      animated = true;
      defs = (
        <>
          <linearGradient id={gid} gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="1200" y2="0" gradientTransform="rotate(22 600 300)">
            {flowStops([[0, P.amberDeep], [0.25, P.amber], [0.5, P.amberSubtle], [0.75, P.amber], [1, P.amberDeep]])}
          </linearGradient>
          <mask id={mid} maskUnits="userSpaceOnUse" x="0" y="0" width="600" height="600"><Mark arc="#fff" face="#fff" /></mask>
        </>
      );
      body = (<g mask={`url(#${mid})`}><rect className="akm-flow" x="0" y="-300" width="1200" height="1200" fill={`url(#${gid})`} /></g>);
      break;
    case 'animated-badge-amber':
      animated = true;
      defs = (
        <>
          <linearGradient id={gid} gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="1200" y2="0" gradientTransform="rotate(22 600 300)">
            {flowStops([[0, P.amber], [0.25, P.amberHover], [0.5, P.amberSubtle], [0.75, P.amberHover], [1, P.amber]])}
          </linearGradient>
          <clipPath id={cid}><circle cx="300" cy="300" r="300" /></clipPath>
        </>
      );
      body = (<><g clipPath={`url(#${cid})`}><rect className="akm-flow" x="0" y="-300" width="1200" height="1200" fill={`url(#${gid})`} /></g><Inset><Mark arc={P.ink} face={P.ink} /></Inset></>);
      break;
    case 'animated-arc-ink':
      animated = true;
      defs = (
        <>
          <linearGradient id={gid} gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="1200" y2="0" gradientTransform="rotate(22 600 300)">
            {flowStops([[0, P.amber], [0.25, P.ivory], [0.5, P.amber], [0.75, P.amberDeep], [1, P.amber]])}
          </linearGradient>
          <mask id={mid} maskUnits="userSpaceOnUse" x="0" y="0" width="600" height="600"><Arc stroke="#fff" /></mask>
        </>
      );
      body = (
        <>
          <circle cx="300" cy="300" r="300" fill={P.ink} />
          <Inset>
            <g mask={`url(#${mid})`}><rect className="akm-flow" x="0" y="-300" width="1200" height="1200" fill={`url(#${gid})`} /></g>
            <Face fill={P.paper} />
          </Inset>
        </>
      );
      break;
  }

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 600 600"
      width={size}
      height={size}
      className={className}
      role={decorative ? undefined : 'img'}
      aria-label={decorative ? undefined : title}
      aria-hidden={decorative ? true : undefined}
      focusable="false"
    >
      {decorative ? null : <title>{title}</title>}
      {animated ? <style>{FLOW_CSS}</style> : null}
      {defs ? <defs>{defs}</defs> : null}
      {body}
    </svg>
  );
}
