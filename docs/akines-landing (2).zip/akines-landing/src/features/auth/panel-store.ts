'use client';

import { useSyncExternalStore } from 'react';

/** Open state of the slide-out sign-in panel. Module level so any button can open it without a provider. */
let open = false;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export const openSignIn = () => {
  if (!open) {
    open = true;
    emit();
  }
};
export const closeSignIn = () => {
  if (open) {
    open = false;
    emit();
  }
};
export const useSignInOpen = () =>
  useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => {
        listeners.delete(cb);
      };
    },
    () => open,
    () => false,
  );
