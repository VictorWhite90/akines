'use client';

/**
 * Messages (Figma 10.2): inbox 17105:6750 and five threads (Amara 17105:6928, Folake 17105:7139, Food Systems Cliq 17105:7345,
 * KinCircle Reflection 17105:7548, University friends 17105:7746). The composer starts with the dummy message of the design;
 * sending appends it to the thread and shows the Sent label.
 * Phones (Figma V2 Mobile 10.2: inbox 18084:6694, threads 18084:6720, 6825, 6911, 6993, 7067): the shell's top bar carries the
 * title and back; the inbox ends with "Start a Quick Catch-up"; a thread opens with the Thread Intro block, its composer is pinned
 * to the bottom with a round send button and "Arrange a Create Call" moves to the top bar as a calendar action. Phone rules live in
 * messages-mobile.css.
 */
import { useEffect, useLayoutEffect, useRef } from 'react';
import { ArrowUp, Calendar } from 'lucide-react';
import { Button, IconButton } from '@/ui';
import { useLayout, useReducedMotion } from '@/lib/hooks';
import { MobileTopBarAction } from '@/app-shell/MobileTopBar';
import './community.css';
import './messages-mobile.css';
import { P, type AvKey } from './data';
import { appendMessage, openModal, setDraft, useCommunity, type ModalId } from './store';
import { Avatar, IArrow, ICheck, IMessage, ListRow, TextLink } from './ui';

type Msg = { from: 'in' | 'out'; sender?: string; text: string };
type Thread = {
  slug: string;
  name: string;
  sub: string;
  av: AvKey;
  preview: string;
  meta: string;
  call?: ModalId;
  groups: { date: string; msgs: Msg[] }[];
  draft: string;
};

export const THREADS: Thread[] = [
  {
    slug: 'amara', name: 'Amara', sub: 'Community Health Initiative', av: 'amara', preview: 'No rush. Tell me when you would like to talk it through.', meta: '6d', call: 'cc-amara',
    groups: [
      { date: 'Thursday', msgs: [{ from: 'in', text: 'I mapped out the three clinics we could visit first. Want to look at it together?' }, { from: 'out', text: 'Yes please. I will send my draft of the outreach plan this week.' }] },
      { date: 'Six days ago', msgs: [{ from: 'in', text: 'No rush. Tell me when you would like to talk it through.' }] },
    ],
    draft: 'I am ready to look at the plan. Could we talk tomorrow?',
  },
  {
    slug: 'folake', name: 'Folake', sub: 'Friend', av: 'folake', preview: 'Yes, I would love that. Let me check my week.', meta: '9d', call: 'cc-folake',
    groups: [
      { date: 'Nine days ago', msgs: [{ from: 'in', text: 'Are we still on for the Sunday walk? No pressure if this week has been busy.' }, { from: 'out', text: 'Yes, I would love that. Let me check my week and come back to you.' }] },
    ],
    draft: 'Yes, Sunday works. Shall we say 8:00 AM?',
  },
  {
    slug: 'food-systems-cliq', name: 'Food Systems Cliq', sub: 'Cliq · 9 members', av: 'health', preview: 'I will bring the budget questions to the 2:00 PM call.', meta: 'Today',
    groups: [{ date: 'Today', msgs: [{ from: 'in', sender: 'Tunde', text: 'Notes from the last call are in the shared folder.' }, { from: 'in', sender: 'Ngozi', text: 'I will bring the budget questions to the 2:00 PM call.' }] }],
    draft: 'Thanks both. See you at 2:00 PM.',
  },
  {
    slug: 'kincircle-reflection', name: 'KinCircle Reflection', sub: 'KinCircle · Tomorrow, 12:30 PM', av: 'kincircle', preview: 'Tomorrow we will begin with one thing that went well.', meta: '1d',
    groups: [{ date: 'Yesterday', msgs: [{ from: 'in', sender: 'Facilitator', text: 'Tomorrow we will begin with one thing that went well this week. No preparation needed.' }] }],
    draft: 'Looking forward to it.',
  },
  {
    slug: 'university-friends', name: 'University friends', sub: 'Group · 7 members', av: 'friends', preview: 'I am bringing the Ludo board.', meta: 'Today',
    groups: [{ date: 'Today', msgs: [{ from: 'in', sender: 'Chuka', text: 'Game night on Friday. Bring snacks, not strategy.' }, { from: 'in', sender: 'Folake', text: 'I am bringing the Ludo board.' }] }],
    draft: 'Count me in for Friday.',
  },
];

function Bubble({ m }: { m: Msg }) {
  return (
    <div className={`ch-bub ch-bub--${m.from}`}>
      <div className="ch-bub__col">
        {m.sender ? <span className="ch-bub__sender">{m.sender}</span> : null}
        <p className="ch-bub__text">{m.text}</p>
      </div>
    </div>
  );
}

/** Phones: the composer's draft field grows with its text (Figma Composer / Mobile hugs a two-line draft), up to the CSS max-height. */
function useAutoGrow(ref: React.RefObject<HTMLTextAreaElement | null>, value: string, on: boolean) {
  useLayoutEffect(() => {
    const el = ref.current;
    if (!on || !el) return;
    const fit = () => {
      el.style.height = 'auto';
      el.style.height = `${el.scrollHeight + el.offsetHeight - el.clientHeight}px`;
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [ref, value, on]);
}

function Conversation({ t }: { t: Thread }) {
  const s = useCommunity();
  const phone = useLayout() === 'mobile';
  const reduce = useReducedMotion();
  const sent = s.sent[t.slug] ?? [];
  const key = `msg-${t.slug}`;
  const value = s.draft[key] ?? t.draft;
  const feed = useRef<HTMLDivElement>(null);
  const field = useRef<HTMLTextAreaElement>(null);
  useAutoGrow(field, value, phone);
  useEffect(() => {
    const el = feed.current;
    if (el) el.scrollTop = el.scrollHeight;
    // phones: the page scrolls, not the feed; bring the newest message up above the pinned composer
    if (phone && sent.length) window.scrollTo({ top: document.documentElement.scrollHeight, behavior: reduce ? 'auto' : 'smooth' });
  }, [sent.length, t.slug, phone, reduce]);
  const send = () => {
    const text = value.trim();
    if (!text) return;
    appendMessage(t.slug, text);
    setDraft(key, '');
  };
  const call = t.call;
  return (
    <div className="ch-msg__main">
      {phone && call ? (
        <MobileTopBarAction label="Arrange a Create Call" icon={<Calendar size={24} strokeWidth={1.5} absoluteStrokeWidth aria-hidden focusable={false} />} onClick={() => openModal(call)} />
      ) : null}
      <TextLink href={P.messages} className="ch-msg__back">
        Back to Messages
      </TextLink>
      {phone ? (
        <header className="ms-intro">
          <Avatar k={t.av} size={72} />
          <div className="ms-intro__details">
            <h1 className="ms-intro__name">{t.name}</h1>
            <p className="ms-intro__sub">{t.sub}</p>
          </div>
        </header>
      ) : null}
      <header className="ch-conv__head">
        <div className="ch-conv__who">
          <Avatar k={t.av} size={48} />
          <div className="ch-conv__details">
            <h1 className="ch-conv__name">{t.name}</h1>
            <p className="ch-conv__sub">{t.sub}</p>
          </div>
        </div>
        {t.call ? (
          <Button variant="secondary" onClick={() => openModal(t.call as ModalId)}>
            Arrange a Create Call
          </Button>
        ) : null}
      </header>
      <div className="ch-conv__feed" ref={feed} role="log" aria-label={`Conversation with ${t.name}`}>
        {t.groups.map((g) => (
          <div key={g.date} style={{ display: 'contents' }}>
            <p className="ch-date">{g.date}</p>
            {g.msgs.map((m, i) => (
              <Bubble key={i} m={m} />
            ))}
          </div>
        ))}
        {sent.map((m) => (
          <Bubble key={m.id} m={{ from: 'out', text: m.text }} />
        ))}
        {sent.length ? (
          <p className="ch-sent">
            <ICheck s={14} />
            <span>Sent</span>
          </p>
        ) : null}
      </div>
      <form
        className="ch-composer"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        {phone ? (
          <>
            <textarea
              ref={field}
              className="ch-composer__field ms-composer__field"
              rows={1}
              aria-label={`Message ${t.name}`}
              placeholder="Write a message"
              enterKeyHint="send"
              value={value}
              onChange={(e) => setDraft(key, e.target.value)}
              onKeyDown={(e) => {
                // Enter sends, as on desktop; Shift+Enter keeps a line break
                if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <IconButton type="submit" label="Send" variant="solid" tooltip={false} className="ms-send" disabled={!value.trim()}>
              <ArrowUp strokeWidth={1.25} absoluteStrokeWidth />
            </IconButton>
          </>
        ) : (
          <>
            <input className="ch-composer__field" aria-label={`Message ${t.name}`} placeholder="Write a message" value={value} onChange={(e) => setDraft(key, e.target.value)} />
            <Button type="submit" iconRight={<IArrow />} disabled={!value.trim()}>
              Send
            </Button>
          </>
        )}
      </form>
    </div>
  );
}

export function Messages({ slug }: { slug?: string }) {
  const t = THREADS.find((x) => x.slug === slug);
  const phone = useLayout() === 'mobile';
  return (
    <div className="ch-msg" data-view={t ? 'thread' : 'list'}>
      <nav className="ch-msg__side" aria-label="Conversations">
        <h2 className="ch-msg__title">Messages</h2>
        <div className="ch-msg__list">
          {THREADS.map((x) => (
            <ListRow key={x.slug} title={x.name} text={x.preview} meta={x.meta} avatar={x.av} href={P.thread(x.slug)} className={x.slug === slug ? 'ch-row--on' : undefined} />
          ))}
        </div>
      </nav>
      {/* phones have no second pane: the inbox action sits under the list (Figma 18084:7190) */}
      {phone && !t ? (
        <div className="ms-inbox__acts">
          <Button variant="secondary" size="lg" fullWidth onClick={() => openModal('quick')}>
            Start a Quick Catch-up
          </Button>
        </div>
      ) : null}
      {t ? (
        <Conversation t={t} key={t.slug} />
      ) : (
        <div className="ch-msg__main">
          <div className="ch-msg__empty">
            <IMessage />
            <h1 className="ch-msg__empty-title">Choose a conversation</h1>
            <p className="ch-msg__empty-text">Pick someone from the list to continue, or start something new.</p>
            <Button variant="secondary" onClick={() => openModal('quick')}>Start a Quick Catch-up</Button>
          </div>
        </div>
      )}
    </div>
  );
}
