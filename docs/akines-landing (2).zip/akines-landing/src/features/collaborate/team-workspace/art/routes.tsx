import type { RouteDef } from '@/routes.types';
import { TW_PATHS } from '../data';
import { DigitalArt } from './DigitalArt';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;
const title = 'Digital Art Workspace';

export const ArtDefault = () => <DigitalArt state="saved" />;
export const ArtCommentThread = () => <DigitalArt state="saved" thread />;
export const ArtSaving = () => <DigitalArt state="saving" />;
export const ArtCouldNotSave = () => <DigitalArt state="couldNotSave" />;
export const ArtCollaboratorOffline = () => <DigitalArt state="collaboratorOffline" />;
export const ArtConnectionLost = () => <DigitalArt state="connectionLost" />;
export const ArtReconnecting = () => <DigitalArt state="reconnecting" />;
export const ArtViewOnly = () => <DigitalArt state="viewOnly" />;
export const ArtVersionHistory = () => <DigitalArt state="versionHistory" />;

/** 12.16 Digital Art Workspace: the default screen and its state frames (a1 to a8). Overlays (d1 to d4) are React state. */
export const artRoutes: RouteDef[] = [
  { path: TW_PATHS.art, title, shell: 'bare', nav, component: ArtDefault },
  { path: `${TW_PATHS.art}/state-comment-thread`, title, shell: 'bare', nav, component: ArtCommentThread },
  { path: `${TW_PATHS.art}/state-saving`, title, shell: 'bare', nav, component: ArtSaving },
  { path: `${TW_PATHS.art}/state-could-not-save`, title, shell: 'bare', nav, component: ArtCouldNotSave },
  { path: `${TW_PATHS.art}/state-collaborator-offline`, title, shell: 'bare', nav, component: ArtCollaboratorOffline },
  { path: `${TW_PATHS.art}/state-connection-lost`, title, shell: 'bare', nav, component: ArtConnectionLost },
  { path: `${TW_PATHS.art}/state-reconnecting`, title, shell: 'bare', nav, component: ArtReconnecting },
  { path: `${TW_PATHS.art}/state-view-only`, title, shell: 'bare', nav, component: ArtViewOnly },
  { path: `${TW_PATHS.art}/state-version-history`, title, shell: 'bare', nav, component: ArtVersionHistory },
];
