'use client';

/**
 * 12.9 Saved projects (Figma 17334:34006): one list with an Open or Closed tag on each card, plus Empty (17334:34403), Loading (17334:34567),
 * Could not load (17334:34748) and Toast:Removed from saved projects (17334:34910). The bookmark on a card removes it and offers Undo.
 */
import { useEffect, useState } from 'react';
import { Button } from '@/ui';
import { toast } from '@/ui/toast';
import { useNav } from '@/lib/nav';
import { projectBySlug } from './data';
import { LOADING_MS, removeSaved, restoreSaved, takeFirstVisit, useSavedState } from './store';
import { BackLink, CardLink, CardSkeleton, PageHead, ProjectCard, StatePanel } from './ui';

export type SavedVariant = 'empty' | 'loading' | 'error';
type Phase = 'loading' | 'ready' | 'error';

export function SavedProjectsScreen({ variant }: { variant?: SavedVariant }) {
  const nav = useNav();
  const { saved } = useSavedState();
  const [phase, setPhase] = useState<Phase>(() => (variant === 'loading' ? 'loading' : variant === 'error' ? 'error' : variant === 'empty' ? 'ready' : takeFirstVisit('saved') ? 'loading' : 'ready'));

  useEffect(() => {
    if (phase !== 'loading') return;
    const t = window.setTimeout(() => {
      if (variant === 'loading') nav.replace('/collaborate/saved');
      else setPhase('ready');
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, variant]);

  /* Could not load */
  if (phase === 'error') {
    return (
      <div className="dsc-page">
        <div className="dsc-stack">
          <BackLink href="/collaborate/discover">Back to discover projects</BackLink>
          <StatePanel pair role="alert" headline="We could not load your saved projects." support="Check your connection and try again. Your saved list is not lost.">
            <Button onClick={() => setPhase('loading')}>Try again</Button>
            <Button variant="secondary" href="/collaborate/discover">
              Back to discover projects
            </Button>
          </StatePanel>
        </div>
      </div>
    );
  }

  const list = variant === 'empty' ? [] : saved.map((s) => projectBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  const head = (
    <PageHead
      eyebrow="Saved projects"
      title="Projects you saved."
      lead="Keep the ones you want to think about. Only you can see this list."
      link={<CardLink href="/collaborate/discover">Discover projects</CardLink>}
    />
  );

  let body: React.ReactNode;
  if (phase === 'loading') {
    body = (
      <section className="dsc-results" aria-busy="true" aria-label="Saved projects">
        <div className="dsc-summary">
          <p className="dsc-summary__count">Loading your saved projects...</p>
        </div>
        <div className="dsc-grid">
          {[0, 1, 2].map((i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      </section>
    );
  } else if (list.length === 0) {
    body = (
      <StatePanel headline="You have not saved any projects yet." support="Use the bookmark on a project to keep it here. Only you can see your list.">
        <Button href="/collaborate/discover">Discover projects</Button>
      </StatePanel>
    );
  } else {
    body = (
      <section className="dsc-results" aria-label="Saved projects">
        <div className="dsc-summary">
          <p className="dsc-summary__count" aria-live="polite">
            {list.length} saved {list.length === 1 ? 'project' : 'projects'}
          </p>
          <span className="dsc-summary__note">Recently saved first</span>
        </div>
        <div className="dsc-grid" data-m="stagger">
          {list.map((p) => (
            <ProjectCard
              key={p.slug}
              project={p}
              mode="saved"
              saved
              onSave={() => {
                const at = removeSaved(p.slug);
                toast.show({ message: 'Removed from saved projects.', actionLabel: 'Undo', onAction: () => restoreSaved(p.slug, at) });
              }}
            />
          ))}
        </div>
      </section>
    );
  }

  return (
    <div className="dsc-page">
      <div className="dsc-stack">
        {head}
        {body}
      </div>
    </div>
  );
}

export const SavedProjects = () => <SavedProjectsScreen />;
