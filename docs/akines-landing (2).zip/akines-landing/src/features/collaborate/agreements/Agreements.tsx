'use client';

import '../workspace/workspace.css';
import './agreements.css';
import { useEffect, useState } from 'react';
import { useNav, usePath } from '@/lib/nav';
import { Button, EmptyState, toast } from '@/ui';
import { DashCard, MetricCard, MetricRow, SegmentBar, StageTracker } from '../workspace/dash';
import { ActionButton, BackLink, CardLink, PageHead, WorkspaceFrame } from '../workspace/parts';
import { useProject } from '../workspace/project';
import { AP, CARD, EMPTY, FORMAL, HEAD, OVERVIEW_METRICS, ROLES, ROLES_ACKNOWLEDGED, STAGES_HEAD, TERMS, TOASTS, stepsAt, type RolesPage } from './data';
import { AcknowledgeModal, CreateAgreementModal, SuggestChangeModal } from './modals';
import { AckTile, GroupLabel, StageCard, useAgreements } from './parts';

/**
 * 12.22 Agreements: Agreements (overview), Empty, Stage detail (Roles), Formal agreement and Acknowledged, with
 * Modal:Create agreement, Modal:Suggest a change, Modal:Acknowledge agreement and the three toasts. One screen component per page
 * drives every frame; the overlay frames are the page that opens them with the overlay (or toast) showing (see routes.tsx).
 *
 * The pages have the dashboard look: the shared project rail on the right (the short rail on the empty page), metric cards and
 * dashboard cards in the centre. The overview keeps its six stage cards under three metric cards; the stage pages are a header, a
 * row of metric cards, the "Agreement stages" card (stage tracker), the "Acknowledgements" card (segment bar and four member tiles),
 * then Proposed terms and Version history. The Formal agreement page has the stage tracker, the "not legally binding" note and the
 * three templates.
 *
 * Wiring (the prototype reactions): Create agreement (overview, Empty, Formal agreement) opens its modal, Create agreement in the
 * modal goes to the overview and shows "Agreement created"; the Roles card opens the stage detail, the Formal Agreement card opens
 * the formal page; Acknowledge opens its modal, which goes to Acknowledged with its toast; Suggest a change (stage detail, Acknowledged)
 * opens its modal, which closes and shows "Change suggested"; Back returns to the overview; View contribution history opens the team
 * list. The metric cards of the stage pages scroll to the matching card of the same page; DRAFTS on the Formal agreement page opens
 * the Create agreement modal.
 * Controls with no destination in the design are shown and do nothing: the three metric cards of the overview, the Intent,
 * Contributions, Ownership and Revenue cards, the member tiles, the stage tracker steps and View version 1.
 *
 * Adire Stories shows the Agreements page too (art-routes.tsx), with its own copy, and its links stay inside Adire Stories. Only
 * this page is mirrored there: the Roles and Formal Agreement cards have no destination, Create agreement opens its modal and
 * confirms on the same page, and View contribution history opens the Adire Team page.
 */

const TOAST_MS = 2500;
/** The toast of a "state-" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

/* ------------------------------------------------------------------ overlays */

/** Create agreement: the modal confirms to the overview (from any other page too) and shows the toast. */
function useCreate(startOpen = false) {
  const nav = useNav();
  const path = usePath();
  const overview = useProject().nav.agreements;
  const [open, setOpen] = useState(startOpen);
  const create = () => {
    setOpen(false);
    if (path !== overview) nav.push(overview);
    toast.show({ message: TOASTS.created, duration: TOAST_MS });
  };
  return { show: () => setOpen(true), modal: <CreateAgreementModal open={open} onClose={() => setOpen(false)} onCreate={create} /> };
}

/** Suggest a change: the modal is swapped for the toast, the page stays where it is. */
function useSuggest(startOpen = false) {
  const [open, setOpen] = useState(startOpen);
  const suggest = () => {
    setOpen(false);
    toast.show({ message: TOASTS.suggested, duration: TOAST_MS });
  };
  return { show: () => setOpen(true), modal: <SuggestChangeModal open={open} onClose={() => setOpen(false)} onSuggest={suggest} /> };
}

/** Acknowledge: the modal confirms to the Acknowledged page and shows the toast. */
function useAcknowledge(startOpen = false) {
  const nav = useNav();
  const [open, setOpen] = useState(startOpen);
  const confirm = () => {
    setOpen(false);
    nav.push(AP.acknowledged);
    toast.show({ message: TOASTS.acknowledged, duration: TOAST_MS });
  };
  return { show: () => setOpen(true), modal: <AcknowledgeModal open={open} onClose={() => setOpen(false)} onConfirm={confirm} /> };
}

/** The "Toast:" frames: the page with the toast already showing. */
function useStateToast(message?: string) {
  useEffect(() => {
    if (message) toast.show({ message, duration: STATE_TOAST_MS });
  }, [message]);
}

/* ------------------------------------------------------------------ Agreements (overview) */

function Overview({ startCreate, toastMessage }: { startCreate?: boolean; toastMessage?: string }) {
  const create = useCreate(startCreate);
  const { nav: paths } = useProject();
  const { stages } = useAgreements();
  useStateToast(toastMessage);
  return (
    <WorkspaceFrame active="agreements" rail>
      <div className="ag-stack">
        <PageHead label={HEAD.label} title={HEAD.title} lead={HEAD.lead}>
          <MetricRow>
            {OVERVIEW_METRICS.map((m) => (
              <MetricCard key={m.label} label={m.label} value={m.value} caption={m.caption} dot={m.dot} />
            ))}
          </MetricRow>
          <div className="cw-actions cw-actions--btns">
            <ActionButton onClick={create.show}>{HEAD.create}</ActionButton>
            <CardLink href={paths.team}>{HEAD.history}</CardLink>
          </div>
        </PageHead>

        <section className="ag-stagesec" data-m="up" aria-label="Agreement stages">
          <div className="ag-stagehead">
            <GroupLabel>{STAGES_HEAD.label}</GroupLabel>
            <p>{STAGES_HEAD.text}</p>
          </div>
          <ul className="ag-stages">
            {stages.map((s) => (
              <li key={s.id}>
                <StageCard stage={s} />
              </li>
            ))}
          </ul>
        </section>
      </div>
      {create.modal}
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Empty */

function EmptyScreen() {
  const create = useCreate();
  return (
    <WorkspaceFrame active="agreements" rail="short">
      <div className="ag-stack">
        <PageHead label={HEAD.label} title={HEAD.title} lead={HEAD.lead} />
        <div data-m="up">
          <EmptyState
            className="cw-empty"
            title={EMPTY.title}
            text={EMPTY.text}
            action={
              <Button arrow="up-right" onClick={create.show}>
                {HEAD.create}
              </Button>
            }
          />
        </div>
      </div>
      {create.modal}
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Stage detail and Acknowledged */

/** Stage detail (Roles) and Acknowledged are the same page before and after everyone has acknowledged version 2. */
function StageScreen({ page, startSuggest, startAcknowledge, toastMessage }: { page: RolesPage; startSuggest?: boolean; startAcknowledge?: boolean; toastMessage?: string }) {
  const suggest = useSuggest(startSuggest);
  const acknowledge = useAcknowledge(startAcknowledge);
  useStateToast(toastMessage);
  return (
    <WorkspaceFrame active="agreements" rail>
      <div className="ag-stack ag-stack--detail">
        <PageHead back={<BackLink href={AP.overview}>{page.back}</BackLink>} label={page.label} title={page.title} lead={page.lead}>
          <div className="cw-actions cw-actions--btns">
            {page.done ? <p className="ag-done">{page.done}</p> : <ActionButton onClick={acknowledge.show}>Acknowledge</ActionButton>}
            <ActionButton variant="secondary" onClick={suggest.show}>
              Suggest a change
            </ActionButton>
          </div>
        </PageHead>

        <MetricRow>
          {page.metrics.map((m) => (
            <MetricCard key={m.label} label={m.label} value={m.value} caption={m.caption} dot={m.dot} scrollTo={m.to} />
          ))}
        </MetricRow>

        <DashCard title={page.stagesLabel} id={CARD.stages} className="ag-card--stages">
          <StageTracker stages={stepsAt(page.stepStates)} />
        </DashCard>

        <DashCard title={page.acksLabel} id={CARD.acks} className="ag-card--acks">
          <p className="ag-total">
            <span className="ag-total__n">{page.acksCount}</span>
            <span className="ag-total__text">{page.acksText}</span>
          </p>
          <div className="ag-seg">
            <SegmentBar done={page.acksCount} total={page.acks.length} />
          </div>
          <ul className="ag-tiles">
            {page.acks.map((a) => (
              <AckTile key={a.name} ack={a} />
            ))}
          </ul>
        </DashCard>

        <section id={CARD.terms} className="ag-block ag-anchor" data-m="up" aria-label={page.termsLabel}>
          <GroupLabel>{page.termsLabel}</GroupLabel>
          <ol className="ag-list ag-list--lined">
            {TERMS.map((t, i) => (
              <li className="ag-term" key={t}>
                <span className="ag-term__n">{String(i + 1).padStart(2, '0')}</span>
                <span className="ag-term__text">{t}</span>
              </li>
            ))}
          </ol>
        </section>

        <section id={CARD.versions} className="ag-block ag-anchor" data-m="up" aria-label={page.versionsLabel}>
          <GroupLabel>{page.versionsLabel}</GroupLabel>
          <ul className="ag-list ag-list--lined">
            {page.versions.map((v) => (
              <li className="ag-version" key={v.title}>
                <span className="ag-version__info">
                  <span className="ag-version__title">{v.title}</span>
                  <span className="ag-version__text">{v.text}</span>
                </span>
                {v.current ? <span className="ag-version__current">Current</span> : null}
                {/* no earlier version has a page in the design: the link has no destination */}
                {v.link ? <CardLink>{v.link}</CardLink> : null}
              </li>
            ))}
          </ul>
        </section>
      </div>
      {suggest.modal}
      {acknowledge.modal}
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ Formal agreement */

function FormalScreen() {
  const create = useCreate();
  return (
    <WorkspaceFrame active="agreements" rail>
      <div className="ag-stack ag-stack--detail">
        <PageHead back={<BackLink href={AP.overview}>{FORMAL.back}</BackLink>} label={FORMAL.label} title={FORMAL.title} lead={FORMAL.lead}>
          <div className="cw-actions cw-actions--btns">
            <ActionButton onClick={create.show}>{HEAD.create}</ActionButton>
          </div>
        </PageHead>

        <MetricRow>
          {FORMAL.metrics.map((m) => (
            <MetricCard key={m.label} label={m.label} value={m.value} caption={m.caption} scrollTo={m.to} onClick={m.to ? undefined : create.show} />
          ))}
        </MetricRow>

        <DashCard title={FORMAL.stagesLabel} id={CARD.stages} className="ag-card--stages">
          <StageTracker stages={stepsAt(FORMAL.stepStates)} />
        </DashCard>

        <section className="ag-note" data-m="up" aria-label={FORMAL.noteTitle}>
          <span className="ag-note__rule" aria-hidden="true" />
          <h2 className="ag-note__title">{FORMAL.noteTitle}</h2>
          <p className="ag-note__text">{FORMAL.noteText}</p>
        </section>

        <section id={CARD.templates} className="ag-block ag-block--templates ag-anchor" data-m="up" aria-label={FORMAL.templatesLabel}>
          <GroupLabel>{FORMAL.templatesLabel}</GroupLabel>
          <ul className="ag-templates">
            {FORMAL.templates.map((t) => (
              <li className="ag-template" key={t.title}>
                <span className="ag-template__tag">{FORMAL.templateTag}</span>
                <span className="ag-template__title">{t.title}</span>
                <span className="ag-template__text">{t.text}</span>
              </li>
            ))}
          </ul>
          <p className="ag-foot">{FORMAL.templatesNote}</p>
        </section>
      </div>
      {create.modal}
    </WorkspaceFrame>
  );
}

/* ------------------------------------------------------------------ one export per route */

export const AgreementsOverview = () => <Overview />;
export const AgreementsEmpty = () => <EmptyScreen />;
export const AgreementsRoles = () => <StageScreen page={ROLES} />;
export const AgreementsFormal = () => <FormalScreen />;
export const AgreementsAcknowledged = () => <StageScreen page={ROLES_ACKNOWLEDGED} />;
/** Frame "Modal:Create agreement": the overview with the modal open. */
export const AgreementsCreateModal = () => <Overview startCreate />;
/** Frame "Toast:Agreement created": the overview with the toast showing. */
export const AgreementsCreated = () => <Overview toastMessage={TOASTS.created} />;
/** Frame "Modal:Suggest a change": the stage detail with the modal open. */
export const AgreementsSuggestModal = () => <StageScreen page={ROLES} startSuggest />;
/** Frame "Toast:Change suggested": the stage detail with the toast showing. */
export const AgreementsSuggested = () => <StageScreen page={ROLES} toastMessage={TOASTS.suggested} />;
/** Frame "Modal:Acknowledge agreement": the stage detail with the modal open. */
export const AgreementsAcknowledgeModal = () => <StageScreen page={ROLES} startAcknowledge />;
/** Frame "Toast:Agreement acknowledged": the Acknowledged page with the toast showing. */
export const AgreementsAcknowledgedToast = () => <StageScreen page={ROLES_ACKNOWLEDGED} toastMessage={TOASTS.acknowledged} />;
