'use client';

/**
 * Connect / People profile (Figma 11.73): one page for each of the nine people, plus its two other frames.
 *  - ProfilePage { slug }: the profile. Connect turns into the pill "Requested" and Say hello into "Hello sent" (kept in the Discover store, so
 *    the person's card reads the same; a person who is one of the suggestions shows "Hello sent" on that card too). Back to Discover goes back.
 *  - ProfilePage { state: 'loading' }: the grey Profile skeleton; after LOADING_MS (2.5 s) it goes to the profile of Anaya Smith, as drawn.
 *  - ProfilePage { state: 'error' }: "We could not load this profile." with Try again (to the Loading frame, then Anaya Smith) and Back to Discover.
 * No analytics: Discover has no events for these buttons.
 */
import '../../community/feed/feed.css';
import './states.css';
import './profile.css';
import { useEffect, useRef, type CSSProperties } from 'react';
import { Check, Eye } from 'lucide-react';
import { Button } from '@/ui';
import { useNav } from '@/lib/nav';
import { LOADING_MS, LOADING_NOTE, PATHS, PROFILE_BY_SLUG, PROFILE_COPY as C, firstOfName, personId, profilePath, type Profile } from './data';
import { src } from './images';
import { BackLink } from './list-parts';
import { connectProfile, sayHelloProfile, useDiscover } from './state';

const route = (state: 'loading' | 'error') => `/connect/people/state-${state}`;

/** The pill that replaces a button once pressed (Requested, Hello sent). The slot is a polite live region, so the new state is announced. */
function Done({ label }: { label: string }) {
  return (
    <div className="dxl-pill">
      <Check size={16} strokeWidth={1.5} absoluteStrokeWidth aria-hidden="true" focusable="false" />
      <span>{label}</span>
    </div>
  );
}

function ProfileView({ profile }: { profile: Profile }) {
  const d = useDiscover();
  const first = firstOfName(profile.name);
  const requested = d.isRequested(personId(profile));
  const hello = d.helloSent(profile);
  const nameId = `dxp-name-${profile.slug}`;
  return (
    <div className="dxp-body">
      <article className="dxp-main" aria-labelledby={nameId}>
        <BackLink href={PATHS.discover}>{C.back}</BackLink>
        <div className="dxp-header">
          <div className="fd-photo dxp-portrait" data-m="frame">
            <img className="cover" src={src(profile.image)} alt="" decoding="async" draggable={false} />
          </div>
          <div className="dxp-info">
            <p className="dxp-status">
              <span className="dxp-dot" aria-hidden="true" />
              {profile.connections}
            </p>
            <h1 className="dxp-name" id={nameId}>
              {profile.name}
            </h1>
            <p className="dxp-role">{profile.identity}</p>
            <p className="dxp-intro">{profile.intro}</p>
            <ul className="dxl-tags">
              {profile.tags.map((t) => (
                <li className="dxl-tag" key={t}>
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <section className="dxl-block" aria-labelledby={`${nameId}-about`}>
          <h2 className="dxl-eyebrow" id={`${nameId}-about`}>
            {C.aboutLabel}
          </h2>
          <p className="dxl-body">{profile.about}</p>
        </section>
        <section className="dxl-block" aria-labelledby={`${nameId}-interests`}>
          <h2 className="dxl-eyebrow" id={`${nameId}-interests`}>
            {C.interestsLabel}
          </h2>
          <ul className="dxl-tags">
            {profile.interests.map((t) => (
              <li className="dxl-tag" key={t}>
                {t}
              </li>
            ))}
          </ul>
        </section>
      </article>

      <aside className="dxp-side" aria-label={`Connect with ${first}`}>
        <section className="dxl-panel" aria-labelledby={`${nameId}-connect`}>
          <h2 className="dxl-eyebrow" id={`${nameId}-connect`}>
            {C.actionsLabel(first)}
          </h2>
          <div aria-live="polite" aria-atomic="true">
            {requested ? (
              <Done label={C.connect.done} />
            ) : (
              <Button fullWidth onClick={() => connectProfile(profile)}>
                {C.connect.action}
              </Button>
            )}
          </div>
          <div aria-live="polite" aria-atomic="true">
            {hello ? (
              <Done label={C.hello.done} />
            ) : (
              <Button variant="secondary" fullWidth onClick={() => sayHelloProfile(profile)}>
                {C.hello.action}
              </Button>
            )}
          </div>
        </section>
        <section className="dxl-panel dxl-panel--tight" aria-labelledby={`${nameId}-seeing`}>
          <div className="dxl-panel__head">
            <Eye size={16} strokeWidth={1.25} absoluteStrokeWidth aria-hidden="true" focusable="false" />
            <h2 className="dxl-eyebrow" id={`${nameId}-seeing`}>
              {C.seeingLabel}
            </h2>
          </div>
          <p className="dxl-note dxl-note--plain">{C.seeing(first)}</p>
        </section>
      </aside>
    </div>
  );
}

/* ---------------------------------------------------------------- Loading */
const Bar = ({ w, h, className = '' }: { w: number | string; h: number; className?: string }) => (
  <span className={`dxp-bar ${className}`.trim()} style={{ width: w, height: h } as CSSProperties} />
);

function ProfileLoading() {
  // After LOADING_MS the profile of Anaya Smith replaces this frame (replace, so Back does not return to the skeleton)
  const { replace } = useNav();
  const go = useRef(replace);
  go.current = replace;
  useEffect(() => {
    const t = window.setTimeout(() => go.current(profilePath(C.fallback)), LOADING_MS);
    return () => window.clearTimeout(t);
  }, []);
  return (
    <div className="dxp-body" role="status" aria-busy="true">
      <p className="sr-only">{LOADING_NOTE}</p>
      <div className="dxp-main" aria-hidden="true">
        <Bar w={190} h={14} />
        <div className="dxp-header">
          <Bar w={280} h={352} />
          <div className="dxp-info dxp-sk-info">
            <Bar w={140} h={12} />
            <Bar w={320} h={56} />
            <Bar w={190} h={16} />
            <Bar w={540} h={18} />
            <Bar w={500} h={18} />
            <Bar w={360} h={18} />
            <div className="dxp-sk-chips">
              <Bar w={120} h={36} />
              <Bar w={120} h={36} />
              <Bar w={120} h={36} />
            </div>
          </div>
        </div>
        <div className="dxp-sk-block">
          <Bar w={140} h={12} />
          <Bar w="100%" h={16} />
          <Bar w={700} h={16} />
        </div>
        <div className="dxp-sk-block">
          <Bar w={140} h={12} />
          <div className="dxp-sk-items">
            {[0, 1, 2].map((i) => (
              <div className="dxp-sk-item" key={i}>
                <Bar w={340} h={22} />
                <Bar w={420} h={14} />
              </div>
            ))}
          </div>
        </div>
        <div className="dxp-sk-block">
          <Bar w={140} h={12} />
          <div className="dxp-sk-chips">
            {[0, 1, 2, 3].map((i) => (
              <Bar w={120} h={36} key={i} />
            ))}
          </div>
        </div>
        <div className="dxp-sk-block">
          <Bar w={140} h={12} />
          <div className="dxp-sk-items">
            {[0, 1, 2, 3].map((i) => (
              <div className="dxp-sk-row" key={i}>
                <Bar w={208} h={14} />
                <Bar w={400} h={16} />
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="dxp-side" aria-hidden="true">
        <div className="dxl-panel">
          <Bar w={200} h={12} />
          <Bar w="100%" h={48} />
          <Bar w="100%" h={48} />
        </div>
        <div className="dxl-panel">
          <Bar w={160} h={12} />
          <Bar w="100%" h={14} />
          <Bar w={300} h={14} />
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- Could not load */
function ProfileError() {
  const { replace } = useNav();
  return (
    <div className="dxp-wide">
      <BackLink href={PATHS.discover}>{C.back}</BackLink>
      <div className="dxp-error" role="alert">
        <span className="dxp-error__rule" aria-hidden="true" />
        <h1 className="dxp-error__title">{C.error.title}</h1>
        <p className="dxp-error__text">{C.error.text}</p>
        <div className="dxp-error__actions">
          <Button onClick={() => replace(route('loading'))}>{C.error.retry}</Button>
          <Button variant="secondary" href={PATHS.discover}>
            {C.error.back}
          </Button>
        </div>
      </div>
    </div>
  );
}

export function ProfilePage({ slug = C.fallback, state }: { slug?: string; state?: 'loading' | 'error' }) {
  const profile = PROFILE_BY_SLUG.get(slug) ?? PROFILE_BY_SLUG.get(C.fallback)!;
  return (
    <div className="fd-page dxp-page" data-profile-state={state}>
      {state === 'loading' ? <ProfileLoading /> : state === 'error' ? <ProfileError /> : <ProfileView profile={profile} />}
    </div>
  );
}
