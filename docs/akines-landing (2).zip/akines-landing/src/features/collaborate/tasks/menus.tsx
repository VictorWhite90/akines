'use client';

import { useState, type KeyboardEvent } from 'react';
import { Button } from '@/ui';
import { CardLink, CheckIcon, Over } from '../workspace/parts';
import { PRIORITIES, STATUSES, matches, plural, type Filters, type Status } from './data';
import { Box, StatusTag } from './parts';
import { useTasksData, useTasksStore } from './store';

/**
 * The two dropdowns of the design. Filter Menu 17672:19391 (320 wide, three groups of options, Clear all and Show N tasks)
 * and Status Menu 17672:19475 (240 wide, four statuses, a check on the current one). Option states (Default, Hover, Pressed, Focus)
 * come from CSS. Both hang from their trigger through Popover.
 */

type GroupKey = keyof Filters;

/* ------------------------------------------------------------------ Filter Menu */

export function FilterMenu({ initial, onApply }: { initial: Filters; onApply: (f: Filters) => void }) {
  const tasks = useTasksStore((s) => s.tasks);
  const { people } = useTasksData();
  const [draft, setDraft] = useState<Filters>(initial);
  const shown = tasks.filter((t) => matches(t, draft)).length;

  const toggle = (group: GroupKey, value: string) =>
    setDraft((d) => {
      const cur = d[group] as string[];
      return { ...d, [group]: cur.includes(value) ? cur.filter((x) => x !== value) : [...cur, value] } as Filters;
    });

  const groups: { key: GroupKey; label: string; options: { value: string; label: string; count: number }[] }[] = [
    { key: 'status', label: 'STATUS', options: STATUSES.map((s) => ({ value: s, label: s, count: tasks.filter((t) => t.status === s).length })) },
    { key: 'priority', label: 'PRIORITY', options: PRIORITIES.map((p) => ({ value: p, label: p, count: tasks.filter((t) => t.priority === p).length })) },
    { key: 'person', label: 'RESPONSIBLE', options: people.map((p) => ({ value: p.name, label: p.label, count: tasks.filter((t) => t.owner === p.name).length })) },
  ];

  return (
    <div className="tk-menu tk-menu--filter" role="group" aria-label="Filter tasks">
      <Over className="tk-menu__heading">FILTER TASKS</Over>
      {groups.map((g) => (
        <div className="tk-fgroup" role="group" aria-label={g.label} key={g.key}>
          <p className="tk-fgroup__label" aria-hidden="true">
            {g.label}
          </p>
          {g.options.map((o) => {
            const on = (draft[g.key] as string[]).includes(o.value);
            return (
              <button type="button" role="checkbox" aria-checked={on} className="tk-opt" key={o.value} onClick={() => toggle(g.key, o.value)}>
                <Box on={on} />
                <span className="tk-opt__label">{o.label}</span>
                <span className="tk-opt__count">{o.count}</span>
              </button>
            );
          })}
        </div>
      ))}
      <div className="tk-menu__actions">
        {/* Clear all has no reaction in the design: it empties the ticks of the menu */}
        <CardLink onClick={() => setDraft({ status: [], priority: [], person: [] })}>Clear all</CardLink>
        <Button size="sm" disabled={shown === 0} onClick={() => onApply(draft)}>
          Show {plural(shown, 'task', 'tasks')}
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Status Menu */

/** Arrow keys move between the options, as in a menu. Not started has no destination in the design: it stays in the menu and does nothing. */
export function StatusMenu({ current, onPick }: { current: Status; onPick: (s: Status) => void }) {
  const move = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Home' && e.key !== 'End') return;
    e.preventDefault();
    const items = Array.from(e.currentTarget.querySelectorAll<HTMLButtonElement>('[role="menuitemradio"]'));
    const i = items.indexOf(document.activeElement as HTMLButtonElement);
    const next = e.key === 'Home' ? 0 : e.key === 'End' ? items.length - 1 : e.key === 'ArrowDown' ? (i + 1) % items.length : (i - 1 + items.length) % items.length;
    items[next]?.focus();
  };
  return (
    <div className="tk-menu tk-menu--status" role="menu" aria-label="Change status" onKeyDown={move}>
      {STATUSES.map((s) => (
        <button type="button" role="menuitemradio" aria-checked={s === current} className="tk-sopt" key={s} onClick={() => onPick(s)}>
          <StatusTag status={s} />
          <span className="tk-sopt__check" aria-hidden="true">
            {s === current ? <CheckIcon size={16} sw={1.5} /> : null}
          </span>
        </button>
      ))}
    </div>
  );
}
