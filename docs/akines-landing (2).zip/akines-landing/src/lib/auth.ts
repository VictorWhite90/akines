'use client';

/**
 * Test-only session. There is no backend: signing in checks the dummy account below and stores a flag in
 * localStorage (memory fallback when storage is blocked, e.g. in a private window or the preview artifact).
 *
 * EVERY FORM in the app is prefilled from DUMMY so any flow can be walked with the Continue / submit button.
 * Clear a field to see its error state.
 */
import { useSyncExternalStore } from 'react';

export const DUMMY = {
  /** Sign in identifier (email). Username and mobile below are accepted too. */
  email: 'kemi.adeyemi@example.com',
  username: 'kemiadeyemi',
  mobile: '+234 803 555 0142',
  password: 'Akines@Lagos2026!',
  /** Six digit code accepted by the join flow. */
  code: '123456',
  first: 'Kemi',
  last: 'Adeyemi',
  fullName: 'Kemi Adeyemi',
  initials: 'KA',
  city: 'Lagos',
  /** The name a brand-new member sees on the welcome step. */
  welcomeUsername: 'kemiadeyemi',
} as const;

export type Session = { signedIn: boolean; username: string; first: string; initials: string };

const KEY = 'akines.session.v1';
let memory: string | null = null;
const listeners = new Set<() => void>();

const read = (): string | null => {
  try {
    return window.localStorage.getItem(KEY) ?? memory;
  } catch {
    return memory;
  }
};
const write = (value: string | null) => {
  memory = value;
  try {
    if (value === null) window.localStorage.removeItem(KEY);
    else window.localStorage.setItem(KEY, value);
  } catch {
    /* storage unavailable: memory fallback above */
  }
  listeners.forEach((l) => l());
};

const SIGNED_OUT: Session = { signedIn: false, username: '', first: '', initials: '' };
const SIGNED_IN: Session = { signedIn: true, username: DUMMY.username, first: DUMMY.first, initials: DUMMY.initials };

export const getSession = (): Session => (read() === '1' ? SIGNED_IN : SIGNED_OUT);
export const subscribeSession = (cb: () => void) => {
  listeners.add(cb);
  window.addEventListener('storage', cb);
  return () => {
    listeners.delete(cb);
    window.removeEventListener('storage', cb);
  };
};

/** React hook. Server render and first client render both return signed out, so markup always matches. */
export function useSession(): Session {
  return useSyncExternalStore(subscribeSession, getSession, () => SIGNED_OUT);
}

/** Which identifiers belong to the dummy account (email, username with or without @, mobile digits). */
export function isDummyIdentifier(value: string): boolean {
  const v = value.trim().toLowerCase().replace(/^@/, '');
  const digits = v.replace(/[^\d+]/g, '');
  return v === DUMMY.email || v === DUMMY.username || digits === DUMMY.mobile.replace(/[^\d+]/g, '');
}

export function checkCredentials(identifier: string, password: string): 'ok' | 'bad' {
  return isDummyIdentifier(identifier) && password === DUMMY.password ? 'ok' : 'bad';
}

export function signIn() {
  write('1');
}
export function signOut() {
  write(null);
}
