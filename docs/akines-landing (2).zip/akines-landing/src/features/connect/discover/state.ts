'use client';

/**
 * Connect / Discover state: the filter of "For you on Akines", the people and circles the member pressed Connect or Join on,
 * and the status of each recommendation. One small module-level store, like features/community/store.ts, in memory only
 * (it resets on reload; requests, joins and dismissals survive route changes during one visit of the app, the filter does not).
 * Every action calls track() with ids, types and positions only.
 */
import { createContext, useContext, useMemo, useSyncExternalStore } from 'react';
import { track, trackCardAction } from './analytics';
import { CARD_BY_ID, SUGGESTIONS, recIdOf, personId, recPosition, type ForYouFilter, type Profile } from './data';

export type RecStatus = 'idle' | 'sent' | 'dismissed';

export type DiscoverState = {
  /** Active filter of "For you on Akines". */
  filter: ForYouFilter;
  /** Ids of the person cards the member pressed Connect on ("person-anaya"): the button reads "Requested". */
  requested: readonly string[];
  /** Ids of the circle cards the member pressed Join or Request to join on ("circle-textiles"): "Joined" or "Requested". */
  joined: readonly string[];
  /** Status of every recommendation ("rec-ayo"): idle, sent (Say hello) or dismissed (Not now). */
  recs: Readonly<Record<string, RecStatus>>;
  /** Slugs of the profiles the member pressed Say hello on ("anaya-smith"): the button reads "Hello sent". */
  hellos: readonly string[];
  /** Event pages the member registered for: slug of the event and the address the confirmation went to. Cancelling removes the entry. */
  registered: Readonly<Record<string, string>>;
};

const initial: DiscoverState = {
  filter: 'all',
  requested: [],
  joined: [],
  recs: Object.fromEntries(SUGGESTIONS.map((r) => [r.id, 'idle' as const])),
  hellos: [],
  registered: {},
};

let state: DiscoverState = initial;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};
function set(patch: Partial<DiscoverState>) {
  state = { ...state, ...patch };
  emit();
}

export function getDiscover(): DiscoverState {
  return state;
}

/** What useDiscover() returns: the state plus three readers. */
export type DiscoverView = DiscoverState & {
  isRequested: (personId: string) => boolean;
  isJoined: (circleId: string) => boolean;
  recStatus: (recommendationId: string) => RecStatus;
  /** Did the member say hello on this profile (here, or on the person's suggestion)? */
  helloSent: (profile: Profile) => boolean;
  /** The address the confirmation of this event went to, or undefined when the member is not registered. */
  registration: (eventSlug: string) => string | undefined;
};

/**
 * The filter the page opens with. DiscoverPage provides it (the route's filter, or nothing for All) so the server render and the
 * hydration show the right filter before enterDiscover() has run.
 */
export const DiscoverEntry = createContext<ForYouFilter | undefined>(undefined);

/** The state for rendering. Components under DiscoverPage call it without arguments. */
export function useDiscover(entry?: ForYouFilter): DiscoverView {
  const fromPage = useContext(DiscoverEntry);
  const open = entry ?? fromPage;
  const server = useMemo<DiscoverState>(() => (open && open !== initial.filter ? { ...initial, filter: open } : initial), [open]);
  const s = useSyncExternalStore(subscribe, () => state, () => server);
  return useMemo<DiscoverView>(
    () => ({
      ...s,
      isRequested: (id) => s.requested.includes(id),
      isJoined: (id) => s.joined.includes(id),
      recStatus: (id) => s.recs[id] ?? 'idle',
      helloSent: (p) => s.hellos.includes(p.slug) || s.recs[recIdOf(p) ?? ''] === 'sent',
      registration: (slug) => s.registered[slug],
    }),
    [s],
  );
}

/**
 * The Discover page calls this when it mounts: the filter starts at `filter` (All unless the route says otherwise).
 * Requests, joins and dismissals are kept. Not a member action, so nothing is tracked.
 */
export function enterDiscover(filter: ForYouFilter = 'all') {
  if (state.filter !== filter) set({ filter });
}

/** Back to the start (tests and previews). */
export function resetDiscover() {
  state = initial;
  emit();
}

/* ---------------------------------------------------------------- actions */
/** Pick a filter of "For you on Akines". Picking the active filter does nothing. */
export function setFilter(next: ForYouFilter) {
  if (next === state.filter) return;
  const previous = state.filter;
  set({ filter: next });
  track('for_you_filter_select', { filter: next, previous });
}

/** Connect on a person card (`id` is the card id, "person-anaya"). Pressing it again does nothing. */
export function connect(id: string) {
  if (CARD_BY_ID.get(id)?.kind !== 'person' || state.requested.includes(id)) return;
  set({ requested: [...state.requested, id] });
  trackCardAction(id, state.filter);
}

/** Join or Request to join on a circle card (`id` is the card id, "circle-textiles"). Pressing it again does nothing. */
export function join(id: string) {
  if (CARD_BY_ID.get(id)?.kind !== 'circle' || state.joined.includes(id)) return;
  set({ joined: [...state.joined, id] });
  trackCardAction(id, state.filter);
}

const setRec = (id: string, status: RecStatus) => set({ recs: { ...state.recs, [id]: status } });
const recProps = (id: string) => ({ recommendation_id: id, position: recPosition(id), source: 'section' as const });

/** Say hello on a recommendation (`id` is the recommendation id, "rec-ayo"): idle to sent. */
export function sayHello(id: string) {
  if (state.recs[id] !== 'idle') return;
  setRec(id, 'sent');
  track('recommendation_say_hello', recProps(id));
}

/** Not now on a recommendation: idle to dismissed. */
export function dismiss(id: string) {
  if (state.recs[id] !== 'idle') return;
  setRec(id, 'dismissed');
  track('recommendation_dismiss', recProps(id));
}

/** Undo after Not now: dismissed back to idle. A hello that was sent cannot be undone. */
export function undo(id: string) {
  if (state.recs[id] !== 'dismissed') return;
  setRec(id, 'idle');
  track('recommendation_undo', recProps(id));
}

/* ---------------------------------------------------------------- profiles and events (Figma 11.71, 11.73) */
/** Connect on a profile page. The person card of the same person reads "Requested" too (both use the id of the card). Pressing it again does nothing. */
export function connectProfile(profile: Profile) {
  const id = personId(profile);
  if (state.requested.includes(id)) return;
  set({ requested: [...state.requested, id] });
}

/** Say hello on a profile page. If the person is one of the suggestions, that card reads "Hello sent" too. Not a recommendation action, so nothing is tracked. */
export function sayHelloProfile(profile: Profile) {
  if (state.hellos.includes(profile.slug)) return;
  const rec = recIdOf(profile);
  set({ hellos: [...state.hellos, profile.slug], ...(rec && state.recs[rec] === 'idle' ? { recs: { ...state.recs, [rec]: 'sent' as const } } : {}) });
}

/** Register for an event: the confirmation goes to `email`. */
export function registerForEvent(slug: string, email: string) {
  if (state.registered[slug]) return;
  set({ registered: { ...state.registered, [slug]: email } });
}

/** Cancel registration, and Undo on the toast: back to the Register button. */
export function cancelRegistration(slug: string) {
  if (!state.registered[slug]) return;
  const { [slug]: _gone, ...rest } = state.registered;
  set({ registered: rest });
}
