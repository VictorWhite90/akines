// READ-ONLY use_figma script: lists the frames of one section (id | name | size | position | reaction count), sorted by position.
// Edit PAGE_ID and SECTION_PREFIX, paste the whole file as `code`, pass skillNames "figma-use". Desktop page 12001:8778, Tablet 16165:274, Mobile 16833:15326.
const PAGE_ID = '12001:8778';
const SECTION_PREFIX = '10'; // first characters of the section name: 07, 08, 10, 12 ...
const NAME_FILTER = ''; // optional substring that frame names must contain, e.g. '12.5 '
const page = await figma.getNodeByIdAsync(PAGE_ID);
await figma.setCurrentPageAsync(page);
const out = [];
for (const s of page.children) {
  if (s.type !== 'SECTION' || !s.name.startsWith(SECTION_PREFIX)) continue;
  out.push('## ' + s.name + ' ' + s.id);
  const kids = s.children.filter((c) => c.type === 'FRAME' && c.name.includes(NAME_FILTER));
  kids.sort((a, b) => a.y - b.y || a.x - b.x);
  for (const c of kids) out.push(c.id + ' | ' + c.name + ' | ' + Math.round(c.width) + 'x' + Math.round(c.height) + ' | @' + Math.round(c.x) + ',' + Math.round(c.y) + ' | rx=' + c.reactions.length);
}
return out.join('\n');
