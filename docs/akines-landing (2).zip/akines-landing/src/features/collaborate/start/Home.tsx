'use client';

/**
 * 12.1 Collaborate Home (Figma frame 17182:10780), its Empty state (17111:9037, the real page with zero tiles) and its Loading state
 * (17974:166533, shown on the first visit and at /collaborate/state-loading).
 * Nine bands: welcome, overview, continue working, needs your attention, suggested collaborators, invitations, open calls,
 * recent team messages, start a project. The four carousels page like the Figma prototype. The four count tiles open the lists
 * 12.10, 12.48, 12.49 and 12.50 (overview-lists/).
 */
import './home.css';
import { useEffect, useState } from 'react';
import { Button } from '@/ui';
import { asset } from '@/lib/assets';
import { Link, useNav } from '@/lib/nav';
import { Carousel } from './Carousel';
import { IcArrowRight } from './parts';
import { PATHS } from './flow-data';
import { personRoutes } from '../people/data';
import { LOADING_MS, takeFirstVisit } from '../projects/store';
import { Bar, CardSkeleton } from '../projects/ui';
import {
  ATTENTION,
  COLLABORATORS,
  COLLABORATORS_HEAD,
  EMPTY_BEGIN,
  EMPTY_CAN,
  EMPTY_GLANCE,
  EMPTY_TILES,
  EMPTY_WELCOME,
  INVITATIONS,
  INVITES_HEAD,
  MESSAGES,
  MESSAGES_HEAD,
  NEW_PROJECT,
  OPEN_CALLS,
  OPEN_HEAD,
  PROJECTS,
  START_PANEL,
  TILES,
  WELCOME,
  WORKSPACE,
  type Collaborator,
  type Invitation,
  type OpenCall,
  type ProjectCard,
  type Tile,
} from './home-data';

/* ------------------------------------------------------------------ small pieces */
function Avatars({ people, size = 32 }: { people: string[]; size?: number }) {
  return (
    <span className="cs-avs" style={{ ['--s' as string]: size + 'px', ['--fs' as string]: (size <= 28 ? 10 : 11) + 'px' }} aria-hidden="true">
      {people.map((p, i) => (
        <span key={p + i} className="cs-av">
          {p}
        </span>
      ))}
    </span>
  );
}

function Dot() {
  return <span className="cs-dot" aria-hidden="true" />;
}

/**
 * Card Link: the kit link Button with an arrow. Inert (a button that does nothing) when the Figma frame gives it no destination.
 * `card` is the Figma Card Link (4 px above and below); without it the link keeps the 19 px slot of the plain text link it replaced.
 */
function CardLink({ children, href, card }: { children: string; href?: string; card?: boolean }) {
  return (
    <Button variant="link" href={href} className={card ? 'cs-card-link' : 'cs-tight'} iconRight={<IcArrowRight />}>
      {children}
    </Button>
  );
}

function SectionHead({ label, title, support, children }: { label: string; title: string; support?: string; children?: React.ReactNode }) {
  return (
    <div className="cs-sec">
      <div className="cs-sec__text">
        <p className="cs-label">{label}</p>
        <h2 className="cs-h2" data-m="words">
          {title}
        </h2>
        {support ? <p className="cs-sec__support">{support}</p> : null}
      </div>
      {children}
    </div>
  );
}

/** Narrow header column of the side by side bands (attention, invitations, messages). */
function SideHead({ label, title }: { label: string; title: string }) {
  return (
    <div className="cs-side">
      <p className="cs-label">{label}</p>
      <h2 className="cs-h2" data-m="words">
        {title}
      </h2>
    </div>
  );
}

/* ------------------------------------------------------------------ cards */
function ProjectCardView({ p }: { p: ProjectCard }) {
  return (
    <article className="cs-pc cs-hcard">
      <div className="cs-pc__top">
        <span className="cs-stage">
          <Dot />
          {p.stage}
        </span>
        <span className="cs-pc__active">{p.active}</span>
      </div>
      <div className="cs-pc__title">
        <h3>{p.title}</h3>
        <p>{p.text}</p>
      </div>
      <hr className="cs-rule" />
      <div className="cs-pc__details">
        <div>
          <p className="cs-label cs-label--muted">Current milestone</p>
          <p className="cs-val">{p.milestone}</p>
        </div>
        <div>
          <p className="cs-label cs-label--muted">Next action</p>
          <p className="cs-val">{p.next}</p>
        </div>
      </div>
      <div className="cs-pc__progress">
        <div className="cs-pc__plabel">
          <span className="cs-label cs-label--muted">Progress</span>
          <span className="cs-small">{p.done} of 5 milestones</span>
        </div>
        <div className="cs-pc__bars" role="img" aria-label={`${p.done} of 5 milestones`}>
          {[0, 1, 2, 3, 4].map((i) => (
            <span key={i} data-on={i < p.done || undefined} />
          ))}
        </div>
      </div>
      <div className="cs-pc__foot">
        <span className="cs-pc__team">
          <Avatars people={p.people} />
          <span>{p.team}</span>
        </span>
        <Button variant="link" className="cs-tight" iconRight={<IcArrowRight />}>
          {p.cta}
        </Button>
      </div>
    </article>
  );
}

function NewProjectTile() {
  return (
    <article className="cs-np">
      <div className="cs-np__text">
        <p className="cs-label cs-label--muted">{NEW_PROJECT.label}</p>
        <h3>{NEW_PROJECT.title}</h3>
        <p>{NEW_PROJECT.text}</p>
      </div>
      <div>
        <Button href={PATHS.start} iconRight={<IcArrowRight />}>
          {NEW_PROJECT.cta}
        </Button>
      </div>
    </article>
  );
}

function CollaboratorCard({ c }: { c: Collaborator }) {
  /* Figma 12.1: the portrait and the name open the profile, Request introduction opens the introduction request. Save for later, Not relevant,
     Ask Akines why and Adjust matching preferences have no destination on the Home card. */
  const routes = personRoutes(c.id);
  return (
    <article className="cs-cc cs-hcard">
      {/* Figma Collaborator Card / Portrait (554x538), node ids in home-data.ts */}
      <Link className="cs-cc__photo" href={routes.profile} tabIndex={-1} aria-hidden="true">
        <img className="cover" src={asset(c.photo)} loading="lazy" decoding="async" alt="" />
      </Link>
      <div className="cs-cc__body">
        <div className="cs-cc__profile">
          <p className="cs-cc__avail">
            <Dot />
            {c.availability}
          </p>
          <div className="cs-cc__who">
            <h3>
              <Link className="cs-cc__name" href={routes.profile}>
                {c.name}
              </Link>
            </h3>
            <p className="cs-cc__role">{c.role}</p>
          </div>
          <p className="cs-cc__skills">{c.skills}</p>
          <hr className="cs-rule" />
          <div className="cs-cc__fields">
            <div>
              <p className="cs-label cs-label--muted">Shared purpose</p>
              <p className="cs-val cs-val--sm">{c.purpose}</p>
            </div>
            <div>
              <p className="cs-label cs-label--muted">Complementary skill</p>
              <p className="cs-val cs-val--sm">{c.skill}</p>
            </div>
            <div>
              <p className="cs-label cs-label--muted">Working preference</p>
              <p className="cs-val cs-val--sm">{c.preference}</p>
            </div>
          </div>
        </div>
        <div className="cs-cc__match">
          <div className="cs-cc__why">
            <p className="cs-label cs-label--muted">Why you may work well together</p>
            <p className="cs-cc__text">{c.match}</p>
          </div>
          <div className="cs-cc__actions">
            <Button fullWidth iconRight={<IcArrowRight />} href={routes.request}>
              Request introduction
            </Button>
            <Button fullWidth variant="secondary">
              Save for later
            </Button>
            <div className="cs-cc__links">
              <Button variant="link">Not relevant</Button>
              <Button variant="link">Ask Akines why</Button>
              <Button variant="link">Adjust matching preferences</Button>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}

function InvitationCard({ v }: { v: Invitation }) {
  return (
    <article className="cs-ic cs-hcard">
      <div className="cs-ic__top">
        <span className="cs-stage">
          <Dot />
          Invitation
        </span>
        <span className="cs-small">{v.date}</span>
      </div>
      <div className="cs-ic__title">
        <h3>{v.title}</h3>
        <p>{v.text}</p>
      </div>
      <hr className="cs-rule" />
      <div className="cs-ic__row">
        <div>
          <p className="cs-label cs-label--muted">Invited by</p>
          <p className="cs-ic__by">
            <Avatars people={[v.by.initials]} />
            <span>{v.by.name}</span>
          </p>
        </div>
        <div>
          <p className="cs-label cs-label--muted">Proposed role</p>
          <p className="cs-val">{v.role}</p>
        </div>
        <div>
          <p className="cs-label cs-label--muted">Time commitment</p>
          <p className="cs-val">{v.commitment}</p>
        </div>
      </div>
      <div className="cs-ic__row cs-ic__row--2">
        <div>
          <p className="cs-label cs-label--muted">Team members</p>
          <p className="cs-ic__by">
            <Avatars people={v.team} />
            <span>{v.members}</span>
          </p>
        </div>
        <div>
          <p className="cs-label cs-label--muted">Expected contribution</p>
          <p className="cs-val">{v.contribution}</p>
        </div>
      </div>
      <div className="cs-ic__actions">
        <Button iconRight={<IcArrowRight />}>Review invitation</Button>
        <Button variant="secondary">Accept</Button>
        <Button variant="link">Decline</Button>
      </div>
    </article>
  );
}

function OpenCallCard({ o }: { o: OpenCall }) {
  return (
    <article className="cs-oc cs-hcard">
      <span className="cs-stage">
        <Dot />
        {o.stage}
      </span>
      <div className="cs-oc__title">
        <h3>{o.title}</h3>
        <p>{o.text}</p>
      </div>
      <hr className="cs-rule" />
      <div className="cs-oc__skills">
        <p className="cs-label cs-label--muted">Looking for</p>
        <p className="cs-val">{o.looking}</p>
      </div>
      <div className="cs-oc__teamf">
        <p className="cs-label cs-label--muted">Current team</p>
        <p className="cs-oc__team">
          <Avatars people={o.team} size={28} />
          <span>{o.teamText}</span>
        </p>
      </div>
      <div className="cs-oc__commit">
        <p className="cs-label cs-label--muted">Commitment</p>
        <p className="cs-val cs-val--sm">{o.commitment}</p>
      </div>
      <div>
        <p className="cs-label cs-label--muted">Project owner</p>
        <p className="cs-val cs-val--sm">{o.owner}</p>
      </div>
      <Button variant="link" className="cs-oc__cta cs-tight" iconRight={<IcArrowRight />}>
        Explore project
      </Button>
    </article>
  );
}

/* ------------------------------------------------------------------ shared bands */

/** 01 Welcome header of Home and of Home Loading (the Empty state has its own text and no buttons). */
function Welcome() {
  return (
    <section className="cs-band cs-welcome" aria-label="Welcome">
      <div className="cs-welcome__text">
        <p className="cs-label">{WELCOME.eyebrow}</p>
        <h1 className="cs-h1" data-m="words">
          {WELCOME.title}
        </h1>
        <p className="cs-welcome__support">{WELCOME.support}</p>
      </div>
      <div className="cs-welcome__actions">
        <Button href={PATHS.start} iconRight={<IcArrowRight />}>
          Start a project
        </Button>
        <Button href={PATHS.collaborators} variant="secondary">
          Explore collaborators
        </Button>
      </div>
    </section>
  );
}

/**
 * Overview Indicator (Figma 17190:11046). The whole tile opens the page of its count (Figma: the tile instance navigates); the Card Link
 * inside is the keyboard and screen reader link, the tile has an inert link over it for the mouse.
 */
function OverviewTile({ t }: { t: Tile }) {
  return (
    <li className="cs-tile">
      {t.href ? <Link className="cs-tile__hit" href={t.href} tabIndex={-1} aria-hidden="true" /> : null}
      <p className="cs-tile__head">
        <span className="cs-tile__n">{t.n}</span>
        <span className="cs-label">{t.label}</span>
      </p>
      <p className="cs-tile__count">
        <span className="cs-tile__big">{t.count}</span>
        <span className="cs-tile__unit">{t.unit}</span>
      </p>
      <p className="cs-tile__text">{t.text}</p>
      <CardLink href={t.href}>{t.link}</CardLink>
    </li>
  );
}

/* ------------------------------------------------------------------ Home */

/** Home: the Loading frame on the first visit of a session (2.5 s, like the other screens), then the page. */
export function Home() {
  const [loading, setLoading] = useState(() => takeFirstVisit('collaborate-home'));
  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(() => setLoading(false), LOADING_MS);
    return () => window.clearTimeout(t);
  }, [loading]);
  return loading ? <HomeSkeleton /> : <HomeMain />;
}

/** The state route of Home Loading (17974:166533): the skeleton, then Home. That visit counts as the first one, so Home does not load twice. */
export function HomeLoadingState() {
  const nav = useNav();
  useState(() => takeFirstVisit('collaborate-home'));
  useEffect(() => {
    const t = window.setTimeout(() => nav.replace(PATHS.home), LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return <HomeSkeleton />;
}

function HomeMain() {
  return (
    <div className="cs-home">
      {/* 01 Welcome header */}
      <Welcome />

      {/* 02 Overview */}
      <section className="cs-band" aria-label="Overview">
        <ul className="cs-ov" data-m="stagger">
          {TILES.map((t) => (
            <OverviewTile key={t.n} t={t} />
          ))}
        </ul>
      </section>

      {/* 03 Continue working */}
      <section className="cs-band cs-stack" aria-label="Continue working">
        <SectionHead label={WORKSPACE.label} title={WORKSPACE.title} support={WORKSPACE.support}>
          <CardLink href={PATHS.myProjects} card>
            {WORKSPACE.link}
          </CardLink>
        </SectionHead>
        <Carousel label="Your projects" noun="projects" per={{ desktop: 2, tablet: 1, mobile: 1 }}>
          {[...PROJECTS.map((p) => <ProjectCardView key={p.title} p={p} />), <NewProjectTile key="new" />]}
        </Carousel>
      </section>

      {/* 04 Needs your attention */}
      <section className="cs-band cs-split2" aria-label="Needs your attention">
        <SideHead label={ATTENTION.label} title={ATTENTION.title} />
        <ul className="cs-att">
          {ATTENTION.items.map((a) => (
            <li key={a.title} className="cs-att__item">
              <div className="cs-att__type">
                <span className="cs-att__kind">
                  <span className="cs-dot cs-dot--sm" aria-hidden="true" />
                  {a.type}
                </span>
                <span className="cs-small">{a.time}</span>
              </div>
              <div className="cs-att__content">
                <h3>{a.title}</h3>
                <p>{a.text}</p>
              </div>
              <Button variant="secondary" className="cs-att__action" iconRight={<IcArrowRight />} href={a.href}>
                {a.cta}
              </Button>
            </li>
          ))}
        </ul>
      </section>

      {/* 05 Suggested collaborators */}
      <section className="cs-band cs-stack" aria-label="Suggested collaborators">
        <SectionHead label={COLLABORATORS_HEAD.label} title={COLLABORATORS_HEAD.title} support={COLLABORATORS_HEAD.support} />
        <Carousel label="Suggested collaborators" noun="collaborator" per={{ desktop: 1, tablet: 1, mobile: 1 }}>
          {COLLABORATORS.map((c) => (
            <CollaboratorCard key={c.name} c={c} />
          ))}
        </Carousel>
      </section>

      {/* 06 Invitations */}
      <section className="cs-band cs-split2" aria-label="Invitations">
        <SideHead label={INVITES_HEAD.label} title={INVITES_HEAD.title} />
        <Carousel label="Your invitations" noun="invitation" per={{ desktop: 1, tablet: 1, mobile: 1 }} className="cs-car--invites">
          {INVITATIONS.map((v) => (
            <InvitationCard key={v.title} v={v} />
          ))}
        </Carousel>
      </section>

      {/* 07 Open calls */}
      <section className="cs-band cs-stack" aria-label="Open calls">
        <SectionHead label={OPEN_HEAD.label} title={OPEN_HEAD.title} support={OPEN_HEAD.support}>
          <div className="cs-sec__links">
            <CardLink href={OPEN_HEAD.yourCalls.href} card>
              {OPEN_HEAD.yourCalls.label}
            </CardLink>
            <CardLink href={OPEN_HEAD.linkHref} card>
              {OPEN_HEAD.link}
            </CardLink>
          </div>
        </SectionHead>
        <Carousel label="Open calls" noun="open calls" per={{ desktop: 3, tablet: 2, mobile: 1 }}>
          {OPEN_CALLS.map((o) => (
            <OpenCallCard key={o.title} o={o} />
          ))}
        </Carousel>
      </section>

      {/* 08 Recent team messages */}
      <section className="cs-band cs-split2" aria-label="Recent team messages">
        <SideHead label={MESSAGES_HEAD.label} title={MESSAGES_HEAD.title} />
        <ul className="cs-msgs2">
          {MESSAGES.map((m) => (
            <li key={m.sender + m.time} className="cs-mp">
              <span className="cs-mp__slot">{m.unread ? <span className="cs-dot" role="img" aria-label="Unread" /> : null}</span>
              <div className="cs-mp__body">
                <p className="cs-label cs-label--muted">{m.project}</p>
                <p className="cs-mp__sender">{m.sender}</p>
                <p className="cs-mp__text">{m.text}</p>
              </div>
              <div className="cs-mp__meta">
                <span className="cs-small">{m.time}</span>
                <Button variant="link" className="cs-tight" iconRight={<IcArrowRight />}>
                  Open conversation
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {/* 09 Start a project */}
      <section className="cs-band" aria-label="Start a project">
        <div className="cs-start">
          <span className="cs-start__rule" aria-hidden="true" />
          <div className="cs-start__content">
            <div className="cs-start__text">
              <p className="cs-label">{START_PANEL.label}</p>
              <h2 className="cs-start__title" data-m="words">
                {START_PANEL.title}
              </h2>
              <p className="cs-start__support">{START_PANEL.support}</p>
            </div>
            <div className="cs-start__actions">
              <Button href={PATHS.start} iconRight={<IcArrowRight />}>
                Start a project
              </Button>
              <Button href={PATHS.collaborators} variant="secondary">
                Explore collaborators
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ Loading state (17974:166533) */

/**
 * Home Loading: the welcome header is live, the four tiles, the three project cards and the three attention rows are skeletons.
 * The bars pulse between two greys (Figma Pulse A and Pulse B).
 */
function HomeSkeleton() {
  return (
    <div className="cs-home" aria-busy="true">
      <Welcome />

      {/* 02 Collaboration overview (loading): Skeleton / Overview Tile */}
      <section className="cs-band" aria-label="Overview, loading">
        <ul className="cs-ov" aria-hidden="true">
          {[0, 1, 2, 3].map((i) => (
            <li key={i} className="cs-sktile">
              <div className="cs-sktile__top">
                <Bar w={150} h={10} />
                <Bar w={56} h={44} />
                <Bar w={230} h={14} />
              </div>
              <Bar w={96} h={14} />
            </li>
          ))}
        </ul>
      </section>

      {/* 03 Continue working (loading): the header is live, the cards are Project Card Skeletons */}
      <section className="cs-band cs-stack" aria-label="Continue working, loading">
        <SectionHead label={WORKSPACE.label} title={WORKSPACE.title} support={WORKSPACE.support}>
          <CardLink href={PATHS.myProjects} card>
            {WORKSPACE.link}
          </CardLink>
        </SectionHead>
        <div className="cs-skcards" aria-hidden="true">
          {[0, 1, 2].map((i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      </section>

      {/* 04 Needs your attention (loading): Skeleton / List Row */}
      <section className="cs-band cs-split2" aria-label="Needs your attention, loading">
        <SideHead label={ATTENTION.label} title={ATTENTION.title} />
        <div className="cs-skatt" aria-hidden="true">
          {[0, 1, 2].map((i) => (
            <div key={i} className="cs-skatt__row">
              <div className="cs-skatt__line">
                <Bar w={300} h={16} />
                <Bar w={150} h={14} />
              </div>
              <div className="cs-skatt__line">
                <Bar w={260} h={12} />
                <Bar w={180} h={12} />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ Empty state (17111:9037) */

/**
 * Home Empty: the page of someone with no projects yet. Welcome, three ways to begin (each opens its journey), the four tiles at zero
 * (each opens the Empty frame of its page) and what you can do here.
 */
export function HomeEmpty() {
  return (
    <div className="cs-home cs-home--empty">
      {/* 01 Welcome */}
      <section className="cs-band cs-welcome" aria-label="Welcome">
        <div className="cs-welcome__text">
          <p className="cs-label">{EMPTY_WELCOME.eyebrow}</p>
          <h1 className="cs-h1" data-m="words">
            {EMPTY_WELCOME.title}
          </h1>
          <p className="cs-welcome__support">{EMPTY_WELCOME.support}</p>
        </div>
      </section>

      {/* 02 Where to begin: Starting Point Cards */}
      <section className="cs-band cs-stack" aria-label="Where to begin">
        <SectionHead label={EMPTY_BEGIN.label} title={EMPTY_BEGIN.title} support={EMPTY_BEGIN.support} />
        <ul className="cs-sps" data-m="stagger">
          {EMPTY_BEGIN.cards.map((c) => (
            <li key={c.n} className="cs-sps__item">
              <Link className="cs-sp" href={c.href}>
                <span className="cs-sp__n">{c.n}</span>
                <span className="cs-sp__bottom">
                  <span className="cs-sp__title">{c.title}</span>
                  <span className="cs-sp__text">{c.text}</span>
                  <span className="cs-sp__action">
                    <span>{c.action}</span>
                    <IcArrowRight />
                  </span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* 03 At a glance: the four tiles at zero */}
      <section className="cs-band cs-stack" aria-label="At a glance">
        <SectionHead label={EMPTY_GLANCE.label} title={EMPTY_GLANCE.title} support={EMPTY_GLANCE.support} />
        <ul className="cs-ov" data-m="stagger">
          {EMPTY_TILES.map((t) => (
            <OverviewTile key={t.n} t={t} />
          ))}
        </ul>
      </section>

      {/* 04 What you can do here */}
      <section className="cs-band cs-split2" aria-label="What you can do here">
        <SideHead label={EMPTY_CAN.label} title={EMPTY_CAN.title} />
        <ul className="cs-cap">
          {EMPTY_CAN.lines.map((l) => (
            <li key={l.title} className="cs-cap__line">
              <p className="cs-cap__title">{l.title}</p>
              <p className="cs-cap__support">{l.support}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
