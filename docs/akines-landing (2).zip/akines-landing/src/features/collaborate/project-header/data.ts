import { PATHS, PROJECT, type Milestone, type Step, type WorkItem } from '../workspace/data';

/**
 * Copy and sample data of 12.25 Project header (switcher, notifications, settings, Create AI, the four modals and their toasts),
 * 12.26 Sample projects (Community Learning Initiative, Mentorship Circle) and the frames added to 12.11 and 12.12
 * (Milestone detail Prototype Review, Work detail 2 and 3, Modal: Add to canvas). Text is word for word from Figma.
 */

/* ------------------------------------------------------------------ the three projects that render the Project header */

export type ProjectSlug = 'career-guidance-for-everyone' | 'community-learning-initiative' | 'mentorship-circle' | 'adire-stories';

export type HeaderProject = {
  slug: ProjectSlug;
  name: string;
  phase: string;
  pulse: string;
  nextMilestone: string;
};

export const CAREER: HeaderProject = {
  slug: 'career-guidance-for-everyone',
  name: PROJECT.name,
  phase: PROJECT.phase,
  pulse: PROJECT.pulse,
  nextMilestone: PROJECT.nextMilestone,
};

/** Adire Stories, the Digital Art project (the fourth card in My projects). It has the full set of project pages, like Career Guidance for Everyone. */
export const ART: HeaderProject = {
  slug: 'adire-stories',
  name: 'Adire Stories',
  phase: 'BUILDING',
  pulse: 'Steady alignment',
  nextMilestone: 'Finish the headwrap portrait.',
};

/* ------------------------------------------------------------------ project switcher (Dropdown: Project switcher) */

export type SwitcherProject = { id: ProjectSlug; name: string; line: string; href: string };

export const SWITCHER_LABEL = 'YOUR PROJECTS';
export const SWITCHER_PROJECTS: SwitcherProject[] = [
  { id: 'career-guidance-for-everyone', name: 'Career Guidance for Everyone', line: 'Building. You are the owner.', href: PATHS.overview },
  { id: 'community-learning-initiative', name: 'Community Learning Initiative', line: 'Planning. Team member.', href: PATHS.communityLearning },
  { id: 'mentorship-circle', name: 'Mentorship Circle', line: 'Planning. You are the owner.', href: PATHS.mentorshipCircle },
  { id: 'adire-stories', name: 'Adire Stories', line: 'Building. You are the owner.', href: PATHS.adireOverview },
];
export const SWITCHER_ALL = { label: 'View all projects', href: PATHS.list };

/* ------------------------------------------------------------------ notifications (Dropdown: Notifications and all read) */

export type NotificationItem = { id: string; title: string; who: string; when: string; action: string; href: string; unread: boolean };

export const NOTIFICATIONS_TITLE = 'Project notifications';
export const NOTIFICATIONS: NotificationItem[] = [
  { id: 'review', title: 'Review requested: Review the student onboarding draft', who: 'Adaeze Okoye', when: '2 hours ago.', action: 'Review work', href: PATHS.draftFile, unread: true },
  { id: 'decision', title: 'Decision awaiting acknowledgement: Choose the onboarding approach', who: 'Ngozi Eze', when: 'Yesterday.', action: 'Review decision', href: PATHS.conversationsDecision, unread: true },
  { id: 'conversation', title: 'New conversation: The onboarding draft is ready', who: 'Tobi Adeyemi', when: 'Today, 10:42 AM.', action: 'Open conversation', href: PATHS.conversations, unread: true },
  { id: 'milestone', title: 'Milestone approaching: First Student Experience', who: 'Reminder', when: '2 days ago.', action: 'View milestone', href: PATHS.milestone, unread: false },
];
export const NOTIFICATION_PREFERENCES = { title: 'Notification preferences', text: 'Choose what reaches you and how often.' };

/* ------------------------------------------------------------------ project settings (Dropdown: Project settings) */

export const SETTINGS = {
  label: 'PROJECT SETTINGS',
  edit: { title: 'Edit project details', text: 'Name, summary and what the team needs.' },
  open: { title: 'Open to new collaborators', text: 'People can find this project and express interest.' },
  archive: { title: 'Archive project', text: 'Moves it out of your active projects. You can restore it.' },
  leave: { title: 'Leave project', text: 'Your access ends. Your work stays on the project record.' },
};

/* ------------------------------------------------------------------ modals and toasts */

export const DEFAULT_DETAILS = {
  name: PROJECT.name,
  summary: PROJECT.description,
  needs: 'Product design, student research and engineering.',
};
export type ProjectDetails = typeof DEFAULT_DETAILS;

export const EDIT_MODAL = {
  eyebrow: 'PROJECT DETAILS',
  title: 'Edit project details',
  description: 'Changes are shown to everyone on the team.',
  name: { label: 'Project name', hint: 'Everyone on the team sees this name.' },
  summary: { label: 'Short summary', hint: 'One or two sentences are enough.' },
  needs: { label: 'What the team needs', hint: 'This helps Akines suggest collaborators.' },
  save: 'Save changes',
  cancel: 'Cancel',
  saved: 'Project details saved.',
};

export const ARCHIVE_MODAL = {
  eyebrow: 'ARCHIVE PROJECT',
  title: 'Archive this project?',
  description: (name: string) => `${name} moves out of your active projects. The team keeps read access and you can restore it at any time.`,
  confirm: 'Archive project',
  keep: 'Keep project',
  done: 'Project archived. You can restore it from My projects.',
};

export const LEAVE_MODAL = {
  eyebrow: 'LEAVE PROJECT',
  title: 'Leave this project?',
  description: 'Your access ends and the team is told. Your work and acknowledgements stay on the project record. If you own the project, you choose a new owner first.',
  confirm: 'Leave project',
  keep: 'Stay on project',
  done: 'You left the project.',
};

export type PreferenceKey = 'review' | 'decisions' | 'conversations' | 'milestones';
export const PREFERENCES_MODAL = {
  eyebrow: 'NOTIFICATIONS',
  title: 'What should reach you?',
  description: (name: string) => `Choose what you hear about for ${name}. Private reflections never appear here.`,
  rows: [
    { key: 'review' as PreferenceKey, label: 'Review requests', text: 'When someone asks you to review work.' },
    { key: 'decisions' as PreferenceKey, label: 'Decisions and agreements', text: 'When something is waiting for your acknowledgement.' },
    { key: 'conversations' as PreferenceKey, label: 'New conversations', text: 'When a conversation starts or someone replies.' },
    { key: 'milestones' as PreferenceKey, label: 'Milestone reminders', text: 'A reminder before a milestone is due.' },
  ],
  save: 'Save preferences',
  cancel: 'Cancel',
  saved: 'Notification preferences saved.',
};
export const DEFAULT_PREFERENCES: Record<PreferenceKey, boolean> = { review: true, decisions: true, conversations: true, milestones: false };

/* ------------------------------------------------------------------ Create AI (project) */

export const AI = {
  title: 'Create AI',
  hello: (name: string) => `${name}.`,
  question: 'How can I help with the project?',
  lead: 'Choose where to start, or ask anything.',
  /** Only the first choice leads anywhere in the design (Thinking, then the Answer); the others only show their selected look. */
  choices: ['Summarise where we are.', 'Prepare the next meeting agenda.', 'What information is missing?', 'Suggest our next steps.', 'Summarise the open decision.'],
  placeholder: 'Ask about this project',
  foot: 'Create AI can get things wrong. Please check anything important.',
  answer:
    'The brief is approved and the team is defining the student experience. The first student experience is due on 28 November. One decision is waiting for acknowledgement and two pieces of work need review. What happens next is for the team to decide.',
  go: [
    { label: 'Review the draft', href: PATHS.draftFile },
    { label: 'Open the decision', href: PATHS.conversationsDecision },
  ],
  /** Figma AFTER_TIMEOUT 2.2 s from Thinking to Answer. */
  thinkingMs: 2200,
};

/* ------------------------------------------------------------------ Modal: Add to canvas and its toast (12.12) */

export const ADD_TO_CANVAS = {
  eyebrow: 'ADD TO CANVAS',
  title: 'What are you adding?',
  description: 'Share a note, a reference or an image with everyone on the team.',
  types: ['Note', 'Reference', 'Image'] as const,
  titleField: { label: 'Title', placeholder: 'Give it a short name', hint: 'Everyone on the team can see it and comment on it.' },
  confirm: 'Add to canvas',
  cancel: 'Cancel',
  done: 'Added to the shared canvas.',
};
export type CanvasAddType = (typeof ADD_TO_CANVAS.types)[number];

/* ------------------------------------------------------------------ Milestone detail (Prototype Review) 17699:72309 */

export const MILESTONE_2 = {
  label: 'MILESTONE',
  title: 'Prototype Review',
  status: 'UPCOMING',
  due: 'Due 12 December',
  description: 'Test the first prototype with five students and record what we learn.',
  criteria: [
    { title: 'Five students are chosen', caption: 'Two schools, ages 14 to 18', status: 'Next' },
    { title: 'The prototype works on a basic phone', caption: 'Tested by Tobi before the sessions', status: 'Next' },
    { title: 'Findings are written up', caption: 'Shared with the whole team', status: 'Next' },
  ] as Step[],
  work: [
    { id: 'plan-sessions', title: 'Plan the student sessions', next: 'Next: agree the questions and who runs each session.', status: 'Not started', member: 'Tobi Adeyemi', phase: 'Planning', action: 'Open work' },
    { id: 'session-guide', title: 'Write the session guide', next: 'Next: turn the interview questions into a short guide.', status: 'Not started', member: 'Ngozi Eze', phase: 'Planning', action: 'Open work' },
  ] as WorkItem[],
  outstanding: [
    { title: 'Choose the schools for the sessions', caption: 'Decision. Not started.' },
    { title: 'Confirm the consent letters', caption: 'Task. Due 5 December.' },
  ],
};

/* ------------------------------------------------------------------ Work detail 2 and 3 (17699:71439, 17699:71874) */

export type WorkEntryData = { initials: string; name: string; time: string; text: string };
export type WorkNote = {
  label: string;
  title: string;
  facts: { label: string; value: string }[];
  workTitle: string;
  workSupport: string;
  doc: { title: string; paragraphs: string[]; screens: string[] };
  commentsSupport: string;
  comments: WorkEntryData[];
  /** Initials of the contributors in the order of the design, with their presence text. */
  contributors: { initials: string; name: string; presence: 'available' | 'working' | 'away' }[];
  history: WorkEntryData[];
  conversation: { title: string; status: string };
};

const RELATED_MILESTONE = 'First Student Experience';

export const WORK_JOURNEY: WorkNote = {
  label: 'RESEARCH NOTE',
  title: 'Map the student journey',
  facts: [
    { label: 'STATUS', value: 'In progress' },
    { label: 'RESPONSIBLE', value: 'Tobi Adeyemi' },
    { label: 'LAST UPDATE', value: 'Yesterday' },
    { label: 'RELATED MILESTONE', value: RELATED_MILESTONE },
  ],
  workTitle: 'The journey, stage by stage.',
  workSupport: 'Version 2. Last edited by Tobi Adeyemi.',
  doc: {
    title: 'Five stages, from curiosity to a first step.',
    paragraphs: [
      'The map follows a student from the first moment they wonder about their future to the day they take one small step.',
      'Each stage lists what the student is thinking, who they ask, and where guidance is missing.',
      'The map comes from the first five interviews and is updated as more students take part.',
    ],
    screens: ['Curious', 'Asking around', 'Comparing paths', 'Choosing', 'First step'],
  },
  commentsSupport: 'Two comments on this note.',
  comments: [
    { initials: 'AO', name: 'Adaeze Okoye', time: 'Yesterday', text: 'The stages match what we heard. Could we show where parents come in?' },
    { initials: 'NE', name: 'Ngozi Eze', time: '3 days ago', text: 'I can add two quotes from the school visit in Kaduna.' },
  ],
  contributors: [
    { initials: 'TA', name: 'Tobi Adeyemi', presence: 'working' },
    { initials: 'NE', name: 'Ngozi Eze', presence: 'away' },
  ],
  history: [
    { initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday', text: 'Updated the map with the third and fourth interviews.' },
    { initials: 'NE', name: 'Ngozi Eze', time: '3 days ago', text: 'Added quotes from the school visit.' },
    { initials: 'TA', name: 'Tobi Adeyemi', time: 'Last week', text: 'Created the note and linked it to the First Student Experience milestone.' },
  ],
  conversation: { title: 'Research findings', status: '3 messages, latest yesterday' },
};

export const WORK_QUESTIONS: WorkNote = {
  label: 'NOTE',
  title: 'Questions students ask about careers',
  facts: [
    { label: 'STATUS', value: 'In progress' },
    { label: 'RESPONSIBLE', value: 'Ngozi Eze' },
    { label: 'LAST UPDATE', value: '3 days ago' },
    { label: 'RELATED MILESTONE', value: RELATED_MILESTONE },
  ],
  workTitle: 'What students asked, in their words.',
  workSupport: 'Version 1. Last edited by Ngozi Eze.',
  doc: {
    title: 'Five questions that came up in every school.',
    paragraphs: [
      'Collected from the first school interviews and added for the onboarding draft.',
      'Students asked what they could study, what jobs exist, and who could help them decide.',
      'Each question is written the way a student said it. Nothing has been reworded to sound formal.',
    ],
    screens: ['What can I study?', 'What jobs are there?', 'Who can I ask?', 'What will it cost?', 'What if I change my mind?'],
  },
  commentsSupport: 'Two comments on this note.',
  comments: [
    { initials: 'AO', name: 'Adaeze Okoye', time: 'Yesterday', text: 'These are the questions the onboarding draft should answer.' },
    { initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday', text: 'I will use these in the interview script for the next round.' },
  ],
  contributors: [
    { initials: 'NE', name: 'Ngozi Eze', presence: 'away' },
    { initials: 'TA', name: 'Tobi Adeyemi', presence: 'working' },
  ],
  history: [
    { initials: 'NE', name: 'Ngozi Eze', time: '3 days ago', text: 'Collected the questions from the first school interviews.' },
    { initials: 'TA', name: 'Tobi Adeyemi', time: 'Yesterday', text: 'Linked the questions to the journey map.' },
    { initials: 'KA', name: 'Kemi Adeyemi', time: 'Last week', text: 'Linked the note to the First Student Experience milestone.' },
  ],
  conversation: { title: 'Research findings', status: '3 messages, latest yesterday' },
};

/* ------------------------------------------------------------------ 12.26 Sample projects */

export type SampleMember = { initials: string; name: string; role: string };
export type SampleProject = {
  header: HeaderProject;
  description: string;
  steps: Step[];
  counts: { n: number; label: string }[];
  brief: { label: string; value: string }[][];
  work: (Pick<WorkItem, 'id' | 'title' | 'next' | 'status' | 'member' | 'phase' | 'action'>)[];
  milestones: Milestone[];
  team: SampleMember[];
  acknowledgements: string[];
  availability: { initials: string; name: string; presence: 'available' | 'working' | 'away' }[];
  conversation: { sender: string; time: string; text: string };
  session: { title: string; when: string; people: string };
  decision: { title: string; status: string };
};

export const COMMUNITY_LEARNING: SampleProject = {
  header: {
    slug: 'community-learning-initiative',
    name: 'Community Learning Initiative',
    phase: 'PLANNING',
    pulse: 'Steady alignment',
    nextMilestone: 'Agree the weekend session format.',
  },
  description: 'A weekend learning programme that pairs local tutors with students who need extra support.',
  steps: [
    { title: 'Project brief approved', caption: 'Completed 20 October', status: 'Completed' },
    { title: 'Weekend session format', caption: 'In progress. Due 30 November', status: 'In progress' },
    { title: 'Tutor onboarding plan', caption: 'Next. Planned for 14 December', status: 'Next' },
  ],
  counts: [
    { n: 1, label: 'Outstanding decision' },
    { n: 2, label: 'Pieces of work to review' },
  ],
  brief: [
    [
      { label: 'PROJECT PURPOSE', value: 'Connect local tutors with students who need extra support.' },
      { label: 'PROBLEM', value: 'Many students cannot afford private lessons at the weekend.' },
    ],
    [
      { label: 'INTENDED AUDIENCE', value: 'Senior secondary students and volunteer tutors.' },
      { label: 'EXPECTED OUTCOME', value: 'A weekend programme running in two community centres.' },
    ],
    [
      { label: 'CURRENT SCOPE', value: 'Tutor recruitment, the session format and a six week pilot.' },
      { label: 'DEFINITION OF SUCCESS', value: '30 students attend at least four sessions.' },
    ],
  ],
  work: [
    { id: 'tutor-list', title: 'Confirm the tutor list', next: 'Next: check the names with Tolu and add any gaps.', status: 'Needs your review', member: 'Tolu Okafor', phase: 'Planning', action: 'Continue working' },
    { id: 'format-proposal', title: 'Respond to the session format proposal', next: 'Next: reply to Funke about the weekend timetable.', status: 'Waiting for your reply', member: 'Funke Adebayo', phase: 'Planning', action: 'Continue working' },
  ],
  milestones: [
    {
      status: 'In progress',
      due: 'Due 30 November',
      title: 'Weekend Session Format',
      description: 'Agree how each weekend session runs, from arrival to the last activity.',
      people: [
        { initials: 'TO', name: 'Tolu Okafor' },
        { initials: 'FA', name: 'Funke Adebayo' },
      ],
    },
    {
      status: 'Upcoming',
      due: 'Due 14 December',
      title: 'Tutor Onboarding Plan',
      description: 'Plan how new tutors are welcomed, briefed and matched with students.',
      people: [
        { initials: 'AY', name: 'Ayo Balogun' },
        { initials: 'TO', name: 'Tolu Okafor' },
      ],
    },
  ],
  team: [
    { initials: 'AY', name: 'Ayo Balogun', role: 'Owner' },
    { initials: 'KA', name: 'Kemi Adeyemi', role: 'Product Designer' },
    { initials: 'TO', name: 'Tolu Okafor', role: 'Volunteer Coordinator' },
    { initials: 'FA', name: 'Funke Adebayo', role: 'Education Researcher' },
  ],
  acknowledgements: ['Tolu acknowledged the project brief. 3 days ago.', 'Funke acknowledged the milestone plan. Last week.'],
  availability: [
    { initials: 'AY', name: 'Ayo Balogun', presence: 'available' },
    { initials: 'TO', name: 'Tolu Okafor', presence: 'working' },
    { initials: 'FA', name: 'Funke Adebayo', presence: 'away' },
  ],
  conversation: { sender: 'Tolu Okafor', time: 'Today, 09:15', text: 'I have drafted the tutor list. Could you check the names?' },
  session: { title: 'Session format workshop', when: 'Thursday, 5:00 PM, 45 minutes', people: 'With Ayo, Tolu and Funke' },
  decision: { title: 'Choose the session length', status: 'Awaiting acknowledgement' },
};

export const MENTORSHIP_CIRCLE: SampleProject = {
  header: {
    slug: 'mentorship-circle',
    name: 'Mentorship Circle',
    phase: 'PLANNING',
    pulse: 'Strong alignment',
    nextMilestone: 'Recruit the first six mentors.',
  },
  description: 'A peer mentoring programme connecting final-year students with early-career professionals.',
  steps: [
    { title: 'Project brief approved', caption: 'Completed 18 October', status: 'Completed' },
    { title: 'Mentor recruitment', caption: 'In progress. Due 27 November', status: 'In progress' },
    { title: 'Mentor guide review', caption: 'Next. Planned for 11 December', status: 'Next' },
  ],
  counts: [
    { n: 1, label: 'Outstanding decision' },
    { n: 1, label: 'Piece of work to review' },
  ],
  brief: [
    [
      { label: 'PROJECT PURPOSE', value: 'Connect final-year students with early-career professionals.' },
      { label: 'PROBLEM', value: 'Final-year students rarely meet people who recently started their careers.' },
    ],
    [
      { label: 'INTENDED AUDIENCE', value: 'Final-year students and professionals in their first five years of work.' },
      { label: 'EXPECTED OUTCOME', value: 'Small mentoring circles that meet every two weeks.' },
    ],
    [
      { label: 'CURRENT SCOPE', value: 'Mentor recruitment, a mentor guide and a first circle of six mentees.' },
      { label: 'DEFINITION OF SUCCESS', value: 'Six mentors complete a full eight week cycle.' },
    ],
  ],
  work: [
    { id: 'signup-form', title: 'Review the mentor sign-up form', next: 'Next: check the questions and leave your comments.', status: 'Needs your review', member: 'Bisi Fashola', phase: 'Planning', action: 'Continue working' },
    { id: 'shortlist', title: 'Respond to the mentor shortlist', next: 'Next: reply to Emeka about the first eight names.', status: 'Waiting for your reply', member: 'Emeka Nwosu', phase: 'Planning', action: 'Continue working' },
  ],
  milestones: [
    {
      status: 'In progress',
      due: 'Due 27 November',
      title: 'Mentor Recruitment',
      description: 'Find and confirm the first six mentors for the pilot circle.',
      people: [
        { initials: 'BF', name: 'Bisi Fashola' },
        { initials: 'EN', name: 'Emeka Nwosu' },
      ],
    },
    {
      status: 'Upcoming',
      due: 'Due 11 December',
      title: 'Mentor Guide',
      description: 'Write the guide that prepares mentors for their first session.',
      people: [
        { initials: 'KA', name: 'Kemi Adeyemi' },
        { initials: 'BF', name: 'Bisi Fashola' },
      ],
    },
  ],
  team: [
    { initials: 'KA', name: 'Kemi Adeyemi', role: 'Owner' },
    { initials: 'BF', name: 'Bisi Fashola', role: 'Mentor Coordinator' },
    { initials: 'EN', name: 'Emeka Nwosu', role: 'Programme Support' },
  ],
  acknowledgements: ['Bisi acknowledged the project brief. 2 days ago.', 'Emeka acknowledged the milestone plan. Last week.'],
  availability: [
    { initials: 'BF', name: 'Bisi Fashola', presence: 'available' },
    { initials: 'EN', name: 'Emeka Nwosu', presence: 'away' },
  ],
  conversation: { sender: 'Bisi Fashola', time: 'Today, 11:20', text: 'I have shared the sign-up form. Could you check the questions?' },
  session: { title: 'Mentor shortlist review', when: 'Friday, 3:00 PM, 30 minutes', people: 'With Bisi and Emeka' },
  decision: { title: 'Choose the circle size', status: 'Awaiting acknowledgement' },
};
