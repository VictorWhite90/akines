'use client';

import { useEffect, useId, useRef, useState } from 'react';
import { ArrowUp, RotateCcw, X } from 'lucide-react';
import { AssistantMark } from '@/components/AssistantMark';
import { Button, Chip, IconButton } from '@/ui';
import { usePresence, useEscape } from '@/ui/internal';
import { useLayout, useReducedMotion } from '@/lib/hooks';
import { AI } from './data';

/**
 * Create AI of the project (Figma 12.25: Overlay: Create AI (project), Thinking, Answer). It is the same panel as the
 * global Create AI (same classes, same place above the launcher) with the project's own opening question.
 * Choosing "Summarise where we are." shows the question, 2.2 s of thinking, then the answer with two buttons. The other four
 * choices only take their selected look. The message field is for show: the design has no reply for typed text and
 * keeps Send disabled.
 */

export type AiView = 'start' | 'thinking' | 'answer';

const stamp = () => `Today, ${new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;

export function ProjectAI({
  open,
  onClose,
  projectName,
  initialView = 'start',
  holdThinking = false,
}: {
  open: boolean;
  onClose: () => void;
  projectName: string;
  /** The state routes open the panel on the Thinking or the Answer frame. */
  initialView?: AiView;
  /** Stay on the Thinking frame (the "state-" route of that frame). */
  holdThinking?: boolean;
}) {
  const layout = useLayout();
  const reduced = useReducedMotion();
  const { mounted, state } = usePresence(open, 220);
  const [view, setView] = useState<AiView>(initialView);
  const [picked, setPicked] = useState<number[]>([]);
  const [openedAt, setOpenedAt] = useState('');
  const [inApp, setInApp] = useState(false);
  const panel = useRef<HTMLElement>(null);
  const body = useRef<HTMLDivElement>(null);
  const first = useRef(true);
  const lead = useId();

  useEscape(open, onClose);

  // every opening starts again (the first one may start on the Thinking or Answer frame)
  useEffect(() => {
    if (!open) return;
    setView(first.current ? initialView : 'start');
    first.current = false;
    setPicked([]);
    setOpenedAt(stamp());
    setInApp(!!document.querySelector('.app'));
    const t = window.setTimeout(() => panel.current?.focus({ preventScroll: true }), 30);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // while the panel is open the global launcher and panel give way to this one (one launcher on screen)
  useEffect(() => {
    if (!open) return;
    document.body.classList.add('ph-ai-on');
    return () => document.body.classList.remove('ph-ai-on');
  }, [open]);

  // Thinking lasts 2.2 s, then the answer (Figma: after a delay, dissolve)
  useEffect(() => {
    if (!open || view !== 'thinking' || holdThinking) return;
    const t = window.setTimeout(() => setView('answer'), AI.thinkingMs);
    return () => window.clearTimeout(t);
  }, [open, view, holdThinking]);

  // keep the newest message in view
  useEffect(() => {
    body.current?.scrollTo({ top: body.current.scrollHeight, behavior: reduced ? 'auto' : 'smooth' });
  }, [view, reduced, mounted]);

  const reset = () => {
    setView('start');
    setPicked([]);
    setOpenedAt(stamp());
  };

  const choose = (i: number) => {
    setPicked((p) => (p.includes(i) ? p : [...p, i]));
    if (i === 0) setView('thinking');
  };

  if (!mounted) return null;
  return (
    <div className="cai ph-ai" data-open={open || undefined} data-layout={layout} data-app={inApp || undefined}>
      <section ref={panel} tabIndex={-1} className="cai-panel" data-state={state} role="dialog" aria-modal="false" aria-label={AI.title}>
        <header className="cai-head">
          <span className="cai-head__mark" aria-hidden="true">
            <AssistantMark colourway="animated-badge-amber" size={32} decorative />
          </span>
          <h2 className="cai-head__title">{AI.title}</h2>
          <div className="cai-head__actions">
            <IconButton label="Start again" size="sm" variant="ghost" onClick={reset}>
              <RotateCcw strokeWidth={1.5} />
            </IconButton>
            <IconButton label="Close" size="sm" variant="ghost" onClick={onClose}>
              <X strokeWidth={1.5} />
            </IconButton>
          </div>
        </header>

        <div className="cai-body" ref={body} aria-live="polite">
          {view === 'start' ? (
            <>
              <p className="cai-stamp">{openedAt}</p>
              <div className="cai-msg cai-msg--bot">
                <p className="cai-hello">{AI.hello(projectName)}</p>
                <h3 className="cai-q">{AI.question}</h3>
                <p className="cai-lead" id={lead}>
                  {AI.lead}
                </p>
                <div className="cai-chips" role="group" aria-labelledby={lead}>
                  {AI.choices.map((c, i) => (
                    <Chip key={c} variant="choice" selected={picked.includes(i)} onClick={() => choose(i)}>
                      {c}
                    </Chip>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="cai-msg cai-msg--me">
                <p>{AI.choices[0]}</p>
              </div>
              <div className="cai-msg cai-msg--bot">
                {view === 'thinking' ? (
                  <p className="cai-typing" role="status" aria-label="Create AI is thinking">
                    <span />
                    <span />
                    <span />
                  </p>
                ) : (
                  <>
                    <p className="cai-text">{AI.answer}</p>
                    <div className="cai-go">
                      {AI.go.map((g) => (
                        <Button key={g.label} size="sm" variant="secondary" arrow="up-right" href={g.href} onClick={onClose}>
                          {g.label}
                        </Button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </>
          )}
        </div>

        <form className="cai-form" onSubmit={(e) => e.preventDefault()}>
          <label className="cai-field">
            <span className="sr-only">Message Create AI</span>
            <input className="cai-input" type="text" readOnly placeholder={AI.placeholder} autoComplete="off" />
            <IconButton label="Send" size="sm" variant="solid" type="submit" disabled>
              <ArrowUp strokeWidth={1.6} />
            </IconButton>
          </label>
          <p className="cai-foot">{AI.foot}</p>
        </form>
      </section>

      <button type="button" className="cai-launcher" aria-label="Close Create AI" aria-expanded={open} onClick={onClose}>
        <AssistantMark colourway="animated-badge-amber" size={56} decorative />
      </button>
    </div>
  );
}
