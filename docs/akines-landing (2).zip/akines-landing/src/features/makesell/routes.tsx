import { placeholderRoutes } from '@/features/placeholder-routes';

/** Section 13 MAKE & SELL: placeholder pages (My Studio, My Journal, My Store). */
export const routes = placeholderRoutes('make-sell');
