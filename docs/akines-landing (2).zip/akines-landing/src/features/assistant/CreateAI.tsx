'use client';

/**
 * Create AI: the Akines assistant. A floating Amber badge (the "Animated gradient, Amber badge" colourway of the
 * assistant mark) at the bottom right of every page, signed in or not.
 *  - The first time someone visits on a given day, the panel opens by itself (light theme, no dimming, no focus steal).
 *  - It opens with the "How would you like to connect today?" survey from Community Home and answers with "For you today".
 *  - The chat box is always there: ask about anything. Answers come from engine.ts (live model in the artifact, built-in
 *    guide elsewhere).
 * Mounted once per build: src/app/layout.tsx (Next.js) and src/artifact/main.tsx (preview artifact).
 */
import { useCallback, useEffect, useId, useMemo, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { ArrowUp, ChevronRight, RotateCcw, X } from 'lucide-react';
import { AssistantMark } from '@/components/AssistantMark';
import { Button, Chip, IconButton, Tooltip } from '@/ui';
import { Avatar } from '@/ui/Chip';
import { usePresence } from '@/ui/internal';
import { rememberNext } from '@/app-shell/AppShell';
import { useNav, usePath } from '@/lib/nav';
import { useSession } from '@/lib/auth';
import { useLayout, useReducedMotion } from '@/lib/hooks';
import { AV, INTENTIONS, P, type Action } from '@/features/community/data';
import { openModal } from '@/features/community/store';
import { askCreateAI, type Turn } from './engine';
import type { Go } from './knowledge';
import { ProjectChatView, START_PATH, useProjectChat } from './project-chat';
import { CollabChatView, EXPLORE_PATH, OPEN_PATH, useCollabChat } from './collab-chat';

type Msg =
  | { id: number; role: 'assistant'; kind: 'survey' }
  | { id: number; role: 'user'; kind: 'text'; text: string }
  | { id: number; role: 'assistant'; kind: 'text'; text: string; go?: Go[]; note?: string; pending?: boolean }
  | { id: number; role: 'assistant'; kind: 'result'; intention: number };

const DAY_KEY = 'akines.createai.day.v1';
let dayMemory: string | null = null;
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const readDay = () => {
  try {
    return window.localStorage.getItem(DAY_KEY) ?? dayMemory;
  } catch {
    return dayMemory;
  }
};
const writeDay = (v: string) => {
  dayMemory = v;
  try {
    window.localStorage.setItem(DAY_KEY, v);
  } catch {
    /* storage blocked: the memory copy keeps it to one pop-up per page load */
  }
};

/** Pages where the panel never opens by itself (it would cover the form the person is filling in). The launcher still shows. */
const QUIET = (path: string) => path === '/sign-in' || path.startsWith('/join') || path.startsWith('/design');
/** The team Workspaces (12.15, 12.16) and the meeting screens (12.43) fill the whole window and have no launcher. */
const WORKSPACE_PATH = /^\/collaborate\/my-projects\/[^/]+\/(workspace|meet)(\/|$)/;

const greeting = (first: string | null) => {
  const h = new Date().getHours();
  const part = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  return first ? `${part}, ${first}.` : `${part}.`;
};
const stamp = () => {
  const d = new Date();
  return `Today, ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
};

let uid = 0;
const nextId = () => ++uid;

export function CreateAI() {
  const path = usePath();
  const nav = useNav();
  const session = useSession();
  const layout = useLayout();
  const reduced = useReducedMotion();
  const panelId = useId();

  const [open, setOpen] = useState(false);
  const { mounted, state } = usePresence(open, 220);
  const [inApp, setInApp] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>(() => [{ id: nextId(), role: 'assistant', kind: 'survey' }]);
  const [picked, setPicked] = useState(0);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [openedAt, setOpenedAt] = useState('');
  const bodyRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const ctl = useRef<AbortController | null>(null);
  const autoDone = useRef(false);
  const noted = useRef(false);
  // "Start a project" inside the thread (Figma 16.3): its own steps replace the conversation until the person starts again
  const project = useProjectChat();
  // "Explore collaborators" and "Open a project" inside the thread (Figma 16.4, 16.5): same idea, one journey at a time
  const collab = useCollabChat();

  const who = useMemo(() => ({ name: session.signedIn ? session.first : null, signedIn: session.signedIn }), [session.signedIn, session.first]);

  // Is the signed-in app frame (with its bottom bar on tablet and mobile) on screen? The launcher then sits above that bar.
  useEffect(() => {
    setInApp(!!document.querySelector('.app'));
  }, [path, session.signedIn]);

  const show = useCallback((byPerson: boolean) => {
    setOpenedAt(stamp());
    setOpen(true);
    if (byPerson && layout === 'desktop') window.setTimeout(() => inputRef.current?.focus({ preventScroll: true }), 60);
  }, [layout]);
  const hide = useCallback(() => {
    setOpen(false);
    window.setTimeout(() => launcherRef.current?.focus({ preventScroll: true }), 0);
  }, []);

  // First visit of the day: open once, a moment after the page has settled.
  useEffect(() => {
    if (autoDone.current || QUIET(path)) return;
    if (readDay() === today()) {
      autoDone.current = true;
      return;
    }
    const t = window.setTimeout(() => {
      if (autoDone.current) return;
      autoDone.current = true;
      writeDay(today());
      show(false);
    }, 1600);
    return () => window.clearTimeout(t);
  }, [path, show]);

  // keep the newest message in view
  useEffect(() => {
    const el = bodyRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: reduced ? 'auto' : 'smooth' });
  }, [msgs, reduced, mounted]);

  useEffect(() => () => ctl.current?.abort(), []);

  const reset = () => {
    ctl.current?.abort();
    setBusy(false);
    setPicked(0);
    setDraft('');
    noted.current = false;
    project.stop();
    collab.stop();
    setOpenedAt(stamp());
    setMsgs([{ id: nextId(), role: 'assistant', kind: 'survey' }]);
  };

  const choose = (i: number) => {
    if (busy) return;
    setPicked(i);
    setMsgs((m) => [...m, { id: nextId(), role: 'user', kind: 'text', text: INTENTIONS[i - 1].label }, { id: nextId(), role: 'assistant', kind: 'result', intention: i }]);
  };

  const run = (a: Action) => {
    hide();
    if ('to' in a) {
      nav.push(a.to); // a signed-out visitor is sent to the sign-in panel by the app frame, which remembers the page
      return;
    }
    if (!session.signedIn) {
      rememberNext(P.home);
      nav.push('/sign-in');
      return;
    }
    openModal(a.modal);
    // the Community overlays live in the signed-in frame; from the landing page go there first
    if (!document.querySelector('.app')) nav.push(P.home);
  };

  const go = (g: Go) => {
    if (g.path === START_PATH) {
      collab.stop();
      project.begin(); // the project is started here, in the chat, not on the web page
      return;
    }
    if (g.path === EXPLORE_PATH || g.path === OPEN_PATH) {
      project.stop();
      collab.begin(g.path === EXPLORE_PATH ? 'explore' : 'open'); // one question, then one button, in the chat
      return;
    }
    hide();
    nav.push(g.path);
  };

  // a free question typed while a project is being started: the thread goes back to the open chat and answers it
  const askFromProject = (text: string) => {
    project.stop();
    void send(text);
  };
  const askFromCollab = (text: string) => {
    collab.stop();
    void send(text);
  };

  const history = (list: Msg[]): Turn[] => {
    const out: Turn[] = [];
    for (const m of list) {
      if (m.kind === 'text' && !('pending' in m && m.pending)) out.push({ role: m.role, content: m.text });
      else if (m.kind === 'result') {
        const it = INTENTIONS[m.intention - 1];
        out.push({ role: 'assistant', content: `${it.headline} Suggestions: ${it.items.map((x) => x.title).join('; ')}.` });
      }
    }
    return out;
  };

  const send = async (raw: string) => {
    const text = raw.trim();
    if (!text || busy) return;
    const userMsg: Msg = { id: nextId(), role: 'user', kind: 'text', text };
    const replyId = nextId();
    const turns = [...history(msgs), { role: 'user' as const, content: text }];
    setDraft('');
    setBusy(true);
    setMsgs((m) => [...m, userMsg, { id: replyId, role: 'assistant', kind: 'text', text: '', pending: true }]);
    const c = new AbortController();
    ctl.current = c;
    try {
      const a = await askCreateAI(turns, who, {
        signal: c.signal,
        onText: (visible) => setMsgs((m) => m.map((x) => (x.id === replyId && x.kind === 'text' ? { ...x, text: visible } : x))),
      });
      // the "built-in guide" note is shown once per conversation, not under every reply
      let note = a.note;
      if (note && !a.live) {
        if (noted.current) note = undefined;
        else noted.current = true;
      }
      setMsgs((m) => m.map((x) => (x.id === replyId ? { id: replyId, role: 'assistant', kind: 'text', text: a.text, go: a.go, note } : x)));
    } catch (e) {
      if ((e as { code?: string }).code === 'cancelled') setMsgs((m) => m.filter((x) => x.id !== replyId));
      else setMsgs((m) => m.map((x) => (x.id === replyId ? { id: replyId, role: 'assistant', kind: 'text', text: 'Something went wrong on my side. Please try again.' } : x)));
    } finally {
      setBusy(false);
      if (ctl.current === c) ctl.current = null;
    }
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    void send(draft);
  };
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape' && open) {
      e.stopPropagation();
      hide();
    }
  };

  if (WORKSPACE_PATH.test(path)) return null;

  return (
    <div className="cai" data-open={open || undefined} data-layout={layout} data-app={inApp || undefined}>
      {mounted ? (
        <section
          id={panelId}
          className="cai-panel"
          data-state={state}
          data-flow={project.active || undefined}
          role="dialog"
          aria-modal="false"
          aria-label="Create AI"
          onKeyDown={onKey}
        >
          <header className="cai-head">
            <span className="cai-head__mark" aria-hidden="true">
              <AssistantMark colourway="animated-badge-amber" size={32} decorative />
            </span>
            <h2 className="cai-head__title">Create AI</h2>
            <div className="cai-head__actions">
              <IconButton label="Start again" size="sm" variant="ghost" onClick={reset}>
                <RotateCcw strokeWidth={1.5} />
              </IconButton>
              <IconButton label="Close" size="sm" variant="ghost" onClick={hide}>
                <X strokeWidth={1.5} />
              </IconButton>
            </div>
          </header>

          {project.active ? (
            <ProjectChatView chat={project} hide={hide} onAsk={askFromProject} />
          ) : collab.active ? (
            <CollabChatView chat={collab} hide={hide} onAsk={askFromCollab} />
          ) : (
            <>
              <div className="cai-body" ref={bodyRef} aria-live="polite">
                <p className="cai-stamp">{openedAt}</p>
                {msgs.map((m) => {
                  if (m.kind === 'survey') {
                    return (
                      <div className="cai-msg cai-msg--bot" key={m.id}>
                        <p className="cai-hello">{greeting(who.name)}</p>
                        <h3 className="cai-q">How would you like to connect today?</h3>
                        <p className="cai-lead" id={`${panelId}-lead`}>Choose what feels right for you.</p>
                        <div className="cai-chips" role="group" aria-labelledby={`${panelId}-lead`}>
                          {INTENTIONS.map((it, i) => (
                            <Chip key={it.label} variant="choice" selected={picked === i + 1} disabled={busy} onClick={() => choose(i + 1)}>
                              {it.label}
                            </Chip>
                          ))}
                        </div>
                      </div>
                    );
                  }
                  if (m.kind === 'result') {
                    const it = INTENTIONS[m.intention - 1];
                    return (
                      <div className="cai-msg cai-msg--bot cai-result" key={m.id}>
                        <p className="cai-label">For you today</p>
                        <h3 className="cai-result__head">{it.headline}</h3>
                        <p className="cai-result__because">Because you chose: {it.label}</p>
                        <ul className="cai-rows">
                          {it.items.map((r) => (
                            <li key={r.title}>
                              <button type="button" className="cai-row" onClick={() => run(r.act)}>
                                {r.avatar ? <Avatar name={r.title} src={AV(r.avatar)} size={36} /> : <span className="cai-row__dot" aria-hidden="true" />}
                                <span className="cai-row__txt">
                                  <span className="cai-row__title">{r.title}</span>
                                  <span className="cai-row__text">{r.text}</span>
                                </span>
                                <span className="cai-row__meta">{r.meta}</span>
                                <ChevronRight className="cai-row__chev" strokeWidth={1.5} aria-hidden="true" />
                              </button>
                            </li>
                          ))}
                        </ul>
                        {!session.signedIn ? <p className="cai-note">Sign in to open these.</p> : null}
                        <Button variant="link" size="sm" onClick={() => run({ to: P.home })}>
                          Show everything
                        </Button>
                      </div>
                    );
                  }
                  if (m.role === 'user') {
                    return (
                      <div className="cai-msg cai-msg--me" key={m.id}>
                        <p>{m.text}</p>
                      </div>
                    );
                  }
                  return (
                    <div className="cai-msg cai-msg--bot" key={m.id}>
                      {m.pending && !m.text ? (
                        <p className="cai-typing" role="status" aria-label="Create AI is thinking">
                          <span />
                          <span />
                          <span />
                        </p>
                      ) : (
                        <p className="cai-text">{m.text}</p>
                      )}
                      {m.go && m.go.length ? (
                        <div className="cai-go">
                          {m.go.map((g) => (
                            <Button key={g.path} size="sm" variant="secondary" arrow="up-right" onClick={() => go(g)}>
                              {g.label}
                            </Button>
                          ))}
                        </div>
                      ) : null}
                      {m.note ? <p className="cai-note">{m.note}</p> : null}
                    </div>
                  );
                })}
              </div>

              <form className="cai-form" onSubmit={onSubmit}>
                <label className="cai-field">
                  <span className="sr-only">Message Create AI</span>
                  <input
                    ref={inputRef}
                    className="cai-input"
                    type="text"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder="Ask Create AI anything"
                    autoComplete="off"
                    enterKeyHint="send"
                    maxLength={600}
                  />
                  <IconButton label="Send" size="sm" variant="solid" type="submit" disabled={!draft.trim() || busy}>
                    <ArrowUp strokeWidth={1.6} />
                  </IconButton>
                </label>
                <p className="cai-foot">Create AI can get things wrong. Please check anything important.</p>
              </form>
            </>
          )}
        </section>
      ) : null}

      <Tooltip label="Create AI" side="top" describe={false}>
        <button
          ref={launcherRef}
          type="button"
          className="cai-launcher"
          aria-label="Create AI"
          aria-expanded={open}
          aria-controls={mounted ? panelId : undefined}
          onClick={() => (open ? hide() : show(true))}
        >
          <AssistantMark colourway="animated-badge-amber" size={56} decorative />
        </button>
      </Tooltip>
    </div>
  );
}
