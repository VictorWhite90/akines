/** Data of the static sign-in panel frames (routes /sign-in/state-*). Kept out of the client module so the route registry can read it on the server. */
import type { SignInPreset } from './SignInPanel';

export const SIGN_IN_FRAMES: { slug: SignInPreset; figma: string }[] = [
  { slug: 'focus', figma: 'Focus' },
  { slug: 'missing', figma: 'Missing' },
  { slug: 'invalid', figma: 'Invalid' },
  { slug: 'loading', figma: 'Loading' },
  { slug: 'success', figma: 'Success' },
];
