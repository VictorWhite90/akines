'use client';

import { useSyncExternalStore } from 'react';
import { DEFAULT_DETAILS, DEFAULT_PREFERENCES, NOTIFICATIONS, type PreferenceKey, type ProjectDetails } from './data';

/**
 * State of the project header that must survive a page change inside one visit: the saved project details, the
 * "open to new collaborators" switch, the notification preferences and which notifications were read.
 * Small external store, same pattern as workspace/store.ts. Nothing is written anywhere else.
 */
type State = {
  details: ProjectDetails;
  open: boolean;
  prefs: Record<PreferenceKey, boolean>;
  unread: string[];
};

let state: State = {
  details: DEFAULT_DETAILS,
  open: true,
  prefs: DEFAULT_PREFERENCES,
  unread: NOTIFICATIONS.filter((n) => n.unread).map((n) => n.id),
};
const listeners = new Set<() => void>();
const set = (patch: Partial<State>) => {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
};
const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
};
const snapshot = () => state;

export function useHeaderState() {
  return useSyncExternalStore(subscribe, snapshot, snapshot);
}

export const headerStore = {
  get: () => state,
  saveDetails: (details: ProjectDetails) => set({ details }),
  setOpen: (open: boolean) => set({ open }),
  savePrefs: (prefs: Record<PreferenceKey, boolean>) => set({ prefs }),
  markRead: (id: string) => set({ unread: state.unread.filter((u) => u !== id) }),
  markAllRead: () => set({ unread: [] }),
};

/**
 * Page links that open a part of the header: "Edit project details" on the Overview opens the Edit modal and
 * "Open project settings" opens the settings menu (Figma: the same overlays as the header buttons).
 */
export type HeaderRequest = 'edit' | 'settings';
const requests = new Set<(r: HeaderRequest) => void>();
export const headerUi = {
  open: (r: HeaderRequest) => requests.forEach((l) => l(r)),
  subscribe: (l: (r: HeaderRequest) => void) => {
    requests.add(l);
    return () => {
      requests.delete(l);
    };
  },
};
