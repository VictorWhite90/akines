'use client';

import './opportunities.css';
import { Link } from '@/lib/nav';
import { IconCardArrow } from '../projects/ui';
import type { Contribution } from './data';

/**
 * Contribution Record (Figma set 17710:19992, 1384 x 340): type with the amber dot and the date on one line, serif title, context,
 * a hairline, three meta fields (the third, Acknowledgement, is hidden when there is none) and the "View related work" call.
 * States: Default (17710:19895), Hover (17710:19920), Pressed (17710:19944), Focus (17710:19968): same as the Opportunity Card.
 * A record without a destination (Final credit) has no reaction in Figma, so it renders without the hover, press and focus states.
 */
export function ContributionRecord({ item }: { item: Contribution }) {
  const body = (
    <>
      <div className="co-rec__top">
        <div className="dsc-stage">
          <i aria-hidden="true" />
          <span className="dsc-stage__name">{item.type}</span>
        </div>
        <span className="co-rec__date">{item.date}</span>
      </div>
      <div className="co-rec__group">
        <h2 className="co-rec__title">{item.title}</h2>
        <p className="co-rec__context">{item.context}</p>
      </div>
      <div className="co-rec__divider" />
      <div className="co-rec__meta">
        <div className="co-rec__field">
          <span className="dsc-label">Related work</span>
          <p className="co-rec__value co-rec__value--work">{item.relatedWork}</p>
        </div>
        <div className="co-rec__field">
          <span className="dsc-label">Project</span>
          <p className="co-rec__value co-rec__value--project">{item.project}</p>
        </div>
        {item.acknowledgement ? (
          <div className="co-rec__field">
            <span className="dsc-label">Acknowledgement</span>
            <p className="co-rec__value">{item.acknowledgement}</p>
          </div>
        ) : null}
      </div>
      <span className="op-card__cta">
        View related work
        <IconCardArrow />
      </span>
    </>
  );
  return item.href ? (
    <Link href={item.href} className="co-rec" aria-label={`${item.title}, ${item.type}, ${item.date}. View related work`}>
      {body}
    </Link>
  ) : (
    <div className="co-rec co-rec--static">{body}</div>
  );
}
