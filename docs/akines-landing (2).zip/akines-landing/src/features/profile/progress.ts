/**
 * Profile completion: what Akines asks of a member to match them well (plain data, no React).
 * The profile page is not designed yet, so every open step leads to the "Complete your profile" placeholder page.
 * The `done` flags are sample data for review; the real values come from the account once the profile exists.
 * Order: the open steps in the order we want them done, then the finished ones.
 */
export type ProfileIconName = 'sparkles' | 'pen' | 'fingerprint' | 'image' | 'camera' | 'pin' | 'mail' | 'users';

export type ProfileTask = { id: string; title: string; text: string; icon: ProfileIconName; done: boolean };

export const PROFILE_TASKS: ProfileTask[] = [
  { id: 'make', title: 'Tell us what you make', text: 'Choose your crafts and interests', icon: 'sparkles', done: false },
  { id: 'intro', title: 'Write a short intro', text: 'Say who you are in a few lines', icon: 'pen', done: false },
  { id: 'dna', title: 'Take the Creative DNA check-in', text: 'So we can match you with care', icon: 'fingerprint', done: false },
  { id: 'work', title: 'Add a work sample', text: 'Show what you are working on', icon: 'image', done: false },
  { id: 'photo', title: 'Add a profile photo', text: 'Help people recognise you', icon: 'camera', done: true },
  { id: 'location', title: 'Add your location', text: 'Find people and rooms near you', icon: 'pin', done: true },
  { id: 'email', title: 'Verify your email', text: 'Build trust with other members', icon: 'mail', done: true },
  { id: 'connect', title: 'Set how you like to connect', text: 'Choose your intentions', icon: 'users', done: true },
];

export const profilePercent = (tasks: ProfileTask[] = PROFILE_TASKS) =>
  tasks.length ? Math.round((tasks.filter((t) => t.done).length / tasks.length) * 100) : 100;

export const PROFILE_COPY = {
  pill: 'Complete profile',
  title: 'Finish your profile',
  left: (n: number) => (n === 1 ? '1 step left. A fuller profile means better matches.' : `${n} steps left. A fuller profile means better matches.`),
  todo: 'Left to do',
  done: 'Completed',
  doneNote: 'Completed',
};
