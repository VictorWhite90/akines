#!/usr/bin/env node
// Builds the single-file preview (the Claude artifact) from the same source as the Next.js app.
//   node scripts/build-preview.mjs [outDir=dist-preview]
// Output: <outDir>/index.html (full page for local tests), <outDir>/artifact.html (page content for the Artifact tool),
//         <outDir>/images/** (copied from public/images). Fonts (Alice, Manrope latin) are inlined as data URIs.
// Local test: `python3 -m http.server -d <outDir> 8123` then open http://localhost:8123/#connect-banter (hash = path, "/" -> "-").
import { build } from 'esbuild';
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outDir = resolve(process.argv[2] || 'dist-preview');
const work = resolve(outDir, '.work');
rmSync(outDir, { recursive: true, force: true });
mkdirSync(work, { recursive: true });

const swap = {
  '@/lib/nav': 'src/lib/nav.hash.tsx',
  '@/lib/assets': 'src/lib/assets.preview.ts',
  'next/image': 'src/artifact/shims/next-image.tsx',
};
const swapPlugin = {
  name: 'preview-swaps',
  setup(b) {
    b.onResolve({ filter: /^(@\/lib\/nav|@\/lib\/assets|next\/image)$/ }, (args) => ({ path: resolve(root, swap[args.path]) }));
  },
};

const result = await build({
  entryPoints: [resolve(root, 'src/artifact/main.tsx')],
  outdir: work,
  bundle: true,
  format: 'iife',
  minify: true,
  target: 'es2020',
  jsx: 'automatic',
  sourcemap: false,
  legalComments: 'none',
  tsconfig: resolve(root, 'tsconfig.json'),
  plugins: [swapPlugin],
  define: { 'process.env.NODE_ENV': '"production"' },
  loader: { '.woff2': 'dataurl', '.woff': 'dataurl' },
  logLevel: 'warning',
  metafile: true,
});

const js = readFileSync(resolve(work, 'main.js'), 'utf8').replace(/<\/script/gi, '<\\/script');
const css = readFileSync(resolve(work, 'main.css'), 'utf8');

const font = (family, weight, file) => {
  const b64 = readFileSync(resolve(root, 'node_modules/@fontsource', file)).toString('base64');
  return `@font-face{font-family:'${family}';font-style:normal;font-weight:${weight};font-display:swap;src:url(data:font/woff2;base64,${b64}) format('woff2')}`;
};
const fonts = [
  font('Alice', 400, 'alice/files/alice-latin-400-normal.woff2'),
  font('Manrope', 400, 'manrope/files/manrope-latin-400-normal.woff2'),
  font('Manrope', 500, 'manrope/files/manrope-latin-500-normal.woff2'),
  font('Manrope', 600, 'manrope/files/manrope-latin-600-normal.woff2'),
].join('\n');

// Same inline script as src/app/layout.tsx: adds the `js` class before first paint and `hero-ready` when the hero photo has loaded.
const headScript = `(function(){var d=document,h=d.documentElement;h.classList.add('js');var r=function(){h.classList.add('hero-ready')};d.addEventListener('load',function(e){var t=e.target;if(t&&t.classList&&(t.classList.contains('hero__img')||t.classList.contains('nf__img')))r()},true);d.addEventListener('error',function(e){var t=e.target;if(t&&t.classList&&(t.classList.contains('hero__img')||t.classList.contains('nf__img')))r()},true);setTimeout(r,4000)})()`;

const title = 'Akines Landing Page';
const body = `<style>${fonts}\n${css}</style>
<script>${headScript}</script>
<div id="root"></div>
<script>${js}</script>`;

writeFileSync(resolve(outDir, 'artifact.html'), `<title>${title}</title>\n${body}\n`);
writeFileSync(
  resolve(outDir, 'index.html'),
  `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>${title}</title></head><body>${body}</body></html>\n`,
);
cpSync(resolve(root, 'public/images'), resolve(outDir, 'images'), { recursive: true });
rmSync(work, { recursive: true, force: true });

const kb = (n) => (n / 1024).toFixed(0) + ' KB';
console.log(`preview built: ${outDir}\n  js ${kb(js.length)}, css ${kb(css.length)}, fonts ${kb(fonts.length)}, artifact.html ${kb(readFileSync(resolve(outDir, 'artifact.html')).length)}`);
