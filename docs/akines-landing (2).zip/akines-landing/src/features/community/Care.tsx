'use client';

/** Care and support (Figma 10.4): Quiet company 17106:8135, Reflect privately 17106:8277, Find professional support 17106:8440. */
import { Button } from '@/ui';
import './community.css';
import { P } from './data';
import { openModal, setCommunity, useCommunity } from './store';
import { Avatar, IAlert, IArrow, ICheckCircle, ILock, TextLink } from './ui';

const Back = () => <TextLink href={P.home}>Back to Community Home</TextLink>;

export function QuietCompany() {
  return (
    <div className="ch-page ch-page--bleed">
      <div className="ch-care">
        <p className="ch-label">Quiet company</p>
        <h1 className="ch-care__title" data-m="words">
          You are in quiet company.
        </h1>
        <p className="ch-care__desc">Four others are here. No one is expected to speak. Stay as long as you like.</p>
        <div className="ch-care__present" aria-label="Four people are here">
          {(['tunde', 'ngozi', 'folake', 'chuka'] as const).map((k) => (
            <Avatar key={k} k={k} size={80} ring="accent" />
          ))}
        </div>
        <div className="ch-care__acts">
          <Button iconRight={<IArrow />} href={P.home}>
            Leave quietly
          </Button>
          <TextLink href={P.reflect}>Write a private note instead</TextLink>
        </div>
      </div>
    </div>
  );
}

export function ReflectPrivately() {
  const s = useCommunity();
  return (
    <div className="ch-page">
      <div className="ch-wide">
        <Back />
        <p className="ch-label">Wellbeing · Reflect privately</p>
        <h1 className="ch-wide__title" data-m="words">
          What would make today feel a little lighter?
        </h1>
        <p className="ch-wide__desc">Write whatever comes to mind. There is no right answer.</p>
        <p className="ch-line">
          <ILock />
          <span>Only you can see this. It is never shared, and nothing is sent.</span>
        </p>
        {s.reflectSaved ? (
          <div className="ch-acts ch-acts--col" aria-live="polite">
            <p className="ch-confirm">
              <ICheckCircle />
              <span>Saved. Only you can see this.</span>
            </p>
            <TextLink onClick={() => setCommunity({ reflectSaved: false, reflectText: '' })}>Write another</TextLink>
            <Button variant="secondary" href={P.home}>
              Back to Community Home
            </Button>
          </div>
        ) : (
          <>
            <textarea
              className="ch-field"
              aria-label="Your private note"
              placeholder="Start writing here."
              value={s.reflectText}
              onChange={(e) => setCommunity({ reflectText: e.target.value })}
            />
            <div className="ch-acts">
              <Button iconRight={<IArrow />} onClick={() => setCommunity({ reflectSaved: true })}>
                Save privately
              </Button>
              <Button variant="secondary" href={P.home}>
                Back to Community Home
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

const OPTIONS = [
  ['A counsellor or therapist', 'Someone trained to listen, who you can see regularly.'],
  ['Your doctor or a local clinic', 'A good first step if you are not sure where to start.'],
  ['A helpline in your country', 'Often free and confidential. Search for one near you.'],
] as const;

export function ProfessionalSupport() {
  return (
    <div className="ch-page">
      <div className="ch-wide">
        <Back />
        <p className="ch-label">Wellbeing · Professional support</p>
        <h1 className="ch-wide__title" data-m="words">
          Find professional support
        </h1>
        <p className="ch-wide__desc">Talking with a trained professional can help, whatever the reason. Akines keeps this page private and does not share it with anyone.</p>
        <div className="ch-opts" data-m="stagger">
          {OPTIONS.map(([t, d]) => (
            <div className="ch-opt" key={t}>
              <span className="ch-opt__title">{t}</span>
              <span className="ch-opt__desc">{d}</span>
            </div>
          ))}
        </div>
        <p className="ch-alert" role="note">
          <IAlert s={20} />
          <span>If you or someone near you may be in immediate danger, contact your local emergency number now.</span>
        </p>
        <div className="ch-acts">
          <Button iconRight={<IArrow />} onClick={() => openModal('trust')}>
            Message someone I trust
          </Button>
          <Button variant="secondary" href={P.home}>
            Back to Community Home
          </Button>
        </div>
      </div>
    </div>
  );
}
