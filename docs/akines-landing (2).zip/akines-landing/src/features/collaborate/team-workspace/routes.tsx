import type { RouteDef } from '@/routes.types';
import { artRoutes } from './art/routes';
import { R_PATHS } from './data';
import { ResearchWorkspace } from './research/ResearchWorkspace';

const nav = { page: 'collaborate', tab: 'My Projects' } as const;
const def = (path: string, component: RouteDef['component']): RouteDef => ({ path, title: 'Research Workspace', shell: 'bare', nav, component });

const Main = () => <ResearchWorkspace />;
const Saving = () => <ResearchWorkspace state="saving" />;
const CouldNotSave = () => <ResearchWorkspace state="couldNotSave" />;
const CollaboratorOffline = () => <ResearchWorkspace state="collaboratorOffline" />;
const ConnectionLost = () => <ResearchWorkspace state="connectionLost" />;
const Reconnecting = () => <ResearchWorkspace state="reconnecting" />;
const ViewOnly = () => <ResearchWorkspace state="viewOnly" />;
const VersionHistory = () => <ResearchWorkspace state="versionHistory" />;
const CommentReply = () => <ResearchWorkspace initialReply />;

/**
 * 12.15 Research Workspace and 12.16 Digital Art Workspace. The "state-" routes are the Figma state frames; the project
 * menu, People and access, heading style, brush library and colour picker are overlays (React state, no routes). The save status
 * popover opens from the status pill on both workspaces; "state-could-not-save" is the failed save frame, which opens with it.
 */
export const routes: RouteDef[] = [
  def(R_PATHS.main, Main),
  def(R_PATHS.saving, Saving),
  def(R_PATHS.couldNotSave, CouldNotSave),
  def(R_PATHS.collaboratorOffline, CollaboratorOffline),
  def(R_PATHS.connectionLost, ConnectionLost),
  def(R_PATHS.reconnecting, Reconnecting),
  def(R_PATHS.viewOnly, ViewOnly),
  def(R_PATHS.versionHistory, VersionHistory),
  def(R_PATHS.commentReply, CommentReply),
  ...artRoutes,
];
