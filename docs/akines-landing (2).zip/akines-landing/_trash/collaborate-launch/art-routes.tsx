import type { RouteDef } from '@/routes.types';
import { PROJECT_PATH } from '../workspace/data';
import { ART_PATH } from '../workspace/project';
import { LP } from './data';
import { routes } from './routes';

/**
 * Routes of the Adire Stories project pages of this feature (the same pages as Career Guidance for Everyone, with the Adire Stories data).
 * Mirrored: Launch (Readiness, the page the Project navigation opens), Materials, Attribution, Ready to share and Outcome. They are
 * the steps of one journey and all read the Adire Stories copy. The Confirm attribution and Share project modals and their toasts open
 * inside Attribution and Ready to share, so they work on Adire Stories without a route of their own. Not mirrored: the "state-" frames
 * (Not ready and the overlay frames), which no control reaches.
 */
const MIRRORED = new Set([LP.readiness, LP.materials, LP.attribution, LP.ready, LP.outcome]);

export const artRoutes: RouteDef[] = routes.filter((r) => MIRRORED.has(r.path)).map((r) => ({ ...r, path: r.path.replace(PROJECT_PATH, ART_PATH) }));
