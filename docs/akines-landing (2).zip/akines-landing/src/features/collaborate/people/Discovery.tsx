'use client';

import { useState } from 'react';
import { Button, toast } from '@/ui';
import { EmptyCard, Heading } from './cc-ui';
import { INTENTIONS, PEOPLE, PROJECT, R, RECOMMENDED, skillsLine, type PersonId } from './data';
import { CcOverlays, type OverlayId } from './overlays';
import { PersonCard } from './PersonCard';
import { ccStore, useCc } from './store';

function DiscoveryView({ forceEmpty }: { forceEmpty?: boolean }) {
  const { dismissed, discoverySaved, prefs, intention } = useCc();
  const [ov, setOv] = useState<OverlayId | null>(null);
  // whose Ask Akines why drawer or Not relevant modal is open (set when it opens, so the exit animation keeps its text)
  const [ovPerson, setOvPerson] = useState<PersonId>('amina');
  const open = (kind: OverlayId, id: PersonId) => {
    setOvPerson(id);
    setOv(kind);
  };
  const list = forceEmpty ? [] : RECOMMENDED.filter((id) => !dismissed.includes(id));
  const intentionLabel = INTENTIONS.find((i) => i.id === intention)?.label ?? 'For a project';

  const save = (id: PersonId) => {
    const undo = ccStore.save(id);
    toast.show({ message: 'Saved to your collaborators.', actionLabel: 'Undo', onAction: undo });
  };

  const context = [
    { label: 'Project', value: PROJECT.name },
    { label: 'Skills needed', value: skillsLine(prefs) },
    { label: 'Project stage', value: PROJECT.stage },
    { label: 'Matching intention', value: intentionLabel },
  ];

  return (
    <>
      <div className="cc-page cc-disc">
        <div className="cc-disc__head">
          <Heading
            className="cc-disc__heading"
            eyebrow="People to create with"
            title="The right people can change an idea."
            support="Explore people whose skills, experience and way of working may complement your project."
          />
          <div className="cc-disc__links" data-m="up">
            <Button variant="link" href={R.saved}>
              Saved collaborators
            </Button>
            <Button variant="link" href={R.requests}>
              Introduction requests
            </Button>
          </div>
        </div>

        <section className="cc-context" aria-label="Matching context" data-m="up">
          {context.map((c) => (
            <div className="cc-context__item" key={c.label}>
              <p className="cc-eyebrow">{c.label}</p>
              <p className="cc-context__value">{c.value}</p>
            </div>
          ))}
          <Button variant="secondary" onClick={() => setOv('prefs')}>
            Adjust matching
          </Button>
        </section>

        {list.length ? (
          <div className="cc-grid" data-m="stagger">
            {list.map((id) => {
              const isSaved = discoverySaved.includes(id);
              return (
                <PersonCard
                  key={id}
                  person={PEOPLE[id]}
                  saved={isSaved}
                  saveLabel={isSaved ? 'Saved' : 'Save for later'}
                  onSave={isSaved ? undefined : () => save(id)}
                  onNotRelevant={() => open('notrelevant', id)}
                  onAsk={() => open('ask', id)}
                />
              );
            })}
          </div>
        ) : (
          <EmptyCard
            title="We’re still finding the right people."
            text="Try adjusting your matching preferences to discover more collaborators."
            textWidth={760}
            action={
              <div>
                <Button onClick={() => setOv('prefs')}>Adjust preferences</Button>
              </div>
            }
          />
        )}
      </div>
      <CcOverlays open={ov} onClose={() => setOv(null)} person={ovPerson} from="cards" />
    </>
  );
}

/** B3 Discovery (Figma 17215:15502; after Not relevant 17215:15928). Route /collaborate/collaborators/discovery. */
export default function Discovery() {
  return <DiscoveryView />;
}

/** B3 No recommendations (Figma 17215:16279). No trigger in the prototype, so it has its own route. */
export function DiscoveryEmpty() {
  return <DiscoveryView forceEmpty />;
}
