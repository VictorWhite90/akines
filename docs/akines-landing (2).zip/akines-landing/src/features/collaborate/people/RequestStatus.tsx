'use client';

import { useEffect, useState } from 'react';
import { Avatar, Button, Modal, Skeleton, toast } from '@/ui';
import { asset } from '@/lib/assets';
import { useNav } from '@/lib/nav';
import { ApplicationTimeline } from '../applications/shared';
import { LOADING_MS } from '../projects/store';
import { BackLink, EmptyCard, Heading, StatusPill } from './cc-ui';
import { PEOPLE, PROJECT, R, REQUEST_PAGES, personRoutes, requestRoute, type PersonId, type RequestStatus } from './data';
import { ccStore } from './store';

/**
 * 12.47 INTRODUCTION REQUEST (Figma V2 Desktop, "12.47 - Collaborate / Introduction request / ..."): where one introduction request stands.
 * One page per request: Pending (Amina 17974:158093, Kunle 17974:165381, Funmi 17974:165496, Chidi 17974:165611), Accepted (Amina 17974:158358)
 * and Not now (Amina 17974:158630, Chidi 17974:165726, the one B12 links to). The card, the timeline ("Where your request stands", the
 * Application Timeline of 12.44) and the sharing notice follow the stage. Withdraw request (Pending only) opens the Withdraw request modal
 * (17974:164019, per person clones 17974:168211, 168228, 168245); Withdraw request then returns to B12 without that request and shows the
 * toast with Undo (17974:164045 and the per person ones).
 */
export function RequestStatusScreen({ id, stage = 'pending' }: { id: PersonId; stage?: RequestStatus }) {
  const nav = useNav();
  const [asking, setAsking] = useState(false);
  const person = PEOPLE[id];
  const page = REQUEST_PAGES[id]?.[stage];
  if (!page) return null;
  const routes = personRoutes(id);

  const withdraw = () => {
    const undo = ccStore.withdraw(page.key);
    setAsking(false);
    // everyone lands on B12; Undo puts the request back, and takes the ones B12 does not list (Kunle, Funmi, Chidi) back to their Pending page
    nav.push(R.requests);
    toast.show({
      message: 'Request withdrawn.',
      actionLabel: 'Undo',
      onAction: () => {
        undo();
        if (id !== 'amina') nav.push(requestRoute(id, stage));
      },
    });
  };

  return (
    <>
      <div className="cc-page cc-req">
        <div className="cc-req__col">
          <BackLink href={R.requests}>Back to introduction requests</BackLink>
          <Heading eyebrow="Your introduction" title={page.headline} support={page.support} />

          <section className="cc-rq" aria-label="Your request" data-m="up">
            <div className="cc-rq__row">
              {/* Figma 64 px round portrait */}
              <Avatar name={person.name} src={asset(person.photo)} size={72} style={{ width: 64, height: 64 }} />
              <div className="cc-rq__info">
                <h2 className="cc-rq__name">{person.name}</h2>
                <p className="cc-rq__project">{`${page.role} · For ${PROJECT.name}`}</p>
              </div>
              <StatusPill status={stage} />
            </div>
            <hr className="cc-rule" />
            <p className="cc-rq__sent">{page.sent}</p>
            <p className="cc-eyebrow">Your note</p>
            <p className="cc-rq__note">{page.note}</p>
          </section>

          <div data-m="up">
            <ApplicationTimeline heading="Where your request stands" steps={page.steps} trailingLine={page.steps[page.steps.length - 1].state !== 'ended'} />
          </div>

          <aside className="cc-notice" data-m="up">
            <h2 className="cc-notice__title">{page.notice.title}</h2>
            <p className="cc-notice__text">{page.notice.text}</p>
          </aside>

          <div className="cc-actions" data-m="up">
            {stage === 'accepted' ? (
              // no one to one thread exists in Conversations, so there is no destination in Figma: left plain
              <Button arrow="up-right">Start a conversation</Button>
            ) : null}
            {stage === 'notnow' ? (
              <Button href={R.discovery} arrow="up-right">
                Find other collaborators
              </Button>
            ) : null}
            <Button variant="secondary" href={routes.profile}>
              View profile
            </Button>
            {stage === 'pending' ? (
              <Button variant="link" onClick={() => setAsking(true)}>
                Withdraw request
              </Button>
            ) : null}
          </div>
        </div>
      </div>

      <Modal
        open={asking}
        onClose={() => setAsking(false)}
        width={640}
        className="cc-wd"
        eyebrow="Withdraw request"
        title="Withdraw your request?"
        description="The request is removed from their list. You can send a new request later."
        footer={
          <>
            <Button onClick={withdraw}>Withdraw request</Button>
            <Button variant="link" onClick={() => setAsking(false)}>
              Keep my request
            </Button>
          </>
        }
      />
    </>
  );
}

/* ------------------------------------------------------------------ Loading (17974:163829) and Could not load (17974:163934) */

function SkeletonRequestCard() {
  return (
    <div className="cc-sk-card" aria-hidden="true">
      <div className="cc-sk-card__top">
        <Skeleton width={56} height={56} radius={28} />
        <div className="cc-sk-card__text">
          <Skeleton width={200} height={22} radius={0} />
          <Skeleton width={140} height={12} radius={0} />
        </div>
      </div>
      <div className="cc-sk-row">
        <Skeleton width={120} height={36} radius={0} />
        <Skeleton width={140} height={36} radius={0} />
        <Skeleton width={110} height={36} radius={0} />
      </div>
      <hr className="cc-rule cc-sk-card__rule" />
      <div className="cc-sk-card__fields">
        <div className="cc-sk-field">
          <Skeleton width={110} height={10} radius={0} />
          <Skeleton width={240} height={16} radius={0} />
        </div>
        <div className="cc-sk-field cc-sk-field--grow">
          <Skeleton width={80} height={10} radius={0} />
          <Skeleton width="100%" height={16} radius={0} />
        </div>
      </div>
      <div className="cc-sk-row cc-sk-card__actions">
        <Skeleton width={81} height={36} radius={0} />
        <Skeleton width={89} height={36} radius={0} />
      </div>
    </div>
  );
}

export type RequestState = 'loading' | 'error';

/**
 * The two states with no trigger of their own in the prototype, so they have routes (.../amina/state-loading, .../amina/state-error).
 * Loading shows for 2.5 s and then the Pending page of Amina (Figma AFTER_TIMEOUT 2.5); Could not load: Try again goes to Loading,
 * Back to requests to B12.
 */
export function RequestStateScreen({ initial }: { initial: RequestState }) {
  const nav = useNav();
  const [phase, setPhase] = useState<RequestState>(initial);

  useEffect(() => {
    if (phase !== 'loading') return;
    const t = window.setTimeout(() => nav.replace(requestRoute('amina')), LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  return (
    <div className="cc-page cc-req">
      <div className="cc-req__col">
        <BackLink href={R.requests}>Back to introduction requests</BackLink>
        {phase === 'loading' ? (
          <div className="cc-sk" aria-busy="true" aria-label="Loading your request">
            <div className="cc-sk-head" aria-hidden="true">
              <Skeleton className="cc-sk--head" width={220} height={28} radius={0} />
              <Skeleton className="cc-sk--head" width={440} height={16} radius={0} />
            </div>
            <SkeletonRequestCard />
            <SkeletonRequestCard />
          </div>
        ) : (
          <div role="alert">
            <EmptyCard
              title="We could not load this request."
              text="Check your connection and try again. Your note and your request are safe."
              textWidth={760}
              action={
                <div className="cc-actions cc-rq-err__actions">
                  <Button onClick={() => setPhase('loading')}>Try again</Button>
                  <Button variant="secondary" href={R.requests}>
                    Back to requests
                  </Button>
                </div>
              }
            />
          </div>
        )}
      </div>
    </div>
  );
}
