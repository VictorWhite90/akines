'use client';

/**
 * 12.7 Member profile: owner (Figma 17322:20439), Team member (17322:20832), Limited profile (17322:32790),
 * Loading (17322:32887) and Could not load (17322:33029).
 * Photos: Ngozi Eze is Figma 17322:20445 (image hash cb6ee846), Obinna Adeyemi is 17322:20838 (hash 36319e61).
 */
import { useEffect, useState } from 'react';
import { Button } from '@/ui';
import { useNav } from '@/lib/nav';
import { asset } from '@/lib/assets';
import { LOADING_MS, takeFirstVisit, toggleSaved, useSavedState } from './store';
import { personBySlug, projectBySlug } from './data';
import { DetailItem, FactList, FactRow, InterestPanel, MatchBox, PrivacyPanel, Section, SkelSection, SkelSidePanels, TagList } from './parts';
import { Bar, BackLink, CardLink, StatePanel } from './ui';

export type ProfileVariant = 'limited' | 'loading' | 'error';
type Phase = 'loading' | 'ready' | 'error';

function ProfileSkeleton() {
  return (
    <div className="dsc-page">
      <div className="dsc-detail" aria-busy="true" aria-label="Loading the profile">
        <div className="dsc-detail__main" aria-hidden="true">
          <Bar w={190} h={14} />
          <span className="dsc-spacer" style={{ height: 36 }} />
          <div className="dsc-profile-head dsc-profile-head--skeleton">
            <Bar w={280} h={352} className="dsc-profile-head__portrait" />
            <div className="dsc-skel-profile-info">
              <Bar w={140} h={12} />
              <Bar w={320} h={56} />
              <Bar w={190} h={16} />
              <div className="dsc-skel-profile-info__lines">
                <Bar w={540} h={18} />
                <Bar w={500} h={18} />
                <Bar w={360} h={18} />
              </div>
              <div className="dsc-skel-chips">
                {[0, 1, 2].map((i) => (
                  <Bar key={i} w={120} h={36} r={999} />
                ))}
              </div>
            </div>
          </div>
          <SkelSection>
            <Bar w={140} h={12} />
            <Bar w="100%" h={16} />
            <Bar w={700} h={16} />
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            {[0, 1, 2].map((i) => (
              <div className="dsc-skel-item" key={i}>
                <Bar w={340} h={22} />
                <Bar w={420} h={14} />
              </div>
            ))}
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            <div className="dsc-skel-chips">
              {[0, 1, 2, 3].map((i) => (
                <Bar key={i} w={120} h={36} r={999} />
              ))}
            </div>
          </SkelSection>
          <SkelSection>
            <Bar w={140} h={12} />
            {[0, 1, 2, 3].map((i) => (
              <div className="dsc-skel-row" key={i}>
                <Bar w={208} h={14} />
                <Bar w={400} h={16} />
              </div>
            ))}
          </SkelSection>
        </div>
        <SkelSidePanels rows={false} />
      </div>
    </div>
  );
}

export function MemberProfileScreen({ slug, variant }: { slug: string; variant?: ProfileVariant }) {
  const person = personBySlug(slug)!;
  const project = projectBySlug(person.projectSlug)!;
  const nav = useNav();
  const { session } = useSavedState();
  const saved = session.includes(project.slug);
  const [phase, setPhase] = useState<Phase>(() => (variant === 'loading' ? 'loading' : variant === 'error' ? 'error' : takeFirstVisit('profile') ? 'loading' : 'ready'));

  useEffect(() => {
    if (phase !== 'loading') return;
    const t = window.setTimeout(() => {
      if (variant === 'loading') nav.replace(`/collaborate/members/${slug}`);
      else setPhase('ready');
    }, LOADING_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, variant, slug]);

  const backHref = `/collaborate/projects/${project.slug}`;
  const backLabel = `Back to ${project.title}`;

  if (phase === 'loading') return <ProfileSkeleton />;

  if (phase === 'error') {
    return (
      <div className="dsc-page">
        <div className="dsc-stack">
          <BackLink href={backHref}>{backLabel}</BackLink>
          <StatePanel pair role="alert" headline="We could not load this profile." support="Check your connection and try again. Your saved projects are safe.">
            <Button onClick={() => setPhase('loading')}>Try again</Button>
            <Button variant="secondary" href={backHref}>
              Back to project
            </Button>
          </StatePanel>
        </div>
      </div>
    );
  }

  const limited = variant === 'limited';
  const label = person.kind === 'owner' ? 'Project owner' : 'Team member';

  return (
    <div className="dsc-page">
      <div className="dsc-detail">
        <div className="dsc-detail__main">
          <BackLink href={backHref}>{backLabel}</BackLink>
          <span className="dsc-spacer" style={{ height: 36 }} />
          <header className="dsc-profile-head">
            {limited ? (
              <div className="dsc-profile-head__portrait dsc-profile-head__portrait--initials" aria-hidden="true">
                {person.name
                  .split(' ')
                  .map((w) => w[0])
                  .join('')}
              </div>
            ) : (
              <img className="dsc-profile-head__portrait" src={asset(person.portrait)} alt={person.name} width={280} height={352} loading="lazy" decoding="async" />
            )}
            <div className="dsc-profile-head__info">
              <p className="dsc-profile-head__label">
                <i aria-hidden="true" />
                {label}
              </p>
              <h1 className="dsc-h1 dsc-h1--detail" data-m="words">
                {person.name}
              </h1>
              <p className="dsc-profile-head__role">{limited ? person.role : `${person.role}, ${person.place}`}</p>
              <p className="dsc-profile-head__intro">{limited ? person.limitedIntro : person.headline}</p>
              <TagList tags={person.keySkills} label="Key skills" />
            </div>
          </header>

          {limited ? null : (
            <>
              <Section title="About">
                <p className="dsc-body">{person.about}</p>
              </Section>
              <Section title="Experience">
                <div className="dsc-items">
                  {person.experience.map((x) => (
                    <DetailItem key={x.title} title={x.title} detail={x.detail} />
                  ))}
                </div>
              </Section>
            </>
          )}
          <Section title="Skills">
            <TagList tags={person.skills} label="Skills" />
          </Section>
          {limited ? null : (
            <>
              <Section title="Interests">
                <TagList tags={person.interests} label="Interests" />
              </Section>
              <Section title="Working preferences">
                <FactList>
                  {person.preferences.map((x) => (
                    <FactRow key={x.label} label={x.label} value={x.value} />
                  ))}
                </FactList>
              </Section>
              <Section title="Contributions">
                <div className="dsc-items">
                  {person.contributions.map((x) => (
                    <DetailItem key={x.title} title={x.title} detail={x.detail} />
                  ))}
                </div>
              </Section>
            </>
          )}
          <Section title="On this project">
            <MatchBox sentence={person.onProject}>
              <CardLink href={backHref} arrow>
                View the project
              </CardLink>
            </MatchBox>
          </Section>
        </div>

        <aside className="dsc-detail__side" aria-label="Project actions">
          <InterestPanel interestHref={`/collaborate/projects/${project.slug}/interest`} saved={saved} onSave={() => toggleSaved(project.slug)} />
          <PrivacyPanel text={limited ? person.seeingLimited : person.seeing} />
        </aside>
      </div>
    </div>
  );
}

export const MemberProfile = ({ slug }: { slug: string }) => <MemberProfileScreen slug={slug} />;
