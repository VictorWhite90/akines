/**
 * Sample data of 12.22 Agreements (Figma frames Agreements 17729:97710, Empty 17729:99565, Stage detail 17729:109768,
 * Formal agreement 17729:114062, Acknowledged 17729:115681, Modal:Create agreement 17729:120702, Toast:Agreement created 17729:120681,
 * Modal:Suggest a change 17729:121142, Toast:Change suggested 17729:120688, Modal:Acknowledge agreement 17729:121194,
 * Toast:Agreement acknowledged 17729:120695). Copy is taken from the frames word for word.
 * One sample workspace exists: "Career Guidance for Everyone".
 */
import { PATHS } from '../workspace/data';

/* ---------------------------------------------------------------- paths */

export const AP = {
  overview: PATHS.agreements,
  empty: `${PATHS.agreements}/state-empty`,
  roles: `${PATHS.agreements}/roles`,
  formal: `${PATHS.agreements}/formal-agreement`,
  acknowledged: `${PATHS.agreements}/state-acknowledged`,
  /** The overlay frames have no trigger of their own: each renders the page that opens it with the overlay showing. */
  createModal: `${PATHS.agreements}/state-create-agreement`,
  created: `${PATHS.agreements}/state-agreement-created`,
  suggestModal: `${PATHS.agreements}/roles/state-suggest-a-change`,
  suggested: `${PATHS.agreements}/roles/state-change-suggested`,
  acknowledgeModal: `${PATHS.agreements}/roles/state-acknowledge-agreement`,
  acknowledgedToast: `${PATHS.agreements}/state-agreement-acknowledged`,
} as const;

/* ---------------------------------------------------------------- statuses */

/** Agreement Status 17729:92365: a dot and the status in medium 13. */
export const STATUSES = ['Not started', 'In progress', 'Awaiting acknowledgement', 'Acknowledged', 'Needs review'] as const;
export type AgreementStatus = (typeof STATUSES)[number];

/* ---------------------------------------------------------------- page header */

export const HEAD = {
  label: 'AGREEMENTS',
  title: "Make sure everyone understands what they're building together.",
  lead: 'Agree on the expectations, contributions and responsibilities that guide your collaboration.',
  create: 'Create agreement',
  history: 'View contribution history',
};

/** A Metric Card of the dashboard look: label, number, caption and, where the design shows the amber dot (Tone=Attention), `dot`. */
export type MetricData = { label: string; value: string; caption: string; dot?: boolean };

/** The three metric cards of the overview (they have no destination in the design). */
export const OVERVIEW_METRICS: MetricData[] = [
  { label: 'ACKNOWLEDGED', value: '1/6', caption: 'stages' },
  { label: 'AWAITING', value: '1', caption: 'stage', dot: true },
  { label: 'NOT STARTED', value: '3', caption: 'stages' },
];

/** The ids of the cards a metric card scrolls to (the DashCard id or the id of the block). */
export const CARD = { stages: 'ag-stages', acks: 'ag-acks', terms: 'ag-terms', versions: 'ag-versions', templates: 'ag-templates' } as const;

export const STAGES_HEAD = { label: 'AGREEMENT STAGES', text: 'Take the stages one at a time. Each one builds on the last.' };

export type Stage = {
  id: string;
  /** "STAGE 01" */
  label: string;
  title: string;
  text: string;
  note: string;
  status: AgreementStatus;
  /** Only Roles and Formal Agreement open a page in the design. */
  href?: string;
};

export const STAGES: Stage[] = [
  { id: 'intent', label: 'STAGE 01', title: 'Intent', text: 'Why the project exists and what each member hopes to achieve.', note: 'Acknowledged by all four members.', status: 'Acknowledged' },
  { id: 'roles', label: 'STAGE 02', title: 'Roles', text: 'Project owner, member roles, responsibilities and decision-making rights.', note: '2 of 4 members have acknowledged. Waiting on Tobi and Ngozi.', status: 'Awaiting acknowledgement', href: AP.roles },
  { id: 'contributions', label: 'STAGE 03', title: 'Contributions', text: 'Expected contributions, skills provided and agreed commitments.', note: 'Being drafted. Not shared for acknowledgement yet.', status: 'In progress' },
  { id: 'ownership', label: 'STAGE 04', title: 'Ownership', text: 'Idea ownership, intellectual property, attribution and shared work.', note: 'Nothing to acknowledge yet.', status: 'Not started' },
  { id: 'revenue', label: 'STAGE 05', title: 'Revenue', text: 'Revenue sharing, commercial outcomes and financial responsibilities, where relevant.', note: 'Nothing to acknowledge yet.', status: 'Not started' },
  { id: 'formal', label: 'STAGE 06', title: 'Formal Agreement', text: 'Optional legal templates for serious commercial projects.', note: 'Optional. A draft is not automatically legally binding.', status: 'Not started', href: AP.formal },
];

/* ---------------------------------------------------------------- empty */

export const EMPTY = {
  title: 'Start with shared understanding.',
  text: 'Clarify expectations, roles and contributions before substantial work begins.',
};

/* ---------------------------------------------------------------- the six steps of the stage tracker */

export type StepState = 'done' | 'doing' | 'next';

/** The six steps of the "Agreement stages" card of the stage pages (the card names the last one "Formal agreement"). */
const STEPS = [
  { when: 'STAGE 01', title: 'Intent' },
  { when: 'STAGE 02', title: 'Roles' },
  { when: 'STAGE 03', title: 'Contributions' },
  { when: 'STAGE 04', title: 'Ownership' },
  { when: 'STAGE 05', title: 'Revenue' },
  { when: 'STAGE 06', title: 'Formal agreement' },
];

/** The steps with their state (done, current, next), for StageTracker. */
export const stepsAt = (states: StepState[]) => STEPS.map((s, i) => ({ ...s, state: states[i] }));

/* ---------------------------------------------------------------- stage detail (Roles) */

export const MEMBERS: { initials: string; name: string; role: string }[] = [
  { initials: 'KA', name: 'Kemi Adeyemi (you)', role: 'Product Designer, project owner' },
  { initials: 'AO', name: 'Adaeze Okoye', role: 'Product Design, supporting' },
  { initials: 'TA', name: 'Tobi Adeyemi', role: 'Software Engineer' },
  { initials: 'NE', name: 'Ngozi Eze', role: 'Career Researcher' },
];

export const TERMS = [
  'Kemi Adeyemi is the project owner and keeps the project brief up to date.',
  'Adaeze Okoye supports product design and reviews design work before it is shared.',
  'Tobi Adeyemi builds the prototype and tells the team early when something is hard to do.',
  'Ngozi Eze leads the career research and shares what she learns with the whole team.',
  'Decisions that change the project are discussed in Decisions. The project owner confirms the outcome once everyone has had their say.',
];

/** A member tile of the Acknowledgements card: `when` is the date of the acknowledgement or "Not yet". */
export type Ack = { initials: string; name: string; role: string; done: boolean; when: string };

export type Version = { title: string; text: string; current?: boolean; link?: string };

/** A metric card of a stage page and the id of the card it scrolls to. */
export type StageMetric = MetricData & { to: string };

export type RolesPage = {
  back: string;
  label: string;
  title: string;
  lead: string;
  /** Acknowledged shows this line instead of the Acknowledge button. */
  done?: string;
  metrics: StageMetric[];
  stepStates: StepState[];
  stagesLabel: string;
  acksLabel: string;
  /** The big number and the line after it ("2", "of 4 members have acknowledged version 2"). */
  acksCount: number;
  acksText: string;
  acks: Ack[];
  termsLabel: string;
  versionsLabel: string;
  versions: Version[];
};

const TUE_3_NOV = 'Tue 3 Nov';
const WED_4_NOV = 'Wed 4 Nov';
const NOT_YET = 'Not yet';

const ack = (i: number, done: boolean, when: string): Ack => ({ ...MEMBERS[i], done, when });

const V1: Version = { title: 'Version 1', text: 'Tuesday 20 October 2026. Acknowledged by all four members.', link: 'View version 1' };

const ROLES_BASE = {
  back: 'Back to agreements',
  label: 'STAGE 02 OF 6',
  title: 'Roles and responsibilities',
  lead: 'Who leads the project, what each member looks after and who makes which decisions.',
  stagesLabel: 'AGREEMENT STAGES',
  acksLabel: 'ACKNOWLEDGEMENTS',
  acksText: 'of 4 members have acknowledged version 2',
  termsLabel: 'PROPOSED TERMS',
  versionsLabel: 'VERSION HISTORY',
};

/** Stage detail 17729:109768: version 2 waits for Tobi and Ngozi. */
export const ROLES: RolesPage = {
  ...ROLES_BASE,
  metrics: [
    { label: 'ACKNOWLEDGED', value: '2/4', caption: 'members', dot: true, to: CARD.acks },
    { label: 'VERSION', value: '2', caption: 'current', to: CARD.versions },
    { label: 'STAGE', value: '2/6', caption: 'of six stages', to: CARD.stages },
    { label: 'TERMS', value: '5', caption: 'proposed', to: CARD.terms },
  ],
  stepStates: ['done', 'doing', 'next', 'next', 'next', 'next'],
  acksCount: 2,
  acks: [ack(0, true, TUE_3_NOV), ack(1, true, TUE_3_NOV), ack(2, false, NOT_YET), ack(3, false, NOT_YET)],
  versions: [{ title: 'Version 2', text: 'Tuesday 3 November 2026. Proposed by Kemi Adeyemi. Added decision-making rights.', current: true }, V1],
};

/** Acknowledged 17729:115681: everyone has acknowledged version 2, so the current stage is Contributions. */
export const ROLES_ACKNOWLEDGED: RolesPage = {
  ...ROLES_BASE,
  done: 'Everyone has acknowledged version 2.',
  metrics: [
    { label: 'ACKNOWLEDGED', value: '4/4', caption: 'members', to: CARD.acks },
    { label: 'VERSION', value: '2', caption: 'current', to: CARD.versions },
    { label: 'STAGE', value: '2/6', caption: 'of six stages', to: CARD.stages },
    { label: 'TERMS', value: '5', caption: 'agreed', to: CARD.terms },
  ],
  stepStates: ['done', 'done', 'doing', 'next', 'next', 'next'],
  acksCount: 4,
  acks: [ack(0, true, TUE_3_NOV), ack(1, true, TUE_3_NOV), ack(2, true, WED_4_NOV), ack(3, true, WED_4_NOV)],
  versions: [{ title: 'Version 2', text: 'Tuesday 3 November 2026. Proposed by Kemi Adeyemi. Acknowledged by all four members.', current: true }, V1],
};

/* ---------------------------------------------------------------- formal agreement */

export const FORMAL = {
  back: 'Back to agreements',
  label: 'STAGE 06 OF 6',
  title: 'Formal Agreement',
  lead: 'Optional legal templates for serious commercial projects.',
  /** DRAFTS opens the Create agreement modal; the other two scroll to a card of the page. */
  metrics: [
    { label: 'DRAFTS', value: '0', caption: 'not started' },
    { label: 'TEMPLATES', value: '3', caption: 'to choose from', to: CARD.templates },
    { label: 'STAGE', value: '6/6', caption: 'optional', to: CARD.stages },
  ] as (MetricData & { to?: string })[],
  stagesLabel: 'AGREEMENT STAGES',
  /** Intent is done, the last stage is the current one. */
  stepStates: ['done', 'next', 'next', 'next', 'next', 'doing'] as StepState[],
  noteTitle: 'A draft is not automatically legally binding.',
  noteText: 'Drafting an agreement on Akines helps your team agree in plain language. It does not, on its own, make anything legally binding. For a binding agreement, speak to a qualified legal adviser.',
  templatesLabel: 'LEGAL TEMPLATES (OPTIONAL)',
  templateTag: 'OPTIONAL',
  templates: [
    { title: 'Collaboration agreement', text: 'How the team works together on a commercial project.' },
    { title: 'Intellectual property agreement', text: 'Who owns what the team creates, and how it is credited.' },
    { title: 'Revenue sharing agreement', text: 'How income from the project is shared between members.' },
  ],
  templatesNote: 'Nothing here changes ownership automatically. The team decides first, and everyone acknowledges.',
};

/* ---------------------------------------------------------------- modals and toasts */

export const CREATE_STAGES = ['Intent', 'Roles', 'Contributions', 'Ownership', 'Revenue', 'Formal Agreement'] as const;
export type CreateStage = (typeof CREATE_STAGES)[number];

export const MODAL = {
  create: {
    eyebrow: 'NEW AGREEMENT',
    title: 'What would you like to agree?',
    description: 'Choose a stage, then name the agreement and describe it.',
    stageLabel: 'Stage',
    stageHint: 'Agreements build up one stage at a time.',
    titleLabel: 'Agreement title',
    titleHint: 'A short, plain name.',
    titlePlaceholder: 'For example, Who owns what we make',
    descLabel: 'Description',
    descHint: 'Optional. Keep it short and clear.',
    descPlaceholder: 'What should this agreement help everyone understand?',
    submit: 'Create agreement',
  },
  suggest: {
    eyebrow: 'SUGGEST A CHANGE',
    title: 'What would you change?',
    description: 'Your team will see your suggestion. Nothing changes until everyone has acknowledged it.',
    changeLabel: 'What to change',
    changeHint: 'Describe the change in a sentence or two.',
    changePlaceholder: 'For example, Ngozi also leads the interview questions',
    whyLabel: 'Why',
    whyHint: 'Optional, but it helps the team decide.',
    whyPlaceholder: 'Help the team understand the reason',
    submit: 'Suggest change',
  },
  acknowledge: {
    eyebrow: 'ACKNOWLEDGE',
    title: 'Acknowledge this agreement?',
    description: 'Take a moment to read the summary before you confirm.',
    summaryLabel: 'ROLES AND RESPONSIBILITIES, VERSION 2',
    summary: [
      'Kemi Adeyemi leads the project as owner.',
      'Adaeze Okoye supports product design.',
      'Tobi Adeyemi builds the prototype.',
      'Ngozi Eze leads the career research.',
      'Decisions are discussed together. The owner confirms the outcome.',
    ],
    note: 'Acknowledging records that you have read and understood this version. It does not change who owns the work. You can suggest a change at any time.',
    submit: 'Acknowledge',
  },
  cancel: 'Cancel',
};

export const TOASTS = {
  created: 'Agreement created. Your team can review it now.',
  suggested: 'Change suggested. Your team will be asked to review it.',
  acknowledged: 'Agreement acknowledged. Your team can see it.',
};

/* ---------------------------------------------------------------- Adire Stories */

/**
 * The same Agreements page for Adire Stories (the Digital Art project): the same shapes, counts and order as the Career data above,
 * with the Adire people and domain. Only the Agreements page is mirrored; the stage pages (Roles, Formal Agreement, Acknowledged), the
 * empty page and the overlay frames are not, so no stage card or context link has a destination there. The three modals keep
 * working and have Adire copy. Copy that names neither a person nor the domain (the page header, the metric cards, the toasts) is shared.
 */

/** Everything the Agreements page and its modals read from the data, per project. */
export type AgreementsData = {
  stages: Stage[];
  modal: typeof MODAL;
};

export const CAREER_AGREEMENTS: AgreementsData = { stages: STAGES, modal: MODAL };

/** The stage cards of Adire Stories: same ids, labels, titles and statuses, and no `href`. */
export const ART_STAGES: Stage[] = [
  STAGES[0],
  { ...STAGES[1], note: '2 of 4 members have acknowledged. Waiting on Ayo and Yusuf.', href: undefined },
  STAGES[2],
  { ...STAGES[3], text: 'Who owns each plate, credits for the dyers, attribution and shared work.' },
  { ...STAGES[4], text: 'Print sales, exhibition costs and how any income is shared, where relevant.' },
  { ...STAGES[5], text: 'Optional legal templates, such as permission to show names and cloth.', href: undefined },
];

export const ART_AGREEMENTS: AgreementsData = {
  stages: ART_STAGES,
  modal: {
    ...MODAL,
    create: { ...MODAL.create, titlePlaceholder: 'For example, How we credit the dyers' },
    suggest: { ...MODAL.suggest, changePlaceholder: 'For example, Yusuf also checks the pattern names' },
    acknowledge: {
      ...MODAL.acknowledge,
      summary: [
        'Kemi Adeyemi leads the project as owner.',
        'Amara Obi illustrates the plates.',
        'Ayo Bello chooses the colours.',
        'Yusuf Danjuma leads the pattern research.',
        'Decisions are discussed together. The owner confirms the outcome.',
      ],
    },
  },
};

/** The Agreements data of a project (`key` is the project key of useProject(), 'career' or 'adire'). */
export const agreementsFor = (key: 'career' | 'adire'): AgreementsData => (key === 'adire' ? ART_AGREEMENTS : CAREER_AGREEMENTS);
