'use client';

import '../workspace/workspace.css';
import './files.css';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Check, Search, X } from 'lucide-react';
import { Link } from '@/lib/nav';
import { Button, EmptyState, TextInput, toast } from '@/ui';
import { ActionButton, PageHead, WorkspaceFrame } from '../workspace/parts';
import { CATEGORIES, COPY, categoryOf, matchesName, type FileItem, type RelatedLink } from './data';
import { CreateDocumentModal, UploadModal } from './modals';
import { TypeTile, useFilesData } from './parts';

/**
 * 12.19 Files: Files (list), Empty, with Modal:Upload file, Toast:File uploaded, Modal:Create document and Toast:Document created.
 * One screen component drives the frames; File preview is in FilePreview.tsx. Both pages show the shared project rail (the short one on
 * Empty) and no metric cards. The "state-" routes are the frames that have no natural
 * trigger (Empty, and the four overlay frames, see routes.tsx).
 * Upload file and Create document (header, and the Empty State) open their modal; the primary button of the modal closes it and shows the
 * toast on the page that was open. Controls with no destination in the design are shown and do nothing: rows 2 to 6 and the Undo of the
 * toasts (it closes the toast).
 *
 * Search and categories (Figma 12.19 Search focused, Search results, Filtered: <category>, No results; Adire Stories 12.37 Search results and
 * No results). The list is in one of three views, as every Figma frame is: all files, the results of a search, or one category.
 *  - Search: typing fills the field (Search focused: the list is still the whole list); Enter or the search icon shows the results over
 *    the file names ("2 FILES FOR 'ONBOARDING'"); Clear (the cross) and All go back to the whole list; no match shows No results with
 *    "Clear search". Emptying the field also goes back to the whole list.
 *  - Categories (Career Guidance for Everyone): a chip shows the files of that category ("DOCUMENTS (2)"); a category without files shows its
 *    empty state ("No project references yet."). A chip is one choice at a time and the field is empty in every category frame, so choosing a
 *    category clears the search and a search shows All. The chip that is chosen again goes back to All.
 *  - Adire Stories has search and results only: its chips beyond All keep toggling their look and do not filter.
 * Adire Stories has the same page (route FP.list under its own root) with its own files (FILES_DATA in data.ts). It has no file preview, work
 * detail or milestone detail, so none of its rows or related links has a destination: they are shown and do nothing, like rows 2 to 6.
 */

const TOAST_MS = 2500;
/** The toast of a "state-" frame stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

type View = 'list' | 'empty';

/** What the list shows: every file, the results of a search, or one category. */
type Browse = { kind: 'all' } | { kind: 'search'; query: string } | { kind: 'category'; category: string };
const ALL: Browse = { kind: 'all' };

/* ------------------------------------------------------------------ Category Chip */

/**
 * Category Chip (17729:92491): Default, Hover (ink border), Pressed (muted fill, ink border), Focus (2 px ink border) and Selected
 * (ink fill with a check). `isOn` and `onPick` are the page's; the chips of Adire Stories toggle themselves (see Browser).
 */
function Categories({ isOn, onPick }: { isOn: (c: string) => boolean; onPick: (c: string) => void }) {
  return (
    <div className="fl-cats" role="group" aria-label="Categories">
      {CATEGORIES.map((c) => {
        const on = isOn(c);
        return (
          <button type="button" key={c} className="fl-cat" aria-pressed={on} onClick={() => onPick(c)}>
            {on ? <Check size={14} strokeWidth={1.6} aria-hidden="true" focusable="false" /> : null}
            <span>{c}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ Search Field with Clear */

/**
 * Search files (Figma Search Field 17309): the search icon, the value and Clear (a 32 px cross at the right, shown once something is typed).
 * Default has the grey border, Focus a 2 px ink border, and a field with a value keeps the 1 px ink border (Search results, No results).
 */
function SearchField({ value, onChange, onSubmit, onClear, placeholder }: { value: string; onChange: (v: string) => void; onSubmit: () => void; onClear: () => void; placeholder: string }) {
  const input = useRef<HTMLInputElement>(null);
  const has = value.length > 0;
  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit();
  };
  return (
    <form className="fl-search" role="search" onSubmit={submit}>
      <TextInput
        ref={input}
        className={has ? 'fl-filled' : undefined}
        iconLeft={
          // the icon is the second way to search (Enter is the first), so it stays out of the tab order
          <span className="fl-search__go" onClick={onSubmit}>
            <Search size={20} strokeWidth={1.5} aria-hidden="true" focusable="false" />
          </span>
        }
        iconRight={
          has ? (
            <button
              type="button"
              className="fl-clear"
              aria-label="Clear search"
              onClick={() => {
                onClear();
                input.current?.focus();
              }}
            >
              <X size={20} strokeWidth={1.5} aria-hidden="true" focusable="false" />
            </button>
          ) : undefined
        }
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label={placeholder}
        autoComplete="off"
        enterKeyHint="search"
      />
    </form>
  );
}

/* ------------------------------------------------------------------ File browser */

/** The search field, the Category Chips and the list (or its No results and empty category blocks). */
function FileBrowser({ onUpload }: { onUpload: () => void }) {
  const { copy, files, filterByCategory } = useFilesData();
  // what is typed, and what the list shows (typing alone does not change the list: Search focused still shows the whole list)
  const [draft, setDraft] = useState('');
  const [browse, setBrowse] = useState<Browse>(ALL);
  // Adire Stories: the chips toggle their look and filter nothing
  const [toggled, setToggled] = useState<string[]>(['All']);

  const submit = () => {
    const query = draft.trim();
    setBrowse(query ? { kind: 'search', query } : ALL);
  };
  const change = (v: string) => {
    setDraft(v);
    // emptying the field shows the whole list again
    if (!v.trim() && browse.kind === 'search') setBrowse(ALL);
  };
  const clear = () => {
    setDraft('');
    if (browse.kind === 'search') setBrowse(ALL);
  };

  const pick = (c: string) => {
    if (c === 'All') {
      // All is the whole list: no search, no category
      setDraft('');
      setBrowse(ALL);
      setToggled(['All']);
    } else if (filterByCategory) {
      setDraft('');
      setBrowse((b) => (b.kind === 'category' && b.category === c ? ALL : { kind: 'category', category: c }));
    } else {
      setToggled((s) => (s.includes(c) ? s.filter((x) => x !== c) : [...s, c]));
    }
  };
  const isOn = (c: string) => (filterByCategory ? (browse.kind === 'category' ? browse.category === c : c === 'All') : toggled.includes(c));

  const shown = files.filter((f) => (browse.kind === 'search' ? matchesName(f.name, browse.query) : browse.kind === 'category' ? categoryOf(f) === browse.category : true));
  const label =
    browse.kind === 'search' ? copy.results(shown.length, browse.query) : browse.kind === 'category' ? `${browse.category} (${shown.length})` : `${copy.group} (${shown.length})`;

  return (
    <section className="fl-browser" data-m="up" aria-label="File browser">
      <SearchField value={draft} onChange={change} onSubmit={submit} onClear={clear} placeholder={copy.search} />
      <Categories isOn={isOn} onPick={pick} />
      {shown.length === 0 ? (
        <div aria-live="polite">
          {browse.kind === 'search' ? (
            <EmptyState
              className="cw-empty fl-empty"
              title={copy.noResults.title(browse.query)}
              text={copy.noResults.text}
              action={<Button onClick={clear}>{copy.clearSearch}</Button>}
            />
          ) : (
            <EmptyState
              className="cw-empty fl-empty"
              title={copy.categoryEmpty(browse.kind === 'category' ? browse.category : '')}
              text={copy.empty.text}
              action={<Button onClick={onUpload}>Upload file</Button>}
            />
          )}
        </div>
      ) : (
        <div className="fl-list">
          <div className="fl-list__head">
            <h2 className="fl-list__label" aria-live="polite">
              {label}
            </h2>
          </div>
          <ul className="fl-rows" aria-label="Files">
            {shown.map((f) => (
              <li key={f.id}>
                <FileRow file={f} />
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ File Row */

/**
 * File Row (17729:93059): type tile, name, meta line, the related work and milestone links, and the avatar of the person who shared it.
 * Default, Hover (subtle), Pressed (muted) and Focus (2 px ink ring inside). The whole row is one target (the name, stretched over the row);
 * the two related links sit above it. Only the first row opens a page, the other rows react to hover and press but go nowhere.
 */
function Related({ link, className }: { link: RelatedLink; className?: string }) {
  return link.href ? (
    <Link href={link.href} className={className}>
      {link.text}
    </Link>
  ) : (
    <button type="button" className={className}>
      {link.text}
    </button>
  );
}

function FileRow({ file }: { file: FileItem }) {
  return (
    <div className="fl-row">
      <TypeTile icon={file.icon} />
      <div className="fl-row__content">
        <h3 className="fl-row__title">
          {file.href ? (
            <Link href={file.href} className="fl-row__main">
              {file.name}
            </Link>
          ) : (
            <button type="button" className="fl-row__main">
              {file.name}
            </button>
          )}
        </h3>
        <p className="fl-row__meta">{file.meta}</p>
        <p className="fl-row__related">
          <span className="fl-rel">
            <span className="fl-rel__label">Work</span>
            <Related link={file.work} className="fl-rel__link" />
          </span>
          <span className="fl-rel">
            <span className="fl-rel__label">Milestone</span>
            <Related link={file.milestone} className="fl-rel__link" />
          </span>
        </p>
      </div>
      <span className="fl-owner" aria-hidden="true">
        {file.owner}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ screen */

function Screen({ view, uploadOpen, createOpen, toastText }: { view: View; uploadOpen?: boolean; createOpen?: boolean; toastText?: string }) {
  const { copy } = useFilesData();
  const [upload, setUpload] = useState(Boolean(uploadOpen));
  const [create, setCreate] = useState(Boolean(createOpen));

  const show = (message: string, ms: number) => toast.show({ message, actionLabel: 'Undo', duration: ms });

  // the "state-file-uploaded" and "state-document-created" frames: the page with the toast already showing
  useEffect(() => {
    if (toastText) show(toastText, STATE_TOAST_MS);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toastText]);

  // The primary button of a modal closes it and shows the toast; the page behind stays where it is (List or Empty)
  const uploaded = () => {
    setUpload(false);
    show(copy.uploaded, TOAST_MS);
  };
  const created = () => {
    setCreate(false);
    show(copy.created, TOAST_MS);
  };

  const head = (
    <PageHead label={copy.label} title={copy.title} lead={copy.lead}>
      <div className="cw-actions cw-actions--btns">
        <ActionButton onClick={() => setUpload(true)}>Upload file</ActionButton>
        <ActionButton variant="secondary" onClick={() => setCreate(true)}>
          Create document
        </ActionButton>
      </div>
    </PageHead>
  );

  const modals = (
    <>
      <UploadModal open={upload} onClose={() => setUpload(false)} onUpload={uploaded} />
      <CreateDocumentModal open={create} onClose={() => setCreate(false)} onCreate={created} />
    </>
  );

  if (view === 'empty') {
    return (
      <WorkspaceFrame active="files" rail="short">
        <div className="fl-page">
          {head}
          <div data-m="up">
            <EmptyState
              className="cw-empty fl-empty"
              title={copy.empty.title}
              text={copy.empty.text}
              action={
                <Button arrow="up-right" onClick={() => setUpload(true)}>
                  Upload file
                </Button>
              }
            />
          </div>
        </div>
        {modals}
      </WorkspaceFrame>
    );
  }

  return (
    <WorkspaceFrame active="files" rail>
      <div className="fl-page">
        {head}
        <FileBrowser onUpload={() => setUpload(true)} />
      </div>
      {modals}
    </WorkspaceFrame>
  );
}

export const Files = () => <Screen view="list" />;
export const FilesEmpty = () => <Screen view="empty" />;
/** Frame "Modal:Upload file": Files with the modal open. */
export const FilesUploadModal = () => <Screen view="list" uploadOpen />;
/** Frame "Toast:File uploaded": Files with the toast showing. */
export const FilesUploaded = () => <Screen view="list" toastText={COPY.uploaded} />;
/** Frame "Modal:Create document": Files with the modal open. */
export const FilesCreateModal = () => <Screen view="list" createOpen />;
/** Frame "Toast:Document created": Files with the toast showing. */
export const FilesCreated = () => <Screen view="list" toastText={COPY.created} />;
