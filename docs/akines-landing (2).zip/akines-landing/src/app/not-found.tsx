import type { Metadata } from 'next';
import { NotFoundView } from '@/features/landing/NotFoundView';

export const metadata: Metadata = {
  title: 'Page not found | Akines',
  description: 'This page has not been made yet. Return to Akines to find people you can genuinely know, trust and create with.',
};

/** Served for /404 and every unknown URL (HTTP 404, noindex). The view is shared with the preview artifact. */
export default function NotFound() {
  return <NotFoundView />;
}
