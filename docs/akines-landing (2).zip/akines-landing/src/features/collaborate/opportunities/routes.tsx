import type { RouteDef } from '@/routes.types';
import { Opportunities, OpportunitiesEmpty } from './Opportunities';
import { Contributions, ContributionsEmpty } from './Contributions';

/**
 * Opportunities 12.31 and My Contributions 12.32, the last two tabs of the Collaborate sub row. Registering these paths
 * replaces their placeholder pages (see collaborate/routes.ts). The Empty frames have no trigger in the prototype, so they get state routes.
 */
const opportunities = { page: 'collaborate', tab: 'Opportunities' } as const;
const contributions = { page: 'collaborate', tab: 'My Contributions' } as const;

export const routes: RouteDef[] = [
  // 12.31 Opportunities
  { path: '/collaborate/opportunities', title: 'Opportunities', shell: 'app', nav: opportunities, component: Opportunities },
  { path: '/collaborate/opportunities/state-empty', title: 'Opportunities', shell: 'app', nav: opportunities, component: OpportunitiesEmpty },
  // 12.32 My Contributions
  { path: '/collaborate/contributions', title: 'My contributions', shell: 'app', nav: contributions, component: Contributions },
  { path: '/collaborate/contributions/state-empty', title: 'My contributions', shell: 'app', nav: contributions, component: ContributionsEmpty },
];
