'use client';

import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { useScrollLock } from '@/lib/hooks';
import { cx, IconClose, useEscape, useFocusTrap, usePresence } from './internal';

/** Exit time of overlays in ms (CSS: 0.28 s). */
const EXIT_MS = 300;

type PanelProps = {
  open: boolean;
  onClose: () => void;
  kind: 'modal' | 'drawer';
  /** CSS class of the panel (size or side modifiers) */
  panelClass?: string;
  panelStyle?: React.CSSProperties;
  title?: ReactNode;
  description?: ReactNode;
  eyebrow?: ReactNode;
  image?: string;
  flush?: boolean;
  footer?: ReactNode;
  hideClose?: boolean;
  closeOnBackdrop?: boolean;
  label?: string;
  children?: ReactNode;
};

/** Shared engine of Modal and Drawer: portal to body, backdrop, focus trap, Escape, scroll lock, exit animation, focus restore. */
export function Overlay({ open, onClose, kind, panelClass, panelStyle, title, description, eyebrow, image, flush, footer, hideClose, closeOnBackdrop = true, label, children }: PanelProps) {
  const [client, setClient] = useState(false);
  useEffect(() => setClient(true), []);
  const { mounted, state } = usePresence(open, EXIT_MS);
  const ref = useRef<HTMLDivElement>(null);
  const downOnBackdrop = useRef(false);
  const uid = useId().replace(/:/g, '');
  const titleId = `k-ov-t-${uid}`;
  const descId = `k-ov-d-${uid}`;

  useScrollLock(open);
  const top = useEscape(open && mounted, onClose);
  useFocusTrap(open && mounted && client, ref, top);

  if (!client || !mounted) return null;
  return createPortal(
    <div className={cx('k-layer', `k-layer--${kind}`)} data-state={state} data-k-overlay>
      <div
        className="k-backdrop"
        onPointerDown={(e) => {
          downOnBackdrop.current = e.target === e.currentTarget;
        }}
        onClick={(e) => {
          if (closeOnBackdrop && downOnBackdrop.current && e.target === e.currentTarget) onClose();
          downOnBackdrop.current = false;
        }}
        aria-hidden="true"
      />
      <div
        className={cx('k-panel', `k-panel--${kind}`, panelClass)}
        style={panelStyle}
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? titleId : undefined}
        aria-label={title ? undefined : label}
        aria-describedby={description ? descId : undefined}
        tabIndex={-1}
        data-state={state}
      >
        <span className="k-panel__handle" aria-hidden="true" />
        {title || description || eyebrow || !hideClose ? (
          <header className={cx('k-panel__head', image && 'k-panel__head--image')}>
            {image ? (
              <>
                <img className="k-panel__img" src={image} alt="" decoding="async" />
                <span className="k-panel__scrim" aria-hidden="true" />
              </>
            ) : null}
            <div className="k-panel__heading">
              {eyebrow ? <p className="k-panel__eyebrow">{eyebrow}</p> : null}
              {title ? (
                <h2 className="k-panel__title" id={titleId}>
                  {title}
                </h2>
              ) : null}
              {description ? (
                <p className="k-panel__desc" id={descId}>
                  {description}
                </p>
              ) : null}
            </div>
            {!hideClose ? (
              <button type="button" className="k-panel__close" aria-label="Close" onClick={onClose}>
                <IconClose size={20} strokeWidth={1.25} />
              </button>
            ) : null}
          </header>
        ) : null}
        <div className={cx('k-panel__body', flush && 'k-panel__body--flush')} data-k-body>
          {children}
        </div>
        {footer ? <footer className="k-panel__foot">{footer}</footer> : null}
      </div>
    </div>,
    document.body,
  );
}

export type ModalProps = {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  /** Small uppercase line above the title (the Figma modal eyebrow). */
  eyebrow?: ReactNode;
  /** Photo header with the title in white over it (Community panels). Gives the panel its 32 px corners. */
  image?: string;
  /** Exact width in px, overrides `size` (Figma modals are 560, 640 and 1040 wide). */
  width?: number;
  /** No padding around the body, for content that brings its own layout. */
  flush?: boolean;
  footer?: ReactNode;
  hideClose?: boolean;
  closeOnBackdrop?: boolean;
  label?: string;
  children?: ReactNode;
  className?: string;
};

/** Centred dialog on tablet and desktop, bottom sheet below 768. Sizes 480, 600, 760, 960. */
export function Modal({ size = 'md', width, className, ...p }: ModalProps) {
  return (
    <Overlay
      {...p}
      kind="modal"
      panelClass={cx(`k-panel--${size}`, p.image && 'k-panel--photo', className)}
      panelStyle={width ? { ['--k-modal-w' as string]: `${width}px` } : undefined}
    />
  );
}

export type DrawerProps = {
  open: boolean;
  onClose: () => void;
  side?: 'right' | 'left';
  width?: number;
  title?: ReactNode;
  description?: ReactNode;
  eyebrow?: ReactNode;
  image?: string;
  flush?: boolean;
  hideClose?: boolean;
  footer?: ReactNode;
  label?: string;
  children?: ReactNode;
  className?: string;
};

/** Side panel (480 wide by default), a full width bottom sheet below 768. */
export function Drawer({ side = 'right', width = 480, className, ...p }: DrawerProps) {
  return <Overlay {...p} kind="drawer" panelClass={cx(`k-panel--${side}`, p.image && 'k-panel--photo', className)} panelStyle={{ ['--k-drawer-w' as string]: `${width}px` }} />;
}
