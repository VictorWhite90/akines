'use client';

/**
 * Join (create account): one route, a five step machine (Figma section 08, desktop 1512, tablet 1194, mobile 402).
 *   1 email or mobile number  2 confirm the code  3 username, password and the 18+ tick
 *   4 what brings you here    5 welcome, "Go to Community"
 * Every field starts prefilled with the dummy values (src/lib/auth.ts DUMMY) so each step completes with its main button.
 * Every Figma state is reached by its trigger (empty field, odd entry, wrong code, taken username, no choice ...);
 * the static routes in routes.ts start the same screen in a given state through `preset`.
 */
import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { takeNext } from '@/app-shell/AppShell';
import { Logo } from '@/components/Logo';
import { asset } from '@/lib/assets';
import { DUMMY, signIn } from '@/lib/auth';
import { useReducedMotion } from '@/lib/hooks';
import { Link, useNav } from '@/lib/nav';
import { SignInPanelHost } from './SignInPanel';
import { openSignIn } from './panel-store';
import { AuField, CheckGlyph, OrDivider, PrimaryButton, ShowToggle, SocialButton, type Provider } from './au-bits';
import {
  DEFAULT_REASON,
  REASONS,
  STRENGTH_LABEL,
  T,
  checkCode,
  checkContact,
  checkUsername,
  groupCode,
  isRegistered,
  onlyDigits,
  passwordAccepted,
  passwordStrength,
  stripAt,
  suggestUsernames,
  type ContactKind,
  type Strength,
} from './join-data';
import '../../styles/auth.css';

type Step = 1 | 2 | 3 | 4 | 5;

/** Starting state of a static frame. Anything left out takes the live (prefilled) value. */
export type JoinPreset = {
  step?: Step;
  /** focus the main field of the step */
  focus?: boolean;
  contact?: string;
  contactErr?: 'missing' | 'invalid' | 'registered';
  sending?: boolean;
  provider?: Provider;
  code?: string;
  codeErr?: 'missing' | 'wrong' | 'expired';
  checking?: boolean;
  sent?: boolean;
  username?: string;
  /** treat the preset username as free (Figma 3d shows @ndegoyit available while 3c shows it taken) */
  available?: boolean;
  password?: string;
  showPw?: boolean;
  age?: boolean;
  /** show validation for these fields as if the form had been submitted */
  submitted?: boolean;
  creating?: boolean;
  /** null = nothing chosen */
  reason?: number | null;
  reasonErr?: boolean;
  confirming?: boolean;
  welcomeUser?: string;
};

type Contact = { value: string; kind: ContactKind };

const TAB_TITLES: Record<number, string> = { 2: 'Confirm', 3: 'Create account', 4: 'Your reason', 5: 'Welcome' };

/** Timers that are cleared when the step goes away. */
function useLater() {
  const ids = useRef<number[]>([]);
  useEffect(
    () => () => {
      ids.current.forEach((t) => window.clearTimeout(t));
      ids.current = [];
    },
    [],
  );
  return useCallback((fn: () => void, ms: number) => {
    ids.current.push(window.setTimeout(fn, ms));
  }, []);
}

/* ---------- shared pieces ---------- */
function Progress({ step }: { step: Step }) {
  return (
    <div className="au-progress" role="img" aria-label={`Step ${step} of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <span key={n} className="au-progress__seg" data-on={n <= step ? '' : undefined} />
      ))}
    </div>
  );
}

function Header({ eyebrow, title, children, headingRef }: { eyebrow: string; title: string; children: ReactNode; headingRef?: React.Ref<HTMLHeadingElement> }) {
  return (
    <div className="au-header">
      <p className="au-eyebrow">{eyebrow}</p>
      <h1 ref={headingRef} tabIndex={-1} className="au-h1">
        {title}
      </h1>
      <p className="au-lede">{children}</p>
    </div>
  );
}

/** Password strength meter (Figma Password Strength: Empty, Weak, Okay, Strong). */
function Meter({ level }: { level: Strength }) {
  const on = level === 'weak' ? 1 : level === 'okay' ? 2 : level === 'strong' ? 4 : 0;
  return (
    <div className="au-meter" data-level={level} aria-live="polite">
      <div className="au-meter__bars" aria-hidden="true">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className="au-meter__bar" data-on={i < on ? '' : undefined} />
        ))}
      </div>
      <p className="au-meter__label">{STRENGTH_LABEL[level]}</p>
    </div>
  );
}

function Check({ checked, onChange, error, inputRef }: { checked: boolean; onChange: (v: boolean) => void; error?: boolean; inputRef?: React.Ref<HTMLInputElement> }) {
  return (
    <div className="au-checkrow">
      <label className="au-check" data-error={error ? '' : undefined}>
        <input ref={inputRef} type="checkbox" className="au-check__input" checked={checked} onChange={(e) => onChange(e.target.checked)} aria-invalid={error ? true : undefined} />
        <span className="au-check__box" aria-hidden="true">
          <CheckGlyph size={14} />
        </span>
        {/* "community promises" has no destination in the design yet */}
        <span className="au-check__text">
          I&apos;m 18 or over and accept the <span className="au-check__link">community promises</span>.
        </span>
      </label>
      {error ? (
        <p className="au-check__error" role="alert">
          Tick the box to confirm you are 18 or over.
        </p>
      ) : null}
    </div>
  );
}

/* ---------- step 1: email or mobile ---------- */
function StepContact({ p, arrived, onNext, onProvider }: { p: JoinPreset; arrived: boolean; onNext: (c: Contact) => void; onProvider: () => void }) {
  const later = useLater();
  const field = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState(p.contact ?? DUMMY.email);
  const [err, setErr] = useState<JoinPreset['contactErr'] | null>(p.contactErr ?? null);
  const [sending, setSending] = useState(!!p.sending);
  const [provider, setProvider] = useState<Provider | null>(p.provider ?? null);
  const busy = sending || provider !== null;

  useEffect(() => {
    if (p.focus || arrived) field.current?.focus();
  }, [p.focus, arrived]);

  const typed = checkContact(value);
  const kind: ContactKind = typed.ok ? typed.kind : 'email';
  const message =
    err === 'missing'
      ? 'Enter your email or mobile number.'
      : err === 'invalid'
        ? 'Enter a valid email address or mobile number.'
        : err === 'registered'
          ? kind === 'mobile'
            ? 'That number already has an account.'
            : 'That email already has an account.'
          : undefined;

  const submit = () => {
    if (busy) return;
    const c = checkContact(value);
    if (!c.ok) {
      setErr(c.error);
      field.current?.focus();
      return;
    }
    if (isRegistered(c.value)) {
      setErr('registered');
      field.current?.focus();
      return;
    }
    setErr(null);
    setSending(true);
    later(() => onNext({ value: c.value, kind: c.kind }), T.sending);
  };

  const startProvider = (which: Provider) => {
    if (busy) return;
    setErr(null);
    setProvider(which);
    later(onProvider, T.provider);
  };

  return (
    <div className="au-card" data-step="1">
      <Progress step={1} />
      <Header eyebrow="Join Akines" title="Take a seat. Stay awhile.">
        Join with your email or mobile number. It takes about a minute.
      </Header>
      <form
        className="au-flow"
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <div className="au-group">
          <AuField
            label="Email or mobile number"
            value={value}
            inputRef={field}
            placeholder="you@example.com or 0803 123 4567"
            inputMode="email"
            autoComplete="email"
            message={message}
            onChange={(v) => {
              setValue(v);
              if (err) setErr(null);
            }}
          />
          {err === 'registered' ? (
            <button type="button" className="au-link au-link--start" onClick={() => openSignIn()}>
              Log in instead
            </button>
          ) : message || sending ? null : (
            <p className="au-helper">We&apos;ll send a 6-digit code to confirm it&apos;s you.</p>
          )}
          <PrimaryButton label="Continue" type="submit" loading={sending} />
        </div>
        <OrDivider />
        <div className="au-providers">
          <SocialButton provider="google" loading={provider === 'google'} onClick={() => startProvider('google')} />
          <SocialButton provider="apple" loading={provider === 'apple'} onClick={() => startProvider('apple')} />
        </div>
      </form>
    </div>
  );
}

/* ---------- step 2: confirm the code ---------- */
function StepCode({ p, contact, arrived, onNext, onBack }: { p: JoinPreset; contact: Contact; arrived: boolean; onNext: () => void; onBack: () => void }) {
  const later = useLater();
  const field = useRef<HTMLInputElement>(null);
  const [digits, setDigits] = useState(p.code ?? DUMMY.code);
  const [err, setErr] = useState<JoinPreset['codeErr'] | null>(p.codeErr ?? null);
  const [checking, setChecking] = useState(!!p.checking);
  const [sent, setSent] = useState(!!p.sent);
  const mobile = contact.kind === 'mobile';

  useEffect(() => {
    if (p.focus || arrived) field.current?.focus();
  }, [p.focus, arrived]);

  const message =
    err === 'missing'
      ? 'Enter the 6-digit code.'
      : err === 'wrong'
        ? "That code doesn't match. Check it and try again."
        : err === 'expired'
          ? 'That code has expired. Send a new code.'
          : undefined;

  const submit = () => {
    if (checking) return;
    const r = checkCode(digits);
    if (r !== 'ok') {
      setErr(r);
      setSent(false);
      field.current?.focus();
      return;
    }
    setErr(null);
    setSent(false);
    setChecking(true);
    later(onNext, T.checking);
  };

  const resend = () => {
    if (checking) return;
    setErr(null);
    setSent(true);
    // The live flow refills the dummy code so Confirm completes the step (the Figma frame shows an empty field).
    setDigits(DUMMY.code);
    field.current?.focus();
  };

  return (
    <div className="au-card" data-step="2">
      <Progress step={2} />
      <Header eyebrow={mobile ? 'Confirm your mobile number' : 'Confirm your email'} title={mobile ? 'Check your messages.' : 'Check your inbox.'}>
        We sent a 6-digit code to {contact.value}. It expires in 10 minutes.
      </Header>
      <form
        className="au-flow au-flow--code"
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <div className="au-group">
          <AuField
            label="6-digit code"
            value={groupCode(digits)}
            inputRef={field}
            placeholder="123 456"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={7}
            message={message}
            onChange={(v) => {
              setDigits(onlyDigits(v));
              if (err) setErr(null);
              if (sent) setSent(false);
            }}
          />
          {sent && !message ? (
            <p className="au-helper" data-tone="success" role="status">
              A new code is on its way to {contact.value}.
            </p>
          ) : null}
          <PrimaryButton label="Confirm and continue" type="submit" loading={checking} />
        </div>
        <div className="au-links">
          <button type="button" className="au-link" onClick={resend}>
            Send a new code
          </button>
          <button type="button" className="au-link" onClick={onBack}>
            {mobile ? 'Use a different number' : 'Use a different email'}
          </button>
        </div>
      </form>
    </div>
  );
}

/* ---------- step 3: username, password, 18+ ---------- */
type View = 'neutral' | 'missing' | 'invalid' | 'taken' | 'available';
function usernameView(raw: string, touched: boolean): View {
  const s = stripAt(raw);
  if (!s) return touched ? 'missing' : 'neutral';
  const c = checkUsername(raw);
  if (c === 'invalid') {
    // odd characters or too long are flagged as you type, "too short" waits until the field is left
    const odd = /[^A-Za-z0-9_.]/.test(s) || s.length > 20;
    return odd || touched ? 'invalid' : 'neutral';
  }
  return c;
}

function StepAccount({ p, arrived, onNext }: { p: JoinPreset; arrived: boolean; onNext: (username: string) => void }) {
  const later = useLater();
  const userRef = useRef<HTMLInputElement>(null);
  const passRef = useRef<HTMLInputElement>(null);
  const checkRef = useRef<HTMLInputElement>(null);
  const [username, setUsername] = useState(p.username ?? `@${DUMMY.username}`);
  const [password, setPassword] = useState(p.password ?? DUMMY.password);
  const [showPw, setShowPw] = useState(!!p.showPw);
  const [age, setAge] = useState(p.age ?? true);
  const [touchedU, setTouchedU] = useState(!!p.submitted);
  const [touchedP, setTouchedP] = useState(!!p.submitted);
  const [touchedK, setTouchedK] = useState(!!p.submitted);
  const [creating, setCreating] = useState(!!p.creating);

  useEffect(() => {
    if (p.focus || arrived) userRef.current?.focus();
  }, [p.focus, arrived]);

  const forcedFree = !!p.available && username === p.username;
  const uv = forcedFree ? 'available' : usernameView(username, touchedU);
  const name = stripAt(username);
  const strength = passwordStrength(password);
  const pMissing = touchedP && !password;
  const kError = touchedK && !age;

  const usernameMessage =
    uv === 'missing' ? 'Choose a username.' : uv === 'invalid' ? 'Use 3 to 20 letters, numbers, underscores or dots.' : uv === 'taken' ? 'That username is taken.' : undefined;

  const submit = () => {
    if (creating) return;
    setTouchedU(true);
    setTouchedP(true);
    setTouchedK(true);
    if (!forcedFree && checkUsername(username) !== 'available') {
      userRef.current?.focus();
      return;
    }
    if (!passwordAccepted(password)) {
      passRef.current?.focus();
      return;
    }
    if (!age) {
      checkRef.current?.focus();
      return;
    }
    setCreating(true);
    later(() => onNext(name), T.creating);
  };

  const chips = uv === 'taken' ? suggestUsernames(username) : null;

  return (
    <div className="au-card" data-step="3">
      <Progress step={3} />
      <Header eyebrow="Almost there" title="Make it yours.">
        Choose a username and a password to finish.
      </Header>
      <form
        className="au-flow au-flow--account"
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <AuField
          label="Username"
          value={username}
          inputRef={userRef}
          placeholder="@username"
          autoComplete="username"
          verified={uv === 'available'}
          message={usernameMessage}
          helper={uv === 'available' ? `@${name} is available.` : '3 to 20 characters. Letters, numbers, underscores and dots.'}
          helperTone={uv === 'available' ? 'strong' : 'default'}
          onChange={(v) => setUsername(v)}
          onBlur={() => setTouchedU(true)}
          below={
            chips ? (
              <div className="au-suggest">
                <span className="au-suggest__try">Try</span>
                {chips.map((c) => (
                  <button
                    key={c}
                    type="button"
                    className="au-chip"
                    onClick={() => {
                      setUsername(c);
                      userRef.current?.focus();
                    }}
                  >
                    {c}
                  </button>
                ))}
              </div>
            ) : null
          }
        />
        <AuField
          label="Password"
          value={password}
          inputRef={passRef}
          type={showPw ? 'text' : 'password'}
          placeholder="Enter at least 12 characters"
          autoComplete="new-password"
          verified={strength === 'strong'}
          message={pMissing ? 'Create a password.' : undefined}
          action={<ShowToggle shown={showPw} onToggle={() => setShowPw((s) => !s)} />}
          onChange={(v) => setPassword(v)}
          onBlur={() => setTouchedP(true)}
          below={<Meter level={strength} />}
        />
        <Check checked={age} onChange={setAge} error={kError} inputRef={checkRef} />
        <PrimaryButton label="Create my account" type="submit" loading={creating} />
      </form>
    </div>
  );
}

/* ---------- step 4: what brings you here ---------- */
function ReasonCard({ index, label, photo, state, onPick }: { index: number; label: string; photo: string; state: 'default' | 'selected' | 'dimmed'; onPick: () => void }) {
  return (
    <label className="au-reason" data-state={state}>
      <input type="radio" name="au-reason" className="au-reason__input" checked={state === 'selected'} onChange={() => {}} onClick={onPick} />
      <img className="au-reason__photo" src={asset(`/images/${photo}.jpg`)} alt="" loading="lazy" decoding="async" draggable={false} />
      <span className="au-reason__scrim" aria-hidden="true" />
      <span className="au-reason__dim" aria-hidden="true" />
      <span className="au-reason__index" aria-hidden="true">
        {String(index).padStart(2, '0')}
      </span>
      <span className="au-reason__radio" aria-hidden="true">
        <CheckGlyph size={14} />
      </span>
      <span className="au-reason__label">{label}</span>
    </label>
  );
}

function StepReason({ p, arrived, onNext }: { p: JoinPreset; arrived: boolean; onNext: () => void }) {
  const later = useLater();
  const heading = useRef<HTMLHeadingElement>(null);
  const [reason, setReason] = useState<number | null>(p.reason === undefined ? DEFAULT_REASON : p.reason);
  const [err, setErr] = useState(!!p.reasonErr);
  const [confirming, setConfirming] = useState(!!p.confirming);

  useEffect(() => {
    if (arrived) heading.current?.focus({ preventScroll: true });
  }, [arrived]);

  const chosen = REASONS.find((r) => r.id === reason) ?? null;
  const confirm = () => {
    if (confirming) return;
    if (!chosen) {
      setErr(true);
      return;
    }
    setConfirming(true);
    later(onNext, T.confirming);
  };

  return (
    <div className="au-split" data-step="4">
      <div className="au-intro">
        <div className="au-intro__top">
          <Progress step={4} />
          <Header eyebrow="One last thing" title="What brings you here today?" headingRef={heading}>
            Choose the one closest to the truth. It only helps us show you the right rooms first.
          </Header>
          <div className="au-choice">
            <p className="au-choice__caption">Your choice</p>
            {chosen ? (
              <>
                <p className="au-choice__echo" aria-live="polite">
                  {chosen.label}
                </p>
                <p className="au-choice__note">Six chairs. One conversation. Tonight.</p>
              </>
            ) : (
              <p className="au-choice__none" aria-live="polite">
                Nothing chosen yet.
              </p>
            )}
          </div>
        </div>
        <div className="au-intro__bottom">
          {err && !chosen ? (
            <p className="au-error" role="alert">
              Choose one to continue.
            </p>
          ) : null}
          <PrimaryButton label="Confirm my choice" loading={confirming} looksDisabled={!chosen} onClick={confirm} />
          <button type="button" className="au-link au-skip" onClick={() => !confirming && onNext()}>
            Skip for now
          </button>
        </div>
      </div>
      <div className="au-reasons" role="radiogroup" aria-label="What brings you here today?">
        {REASONS.map((r) => (
          <ReasonCard
            key={r.id}
            index={r.id}
            label={r.label}
            photo={r.photo}
            state={reason === null ? 'default' : reason === r.id ? 'selected' : 'dimmed'}
            onPick={() => {
              setErr(false);
              setReason((cur) => (cur === r.id ? null : r.id));
            }}
          />
        ))}
      </div>
    </div>
  );
}

/* ---------- step 5: welcome ---------- */
function StepWelcome({ username, arrived }: { username: string; arrived: boolean }) {
  const nav = useNav();
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    if (arrived) heading.current?.focus({ preventScroll: true });
  }, [arrived]);
  return (
    <div className="au-card" data-step="5">
      <Progress step={5} />
      <img className="au-welcome__photo" src={asset('/images/conversation.jpg')} alt="" decoding="async" />
      <Header eyebrow="You're in" title={`Welcome to Akines, @${username}.`} headingRef={heading}>
        Your seat is saved. Take a look around. You can add your photo, role and city whenever you like from your profile.
      </Header>
      <PrimaryButton
        label="Go to Community"
        onClick={() => {
          signIn();
          nav.push(takeNext('/community'));
        }}
      />
    </div>
  );
}

/* ---------- the page ---------- */
export function JoinPage({ preset }: { preset?: JoinPreset }) {
  const p = preset ?? {};
  const reduced = useReducedMotion();
  const [step, setStep] = useState<Step>(p.step ?? 1);
  const [leaving, setLeaving] = useState(false);
  const [arrived, setArrived] = useState(false);
  const [contact, setContact] = useState<Contact>({ value: p.contact ?? DUMMY.email, kind: 'email' });
  const [username, setUsername] = useState(stripAt(p.welcomeUser ?? DUMMY.welcomeUsername));
  const timer = useRef(0);
  useEffect(() => () => window.clearTimeout(timer.current), []);

  /** Cross-fade to the next step: the current one fades up and out, the next one rises in (reduced motion: instant). */
  const go = useCallback(
    (next: Step) => {
      const swap = () => {
        setStep(next);
        setArrived(true);
        setLeaving(false);
        window.scrollTo(0, 0);
      };
      if (reduced) {
        swap();
        return;
      }
      setLeaving(true);
      timer.current = window.setTimeout(swap, T.exit);
    },
    [reduced],
  );

  useEffect(() => {
    if (step > 1) document.title = `${TAB_TITLES[step]} | Akines`;
  }, [step]);

  // Presets only seed the first step shown; later steps use live values
  const seed = arrived ? {} : p;

  return (
    <div className="au-join" data-step={step}>
      <header className="au-bar">
        <Link href="/" className="au-bar__logo" aria-label="Akines, home">
          <Logo />
        </Link>
        {step <= 3 ? (
          <p className="au-bar__prompt">
            <span>Already a member?</span>
            <button type="button" className="au-link au-link--inline" onClick={() => openSignIn()}>
              Sign in
            </button>
          </p>
        ) : null}
      </header>
      <main className="au-stage" data-wide={step === 4 ? '' : undefined}>
        <div className="au-step" key={step} data-leaving={leaving ? '' : undefined}>
          {step === 1 ? (
            <StepContact
              p={seed}
              arrived={arrived}
              onNext={(c) => {
                setContact(c);
                go(2);
              }}
              onProvider={() => go(3)}
            />
          ) : step === 2 ? (
            <StepCode p={seed} contact={contact} arrived={arrived} onNext={() => go(3)} onBack={() => go(1)} />
          ) : step === 3 ? (
            <StepAccount
              p={seed}
              arrived={arrived}
              onNext={(u) => {
                setUsername(u);
                go(4);
              }}
            />
          ) : step === 4 ? (
            <StepReason p={seed} arrived={arrived} onNext={() => go(5)} />
          ) : (
            <StepWelcome username={username} arrived={arrived} />
          )}
        </div>
      </main>
      <SignInPanelHost />
    </div>
  );
}

export default JoinPage;
