/** next/image stand-in for the preview artifact: a plain <img>. `fill` fills the positioned parent. */
import type { CSSProperties, ImgHTMLAttributes } from 'react';

type Props = Omit<ImgHTMLAttributes<HTMLImageElement>, 'src'> & {
  src: string;
  fill?: boolean;
  priority?: boolean;
  sizes?: string;
  quality?: number;
  placeholder?: string;
};

function build({ src, fill, priority, quality: _q, placeholder: _p, style, ...rest }: Props) {
  const fillStyle: CSSProperties = fill ? { position: 'absolute', inset: 0, width: '100%', height: '100%' } : {};
  return {
    ...rest,
    src,
    srcSet: src,
    loading: priority ? ('eager' as const) : ('lazy' as const),
    decoding: 'async' as const,
    style: { ...fillStyle, ...style },
  };
}

export default function Image(props: Props) {
  const { srcSet: _s, ...p } = build(props);
  // eslint-disable-next-line @next/next/no-img-element
  return <img {...p} alt={props.alt ?? ''} />;
}

export function getImageProps(props: Props) {
  return { props: build(props) };
}
