/** Page whose content is not designed yet. Same words as the Figma placeholder pages. */
export function Placeholder({ eyebrow, title }: { eyebrow?: string; title: string }) {
  return (
    <section className="ph">
      {eyebrow ? <p className="ph__eyebrow">{eyebrow}</p> : null}
      <h1 className="ph__title">{title}</h1>
      <p className="ph__text">Placeholder page. The content is designed later; use the header and tabs to move around.</p>
    </section>
  );
}
