'use client';

import { useEffect, type ReactNode } from 'react';
import { Motion } from '@/components/Motion';
import { usePath } from '@/lib/nav';
import type { RouteDef } from '@/routes.types';
import { AppShell } from './AppShell';

export type RouteMeta = Pick<RouteDef, 'path' | 'title' | 'shell' | 'nav' | 'mobile'>;

/** Wraps a screen in its shell (set by the route): app header and bars, plain site page, or nothing. */
export function RouteFrame({ meta, children }: { meta: RouteMeta; children: ReactNode }) {
  const path = usePath();
  useEffect(() => {
    document.title = meta.title ? `${meta.title} | Akines` : 'Akines';
  }, [meta.title]);
  if (meta.shell === 'app') {
    return <AppShell route={meta as RouteDef}>{children}</AppShell>;
  }
  return (
    <>
      {children}
      <Motion key={path} />
    </>
  );
}
