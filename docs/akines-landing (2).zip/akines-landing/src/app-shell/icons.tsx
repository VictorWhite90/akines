import {
  Bell, ChevronDown, Compass, CircleHelp, Heart, House, LogOut, MessageSquare, Palette,
  SlidersHorizontal, User, UserCheck, Users,
} from 'lucide-react';
import type { AppIconName } from './nav-model';

type P = { size?: number; className?: string };

/** Two overlapping circles (Figma icon/collaborate: two 11 px rings 6 px apart). */
function Collaborate({ size = 24, className }: P) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      <circle cx="9" cy="12" r="5.5" />
      <circle cx="15" cy="12" r="5.5" />
    </svg>
  );
}

const MAP: Record<AppIconName, React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }>> = {
  home: House, connect: Users, collaborate: Collaborate as never, 'make-sell': Palette, explore: Compass, care: Heart,
  messages: MessageSquare, notifications: Bell, 'chevron-down': ChevronDown, user: User, 'user-check': UserCheck,
  settings: SlidersHorizontal, help: CircleHelp, 'log-out': LogOut,
};

/** The Figma header icon set: 24 px grid, 1.5 stroke, coloured by currentColor. */
export function AppIcon({ name, size = 24, className }: { name: AppIconName; size?: number; className?: string }) {
  const Cmp = MAP[name];
  return <Cmp size={size} strokeWidth={1.5} className={className} aria-hidden={true} />;
}
