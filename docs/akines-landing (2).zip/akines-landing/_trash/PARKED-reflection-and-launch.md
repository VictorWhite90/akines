# Parked 5 Nov 2026: Reflection and Launch (collaboration flow)

The Reflection and Launch project pages were removed from the product and from the Figma prototype (Figma: TRASH page, sections
"PARKED / Reflection and Launch pages" and "PARKED / Reflection and Launch components").

Code moved here: `collaborate-reflection/` (was `src/features/collaborate/reflection/`) and `collaborate-launch/` (was `src/features/collaborate/launch/`).
`_trash` is excluded from the TypeScript project (tsconfig `exclude`), so nothing here is built.

To bring them back:
1. Move the two folders back to `src/features/collaborate/reflection` and `src/features/collaborate/launch`.
2. In `src/features/collaborate/routes.ts` remove the `//` in front of the four commented imports and the two spread entries (`reflection`, `launch`, `artReflection`, `artLaunch`).
3. In `src/features/collaborate/workspace/project.ts` restore `'reflection' | 'launch'` in `NavKey`, the two `NAV_ITEMS` rows (`hidden: true` keeps them out of the navigation), `navPaths` and `NAV_PATHS.career`, and in `workspace/data.ts` the two `PATHS` entries (all marked "Reflection and Launch removed 5 Nov 2026").
