'use client';

import { useSyncExternalStore } from 'react';
import type { ProjectKey } from '../workspace/project';
import { useProject } from '../workspace/project';

/**
 * The meeting of a project (Figma 12.43 Meetings, Meeting Card 17798 and its three states). One store for both projects, one meeting each.
 * The meeting card of the project rail, the Meet menu, the Join card in the conversation and the lobby all read it:
 *  - upcoming: a meeting is scheduled (Prototype review, Thursday 4 PM);
 *  - ongoing:  "Start a meeting now" started one, it is happening for everyone;
 *  - none:     the call has ended (ending the call clears the meeting) and nothing is planned.
 * Lives for one visit (not across reloads), like the other workspace stores.
 */
export type MeetingStatus = 'none' | 'upcoming' | 'ongoing';

export type Meeting = {
  status: MeetingStatus;
  name: string;
  /** "THU" and "4 PM": the date tile of the upcoming card. */
  day: string;
  time: string;
  /** "Thursday, 4:00 PM": the lobby line and the Join card. */
  when: string;
  minutes: number;
  /** People invited (everyone on the project). */
  people: number;
  /** Ongoing: when it started, "4:00 PM". */
  startedAt: string;
  /** The sample meeting nobody has touched yet: the empty pages (Figma "Empty" frames) show it as "No meeting yet". */
  fresh?: boolean;
};

const UPCOMING: Record<ProjectKey, Meeting> = {
  career: { status: 'upcoming', name: 'Prototype review', day: 'THU', time: '4 PM', when: 'Thursday, 4:00 PM', minutes: 45, people: 4, startedAt: '4:00 PM', fresh: true },
  adire: { status: 'upcoming', name: 'Colour review', day: 'THU', time: '4 PM', when: 'Thursday, 4:00 PM', minutes: 45, people: 4, startedAt: '4:00 PM', fresh: true },
};

/** The meeting the lobby and the call screens show when someone opens them without a meeting in the store (a direct address, a state frame). */
export const SAMPLE_MEETING: Record<ProjectKey, Meeting> = UPCOMING;

let state: Record<ProjectKey, Meeting> = { career: UPCOMING.career, adire: UPCOMING.adire };
const listeners = new Set<() => void>();
const set = (key: ProjectKey, meeting: Meeting) => {
  state = { ...state, [key]: meeting };
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};

/** "4:12 PM" for the moment a meeting started. */
const clock = (d = new Date()) => d.toLocaleTimeString('en-GB', { hour: 'numeric', minute: '2-digit', hour12: true }).replace(/\s?([ap])m/i, (_, x: string) => ` ${x.toUpperCase()}M`);

export const meetings = {
  get: (key: ProjectKey) => state[key],

  /** Start a meeting now: it is ongoing for everyone. A meeting that was scheduled keeps its name. */
  startNow(key: ProjectKey) {
    const cur = state[key];
    const name = cur.status === 'none' ? 'Team meeting' : cur.name;
    set(key, { ...cur, name, status: 'ongoing', minutes: cur.minutes || 45, startedAt: clock() });
  },

  /** Schedule for later: an upcoming meeting. */
  schedule(key: ProjectKey, v: { name: string; minutes: number; when: string }) {
    const [dayName, hm] = v.when.split(', ');
    const day = (dayName ?? 'Thursday').slice(0, 3).toUpperCase();
    const time = (hm ?? '4:00 PM').replace(':00', '');
    set(key, { ...state[key], status: 'upcoming', fresh: false, name: v.name.trim() || 'Team meeting', day, time, when: v.when, minutes: v.minutes });
  },

  /** Puts a meeting back as it was (Undo of the "Meeting scheduled" toast). */
  restore(key: ProjectKey, meeting: Meeting) {
    set(key, meeting);
  },

  /** Ending the call clears the meeting for everyone. */
  end(key: ProjectKey) {
    set(key, { ...state[key], status: 'none' });
  },
};

/** The meeting of a project; without `key` the project of the page being shown. */
export function useMeeting(key?: ProjectKey): Meeting {
  const own = useProject().key;
  const k = key ?? own;
  return useSyncExternalStore(
    subscribe,
    () => state[k],
    () => state[k],
  );
}

/** What the lobby and the call screens show: the meeting in the store, or the sample meeting when there is none. */
export function useMeetingView(): Meeting {
  const { key } = useProject();
  const m = useMeeting(key);
  return m.status === 'none' ? { ...SAMPLE_MEETING[key], status: 'none' } : m;
}

export { meetPaths, type MeetPaths } from './paths';
