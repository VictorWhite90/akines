'use client';

import type { ReactNode } from 'react';
import { asset } from '@/lib/assets';
import { Link } from '@/lib/nav';
import './dash.css';
import { ArrowRight, ArrowUpRight, CheckIcon, Dot } from './atoms';
import { cx, scrollToId } from './util';

/**
 * The dashboard pieces of the project pages (Figma 17791 to 17798): Metric Card, Activity Card, Timeline Step, Work Row, the cards of the
 * Overview (stage tracker, task status bar, weekly bars, brief at a glance) and the round Portrait. Every class is prefixed cd- and lives
 * in dash.css. Cards are square with a 1 px border; hover and press come from CSS.
 */

/* ------------------------------------------------------------------ Portrait */

export type Tone = 'green' | 'accent' | 'gray';

/** Round portrait. With `tone` a status dot sits on its lower right corner (green available, amber working, grey away). */
export function Portrait({ src, size = 56, tone, className }: { src?: string; size?: number; tone?: Tone; className?: string }) {
  return (
    <span className={cx('cd-portrait', className)} style={{ ['--cd-p' as string]: `${size}px` }} aria-hidden="true">
      {src ? <img src={asset(src)} alt="" width={size} height={size} loading="lazy" decoding="async" /> : null}
      {tone ? <i className={cx('cd-portrait__dot', `cd-portrait__dot--${tone}`)} /> : null}
    </span>
  );
}

/* ------------------------------------------------------------------ Metric Card */

type MetricProps = {
  label: string;
  value: ReactNode;
  caption?: string;
  /** Amber dot before the caption ("needs you", "to make"). */
  dot?: boolean;
  /** Opens a page. */
  href?: string;
  /** Scrolls to a card of the same page (its DashCard id). */
  scrollTo?: string;
  /** Anything else the card does (opens a modal). */
  onClick?: () => void;
};

/** Metric Card: small uppercase label, the number in Alice, a caption. With a destination the whole card is one link or button; without one it is plain. */
export function MetricCard({ label, value, caption, dot, href, scrollTo, onClick }: MetricProps) {
  const goes = Boolean(href || scrollTo || onClick);
  const body = (
    <>
      <span className="cd-metric__label">{label}</span>
      <span className="cd-metric__value">{value}</span>
      {caption ? (
        <span className="cd-metric__cap">
          {dot ? <Dot size={6} /> : null}
          {caption}
        </span>
      ) : null}
      {goes ? (
        <span className="cd-metric__go" aria-hidden="true">
          <ArrowUpRight size={16} />
        </span>
      ) : null}
    </>
  );
  if (href) {
    return (
      <Link href={href} className="cd-metric">
        {body}
      </Link>
    );
  }
  const act = scrollTo ? () => scrollToId(scrollTo) : onClick;
  if (act) {
    return (
      <button type="button" className="cd-metric" onClick={act}>
        {body}
      </button>
    );
  }
  return <div className="cd-metric cd-metric--plain">{body}</div>;
}

/** The row of metric cards (four on most pages, three on the task list). */
export function MetricRow({ children }: { children: ReactNode }) {
  const n = Array.isArray(children) ? children.filter(Boolean).length : 1;
  return (
    <div className="cd-metrics" style={{ ['--cd-cols' as string]: n }}>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ cards */

/** A bordered dashboard card with its small uppercase title. `id` is the target of a metric card that scrolls here. */
export function DashCard({ title, id, action, children, className }: { title?: string; id?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={cx('cd-card', className)} data-m="up">
      {title ? (
        <header className="cd-card__head">
          <h3 className="cd-card__title">{title}</h3>
          {action}
        </header>
      ) : null}
      {children}
    </section>
  );
}

/** Two cards side by side (Task status and This week). */
export const DashPair = ({ children }: { children: ReactNode }) => <div className="cd-pair">{children}</div>;

/** The small uppercase label above a group of rows that are not inside a card ("Continue working"). */
export const DashLabel = ({ children }: { children: ReactNode }) => <h3 className="cd-label">{children}</h3>;

/* ------------------------------------------------------------------ Timeline Step / stage tracker */

export type Stage = { state: 'done' | 'doing' | 'next'; when: string; title: string; href?: string };

/** "Completed 12 October" becomes "DONE 12 OCT", "In progress. Due 28 November" "DUE 28 NOV", "Next. Planned for 12 December" "PLANNED 12 DEC". */
export function stageWhen(status: 'Completed' | 'In progress' | 'Next', caption: string): string {
  const m = caption.match(/(\d{1,2})\s+([A-Za-z]{3})/);
  const date = m ? `${m[1]} ${m[2].toUpperCase()}` : '';
  return `${status === 'Completed' ? 'DONE' : status === 'In progress' ? 'DUE' : 'PLANNED'} ${date}`.trim();
}

/** The stage tracker: a marker per stage on one line (done is ink with a tick, current is an amber ring, next is an empty ring), its date and its name. */
export function StageTracker({ stages }: { stages: Stage[] }) {
  return (
    <ol className="cd-stages" style={{ ['--cd-n' as string]: stages.length }}>
      {stages.map((s) => {
        const inner = (
          <>
            <span className="cd-stage__rail">
              <span className={cx('cd-stage__mark', `cd-stage__mark--${s.state}`)} aria-hidden="true">
                {s.state === 'done' ? <CheckIcon size={13} sw={1.6} /> : s.state === 'doing' ? <i /> : null}
              </span>
              <i className="cd-stage__line" aria-hidden="true" />
            </span>
            <span className="cd-stage__when">{s.when}</span>
            <span className="cd-stage__title">{s.title}</span>
          </>
        );
        return (
          <li key={s.title} className="cd-stage" aria-current={s.state === 'doing' ? 'step' : undefined}>
            {s.href ? (
              <Link href={s.href} className="cd-stage__body">
                {inner}
              </Link>
            ) : (
              <div className="cd-stage__body">{inner}</div>
            )}
          </li>
        );
      })}
    </ol>
  );
}

/* ------------------------------------------------------------------ Task status */

export type StatusItem = { label: string; n: number; tone: 'gray' | 'accent' | 'ink' | 'green' };

/** One bar split by the counts, then a legend row per count. */
export function StatusBar({ items }: { items: StatusItem[] }) {
  const total = items.reduce((a, i) => a + i.n, 0) || 1;
  return (
    <div className="cd-status">
      <div className="cd-status__bar" role="img" aria-label={items.map((i) => `${i.label} ${i.n}`).join(', ')}>
        {items.map((i) => (
          <i key={i.label} className={`cd-tone--${i.tone}`} style={{ flexGrow: i.n }} hidden={i.n === 0} />
        ))}
      </div>
      <ul className="cd-status__list">
        {items.map((i) => (
          <li key={i.label}>
            <span className="cd-status__name">
              <i className={cx('cd-status__dot', `cd-tone--${i.tone}`)} aria-hidden="true" />
              {i.label}
            </span>
            <span className="cd-status__n">{i.n}</span>
          </li>
        ))}
      </ul>
      <span className="sr-only">{total} in all</span>
    </div>
  );
}

/* ------------------------------------------------------------------ Activity Card (weekly bars) */

/** Seven bars Monday to Sunday; the amber one is today. A day without anything is a thin line. */
export function WeekBars({ total, caption, bars, today }: { total: number; caption: string; bars: number[]; today: number }) {
  const max = Math.max(...bars, 1);
  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  return (
    <div className="cd-week">
      <p className="cd-week__total">
        <span>{total}</span>
        {caption}
      </p>
      <div className="cd-week__bars" role="img" aria-label={`${caption}: ${bars.join(', ')} from Monday to Sunday`}>
        {bars.map((n, i) => (
          <span className="cd-week__col" key={i}>
            <i className={cx('cd-week__bar', i === today && 'cd-week__bar--today', n === 0 && 'cd-week__bar--zero')} style={n ? { height: `${Math.round((n / max) * 100)}%` } : undefined} />
            <span className="cd-week__day">{days[i]}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Brief at a glance */

export function Glance({ items, link }: { items: { label: string; value: string }[]; link?: ReactNode }) {
  return (
    <>
      <dl className="cd-glance">
        {items.map((f) => (
          <div key={f.label}>
            <dt>{f.label}</dt>
            <dd>{f.value}</dd>
          </div>
        ))}
      </dl>
      {link}
    </>
  );
}

/* ------------------------------------------------------------------ Work Row (slim) */

/** Slim work row: title, status with a dot, and the action at the right. A row with a destination is one link; without one it is plain. */
export function SlimRow({ title, status, action = 'Continue', href }: { title: string; status: string; action?: string; href?: string }) {
  const body = (
    <>
      <span className="cd-row__text">
        <span className="cd-row__title">{title}</span>
        <span className="cd-row__status">
          <Dot size={7} />
          {status}
        </span>
      </span>
      <span className="cd-row__act">
        <span className="cd-row__lbl">{action}</span>
        <ArrowUpRight size={16} />
      </span>
    </>
  );
  return href ? (
    <Link href={href} className="cd-row">
      {body}
    </Link>
  ) : (
    <div className="cd-row cd-row--plain">{body}</div>
  );
}

/* ------------------------------------------------------------------ segment bar and tiles (acknowledgements) */

/** Segment bar of "2 of 4 have acknowledged": one segment per person, filled for those who have. */
export function SegmentBar({ done, total }: { done: number; total: number }) {
  return (
    <div className="cd-seg" role="img" aria-label={`${done} of ${total} acknowledged`}>
      {Array.from({ length: total }, (_, i) => (
        <i key={i} className={i < done ? 'is-done' : undefined} />
      ))}
    </div>
  );
}

/** A person tile with a status dot (Acknowledged or Still needed). */
export function PersonTile({ name, state, note }: { name: string; state: 'done' | 'waiting'; note: string }) {
  return (
    <li className="cd-tile">
      <span className="cd-tile__name">{name}</span>
      <span className="cd-tile__note">
        <Dot tone={state === 'done' ? 'green' : 'accent'} size={7} />
        {note}
      </span>
    </li>
  );
}

/** A "label, then arrow" link line for the end of a dashboard card. */
export function CardArrow({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link href={href} className="cd-arrow">
      <span>{children}</span>
      <ArrowRight />
    </Link>
  );
}
