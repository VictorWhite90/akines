'use client';

import '../workspace/workspace.css';
import '../workspace/conversations/conversations.css';
import './tasks.css';
import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { FileText } from 'lucide-react';
import { useNav } from '@/lib/nav';
import { Button, toast } from '@/ui';
import { PATHS } from '../workspace/data';
import { Av, BackLink, CardLink, Ctx, Over, PageHead, PeopleRows } from '../workspace/parts';
import {
  COMMENT_SEEDS,
  COPY,
  DETAIL,
  EDIT,
  MILESTONES,
  PEOPLE,
  STAGE_STATUS,
  TODAY,
  TP,
  WRITE_ID,
  longDate,
  parseDay,
  type Stage,
  type Status,
  type TaskComment,
} from './data';
import { StatusMenu } from './menus';
import { EditTaskSlideOut, RequestReviewModal, type TaskEdit } from './modals';
import { Box, Popover, PriorityTag, StatusTag, TasksFrame } from './parts';
import { tasksStore, useTasksStore } from './store';

/**
 * 12.14 Tasks: Task detail (17677:149), Task detail / In review (17678:1287), Task detail / Completed (17678:1754), with Modal:Request review,
 * Dropdown:Change status and the Toast:Review requested and Toast:Task completed overlays.
 * The three frames are three stages of one task, "Write the guided onboarding questions", and each stage has its own route. Request review
 * (modal) leads to In review with its toast, Complete task (and Completed in the status menu) leads to Completed with its toast, and a
 * visit to a stage sets the status of the task, so the List, the Board and the Milestone view show it. The toast's Undo goes back one stage.
 * Edit task (all three stages) opens the Edit task slide-out (12.14 Slide-out:Edit task and its Needs attention state): Save changes
 * stores the new title, description, person, due date and milestone in tasks/store.ts, so this screen, the List, the Board and the
 * Milestone view show them (Task detail (updated)), and shows Toast:Task updated. The design jumps to the first stage from every
 * Save changes; here the screen you were on stays, so a task in review or completed keeps its status.
 * Without a destination in the design (shown, they do nothing): Open (files), Reply, Attach file, Link task, Link decision,
 * Change status on In review and Completed, and the Not started option of the status menu.
 */

const TOAST_MS = 2500;
/** The toast of the "state-" frames stays longer so it can be looked at. */
const STATE_TOAST_MS = 8000;

/* ------------------------------------------------------------------ context panel */

function DetailContext({ stage }: { stage: Stage }) {
  const tasks = useTasksStore((s) => s.tasks);
  const task = tasks.find((t) => t.id === WRITE_ID);
  const ms = MILESTONES.find((m) => m.name === task?.milestone) ?? MILESTONES[0];
  // counted from the stage (not from the store) so the first paint already shows the right number
  const total = tasks.filter((t) => t.milestone === ms.name).length;
  const done = tasks.filter((t) => t.milestone === ms.name && t.id !== WRITE_ID && t.status === 'Completed').length + (stage === 'done' ? 1 : 0);
  return (
    <>
      <Ctx label="ON THIS TASK">
        <PeopleRows people={DETAIL.people} />
      </Ctx>
      <Ctx label="RELATED MILESTONE">
        <p className="cw-session__title">{ms.name}</p>
        <p className="cw-ctx__line">{ms.due}</p>
        <p className="cw-ctx__line">
          {done} of {total} tasks done
        </p>
        <CardLink href={ms.href ?? PATHS.milestone} arrow>
          View milestone
        </CardLink>
      </Ctx>
      <Ctx label="RELATED CONVERSATION">
        <p className="cw-ctx__item">{DETAIL.conversation.title}</p>
        <p className="cw-ctx__status">{DETAIL.conversation.line}</p>
        <CardLink href={PATHS.conversations} arrow>
          Open conversation
        </CardLink>
      </Ctx>
    </>
  );
}

/* ------------------------------------------------------------------ comments */

/** Comment (Figma "Comment / <name>", 17972:163437): a 36 px portrait, the name and time on one line and the text under it. The Reply action shows on hover or focus and has no destination in the design. */
function Comment({ c }: { c: TaskComment }) {
  return (
    <li className="tk-msg">
      <Av initials={c.initials} size={36} tone="muted" />
      <div className="tk-msg__body">
        <div className="tk-msg__head">
          <span className="tk-msg__who">
            <span className="tk-msg__name">{c.name}</span>
            <span className="tk-msg__time">{c.time}</span>
          </span>
          <button type="button" className="tk-msg__reply" aria-label={`Reply to ${c.name}`}>
            Reply
          </button>
        </div>
        <p className="tk-msg__text">{c.text}</p>
      </div>
    </li>
  );
}

/** Composer (Figma 17385:14191): the field takes the ink border on focus, Send turns primary once something is typed. */
function Composer({ onSend }: { onSend: (text: string) => void }) {
  const [draft, setDraft] = useState('');
  const field = useRef<HTMLTextAreaElement>(null);
  const filled = draft.trim().length > 0;

  // the field grows with what is typed (92 px at least, as in the design)
  useEffect(() => {
    const el = field.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight + 2}px`;
  }, [draft]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!filled) return;
    onSend(draft.trim());
    setDraft('');
    field.current?.focus();
  };

  return (
    <form className="tk-composer" onSubmit={submit} noValidate>
      <textarea ref={field} className="tk-composer__field" rows={1} value={draft} placeholder="Add a comment." aria-label="Add a comment" onChange={(e) => setDraft(e.target.value)} />
      <div className="tk-composer__actions">
        <div className="tk-composer__refs">
          <CardLink>Attach file</CardLink>
          <CardLink>Link task</CardLink>
          <CardLink>Link decision</CardLink>
        </div>
        <Button type="submit" variant={filled ? 'primary' : 'secondary'} disabled={!filled}>
          Send
        </Button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ the page */

type Props = {
  stage: Stage;
  /** The Modal:Request review frame: the modal is open when the page loads. */
  requestOpen?: boolean;
  /** The Dropdown:Change status frame: the status menu is open when the page loads. */
  menuOpen?: boolean;
  /** The Toast frames: the toast shows when the page loads. */
  toastOnLoad?: 'review' | 'done' | 'updated';
  /** The Slide-out:Edit task frames: the slide-out is open when the page loads (invalid: the Needs attention state with the empty title). */
  editOpen?: 'default' | 'invalid';
  /** The Task detail (updated) frame: the page loads with the Edit task form already saved (the due date of the design, Thursday 12 November). */
  updated?: boolean;
};

function DetailBody({ stage, requestOpen, menuOpen, toastOnLoad, editOpen, updated }: Props) {
  const nav = useNav();
  const tasks = useTasksStore((s) => s.tasks);
  const reviewer = useTasksStore((s) => s.reviewer);
  const task = tasks.find((t) => t.id === WRITE_ID);
  const [met, setMet] = useState<boolean[]>(DETAIL.criteriaMet[stage]);
  const [comments, setComments] = useState<TaskComment[]>(COMMENT_SEEDS[stage]);
  const [modal, setModal] = useState(Boolean(requestOpen));
  const [menu, setMenu] = useState(Boolean(menuOpen));
  const [edit, setEdit] = useState(Boolean(editOpen));
  const status: Status = STAGE_STATUS[stage];

  // a visit to a stage sets the status of the task, so the other views show it
  useEffect(() => {
    tasksStore.setStatus(WRITE_ID, status, TODAY);
  }, [status]);

  // the toast frames
  useEffect(() => {
    if (toastOnLoad === 'review') toast.show({ message: COPY.reviewRequested(reviewer), actionLabel: 'Undo', duration: STATE_TOAST_MS });
    if (toastOnLoad === 'done') toast.show({ message: COPY.completed, actionLabel: 'Undo', duration: STATE_TOAST_MS });
    if (toastOnLoad === 'updated') toast.show({ message: COPY.updated, duration: STATE_TOAST_MS });
    // once, when the page loads
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // the Task detail (updated) frame: the task has the new due date of the design
  useEffect(() => {
    const day = parseDay(EDIT.dueSample);
    if (updated && day !== null) tasksStore.update(WRITE_ID, { day, dueText: undefined });
    // once, when the page loads
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveEdit = (e: TaskEdit) => {
    tasksStore.update(WRITE_ID, e);
    setEdit(false);
    toast.show({ message: COPY.updated, duration: TOAST_MS });
  };

  const completed = (undoTo: string) => {
    nav.push(TP.completed);
    toast.show({ message: COPY.completed, actionLabel: 'Undo', duration: TOAST_MS, onAction: () => nav.push(undoTo) });
  };

  const requestReview = (name: string) => {
    tasksStore.setReviewer(name);
    setModal(false);
    nav.push(TP.inReview);
    toast.show({ message: COPY.reviewRequested(name), actionLabel: 'Undo', duration: TOAST_MS, onAction: () => nav.push(TP.detail) });
  };

  const pickStatus = (s: Status) => {
    // Not started has no destination in the design: it stays in the menu and does nothing
    if (s === 'Not started') return;
    setMenu(false);
    if (s === 'In review') nav.push(TP.inReview);
    else if (s === 'Completed') completed(TP.detail);
  };

  const toggle = (i: number) => setMet((m) => m.map((v, j) => (j === i ? !v : v)));

  const send = (text: string) =>
    setComments((c) => [...c, { id: `sent-${c.length}`, initials: 'KA', name: 'Kemi Adeyemi', time: 'Just now', text }]);

  const notice = useMemo(() => {
    if (stage === 'review') return DETAIL.notice.review(reviewer);
    if (stage === 'done') return DETAIL.notice.done;
    return null;
  }, [stage, reviewer]);

  const changeStatus = (props: Record<string, unknown> = {}) => (
    <Button variant="secondary" {...props}>
      Change status
    </Button>
  );

  return (
    <TasksFrame context={<DetailContext stage={stage} />}>
      <div className="tk-detail">
        <PageHead back={<BackLink href={TP.list}>Back to tasks</BackLink>} label="TASK" title={task?.title ?? 'Write the guided onboarding questions'} lead={task?.description ?? DETAIL.description}>
          {notice ? <p className="tk-notice">{notice}</p> : null}
          <div className="cw-actions cw-actions--btns">
            {stage === 'progress' ? <Button onClick={() => setModal(true)}>Request review</Button> : null}
            {stage === 'review' ? <Button onClick={() => completed(TP.inReview)}>Complete task</Button> : null}
            {stage === 'progress' ? (
              <Popover
                open={menu}
                onClose={() => setMenu(false)}
                trigger={changeStatus({ 'data-tk-trigger': '', 'aria-haspopup': 'menu', 'aria-expanded': menu, onClick: () => setMenu((o) => !o) })}
              >
                <StatusMenu current={status} onPick={pickStatus} />
              </Popover>
            ) : (
              changeStatus()
            )}
            <CardLink onClick={() => setEdit(true)}>Edit task</CardLink>
          </div>
        </PageHead>

        <dl className="tk-details" data-m="up" aria-label="Details">
          <div className="tk-field">
            <dt>RESPONSIBLE</dt>
            <dd>{task ? (PEOPLE.find((p) => p.name === task.owner)?.label ?? task.owner) : DETAIL.responsible}</dd>
          </div>
          <div className="tk-field">
            <dt>SUPPORTING</dt>
            <dd>{DETAIL.supporting}</dd>
          </div>
          <div className="tk-field">
            <dt>DUE DATE</dt>
            <dd>{task ? (task.dueText ?? longDate(task.day)) : DETAIL.due}</dd>
          </div>
          <div className="tk-field">
            <dt>STATUS</dt>
            <dd>
              <StatusTag status={status} />
            </dd>
          </div>
          <div className="tk-field">
            <dt>PRIORITY</dt>
            <dd>
              <PriorityTag priority={task?.priority ?? 'Medium'} />
            </dd>
          </div>
          <div className="tk-field">
            <dt>MILESTONE</dt>
            <dd>{task?.milestone ?? MILESTONES[0].name}</dd>
          </div>
        </dl>

        <section className="tk-sec" data-m="up" aria-label="Completion criteria">
          <Over as="h3">COMPLETION CRITERIA</Over>
          <ul className="tk-crit">
            {DETAIL.criteria.map((c, i) => (
              <li key={c}>
                <button type="button" role="checkbox" aria-checked={met[i]} className="tk-crit__item" onClick={() => toggle(i)}>
                  <Box on={met[i]} />
                  <span>{c}</span>
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="tk-sec" data-m="up" aria-label="Related files">
          <Over as="h3">RELATED FILES</Over>
          <ul className="tk-files">
            {DETAIL.files.map((f) => (
              <li className="tk-file" key={f.name}>
                <span className="tk-file__icon" aria-hidden="true">
                  <FileText size={22} strokeWidth={1.5} focusable="false" />
                </span>
                <span className="tk-file__text">
                  <span className="tk-file__name">{f.name}</span>
                  <span className="tk-file__meta">{f.meta}</span>
                </span>
                {/* Open has no destination in the design */}
                <CardLink>Open</CardLink>
              </li>
            ))}
          </ul>
        </section>

        <section className="tk-sec" data-m="up" aria-label="Comments">
          <Over as="h3">COMMENTS ({comments.length})</Over>
          <div className="tk-thread">
            <ol className="tk-msgs" aria-label="Comments">
              {comments.map((c) => (
                <Comment c={c} key={c.id} />
              ))}
            </ol>
            <Composer onSend={send} />
          </div>
        </section>
      </div>

      <RequestReviewModal open={modal} reviewer={reviewer} onClose={() => setModal(false)} onRequest={requestReview} />
      {task ? <EditTaskSlideOut open={edit} task={task} invalid={editOpen === 'invalid'} onClose={() => setEdit(false)} onSave={saveEdit} /> : null}
    </TasksFrame>
  );
}

/** Outer component: the body starts again for every stage, so criteria and comments take the values of the frame. */
export function TaskDetail(props: Props) {
  return <DetailBody key={props.stage} {...props} />;
}

export const TaskInProgress = () => <TaskDetail stage="progress" />;
export const TaskInReview = () => <TaskDetail stage="review" />;
export const TaskCompleted = () => <TaskDetail stage="done" />;
/** Frame "Modal:Request review": the detail with the modal open. */
export const TaskRequestModal = () => <TaskDetail stage="progress" requestOpen />;
/** Frame "Dropdown:Change status": the detail with the status menu open. */
export const TaskChangeStatus = () => <TaskDetail stage="progress" menuOpen />;
/** Frame "Toast:Review requested": In review with the toast showing. */
export const TaskReviewRequested = () => <TaskDetail stage="review" toastOnLoad="review" />;
/** Frame "Toast:Task completed": Completed with the toast showing. */
export const TaskCompletedToast = () => <TaskDetail stage="done" toastOnLoad="done" />;
/** Frame "Slide-out:Edit task": the detail with the Edit task slide-out open. */
export const TaskEditOpen = () => <TaskDetail stage="progress" editOpen="default" />;
/** Frame "Slide-out:Edit task / Needs attention": the slide-out open with the empty title and its error. */
export const TaskEditInvalid = () => <TaskDetail stage="progress" editOpen="invalid" />;
/** Frames "Task detail (updated)" and "Toast:Task updated": the detail with the saved due date and the toast showing. */
export const TaskUpdated = () => <TaskDetail stage="progress" updated toastOnLoad="updated" />;
