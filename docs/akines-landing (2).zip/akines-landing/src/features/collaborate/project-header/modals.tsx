'use client';

import { useEffect, useId, useState, type FormEvent } from 'react';
import { Button, Field, Modal, TextArea, TextInput, Toggle } from '@/ui';
import { ARCHIVE_MODAL, EDIT_MODAL, LEAVE_MODAL, PREFERENCES_MODAL, type PreferenceKey, type ProjectDetails } from './data';

/**
 * The four modals of the project header (Figma 12.25): Edit project details, Archive project, Leave project,
 * Notification preferences. Same kit Modal as the other workspace modals (640 wide, eyebrow, title, description,
 * a primary button and a text link).
 */

const FooterLink = ({ onClick, children }: { onClick: () => void; children: string }) => (
  <button type="button" className="cw-link ph-link" onClick={onClick}>
    <span className="cw-link__label">{children}</span>
  </button>
);

/* ------------------------------------------------------------------ Edit project details */

export function EditDetailsModal({ open, onClose, details, onSave }: { open: boolean; onClose: () => void; details: ProjectDetails; onSave: (next: ProjectDetails) => void }) {
  const [name, setName] = useState(details.name);
  const [summary, setSummary] = useState(details.summary);
  const [needs, setNeeds] = useState(details.needs);
  const [error, setError] = useState('');
  const form = useId().replace(/:/g, '');

  // every opening starts from the saved details
  useEffect(() => {
    if (open) {
      setName(details.name);
      setSummary(details.summary);
      setNeeds(details.needs);
      setError('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const save = (e?: FormEvent) => {
    e?.preventDefault();
    if (!name.trim()) {
      setError('Give the project a name to continue.');
      return;
    }
    onSave({ name: name.trim(), summary: summary.trim(), needs: needs.trim() });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="ph-modal"
      eyebrow={EDIT_MODAL.eyebrow}
      title={EDIT_MODAL.title}
      description={EDIT_MODAL.description}
      footer={
        <>
          <Button type="submit" form={form}>
            {EDIT_MODAL.save}
          </Button>
          <FooterLink onClick={onClose}>{EDIT_MODAL.cancel}</FooterLink>
        </>
      }
    >
      <form id={form} className="cw-form" onSubmit={save} noValidate>
        <Field label={EDIT_MODAL.name.label} hint={EDIT_MODAL.name.hint} error={error || undefined}>
          <TextInput
            value={name}
            placeholder={details.name}
            onChange={(e) => {
              setName(e.target.value);
              if (error) setError('');
            }}
          />
        </Field>
        <Field label={EDIT_MODAL.summary.label} hint={EDIT_MODAL.summary.hint}>
          <TextArea rows={2} className="cw-ta" value={summary} onChange={(e) => setSummary(e.target.value)} />
        </Field>
        <Field label={EDIT_MODAL.needs.label} hint={EDIT_MODAL.needs.hint}>
          <TextInput value={needs} onChange={(e) => setNeeds(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Archive project and Leave project */

export function ArchiveModal({ open, onClose, name, onConfirm }: { open: boolean; onClose: () => void; name: string; onConfirm: () => void }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="ph-modal"
      eyebrow={ARCHIVE_MODAL.eyebrow}
      title={ARCHIVE_MODAL.title}
      description={ARCHIVE_MODAL.description(name)}
      footer={
        <>
          <Button onClick={onConfirm}>{ARCHIVE_MODAL.confirm}</Button>
          <FooterLink onClick={onClose}>{ARCHIVE_MODAL.keep}</FooterLink>
        </>
      }
    />
  );
}

export function LeaveModal({ open, onClose, onConfirm }: { open: boolean; onClose: () => void; onConfirm: () => void }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="ph-modal"
      eyebrow={LEAVE_MODAL.eyebrow}
      title={LEAVE_MODAL.title}
      description={LEAVE_MODAL.description}
      footer={
        <>
          <Button onClick={onConfirm}>{LEAVE_MODAL.confirm}</Button>
          <FooterLink onClick={onClose}>{LEAVE_MODAL.keep}</FooterLink>
        </>
      }
    />
  );
}

/* ------------------------------------------------------------------ Notification preferences */

export function PreferencesModal({ open, onClose, name, prefs, onSave }: { open: boolean; onClose: () => void; name: string; prefs: Record<PreferenceKey, boolean>; onSave: (next: Record<PreferenceKey, boolean>) => void }) {
  const [draft, setDraft] = useState(prefs);
  const uid = useId().replace(/:/g, '');

  useEffect(() => {
    if (open) setDraft(prefs);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      className="ph-modal"
      eyebrow={PREFERENCES_MODAL.eyebrow}
      title={PREFERENCES_MODAL.title}
      description={PREFERENCES_MODAL.description(name)}
      footer={
        <>
          <Button onClick={() => onSave(draft)}>{PREFERENCES_MODAL.save}</Button>
          <FooterLink onClick={onClose}>{PREFERENCES_MODAL.cancel}</FooterLink>
        </>
      }
    >
      <ul className="ph-prefs">
        {PREFERENCES_MODAL.rows.map((r) => (
          <li className="ph-pref" key={r.key}>
            <label className="ph-pref__text" htmlFor={`${uid}-${r.key}`}>
              <span className="ph-pref__label">{r.label}</span>
              <span className="ph-pref__desc">{r.text}</span>
            </label>
            <Toggle id={`${uid}-${r.key}`} checked={draft[r.key]} onChange={(v) => setDraft((d) => ({ ...d, [r.key]: v }))} aria-label={r.label} />
          </li>
        ))}
      </ul>
    </Modal>
  );
}
