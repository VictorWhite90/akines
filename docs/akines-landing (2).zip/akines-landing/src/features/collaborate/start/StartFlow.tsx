'use client';

/**
 * 12.2 Start a project. One step machine behind /collaborate/start (and the Brief error state route): entry, idea, four purpose
 * questions, progress, people, Workspace recommendation (12.17 Research, 12.18 Digital art; accepted is its own step), preparing,
 * review, ready. Every Figma frame of the journey is one state of this component.
 * The answers start as the dummy project, so pressing Next all the way through completes the flow.
 */
import { useEffect, useRef, useState } from 'react';
import './start.css';
import { useNav } from '@/lib/nav';
import { useMemoState } from '@/lib/hooks';
import { toast } from '@/ui/toast';
import { BriefErrorStep, PreparingStep, ReadyStep, ReviewStep } from './brief';
import {
  ART_ANSWERS,
  DEFAULT_ANSWERS,
  PATHS,
  WORKSPACE_KEY,
  buildBrief,
  followIdea,
  isSample,
  recommendWorkspace,
  type Answers,
  type Brief,
  type BriefId,
  type StepId,
  type SuggestionState,
  type WorkspaceKind,
} from './flow-data';
import { EntryStep, IdeaStep, PeopleStep, QuestionStep, StageStep } from './steps';
import { WorkspaceStep } from './workspace';

/** Figma Toast frames close themselves after 2.5 s. */
const TOAST_MS = 2500;

/**
 * Review brief / Draft removed (Figma 17974:155087): where Undo on the Draft saved toast leads. It is the Review brief page with the answers
 * and the edits the person made (they are kept in memory, so "Your brief is still here") and Toast:Draft removed (17974:155123) over it.
 */
const DRAFT_REMOVED = 'Draft removed from My Projects. Your brief is still here.';

export function StartFlow({ initial = 'entry', draftRemoved = false }: { initial?: StepId; draftRemoved?: boolean }) {
  const nav = useNav();
  const [step, setStep] = useState<StepId>(initial);
  const [answers, setAnswers] = useMemoState<Answers>('cs-answers', DEFAULT_ANSWERS);
  const [edits, setEdits] = useMemoState<Partial<Brief>>('cs-brief-edits', {});
  const [suggestions, setSuggestions] = useState<Record<string, SuggestionState>>({});
  // The accepted Workspace type, shared with the Create AI chat. Starting the flow again clears it.
  const [workspace, setWorkspace] = useMemoState<WorkspaceKind | null>(WORKSPACE_KEY, null);
  const first = useRef(true);

  useEffect(() => {
    if (initial === 'entry') {
      setWorkspace(null);
      // a flow that began on the 12.18 route used the Adire Stories answers: a new flow starts from the first sample again
      setAnswers((a) => (isSample(a, ART_ANSWERS) ? DEFAULT_ANSWERS : a));
    }
    // the 12.18 starting point is the Adire Stories project, so its answers stand in unless the person has typed their own
    if (initial === 'workspace-art' || initial === 'workspace-art-accepted') setAnswers((a) => (isSample(a, DEFAULT_ANSWERS) ? ART_ANSWERS : a));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Review brief / Draft removed: the toast over the page (Undo of Draft saved navigates here, the toast follows the page)
  useEffect(() => {
    if (draftRemoved) toast.show({ message: DRAFT_REMOVED, duration: TOAST_MS });
    // once, when the page loads
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // each step opens at the top with its heading focused (Figma reactions reset the scroll)
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    const h = document.querySelector<HTMLElement>('.cs-step h1');
    h?.focus({ preventScroll: true });
  }, [step]);

  const go = (next: StepId) => {
    // the Workspace recommendation follows the answers: Digital art for visual ideas (12.18), Research otherwise (12.17)
    if (next === 'workspace') next = recommendWorkspace(answers) === 'art' ? 'workspace-art' : 'workspace';
    // the prefilled answers after the idea follow the idea (an art idea brings the Adire Stories answers)
    if (step === 'idea' && next === 'q1') setAnswers(followIdea);
    // a fresh brief is written whenever the preparing step completes
    if (step === 'preparing' && next === 'review') setEdits({});
    if (next === 'preparing') setSuggestions({});
    if (next === 'entry') setWorkspace(null);
    setStep(next);
  };

  const brief: Brief = { ...buildBrief(answers), ...edits };

  const saveDraft = () => {
    nav.push(PATHS.myProjects);
    // Undo leads back to the Review brief page, Draft removed (the brief and its edits are still in memory)
    toast.show({ message: 'Draft saved.', actionLabel: 'Undo', duration: TOAST_MS, onAction: () => nav.push(PATHS.draftRemoved) });
  };
  // the Workspace the person accepted (or the one recommended when they reached the brief another way)
  const kind: WorkspaceKind = workspace ?? recommendWorkspace(answers);
  const saveProject = () => {
    // a saved art project opens the Overview of Adire Stories
    nav.push(kind === 'art' ? PATHS.artProject : PATHS.project);
    toast.show({ message: 'Project saved.', actionLabel: 'Undo', duration: TOAST_MS });
  };

  const props = { answers, setAnswers, go };
  let body;
  switch (step) {
    case 'entry':
      body = <EntryStep go={go} />;
      break;
    case 'idea':
      body = <IdeaStep {...props} />;
      break;
    case 'q1':
    case 'q2':
    case 'q3':
    case 'q4':
      body = <QuestionStep {...props} qid={step} />;
      break;
    case 'stage':
      body = <StageStep {...props} />;
      break;
    case 'people':
      body = <PeopleStep {...props} />;
      break;
    case 'workspace':
    case 'workspace-art':
    case 'workspace-accepted':
    case 'workspace-art-accepted': {
      const wsKind: WorkspaceKind = step === 'workspace' || step === 'workspace-accepted' ? 'research' : 'art';
      const accepted = step === 'workspace-accepted' || step === 'workspace-art-accepted';
      body = (
        <WorkspaceStep
          kind={wsKind}
          accepted={accepted}
          project={brief.name}
          onAccept={() => {
            setWorkspace(wsKind);
            go(wsKind === 'research' ? 'workspace-accepted' : 'workspace-art-accepted');
          }}
          go={go}
        />
      );
      break;
    }
    case 'preparing':
      body = <PreparingStep answers={answers} go={go} />;
      break;
    case 'error':
      body = <BriefErrorStep answers={answers} go={go} />;
      break;
    case 'review':
      body = (
        <ReviewStep
          brief={brief}
          workspace={kind}
          setBrief={(id: BriefId, v: string) => setEdits((e) => ({ ...e, [id]: v }))}
          suggestions={suggestions}
          setSuggestion={(id, s) => setSuggestions((m) => ({ ...m, [id]: s }))}
          go={go}
          onDraft={saveDraft}
        />
      );
      break;
    case 'ready':
      body = <ReadyStep answers={answers} brief={brief} onExplore={() => nav.push(PATHS.matching)} onSave={saveProject} />;
      break;
  }
  return (
    <div className="cs-flow" data-step={step}>
      <div className="cs-step" key={step}>
        {body}
      </div>
    </div>
  );
}

/** 12.2 Brief error (Figma 17214:14484): it has no trigger in the prototype, so it also gets a route of its own. */
export function BriefErrorState() {
  return <StartFlow initial="error" />;
}

/** 12.2 Review brief / Draft removed (Figma 17974:155087) with Toast:Draft removed. Undo of Toast:Draft saved leads here. */
export function DraftRemovedState() {
  return <StartFlow initial="review" draftRemoved />;
}

/** 12.17 Workspace recommendation (Research), Figma starting point 17611:149. */
export function WorkspaceResearchState() {
  return <StartFlow initial="workspace" />;
}

/** 12.18 Workspace recommendation (Digital art), Figma starting point 17611:973. */
export function WorkspaceArtState() {
  return <StartFlow initial="workspace-art" />;
}
