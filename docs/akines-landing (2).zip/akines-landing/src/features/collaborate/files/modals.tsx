'use client';

import { useEffect, useState, type DragEvent, type FormEvent } from 'react';
import { ArrowUp } from 'lucide-react';
import { Button, Field, Modal, TextInput } from '@/ui';
import { CardLink } from '../workspace/parts';
import { TypeTile, useFilesData } from './parts';

/**
 * Modal:Upload file (17730:87292) and Modal:Create document (17730:87379). Both are 640 wide with the eyebrow, headline and support
 * line of the design, Line Fields, and the primary button with a Cancel link. The scrim, the close button and Cancel close the modal.
 * "Filled" fields (ink border) are the ones the design shows with a value.
 */

/** Line Field with a value shows the ink border of the Filled state. */
const filled = (v: string) => (v.trim() ? 'fl-filled' : undefined);

/* ------------------------------------------------------------------ File Drop Area */

/**
 * File Drop Area (17729:99260): Default (dashed), Hover, Pressed, Focus and Chosen. A click on the area chooses the sample file of the
 * design, a click on a chosen file goes back to the empty area. A file dropped on the area counts as a click.
 */
export function DropArea() {
  const { drop: DROP } = useFilesData();
  const [chosen, setChosen] = useState(false);
  const drop = (e: DragEvent) => {
    e.preventDefault();
    setChosen(true);
  };
  const over = (e: DragEvent) => e.preventDefault();

  if (chosen) {
    return (
      <button type="button" className="fl-drop fl-drop--chosen" onClick={() => setChosen(false)} onDragOver={over} onDrop={drop} aria-label={`${DROP.chosen.name}, ${DROP.chosen.meta}. ${DROP.chosen.change}`}>
        <TypeTile icon="text" />
        <span className="fl-drop__text">
          <span className="fl-drop__name">{DROP.chosen.name}</span>
          <span className="fl-drop__meta">{DROP.chosen.meta}</span>
        </span>
        <span className="fl-drop__change">{DROP.chosen.change}</span>
      </button>
    );
  }
  return (
    <button type="button" className="fl-drop" onClick={() => setChosen(true)} onDragOver={over} onDrop={drop}>
      <span className="fl-drop__icon" aria-hidden="true">
        <ArrowUp size={20} strokeWidth={1.5} focusable="false" />
      </span>
      <span className="fl-drop__title">{DROP.title}</span>
      <span className="fl-drop__copy">{DROP.copy}</span>
    </button>
  );
}

/* ------------------------------------------------------------------ Modal: Upload file */

export function UploadModal({ open, onClose, onUpload }: { open: boolean; onClose: () => void; onUpload: () => void }) {
  const { upload: UPLOAD } = useFilesData();
  const [work, setWork] = useState(UPLOAD.work.value);
  const [milestone, setMilestone] = useState(UPLOAD.milestone.value);

  // every opening starts again from the frame: no file chosen, both fields filled
  useEffect(() => {
    if (open) {
      setWork(UPLOAD.work.value);
      setMilestone(UPLOAD.milestone.value);
    }
  }, [open, UPLOAD]);

  const upload = (e?: FormEvent) => {
    e?.preventDefault();
    onUpload();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={UPLOAD.eyebrow}
      title={UPLOAD.title}
      description={UPLOAD.description}
      footer={
        <>
          <Button type="submit" form="fl-upload-form">
            {UPLOAD.cta}
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="fl-upload-form" className="cw-form" onSubmit={upload} noValidate>
        <DropArea />
        <Field label={UPLOAD.work.label} hint={UPLOAD.work.hint}>
          <TextInput className={filled(work)} value={work} onChange={(e) => setWork(e.target.value)} />
        </Field>
        <Field label={UPLOAD.milestone.label} hint={UPLOAD.milestone.hint}>
          <TextInput className={filled(milestone)} value={milestone} onChange={(e) => setMilestone(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ Modal: Create document */

export function CreateDocumentModal({ open, onClose, onCreate }: { open: boolean; onClose: () => void; onCreate: () => void }) {
  const { create: CREATE } = useFilesData();
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(CREATE.category.value);

  // every opening starts again from the frame: the title empty, the category filled
  useEffect(() => {
    if (open) {
      setTitle('');
      setCategory(CREATE.category.value);
    }
  }, [open, CREATE]);

  const create = (e?: FormEvent) => {
    e?.preventDefault();
    onCreate();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={640}
      eyebrow={CREATE.eyebrow}
      title={CREATE.title}
      description={CREATE.description}
      footer={
        <>
          <Button type="submit" form="fl-create-form">
            {CREATE.cta}
          </Button>
          <CardLink onClick={onClose}>Cancel</CardLink>
        </>
      }
    >
      <form id="fl-create-form" className="cw-form" onSubmit={create} noValidate>
        <Field label={CREATE.docTitle.label} hint={CREATE.docTitle.hint}>
          <TextInput className={filled(title)} value={title} placeholder={CREATE.docTitle.placeholder} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label={CREATE.category.label} hint={CREATE.category.hint}>
          <TextInput className={filled(category)} value={category} onChange={(e) => setCategory(e.target.value)} />
        </Field>
      </form>
    </Modal>
  );
}
