'use client';

/**
 * Connect / Discover (PRD "Connect / Discover", Figma section 11).
 * Layout: Feed > Body (flex, gap 40, side padding 64) > Column (984 wide, the four sections stacked 96 apart) + Rail (360, sticky
 * under the pinned app header like the Community Home rail). All geometry is in the first block of discover.css.
 * Sections in order: Explore, For you on Akines, Explore by interest, People whose journeys complement yours.
 * Rail: Your circles and You two would get along (the community feed's components, see DiscoverRail.tsx).
 *
 * `force` opens the page with one For you filter selected (preview routes /connect/filter-*). Without it the filter is All.
 * `state` is one of the three state routes (they open with the filter All):
 *  - loading: Explore, the rail and the page chrome are live; the other three sections show their skeletons (Figma Loading frame:
 *    no visible note, the status is for assistive technology only) and continue to the live sections after LOADING_MS, like the community feed.
 *  - error: People whose journeys complement yours shows the error panel under its heading; "Try again" reloads that section only.
 *  - empty: the empty states of Your circles, You two would get along, Explore by interest and the recommendations.
 */
import '../../community/feed/feed.css';
import './discover.css';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Explore } from './Explore';
import { ForYou } from './ForYou';
import { Interests } from './Interests';
import { Recommendations } from './Recommendations';
import { DiscoverRail } from './DiscoverRail';
import { DiscoverSkeleton } from './states';
import { beginVisit, track } from './analytics';
import { LOADING_MS, SECTION_DOM, type ForYouFilter } from './data';
import { DiscoverEntry, enterDiscover, setFilter } from './state';
import { useReducedMotion } from '@/lib/hooks';

export type DiscoverPageState = 'loading' | 'error' | 'empty';

/** useLayoutEffect warns on the server in older React versions; this runs the same code without the warning there. */
const useIsoLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect;

export function DiscoverPage({ force, state }: { force?: ForYouFilter; state?: DiscoverPageState }) {
  const [settled, setSettled] = useState(state !== 'loading');
  useEffect(() => {
    if (state !== 'loading') return;
    const t = window.setTimeout(() => setSettled(true), LOADING_MS);
    return () => window.clearTimeout(t);
  }, [state]);

  // The filter starts at the route's filter (or All) on every visit; requests, joins and dismissals are kept.
  useIsoLayoutEffect(() => {
    enterDiscover(force);
  }, [force]);

  // discover_page_view, once per visit (the ref also covers React strict mode running the effect twice in development).
  const viewed = useRef(false);
  useEffect(() => {
    if (viewed.current) return;
    viewed.current = true;
    beginVisit();
    track('discover_page_view', { variant: state ?? 'live', filter: force ?? 'all' });
  }, [state, force]);

  // "Find circles" in the empty Your circles card: show the Circles filter of For you on Akines and bring that section into view.
  const reduced = useReducedMotion();
  const findCircles = () => {
    setFilter('circles');
    document.getElementById(SECTION_DOM['for-you'].id)?.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' });
  };

  return (
    <DiscoverEntry.Provider value={force}>
      <div className="fd-page dx-feed" data-discover-state={state}>
        <div className="dx-body">
          <div className="dx-column">
            <Explore />
            {settled ? (
              <>
                <ForYou />
                <Interests empty={state === 'empty'} />
                <Recommendations empty={state === 'empty'} failing={state === 'error'} />
              </>
            ) : (
              <DiscoverSkeleton />
            )}
          </div>
          <DiscoverRail empty={state === 'empty'} onFindCircles={findCircles} />
        </div>
      </div>
    </DiscoverEntry.Provider>
  );
}
